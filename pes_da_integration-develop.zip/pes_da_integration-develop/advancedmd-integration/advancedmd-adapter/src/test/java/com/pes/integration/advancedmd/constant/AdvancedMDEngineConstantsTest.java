package com.pes.integration.advancedmd.constant;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class AdvancedMDEngineConstantsTest {

    @Test
    public void epmNamePrefix_isCorrect() {
        assertEquals("am", AdvancedMDEngineConstants.EPM_NAME_PREFIX);
    }

    @Test
    public void advancedmdConfig_isCorrect() {
        assertEquals("advancedmdprop", AdvancedMDEngineConstants.ADVANCEDMD_CONFIG);
    }

    @Test
    public void dateFormat_isCorrect() {
        assertEquals("MM/dd/yyyy", AdvancedMDEngineConstants.DATE_FORMAT);
    }

    @Test
    public void tokenUrl_isCorrect() {
        assertEquals("token_url", AdvancedMDEngineConstants.TOKEN_URL);
    }

    @Test
    public void oauthVersion_isCorrect() {
        assertEquals("oauth_ver", AdvancedMDEngineConstants.OAUTH_VERSION);
    }

    @Test
    public void blank_isCorrect() {
        assertEquals("", AdvancedMDEngineConstants.BLANK);
    }

    @Test
    public void comma_isCorrect() {
        assertEquals(", ", AdvancedMDEngineConstants.COMMA);
    }

    @Test
    public void auto_isCorrect() {
        assertEquals("AUTO", AdvancedMDEngineConstants.AUTO);
    }

    @Test
    public void n18_isCorrect() {
        assertEquals("18", AdvancedMDEngineConstants.N18);
    }

    @Test
    public void c_isCorrect() {
        assertEquals("C", AdvancedMDEngineConstants.C);
    }

    @Test
    public void retryCount_isCorrect() {
        assertEquals("retrycount", AdvancedMDEngineConstants.RETRY_COUNT);
    }

    @Test
    public void url_isCorrect() {
        assertEquals("url", AdvancedMDEngineConstants.URL);
    }

    @Test
    public void method_isCorrect() {
        assertEquals("method", AdvancedMDEngineConstants.METHOD);
    }

    @Test
    public void class_isCorrect() {
        assertEquals("@class", AdvancedMDEngineConstants.CLASS);
    }

    @Test
    public void name_isCorrect() {
        assertEquals("Name", AdvancedMDEngineConstants.NAME);
    }

    @Test
    public void requestMappingKeyName_isCorrect() {
        assertEquals("am_req_map", AdvancedMDEngineConstants.REQUEST_MAPPING_KEY_NAME);
    }

    @Test
    public void responseMappingKeyName_isCorrect() {
        assertEquals("am_res_map", AdvancedMDEngineConstants.RESPONSE_MAPPING_KEY_NAME);
    }

    @Test
    public void requestConfigKeyName_isCorrect() {
        assertEquals("am_req_conf", AdvancedMDEngineConstants.REQUEST_CONFIG_KEY_NAME);
    }

    @Test
    public void responseCodesMappingKeyName_isCorrect() {
        assertEquals("am_res_codes", AdvancedMDEngineConstants.RESPONSE_CODES_MAPPING_KEY_NAME);
    }

    @Test
    public void endPoint_isCorrect() {
        assertEquals("endpoint", AdvancedMDEngineConstants.END_POINT);
    }

    @Test
    public void epmType_isCorrect() {
        assertEquals("advancedmd", AdvancedMDEngineConstants.EPM_TYPE);
    }

    @Test
    public void epmConfigGroups_isCorrect() {
        assertEquals("RunBaselineSync,Epic Properties,Filter Service Config", AdvancedMDEngineConstants.EPM_CONFIG_GROUPS);
    }

    @Test
    public void columnId_isCorrect() {
        assertEquals("SchedulingData.Provider[0].ColumnId", AdvancedMDEngineConstants.COLUMN_ID);
    }

    @Test
    public void apptEpisodeId_isCorrect() {
        assertEquals("SchedulingData.Provider[0].EpisodeId", AdvancedMDEngineConstants.APPT_EPISODE_ID);
    }

    @Test
    public void episodeId_isCorrect() {
        assertEquals("Episodes[0].EpisodeId", AdvancedMDEngineConstants.EPISODE_ID);
    }

    @Test
    public void view_isCorrect() {
        assertEquals("temp.view", AdvancedMDEngineConstants.VIEW);
    }

    @Test
    public void hippaRelationship_isCorrect() {
        assertEquals("DemographicData.PatientInformation[0].hipaarelationship", AdvancedMDEngineConstants.HIPPA_RELATIONSHIP);
    }

    @Test
    public void chart_isCorrect() {
        assertEquals("DemographicData.PatientInformation[0].chart", AdvancedMDEngineConstants.CHART);
    }

    @Test
    public void otherPhoneType_isCorrect() {
        assertEquals("DemographicData.PatientInformation[0].OtheryPhoneType", AdvancedMDEngineConstants.OTHER_PHONE_TYPE);
    }

    @Test
    public void fname_isCorrect() {
        assertEquals("DemographicData.PatientInformation[0].PatientFirstName", AdvancedMDEngineConstants.FNAME);
    }

    @Test
    public void lname_isCorrect() {
        assertEquals("DemographicData.PatientInformation[0].PatientLastName", AdvancedMDEngineConstants.LNAME);
    }

    @Test
    public void inactive_isCorrect() {
        assertEquals("DemographicData.PatientInformation[0].Inactive", AdvancedMDEngineConstants.INACTIVE);
    }

    @Test
    public void deceased_isCorrect() {
        assertEquals("DemographicData.PatientInformation[0].Deceased", AdvancedMDEngineConstants.DECEASED);
    }

    @Test
    public void provColumnId_isCorrect() {
        assertEquals("ColumnId", AdvancedMDEngineConstants.PROV_COLUMN_ID);
    }

    @Test
    public void apptReasonId_isCorrect() {
        assertEquals("ApptReasonId", AdvancedMDEngineConstants.APPT_REASON_ID);
    }

    @Test
    public void reasonTypeVal_isCorrect() {
        assertEquals("2", AdvancedMDEngineConstants.REASON_TYPE_VAL);
    }

    @Test
    public void columns_isCorrect() {
        assertEquals("Columns", AdvancedMDEngineConstants.COLUMNS);
    }

    @Test
    public void isHoldOnly_isCorrect() {
        assertEquals("is_hold_only", AdvancedMDEngineConstants.IS_HOLD_ONLY);
    }

    @Test
    public void bsSlotInterval_isCorrect() {
        assertEquals("slot_interval", AdvancedMDEngineConstants.BS_SLOT_INTERVAL);
    }

    @Test
    public void ignoreApptNameMatch_isCorrect() {
        assertEquals("ignore_match", AdvancedMDEngineConstants.IGNORE_APPT_NAME_MATCH);
    }

    @Test
    public void holdReasonMap_isCorrect() {
        assertEquals("hold_reason_map", AdvancedMDEngineConstants.HOLD_REASON_MAP);
    }

    @Test
    public void excludeStatusCode_isCorrect() {
        assertEquals("ex_status_code", AdvancedMDEngineConstants.EXCLUDE_STATUS_CODE);
    }

    @Test
    public void isHoldWithGen_isCorrect() {
        assertEquals("is_hold_with_gen", AdvancedMDEngineConstants.IS_HOLD_WITH_GEN);
    }

    @Test
    public void isBlocked_isCorrect() {
        assertEquals("is_blocked", AdvancedMDEngineConstants.IS_BLOCKED);
    }

    @Test
    public void slotId_isCorrect() {
        assertEquals("SchedulingData.Schedule[0].SlotId", AdvancedMDEngineConstants.SLOT_ID);
    }

    @Test
    public void apptTemplateId_isCorrect() {
        assertEquals("SchedulingData.Schedule[0].TemplateId", AdvancedMDEngineConstants.APPT_TEMPLATE_ID);
    }

    @Test
    public void portalId_isCorrect() {
        assertEquals("temp.portalId", AdvancedMDEngineConstants.PORTAL_ID);
    }

    @Test
    public void applicationId_isCorrect() {
        assertEquals("temp.applicationId", AdvancedMDEngineConstants.APPLICATION_ID);
    }

    @Test
    public void disableFlag_isCorrect() {
        assertEquals("temp.portalId", AdvancedMDEngineConstants.DISABLE_FLAG);
    }

    @Test
    public void displayFlag_isCorrect() {
        assertEquals("temp.portalId", AdvancedMDEngineConstants.DISPLAY_FLAG);
    }

    @Test
    public void fullname_isCorrect() {
        assertEquals("temp.fullName", AdvancedMDEngineConstants.FULLNAME);
    }

    @Test
    public void email_isCorrect() {
        assertEquals("temp.Email", AdvancedMDEngineConstants.EMAIL);
    }

    @Test
    public void id_isCorrect() {
        assertEquals("temp.id", AdvancedMDEngineConstants.ID);
    }

    @Test
    public void comment_isCorrect() {
        assertEquals("temp.comment", AdvancedMDEngineConstants.COMMENT);
    }

    @Test
    public void display_isCorrect() {
        assertEquals("temp.display", AdvancedMDEngineConstants.DISPLAY);
    }

    @Test
    public void disable_isCorrect() {
        assertEquals("temp.disable", AdvancedMDEngineConstants.DISABLE);
    }

    @Test
    public void msgTime_isCorrect() {
        assertEquals("temp.msgtime", AdvancedMDEngineConstants.MSG_TIME);
    }

    @Test
    public void appointmentSync_isCorrect() {
        assertEquals("appointment_sync", AdvancedMDEngineConstants.APPOINTMENT_SYNC);
    }

    @Test
    public void page_isCorrect() {
        assertEquals("page", AdvancedMDEngineConstants.PAGE);
    }

    @Test
    public void pageCount_isCorrect() {
        assertEquals("pagecount", AdvancedMDEngineConstants.PAGE_COUNT);
    }

    @Test
    public void effectiveDate_isCorrect() {
        assertEquals("DemographicData.InsuranceInformation[0].EffectiveDate", AdvancedMDEngineConstants.EFFECTIVE_DATE);
    }

    @Test
    public void respPartyId_isCorrect() {
        assertEquals("temp.resPartyId", AdvancedMDEngineConstants.RESP_PARTY_ID);
    }

    @Test
    public void clientLocations_isCorrect() {
        assertEquals("clientlocations", AdvancedMDEngineConstants.CLIENT_LOCATIONS);
    }

    @Test
    public void practiceId_isCorrect() {
        assertEquals("practiceid", AdvancedMDEngineConstants.PRACTICE_ID);
    }

    @Test
    public void genericApptType_isCorrect() {
        assertEquals("genapptype", AdvancedMDEngineConstants.GENERIC_APPT_TYPE);
    }

    @Test
    public void limit_isCorrect() {
        assertEquals("limit", AdvancedMDEngineConstants.LIMIT);
    }

    @Test
    public void useLocalProvider_isCorrect() {
        assertEquals("uselocalprovider", AdvancedMDEngineConstants.USE_LOCAL_PROVIDER);
    }

    @Test
    public void runRealtimeByFilter_isCorrect() {
        assertEquals("realt_by_fil", AdvancedMDEngineConstants.RUN_REALTIME_BY_FILTER);
    }

    @Test
    public void addInsurancesAtBottom_isCorrect() {
        assertEquals("add_to_bottom", AdvancedMDEngineConstants.ADD_INSURANCES_AT_BOTTOM);
    }

    @Test
    public void maxInsurancesAllowed_isCorrect() {
        assertEquals(3, AdvancedMDEngineConstants.MAX_INSURANCES_ALLOWED);
    }

    @Test
    public void athenaConfig_isCorrect() {
        assertEquals("athenaprop", AdvancedMDEngineConstants.ATHENA_CONFIG);
    }

    @Test
    public void guarantorRelations_isCorrect() {
        assertEquals("guarRelation", AdvancedMDEngineConstants.GUARANTOR_RELATIONS);
    }

    @Test
    public void space_isCorrect() {
        assertEquals(" ", AdvancedMDEngineConstants.SPACE);
    }

    @Test
    public void insuranceLogic_isCorrect() {
        assertEquals("inslogic", AdvancedMDEngineConstants.INSURANCE_LOGIC);
    }

    @Test
    public void consentToEmail_isCorrect() {
        assertEquals("consenttoemail", AdvancedMDEngineConstants.CONSENT_TO_EMAIL);
    }

    @Test
    public void consentToText_isCorrect() {
        assertEquals("consenttotext", AdvancedMDEngineConstants.CONSENT_TO_TEXT);
    }

    @Test
    public void errorWithMessage_isCorrect() {
        assertEquals("Error while calling advancedmd api with  Error message:: {} ", AdvancedMDEngineConstants.ERROR_WITH_MESSAGE);
    }

    @Test
    public void successMessage_isCorrect() {
        assertEquals("Successfully fetched data for advancedmd Api for url {} ", AdvancedMDEngineConstants.SUCCESS_MESSAGE);
    }

    @Test
    public void errorWithCode_isCorrect() {
        assertEquals("Error status code while calling advancedmd api is Status code:: {} and errorBody:: {}", AdvancedMDEngineConstants.ERROR_WITH_CODE);
    }

    @Test
    public void configNotSet_isCorrect() {
        assertEquals(" Config not set for deploymentId ", AdvancedMDEngineConstants.CONFIG_NOT_SET);
    }

    @Test
    public void true_isCorrect() {
        assertEquals("true", AdvancedMDEngineConstants.TRUE);
    }
}