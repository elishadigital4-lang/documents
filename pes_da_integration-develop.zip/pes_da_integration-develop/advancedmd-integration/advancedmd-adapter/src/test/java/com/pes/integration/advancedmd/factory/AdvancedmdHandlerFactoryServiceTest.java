package com.pes.integration.advancedmd.factory;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.handlers.BaseHandler;

import java.util.Map;

@ExtendWith(MockitoExtension.class)
public class AdvancedmdHandlerFactoryServiceTest {

    @Mock
    private Map<String, BaseHandler> handlerMap;

    @InjectMocks
    private AdvancedmdHandlerFactoryService advancedmdHandlerFactoryService;

    private HandlerType handlerType;
    private Object inputObject;
    private Object outputObject;
    private BaseHandler baseHandler;

    @BeforeEach
    public void setUp() {
        handlerType = Mockito.mock(HandlerType.class);
        inputObject = new Object();
        outputObject = new Object();
        baseHandler = mock(BaseHandler.class);
    }


    @Test
    public void create_returnsNull_whenHandlerTypeIsNull() {
        BaseHandler result = advancedmdHandlerFactoryService.create(handlerType, inputObject, outputObject);

        assertNull(result);
    }
}