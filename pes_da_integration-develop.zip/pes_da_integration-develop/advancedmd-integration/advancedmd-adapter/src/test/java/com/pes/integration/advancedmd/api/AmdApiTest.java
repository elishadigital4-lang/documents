package com.pes.integration.advancedmd.api;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class AmdApiTest {

    @Test
    void constructor_initializesFieldsCorrectly() {
        AmdApi amdApi = new AmdApi("loginUrl", "userId", "password", "officeCode", "appName", "endpoint", "deploymentId");

        assertEquals("loginUrl", amdApi.getLoginUrl());
        assertEquals("userId", amdApi.getUserId());
        assertEquals("password", amdApi.getPassword());
        assertEquals("officeCode", amdApi.getOfficeCode());
        assertEquals("appName", amdApi.getAppName());
        assertEquals("endpoint", amdApi.getEndpoint());
        assertEquals("deploymentId", amdApi.getDeploymentId());
    }

    @Test
    void noArgsConstructor_initializesFieldsToNull() {
        AmdApi amdApi = new AmdApi();

        assertNull(amdApi.getLoginUrl());
        assertNull(amdApi.getUserId());
        assertNull(amdApi.getPassword());
        assertNull(amdApi.getOfficeCode());
        assertNull(amdApi.getAppName());
        assertNull(amdApi.getEndpoint());
        assertNull(amdApi.getDeploymentId());
    }

    @Test
    void setters_updateFieldsCorrectly() {
        AmdApi amdApi = new AmdApi();
        amdApi.setLoginUrl("newLoginUrl");
        amdApi.setUserId("newUserId");
        amdApi.setPassword("newPassword");
        amdApi.setOfficeCode("newOfficeCode");
        amdApi.setAppName("newAppName");
        amdApi.setEndpoint("newEndpoint");
        amdApi.setDeploymentId("newDeploymentId");

        assertEquals("newLoginUrl", amdApi.getLoginUrl());
        assertEquals("newUserId", amdApi.getUserId());
        assertEquals("newPassword", amdApi.getPassword());
        assertEquals("newOfficeCode", amdApi.getOfficeCode());
        assertEquals("newAppName", amdApi.getAppName());
        assertEquals("newEndpoint", amdApi.getEndpoint());
        assertEquals("newDeploymentId", amdApi.getDeploymentId());
    }
}