package com.pes.integration.advancedmd.component;

import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.function.Function;

import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.utils.MetricsUtil.metricClientRequestCount;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdvancedmdClientCallerTest {

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @InjectMocks
    private AdvancedmdClientCaller advancedmdClientCaller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(advancedmdClientCaller, "webClient", webClient);
        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    }

    @Test
    void getRedirectURL_returnsCorrectResponse() {
        String expectedResponse = "redirectUrl";
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just(expectedResponse));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String result = advancedmdClientCaller.getRedirectURL("GET", "http://example.com", "{}", "componentId");

            assertEquals(expectedResponse, result);
        }
    }

    @Test
    void getRedirectURL_throwsIHubExceptionOnError() {
        String errorBody = "Error occurred";
        lenient().when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<Throwable>> errorFunction = invocation.getArgument(1);
            ClientResponse clientResponse = mock(ClientResponse.class);
            lenient().when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
            lenient().when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
            return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(),
                    errorBody));
        });
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Exception exception = assertThrows(Exception.class, () -> {
                advancedmdClientCaller.getRedirectURL("GET", "http://example.com", "{}", "componentId");
            });

        }
    }

    @Test
    void getPostData_returnsCorrectResponse() {
        String expectedResponse = "postData";
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just(expectedResponse));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String result = advancedmdClientCaller.getPostData("POST", "http://example.com", "{}", "token");

            assertEquals(expectedResponse, result);
        }
    }

    @Test
    void getPostData_throwsIHubExceptionOnError() {
        String errorBody = "Error occurred";
        lenient().when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<Throwable>> errorFunction = invocation.getArgument(1);
            ClientResponse clientResponse = mock(ClientResponse.class);
            lenient().when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
            lenient().when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
            return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(),
                    errorBody));
        });
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Exception exception = assertThrows(Exception.class, () -> {
                advancedmdClientCaller.getPostData("POST", "http://example.com", "{}", "token");
            });

        }
    }

    @Test
    void getData_returnsCorrectResponse() {
        String expectedResponse = "data";
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just(expectedResponse));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String result = advancedmdClientCaller.getData("GET", "http://example.com", "{}", "token");

            assertEquals(expectedResponse, result);
        }
    }

    @Test
    void getData_throwsIHubExceptionOnError() {
        String errorBody = "Error occurred";
        lenient().when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<Throwable>> errorFunction = invocation.getArgument(1);
            ClientResponse clientResponse = mock(ClientResponse.class);
            lenient().when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
            lenient().when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
            return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(),
                    errorBody));
        });
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(),anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Exception exception = assertThrows(Exception.class, () -> {
                advancedmdClientCaller.getData("GET", "http://example.com", "{}", "token");
            });

        }
    }

    @Test
    void getRedirectURL_onStatusError_shouldLogAndThrowIHubException() {
        String errorBody = "Some error";
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;

        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            java.util.function.Predicate<HttpStatus> predicate = invocation.getArgument(0);
            java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
            if (predicate.test(HttpStatus.INTERNAL_SERVER_ERROR)) {
                ClientResponse clientResponse = mock(ClientResponse.class);
                when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
                when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
                Mono<? extends Throwable> errorMono = function.apply(clientResponse);
                throw errorMono.block();
            }
            // Simulate the error function
            return responseSpec;
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            assertThrows(IHubException.class, () -> {
                try {
                    advancedmdClientCaller.getRedirectURL("GET", "http://example.com", "{}", "componentId");
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof IHubException) {
                        throw (IHubException) cause;
                    }
                    throw e;
                }
            });
        }
    }

    @Test
    void getPostData_onStatusError_shouldLogAndThrowIHubException() {
        String errorBody = "Some error";

        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            java.util.function.Predicate<HttpStatus> predicate = invocation.getArgument(0);
            java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
            if (predicate.test(HttpStatus.INTERNAL_SERVER_ERROR)) {
                ClientResponse clientResponse = mock(ClientResponse.class);
                when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
                when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
                Mono<? extends Throwable> errorMono = function.apply(clientResponse);
                throw errorMono.block();
            }
            // Simulate the error function
            return responseSpec;
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            assertThrows(IHubException.class, () -> {
                try {
                    advancedmdClientCaller.getPostData("POST", "http://example.com", "{}", "token");
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof IHubException) {
                        throw (IHubException) cause;
                    }
                    throw e;
                }
            });
        }
    }

    @Test
    void getData_onStatusError_shouldLogAndThrowIHubException() {
        String errorBody = "Some error";

        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            java.util.function.Predicate<HttpStatus> predicate = invocation.getArgument(0);
            java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
            if (predicate.test(HttpStatus.BAD_REQUEST)) {
                ClientResponse clientResponse = mock(ClientResponse.class);
                when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
                when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
                Mono<? extends Throwable> errorMono = function.apply(clientResponse);
                throw errorMono.block();
            }
            // Simulate the error function
            return responseSpec;
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            assertThrows(IHubException.class, () -> {
                try {
                    advancedmdClientCaller.getData("POST", "http://example.com", "{}", "token");
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof IHubException) {
                        throw (IHubException) cause;
                    }
                    throw e;
                }
            });
        }
    }
}