package com.pes.integration.advancedmd.constant;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class AdvancedMDLanguageCodeTest {

    @Test
    public void getKey_returnsCorrectKey() {
        assertEquals(0, AdvancedMDLanguageCode.UNKNOWN.getKey());
        assertEquals(1, AdvancedMDLanguageCode.ABKHAZIAN.getKey());
        assertEquals(2, AdvancedMDLanguageCode.AFAR.getKey());
        assertEquals(3, AdvancedMDLanguageCode.AFRIKAANS.getKey());
        assertEquals(4, AdvancedMDLanguageCode.AKAN.getKey());
        assertEquals(5, AdvancedMDLanguageCode.ALBANIAN.getKey());
        assertEquals(6, AdvancedMDLanguageCode.AMHARIC.getKey());
        assertEquals(7, AdvancedMDLanguageCode.ARABIC.getKey());
        assertEquals(8, AdvancedMDLanguageCode.ARAGONESE.getKey());
        assertEquals(9, AdvancedMDLanguageCode.ARMENIAN.getKey());
        assertEquals(10, AdvancedMDLanguageCode.ASSAMESE.getKey());
        assertEquals(11, AdvancedMDLanguageCode.AVARIC.getKey());
        assertEquals(12, AdvancedMDLanguageCode.AVESTAN.getKey());
        assertEquals(13, AdvancedMDLanguageCode.AYMARA.getKey());
        assertEquals(14, AdvancedMDLanguageCode.AZERBAIJANI.getKey());
        assertEquals(15, AdvancedMDLanguageCode.BAMBARA.getKey());
        assertEquals(16, AdvancedMDLanguageCode.BASHKIR.getKey());
        assertEquals(17, AdvancedMDLanguageCode.BASQUE.getKey());
        assertEquals(18, AdvancedMDLanguageCode.BELARUSIAN.getKey());
        assertEquals(19, AdvancedMDLanguageCode.BENGALI.getKey());
        assertEquals(21, AdvancedMDLanguageCode.BISLAMA.getKey());
        assertEquals(23, AdvancedMDLanguageCode.BOSNIAN.getKey());
        assertEquals(24, AdvancedMDLanguageCode.BRETON.getKey());
        assertEquals(25, AdvancedMDLanguageCode.BULGARIAN.getKey());
        assertEquals(26, AdvancedMDLanguageCode.BURMESE.getKey());
        assertEquals(27, AdvancedMDLanguageCode.CATALAN.getKey());
        assertEquals(29, AdvancedMDLanguageCode.CHAMORRO.getKey());
        assertEquals(30, AdvancedMDLanguageCode.CHECHEN.getKey());
        assertEquals(31, AdvancedMDLanguageCode.CHICHEWA.getKey());
        assertEquals(32, AdvancedMDLanguageCode.CHINESE.getKey());
        assertEquals(34, AdvancedMDLanguageCode.CHUVASH.getKey());
        assertEquals(35, AdvancedMDLanguageCode.CORNISH.getKey());
        assertEquals(36, AdvancedMDLanguageCode.CORSICAN.getKey());
        assertEquals(37, AdvancedMDLanguageCode.CREE.getKey());
        assertEquals(38, AdvancedMDLanguageCode.CROATIAN.getKey());
        assertEquals(39, AdvancedMDLanguageCode.CZECH.getKey());
        assertEquals(40, AdvancedMDLanguageCode.DANISH.getKey());
        assertEquals(186, AdvancedMDLanguageCode.DECLINED_TO_SPECIFY.getKey());
        assertEquals(42, AdvancedMDLanguageCode.DUTCH.getKey());
        assertEquals(41, AdvancedMDLanguageCode.DIVEHI.getKey());
        assertEquals(43, AdvancedMDLanguageCode.DZONGKHA.getKey());
        assertEquals(44, AdvancedMDLanguageCode.ENGLISH.getKey());
        assertEquals(45, AdvancedMDLanguageCode.ESPERANTO.getKey());
        assertEquals(46, AdvancedMDLanguageCode.ESTONIAN.getKey());
        assertEquals(48, AdvancedMDLanguageCode.FAROESE.getKey());
        assertEquals(49, AdvancedMDLanguageCode.FIJIAN.getKey());
        assertEquals(47, AdvancedMDLanguageCode.EWE.getKey());
        assertEquals(50, AdvancedMDLanguageCode.FINNISH.getKey());
        assertEquals(51, AdvancedMDLanguageCode.FRENCH.getKey());
        assertEquals(52, AdvancedMDLanguageCode.FULAH.getKey());
        assertEquals(53, AdvancedMDLanguageCode.GAELIC.getKey());
        assertEquals(54, AdvancedMDLanguageCode.GALICIAN.getKey());
        assertEquals(55, AdvancedMDLanguageCode.GANDA.getKey());
        assertEquals(56, AdvancedMDLanguageCode.GEORGIAN.getKey());
        assertEquals(57, AdvancedMDLanguageCode.GERMAN.getKey());
        assertEquals(59, AdvancedMDLanguageCode.GUARANI.getKey());
        assertEquals(60, AdvancedMDLanguageCode.GUJARATI.getKey());
        assertEquals(61, AdvancedMDLanguageCode.HAITIAN.getKey());
        assertEquals(62, AdvancedMDLanguageCode.HAUSA.getKey());
        assertEquals(63, AdvancedMDLanguageCode.HEBREW.getKey());
        assertEquals(64, AdvancedMDLanguageCode.HERERO.getKey());
        assertEquals(65, AdvancedMDLanguageCode.HINDI.getKey());
        assertEquals(187, AdvancedMDLanguageCode.HMONG.getKey());
        assertEquals(67, AdvancedMDLanguageCode.HUNGARIAN.getKey());
        assertEquals(68, AdvancedMDLanguageCode.ICELANDIC.getKey());
        assertEquals(69, AdvancedMDLanguageCode.IDO.getKey());
        assertEquals(70, AdvancedMDLanguageCode.IGBO.getKey());
        assertEquals(71, AdvancedMDLanguageCode.INDONESIAN.getKey());
        assertEquals(72, AdvancedMDLanguageCode.INTERLINGUA.getKey());
        assertEquals(73, AdvancedMDLanguageCode.INTERLINGUE.getKey());
        assertEquals(74, AdvancedMDLanguageCode.INUKTITUT.getKey());
        assertEquals(75, AdvancedMDLanguageCode.INUPIAQ.getKey());
        assertEquals(76, AdvancedMDLanguageCode.IRISH.getKey());
        assertEquals(77, AdvancedMDLanguageCode.ITALIAN.getKey());
        assertEquals(78, AdvancedMDLanguageCode.JAPANESE.getKey());
        assertEquals(149, AdvancedMDLanguageCode.SPANISH.getKey());
    }

    @Test
    public void getEnum_returnsCorrectEnum_whenKeyExists() {
        assertEquals(AdvancedMDLanguageCode.UNKNOWN, AdvancedMDLanguageCode.getEnum(0));
        assertEquals(AdvancedMDLanguageCode.ABKHAZIAN, AdvancedMDLanguageCode.getEnum(1));
        assertEquals(AdvancedMDLanguageCode.AFAR, AdvancedMDLanguageCode.getEnum(2));
        assertEquals(AdvancedMDLanguageCode.AFRIKAANS, AdvancedMDLanguageCode.getEnum(3));
        assertEquals(AdvancedMDLanguageCode.AKAN, AdvancedMDLanguageCode.getEnum(4));
        assertEquals(AdvancedMDLanguageCode.ALBANIAN, AdvancedMDLanguageCode.getEnum(5));
        assertEquals(AdvancedMDLanguageCode.AMHARIC, AdvancedMDLanguageCode.getEnum(6));
        assertEquals(AdvancedMDLanguageCode.ARABIC, AdvancedMDLanguageCode.getEnum(7));
        assertEquals(AdvancedMDLanguageCode.ARAGONESE, AdvancedMDLanguageCode.getEnum(8));
        assertEquals(AdvancedMDLanguageCode.ARMENIAN, AdvancedMDLanguageCode.getEnum(9));
        assertEquals(AdvancedMDLanguageCode.ASSAMESE, AdvancedMDLanguageCode.getEnum(10));
        assertEquals(AdvancedMDLanguageCode.AVARIC, AdvancedMDLanguageCode.getEnum(11));
        assertEquals(AdvancedMDLanguageCode.AVESTAN, AdvancedMDLanguageCode.getEnum(12));
        assertEquals(AdvancedMDLanguageCode.AYMARA, AdvancedMDLanguageCode.getEnum(13));
        assertEquals(AdvancedMDLanguageCode.AZERBAIJANI, AdvancedMDLanguageCode.getEnum(14));
        assertEquals(AdvancedMDLanguageCode.BAMBARA, AdvancedMDLanguageCode.getEnum(15));
        assertEquals(AdvancedMDLanguageCode.BASHKIR, AdvancedMDLanguageCode.getEnum(16));
        assertEquals(AdvancedMDLanguageCode.BASQUE, AdvancedMDLanguageCode.getEnum(17));
        assertEquals(AdvancedMDLanguageCode.BELARUSIAN, AdvancedMDLanguageCode.getEnum(18));
        assertEquals(AdvancedMDLanguageCode.BENGALI, AdvancedMDLanguageCode.getEnum(19));
        assertEquals(AdvancedMDLanguageCode.BISLAMA, AdvancedMDLanguageCode.getEnum(21));
        assertEquals(AdvancedMDLanguageCode.BOSNIAN, AdvancedMDLanguageCode.getEnum(23));
        assertEquals(AdvancedMDLanguageCode.BRETON, AdvancedMDLanguageCode.getEnum(24));
        assertEquals(AdvancedMDLanguageCode.BULGARIAN, AdvancedMDLanguageCode.getEnum(25));
        assertEquals(AdvancedMDLanguageCode.BURMESE, AdvancedMDLanguageCode.getEnum(26));
        assertEquals(AdvancedMDLanguageCode.CATALAN, AdvancedMDLanguageCode.getEnum(27));
        assertEquals(AdvancedMDLanguageCode.CHAMORRO, AdvancedMDLanguageCode.getEnum(29));
        assertEquals(AdvancedMDLanguageCode.CHECHEN, AdvancedMDLanguageCode.getEnum(30));
        assertEquals(AdvancedMDLanguageCode.CHICHEWA, AdvancedMDLanguageCode.getEnum(31));
        assertEquals(AdvancedMDLanguageCode.CHINESE, AdvancedMDLanguageCode.getEnum(32));
        assertEquals(AdvancedMDLanguageCode.CHUVASH, AdvancedMDLanguageCode.getEnum(34));
        assertEquals(AdvancedMDLanguageCode.CORNISH, AdvancedMDLanguageCode.getEnum(35));
        assertEquals(AdvancedMDLanguageCode.CORSICAN, AdvancedMDLanguageCode.getEnum(36));
        assertEquals(AdvancedMDLanguageCode.CREE, AdvancedMDLanguageCode.getEnum(37));
        assertEquals(AdvancedMDLanguageCode.CROATIAN, AdvancedMDLanguageCode.getEnum(38));
        assertEquals(AdvancedMDLanguageCode.CZECH, AdvancedMDLanguageCode.getEnum(39));
        assertEquals(AdvancedMDLanguageCode.DANISH, AdvancedMDLanguageCode.getEnum(40));
        assertEquals(AdvancedMDLanguageCode.DECLINED_TO_SPECIFY, AdvancedMDLanguageCode.getEnum(186));
        assertEquals(AdvancedMDLanguageCode.DUTCH, AdvancedMDLanguageCode.getEnum(42));
        assertEquals(AdvancedMDLanguageCode.DIVEHI, AdvancedMDLanguageCode.getEnum(41));
        assertEquals(AdvancedMDLanguageCode.DZONGKHA, AdvancedMDLanguageCode.getEnum(43));
        assertEquals(AdvancedMDLanguageCode.ENGLISH, AdvancedMDLanguageCode.getEnum(44));
        assertEquals(AdvancedMDLanguageCode.ESPERANTO, AdvancedMDLanguageCode.getEnum(45));
        assertEquals(AdvancedMDLanguageCode.ESTONIAN, AdvancedMDLanguageCode.getEnum(46));
        assertEquals(AdvancedMDLanguageCode.FAROESE, AdvancedMDLanguageCode.getEnum(48));
        assertEquals(AdvancedMDLanguageCode.FIJIAN, AdvancedMDLanguageCode.getEnum(49));
        assertEquals(AdvancedMDLanguageCode.EWE, AdvancedMDLanguageCode.getEnum(47));
        assertEquals(AdvancedMDLanguageCode.FINNISH, AdvancedMDLanguageCode.getEnum(50));
        assertEquals(AdvancedMDLanguageCode.FRENCH, AdvancedMDLanguageCode.getEnum(51));
        assertEquals(AdvancedMDLanguageCode.FULAH, AdvancedMDLanguageCode.getEnum(52));
        assertEquals(AdvancedMDLanguageCode.GAELIC, AdvancedMDLanguageCode.getEnum(53));
        assertEquals(AdvancedMDLanguageCode.GALICIAN, AdvancedMDLanguageCode.getEnum(54));
        assertEquals(AdvancedMDLanguageCode.GANDA, AdvancedMDLanguageCode.getEnum(55));
        assertEquals(AdvancedMDLanguageCode.GEORGIAN, AdvancedMDLanguageCode.getEnum(56));
        assertEquals(AdvancedMDLanguageCode.GERMAN, AdvancedMDLanguageCode.getEnum(57));
        assertEquals(AdvancedMDLanguageCode.GUARANI, AdvancedMDLanguageCode.getEnum(59));
        assertEquals(AdvancedMDLanguageCode.GUJARATI, AdvancedMDLanguageCode.getEnum(60));
        assertEquals(AdvancedMDLanguageCode.HAITIAN, AdvancedMDLanguageCode.getEnum(61));
        assertEquals(AdvancedMDLanguageCode.HAUSA, AdvancedMDLanguageCode.getEnum(62));
        assertEquals(AdvancedMDLanguageCode.HEBREW, AdvancedMDLanguageCode.getEnum(63));
        assertEquals(AdvancedMDLanguageCode.HERERO, AdvancedMDLanguageCode.getEnum(64));
        assertEquals(AdvancedMDLanguageCode.HINDI, AdvancedMDLanguageCode.getEnum(65));
        assertEquals(AdvancedMDLanguageCode.HMONG, AdvancedMDLanguageCode.getEnum(187));
        assertEquals(AdvancedMDLanguageCode.HUNGARIAN, AdvancedMDLanguageCode.getEnum(67));
        assertEquals(AdvancedMDLanguageCode.ICELANDIC, AdvancedMDLanguageCode.getEnum(68));
        assertEquals(AdvancedMDLanguageCode.IDO, AdvancedMDLanguageCode.getEnum(69));
        assertEquals(AdvancedMDLanguageCode.IGBO, AdvancedMDLanguageCode.getEnum(70));
        assertEquals(AdvancedMDLanguageCode.INDONESIAN, AdvancedMDLanguageCode.getEnum(71));
        assertEquals(AdvancedMDLanguageCode.INTERLINGUA, AdvancedMDLanguageCode.getEnum(72));
        assertEquals(AdvancedMDLanguageCode.INTERLINGUE, AdvancedMDLanguageCode.getEnum(73));
        assertEquals(AdvancedMDLanguageCode.INUKTITUT, AdvancedMDLanguageCode.getEnum(74));
        assertEquals(AdvancedMDLanguageCode.INUPIAQ, AdvancedMDLanguageCode.getEnum(75));
        assertEquals(AdvancedMDLanguageCode.IRISH, AdvancedMDLanguageCode.getEnum(76));
        assertEquals(AdvancedMDLanguageCode.ITALIAN, AdvancedMDLanguageCode.getEnum(77));
        assertEquals(AdvancedMDLanguageCode.JAPANESE, AdvancedMDLanguageCode.getEnum(78));
        assertEquals(AdvancedMDLanguageCode.SPANISH, AdvancedMDLanguageCode.getEnum(149));
    }

    @Test
    public void getEnum_returnsNull_whenKeyDoesNotExist() {
        assertNull(AdvancedMDLanguageCode.getEnum(-1));
        assertNull(AdvancedMDLanguageCode.getEnum(1000));
    }

    @Test
    public void getEnum_handlesEdgeCases() {
        assertNull(AdvancedMDLanguageCode.getEnum(Integer.MAX_VALUE));
        assertNull(AdvancedMDLanguageCode.getEnum(Integer.MIN_VALUE));
    }
}