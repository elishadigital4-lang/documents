package com.pes.integration.advancedmd.api;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ApiNameTest {

    @Test
    public void getKey_returnsCorrectKey() {
        ApiName apiName = ApiName.NEW_PATIENT;
        assertEquals("new_patient", apiName.getKey());
    }

    @Test
    public void getEnum_returnsCorrectEnum_whenKeyExists() {
        ApiName apiName = ApiName.NEW_PATIENT.getEnum("new_patient");
        assertEquals(ApiName.NEW_PATIENT, apiName);
    }

    @Test
    public void getEnum_returnsNull_whenKeyDoesNotExist() {
        ApiName apiName = ApiName.NEW_PATIENT.getEnum("non_existent_key");
        assertNull(apiName);
    }

    @Test
    public void getEnum_isCaseSensitive() {
        ApiName apiName = ApiName.NEW_PATIENT.getEnum("New_Patient");
        assertNull(apiName);
    }

    @Test
    public void getKey_returnsCorrectKey_forAllEnums() {
        assertEquals("new_patient", ApiName.NEW_PATIENT.getKey());
        assertEquals("get_patient_demographics", ApiName.GET_PATIENT_DEMOGRAPHICS.getKey());
        assertEquals("get_patient_insurance", ApiName.GET_PATIENT_INSURANCE.getKey());
        assertEquals("changed_patients", ApiName.CHANGED_PATIENTS.getKey());
        assertEquals("cancel_appointment", ApiName.CANCEL_APPOINTMENT.getKey());
        assertEquals("booked_appointments", ApiName.BOOKED_APPOINTMENTS.getKey());
        assertEquals("open_appointments", ApiName.OPEN_APPOINTMENTS.getKey());
        assertEquals("new_appointment", ApiName.NEW_APPOINTMENT.getKey());
        assertEquals("get_columns", ApiName.GET_COLUMNS.getKey());
        assertEquals("patient_search", ApiName.GET_PATIENT.getKey());
        assertEquals("get_locations", ApiName.GET_LOCATIONS.getKey());
        assertEquals("get_providers", ApiName.GET_PROVIDERS.getKey());
        assertEquals("get_provider_schedule", ApiName.GET_PROVIDER_SCHEDULE.getKey());
        assertEquals("hold_appointments", ApiName.HOLD_APPOINTMENTS.getKey());
        assertEquals("changed_appointments", ApiName.CHANGED_APPOINTMENTS.getKey());
        assertEquals("patient_lookup", ApiName.GET_PATIENTS.getKey());
        assertEquals("get_appointment", ApiName.GET_APPOINTMENT.getKey());
        assertEquals("get_episodes", ApiName.GET_EPISODES.getKey());
        assertEquals("set_patient_insurance", ApiName.SET_PATIENT_INSURANCE.getKey());
        assertEquals("get_appointment_types", ApiName.GET_APPOINTMENT_TYPES.getKey());
        assertEquals("update_patient", ApiName.UPDATE_PATIENT.getKey());
        assertEquals("freeze_appointment", ApiName.FREEZE_APPOINTMENT.getKey());
        assertEquals("get_appointment_cancel_reasons", ApiName.GET_APPOINTMENT_CANCEL_REASONS.getKey());
        assertEquals("get_patient_visit_reasons", ApiName.GET_PATIENT_VISIT_REASONS.getKey());
        assertEquals("verify_patient_privacy_information", ApiName.VERIFY_PATIENT_PRIVACY_INFORMATION.getKey());
        assertEquals("add_custom_fields", ApiName.ADD_CUSTOM_FIELDS.getKey());
        assertEquals("update_appointment_checkin", ApiName.UPDATE_APPOINTMENT_CHECKIN.getKey());
        assertEquals("check_if_patient_registered", ApiName.CHECK_IF_PATIENT_REGISTERED.getKey());
        assertEquals("register_patient_with_department", ApiName.REGISTER_PATIENT_DPPT.getKey());
        assertEquals("is_patient_insured", ApiName.CHECK_IF_PATIENT_INSURED.getKey());
        assertEquals("get_payments", ApiName.GET_PAYMENTS.getKey());
        assertEquals("move_appointment", ApiName.MOVE_APPOINTMENT.getKey());
        assertEquals("auto_assign_forms", ApiName.AUTO_ASSIGN_FORMS.getKey());
        assertEquals("lookup_patient_portal_account", ApiName.LOOKUP_PORTAL_ACCOUNT.getKey());
        assertEquals("send_invitation", ApiName.SEND_INVITATION.getKey());
        assertEquals("save_patient_portal_account", ApiName.SAVE_PORTAL_ACCOUNT.getKey());
        assertEquals("reschedule_appointment", ApiName.RESCHEDULE_APPOINTMENT.getKey());
    }
}