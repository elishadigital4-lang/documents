package com.pes.integration.advancedmd.component;

import static com.pes.integration.constant.UtilitiesConstants.LOCATION_ID;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pes.integration.config.data.DataCacheManager;

import java.util.List;

@ExtendWith(MockitoExtension.class)
public class EPMFilterTest {

    @Mock
    private DataCacheManager dataCacheManager;

    @InjectMocks
    private EPMFilter epmFilter;

    private String deploymentId;

    @BeforeEach
    public void setUp() {
        deploymentId = "testDeploymentId";
    }

    @Test
    public void getAllowedLocations_returnsLocations_whenFilterArrayHasLocations() throws IHubException {
        JSONArray filterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(LOCATION_ID, "location1");
        filterArray.put(filterObject);
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(filterArray);

        List<String> result = epmFilter.getAllowedLocations(deploymentId);

        assertEquals(1, result.size());
        assertEquals("location1", result.get(0));
    }

    @Test
    public void getAllowedLocations_returnsEmptyList_whenFilterArrayIsEmpty() throws IHubException {
        JSONArray filterArray = new JSONArray();
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(filterArray);

        List<String> result = epmFilter.getAllowedLocations(deploymentId);

        assertTrue(result.isEmpty());
    }

    @Test
    public void getAllowedLocations_returnsEmptyList_whenFilterArrayHasNoLocations() throws IHubException {
        JSONArray filterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterArray.put(filterObject);
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(filterArray);

        List<String> result = epmFilter.getAllowedLocations(deploymentId);

        assertTrue(result.isEmpty());
    }

    @Test
    public void getAllowedLocations_returnsEmptyList_whenExceptionOccurs() throws IHubException {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        List<String> result = epmFilter.getAllowedLocations(deploymentId);

        assertTrue(result.isEmpty());
    }
}