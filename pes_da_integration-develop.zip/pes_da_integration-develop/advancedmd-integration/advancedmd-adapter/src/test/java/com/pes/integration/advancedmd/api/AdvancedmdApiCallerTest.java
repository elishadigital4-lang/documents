package com.pes.integration.advancedmd.api;

import com.pes.integration.advancedmd.component.AdvancedmdClientCaller;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.*;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.constant.BaseEPMConstants.BASE_URL;
import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.EngineConstants.METHOD;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AdvancedmdApiCallerTest {

    @Mock
    private ConfigCache configCache;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private RedisService redisService;

    @Mock
    DataTransactionService dataTransactionService;
    @Mock
    private AdvancedmdClientCaller advancedmdClientCaller;

    @InjectMocks
    private AdvancedmdApiCaller advancedmdApiCaller;
    private AmdApi amdApi;

    @BeforeEach
    public void setUp() {
        amdApi = new AmdApi("loginUrl", "userId", "password", "officeCode", "appName", "http://endpoint", "deploymentId");

        String[] configTypes = {GENERIC_CONFIG, ADVANCEDMD_CONFIG,
                ENVIRONMENT_CONFIG, FILTER_CONFIG};
        initialiseEPMConstants(AdvancedMDConstants.DATE_FORMAT,
                DATE_TIME_FORMAT,
                TIME_FORMAT,
                BASE_URL,
                AdvancedMDEngineConstants.TRUE,
                EPM_NAME_PREFIX,
                ADVANCEDMD_CONFIG,
                RETRY_COUNT,
                REQUEST_MAPPING_KEY_NAME,
                RESPONSE_MAPPING_KEY_NAME,
                REQUEST_CONFIG_KEY_NAME,
                RESPONSE_CODES_MAPPING_KEY_NAME,
                configTypes);
        JSONObject availableTimeRequest = new JSONObject();
        availableTimeRequest.put("startDate", "2024-09-26");
        availableTimeRequest.put("endDate", "2023-01-02");
        availableTimeRequest.put("epmPrefix", "EPM");
    }

    @Test
    public void callApi_throwsException_whenGenericExceptionOccurs() throws Exception {
        JSONObject apiConfig = new JSONObject();
        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "testDeploymentId");

        apiConfig.put(METHOD, "GET");
        apiConfig.put(URL, "/test/url");

        when(redisService.get(anyString())).thenReturn("validToken");
        lenient().when(configCache.getContext(anyString())).thenReturn(new JSONObject().put("@webserver", "web"));
        lenient().when(cacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("value");
        when(advancedmdClientCaller.getData(anyString(), anyString(), anyString(), anyString()))
                .thenThrow(new RuntimeException("Generic error"));

        Exception exception = assertThrows(RuntimeException.class, () -> {
            org.springframework.test.util.ReflectionTestUtils.invokeMethod(
                    advancedmdApiCaller, "callApi", apiConfig, requestObject);
        });

        assertEquals("Generic error", exception.getMessage());
    }

    @Test
    public void customizeResponseMapping_returnsNull() throws Exception {
        JSONObject apiResponseMapping = new JSONObject();
        String apiName = "testApi";
        Object inputObject = new Object();

        JSONObject result = (JSONObject)
                org.springframework.test.util.ReflectionTestUtils.invokeMethod(
                        advancedmdApiCaller, "customizeResponseMapping", apiResponseMapping, apiName, inputObject);

        assertNull(result);
    }

    @Test
    public void callApi_returnsResponse_whenTokenIsValid() throws IHubException {

        String deploymentId;
        JSONObject apiConfig;
        JSONObject requestObject;

        deploymentId = "testDeploymentId";
        apiConfig = new JSONObject();
        requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, deploymentId);

        apiConfig.put(METHOD, "GET");
        apiConfig.put(URL, "/test/url");
        apiConfig.put(CLASS, "class");
        apiConfig.put("custome", "true");
        when(redisService.get(deploymentId + "advancedmd_token")).thenReturn("validToken");
        when(configCache.getContext(deploymentId)).thenReturn(new JSONObject().put("@webserver", "web"));
        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, USR_ID)).thenReturn("userId");
        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, USR_PSWD)).thenReturn("password");
        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, OFFICE_CODE)).thenReturn("233");
        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, END_POINT)).thenReturn("endpoint");
        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, APP_NAME)).thenReturn("appName");
//        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, "context_url")).thenReturn("context_url");
        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, LOGIN_URL)).thenReturn("loginUrl");
        String response = "[{\"key\":\"value\"}]";
        when(advancedmdClientCaller.getData(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        doNothing().when(dataTransactionService).saveUpdateDataAsync(any());
        Object result = advancedmdApiCaller.callApi(apiConfig, requestObject);

        assertInstanceOf(JSONObject.class, result);
        System.out.println(result);
        assertEquals("value", ((JSONObject) result).getJSONArray("PPMDResults").getJSONObject(0).getString("key"));
    }

    @Test
    public void initializeObject_initializesConfigsCorrectly() throws IHubException {
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();

        when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, ADVANCEDMD_CONFIG,
                REQUEST_CONFIG_KEY_NAME, false))
                .thenReturn(requestConfig);
        when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, ADVANCEDMD_CONFIG,
                REQUEST_MAPPING_KEY_NAME, false))
                .thenReturn(requestMapping);
        when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, ADVANCEDMD_CONFIG,
                RESPONSE_MAPPING_KEY_NAME, false))
                .thenReturn(responseMapping);

        Assertions.assertDoesNotThrow(() -> advancedmdApiCaller.initializeObject());
    }

    @Test
    public void getMappingConfig_setsConfigsCorrectly_whenProviderConfigExists() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONObject providerConfig = new JSONObject();
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();
        providerConfig.put(REQUEST_CONFIG_KEY_NAME, requestConfig);
        providerConfig.put(REQUEST_MAPPING_KEY_NAME, requestMapping);
        providerConfig.put(RESPONSE_MAPPING_KEY_NAME, responseMapping);

        lenient().when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(providerConfig);

        Assertions.assertDoesNotThrow(() -> advancedmdApiCaller.getMappingConfig(deploymentId));

    }

    @Test
    public void getMappingConfig_setsConfigsCorrectly_whenProviderConfigDoesNotExist() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONObject providerConfig = new JSONObject();

        lenient().when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(providerConfig);

        Assertions.assertDoesNotThrow(() -> advancedmdApiCaller.getMappingConfig(deploymentId));

    }

    @Test
    public void buildUrl_constructsUrlCorrectly() {
        String url = "/test/url?/:param1/:param2";
        Map<String, String> parameters = new HashMap<>();
        parameters.put(":param1", "value1");
        parameters.put(":param2", "value2");

        String result = ReflectionTestUtils.invokeMethod(advancedmdApiCaller, "buildUrl", url, parameters, amdApi);

        System.out.println(result);
        assertEquals("http://endpoint/test/url?:param1=value1&:param2=value2", result);
    }

    @Test
    public void getToken_returnsToken_whenTokenExistsInRedis() throws IHubException {
        String tokenStr = "{\"#text\":\"validToken\"}";
        when(redisService.get(amdApi.getDeploymentId())).thenReturn(tokenStr);

        String token = ReflectionTestUtils.invokeMethod(advancedmdApiCaller, "getToken", "componentId", amdApi);

        assertEquals("validToken", token);
    }

    @Test
    public void getToken_returnsToken_Empty() throws IHubException {
        ReflectionTestUtils.setField(advancedmdApiCaller, "tokenTtl", 10);
        String tokenStr = "";
        when(redisService.get(amdApi.getDeploymentId())).thenReturn(tokenStr);
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonObject1 = new JSONObject().put(RESULTS, new JSONObject().put("@success", "1").put(USER_CONTEXT, new JSONObject()
                .put("@webserver", "web")
                .put("#text", "validToken").put("@servertimezone", "UTC")));
        jsonObject.put(PPMD_RESULTS, jsonObject1);
        when(advancedmdClientCaller.getRedirectURL(anyString(), anyString(), anyString(), anyString())).thenReturn(jsonObject.toString());
        String token = ReflectionTestUtils.invokeMethod(advancedmdApiCaller, "getToken", "componentId", amdApi);

        assertEquals("validToken", token);
    }

    @Test
    public void getToken_returnsToken_IHubException() throws IHubException {
        ReflectionTestUtils.setField(advancedmdApiCaller, "tokenTtl", 10);
        String tokenStr = "";
        when(redisService.get(amdApi.getDeploymentId())).thenReturn(tokenStr);
        JSONObject jsonObject = new JSONObject();
        JSONObject usrContext = new JSONObject()
                .put("@webserver", "web")
                .put("#text", "validToken")
                .put("@servertimezone", "UTC");
        JSONObject results = new JSONObject();
        results.put("@success", "0");
        results.put(USER_CONTEXT, usrContext);
        JSONObject jsonObject1 = new JSONObject();
        jsonObject1.put(RESULTS, results);
        jsonObject1.put("Error", new JSONObject().put("Fault", new JSONObject().put("detail", new JSONObject().put("source", "100").put("description", "Invalid user"))));
        jsonObject.put(PPMD_RESULTS, jsonObject1);
        when(advancedmdClientCaller.getRedirectURL(anyString(), anyString(), anyString(), anyString())).thenReturn(jsonObject.toString());
        UndeclaredThrowableException hubException = Assertions.assertThrows(UndeclaredThrowableException.class, () -> ReflectionTestUtils.invokeMethod(advancedmdApiCaller, "getToken", "componentId", amdApi));

        assertInstanceOf(IHubException.class, hubException.getCause());

    }
}