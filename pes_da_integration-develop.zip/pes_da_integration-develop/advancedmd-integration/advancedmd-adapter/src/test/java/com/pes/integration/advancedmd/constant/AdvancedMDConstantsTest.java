package com.pes.integration.advancedmd.constant;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class AdvancedMDConstantsTest {

    @Test
    public void dateFormat_isCorrect() {
        assertEquals("yyyy-MM-dd", AdvancedMDConstants.DATE_FORMAT);
    }

    @Test
    public void timeFormat_isCorrect() {
        assertEquals("HH:mm", AdvancedMDConstants.TIME_FORMAT);
    }

    @Test
    public void dateTimeFormat_isCorrect() {
        assertEquals("yyyy-MM-dd'T'HH:mm:ss", AdvancedMDConstants.DATE_TIME_FORMAT);
    }

    @Test
    public void dateTimeFormatAmPm_isCorrect() {
        assertEquals("MM/dd/yyyy hh:mm:ss a", AdvancedMDConstants.DATE_TIME_FORMAT_AM_PM);
    }

    @Test
    public void timeFormatRealTime_isCorrect() {
        assertEquals("MM/dd/yyyy hh:mma", AdvancedMDConstants.TIME_FORMAT_REALTIME);
    }

    @Test
    public void timeFormatAmPm_isCorrect() {
        assertEquals("hh:mm a", AdvancedMDConstants.TIME_FORMAT_AM_PM);
    }

    @Test
    public void dateTimeFormatWithoutAmPm_isCorrect() {
        assertEquals("MM/dd/yyyy HH:mm:ss", AdvancedMDConstants.DATE_TIME_FORMAT_WITHOUT_AM_PM);
    }

    @Test
    public void dobDateFormat_isCorrect() {
        assertEquals("MM/dd/yyyy", AdvancedMDConstants.DOB_DATE_FORMAT);
    }

    @Test
    public void usrId_isCorrect() {
        assertEquals("userid", AdvancedMDConstants.USR_ID);
    }

    @Test
    public void usrPswd_isCorrect() {
        assertEquals("password", AdvancedMDConstants.USR_PSWD);
    }

    @Test
    public void officeCode_isCorrect() {
        assertEquals("officecode", AdvancedMDConstants.OFFICE_CODE);
    }

    @Test
    public void appName_isCorrect() {
        assertEquals("appname", AdvancedMDConstants.APP_NAME);
    }

    @Test
    public void loginUrl_isCorrect() {
        assertEquals("login_url", AdvancedMDConstants.LOGIN_URL);
    }

    @Test
    public void loginConstant_isCorrect() {
        assertEquals("/xmlrpc/processrequest.aspx", AdvancedMDConstants.LOGIN_CONSTANT);
    }

    @Test
    public void next_isCorrect() {
        assertEquals("next", AdvancedMDConstants.NEXT);
    }

    @Test
    public void id_isCorrect() {
        assertEquals("Id", AdvancedMDConstants.ID);
    }

    @Test
    public void time_isCorrect() {
        assertEquals("Time", AdvancedMDConstants.TIME);
    }

    @Test
    public void startTime_isCorrect() {
        assertEquals("startTime", AdvancedMDConstants.START_TIME);
    }

    @Test
    public void defaultCancelReason_isCorrect() {
        assertEquals("defcanreason", AdvancedMDConstants.DEFAULT_CANCEL_REASON);
    }

    @Test
    public void apptReason_isCorrect() {
        assertEquals("apptReason", AdvancedMDConstants.APPT_REASON);
    }

    @Test
    public void allowMultiplePatient_isCorrect() {
        assertEquals("allow_mul_pat", AdvancedMDConstants.ALLOW_MULTIPLE_PATIENT);
    }

    @Test
    public void allowDuplicatePatient_isCorrect() {
        assertEquals("allow_dup_pat", AdvancedMDConstants.ALLOW_DUPLICATE_PATIENT);
    }

    @Test
    public void colorConfig_isCorrect() {
        assertEquals("color", AdvancedMDConstants.COLOR_CONFIG);
    }

    @Test
    public void triggerPatientForms_isCorrect() {
        assertEquals("trigger_patient_forms", AdvancedMDConstants.TRIGGER_PATIENT_FORMS);
    }

    @Test
    public void saveAccDisableForms_isCorrect() {
        assertEquals("disable", AdvancedMDConstants.SAVE_ACC_DISABLE_FORMS);
    }

    @Test
    public void saveAccDisplayForms_isCorrect() {
        assertEquals("display", AdvancedMDConstants.SAVE_ACC_DISPLAY_FORMS);
    }

    @Test
    public void sendInviteAppId_isCorrect() {
        assertEquals("applicationid", AdvancedMDConstants.SEND_INVITE_APP_ID);
    }

    @Test
    public void triggerPatientFormsRetryCount_isCorrect() {
        assertEquals("patient_forms_retrycount", AdvancedMDConstants.TRIGGER_PATIENT_FORMS_RETRYCOUNT);
    }

    @Test
    public void success_isCorrect() {
        assertEquals("temp.success", AdvancedMDConstants.SUCCESS);
    }

    @Test
    public void errorCode_isCorrect() {
        assertEquals("PPMDResults.Error.Fault.detail.code", AdvancedMDConstants.ERROR_CODE);
    }

    @Test
    public void errorDetails_isCorrect() {
        assertEquals("PPMDResults.Error.Fault.detail.description", AdvancedMDConstants.ERROR_DETAILS);
    }

    @Test
    public void errorMessage_isCorrect() {
        assertEquals("PPMDResults.Error.Fault.faultstring", AdvancedMDConstants.ERROR_MESSAGE);
    }

    @Test
    public void codeCanceled_isCorrect() {
        assertEquals("D", AdvancedMDConstants.CODE_CANCELED);
    }

    @Test
    public void codeNew_isCorrect() {
        assertEquals("N", AdvancedMDConstants.CODE_NEW);
    }

    @Test
    public void codeRescheduled_isCorrect() {
        assertEquals("C", AdvancedMDConstants.CODE_RESCHEDULED);
    }

    @Test
    public void codeNoShow_isCorrect() {
        assertEquals("noshowid", AdvancedMDConstants.CODE_NO_SHOW);
    }

    @Test
    public void timeZone_isCorrect() {
        assertEquals("timezone", AdvancedMDConstants.TIME_ZONE);
    }

    @Test
    public void one_isCorrect() {
        assertEquals("1", AdvancedMDConstants.ONE);
    }

    @Test
    public void results_isCorrect() {
        assertEquals("Results", AdvancedMDConstants.RESULTS);
    }

    @Test
    public void ppmdResults_isCorrect() {
        assertEquals("PPMDResults", AdvancedMDConstants.PPMD_RESULTS);
    }

    @Test
    public void userContext_isCorrect() {
        assertEquals("usercontext", AdvancedMDConstants.USER_CONTEXT);
    }

    @Test
    public void error_isCorrect() {
        assertEquals("Error", AdvancedMDConstants.ERROR);
    }

    @Test
    public void slotId_isCorrect() {
        assertEquals("SlotId", AdvancedMDConstants.SLOTID);
    }

    @Test
    public void setInsurance_isCorrect() {
        assertEquals("set_insurance", AdvancedMDConstants.SET_INSURANCE);
    }

    @Test
    public void regPatientInDepartment_isCorrect() {
        assertEquals("Registerpatientindepartment", AdvancedMDConstants.REG_PATIENT_IN_DEPARTMENT);
    }

    @Test
    public void lookupDepartmentId_isCorrect() {
        assertEquals("Lookupdepartmentid", AdvancedMDConstants.LOOKUP_DEPARTMENT_ID);
    }

    @Test
    public void baseUrl_isCorrect() {
        assertEquals("https://api.advancemdhealth.com", AdvancedMDConstants.BASE_URL);
    }

    @Test
    public void version_isCorrect() {
        assertEquals("version", AdvancedMDConstants.VERSION);
    }

    @Test
    public void clientId_isCorrect() {
        assertEquals("clientid", AdvancedMDConstants.CLIENT_ID);
    }

    @Test
    public void clientSecret_isCorrect() {
        assertEquals("clientsecret", AdvancedMDConstants.CLIENT_SECRET);
    }

    @Test
    public void classAnot_isCorrect() {
        assertEquals("@class", AdvancedMDConstants.CLASS_ANOT);
    }
}