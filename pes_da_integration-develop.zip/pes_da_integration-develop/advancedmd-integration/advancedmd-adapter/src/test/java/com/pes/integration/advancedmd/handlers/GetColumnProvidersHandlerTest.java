package com.pes.integration.advancedmd.handlers;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.PROV_COLUMN_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.PROVIDER_ID;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.exceptions.IHubException;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
public class GetColumnProvidersHandlerTest {

    @Mock
    private AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    private ConfigCache configCache;

    @InjectMocks
    private GetColumnProvidersHandler getColumnProvidersHandler;

    private JSONObject inputObject;
    private JSONObject outputObject;
    private JSONArray columnsArray;

    private JSONArray columns;
    private StringBuilder columnIdsStr;
    private Map<String, String> providerIdsMap;
    private Map<String, String> columnHeaderWithColMap;
    private Map<String, String> columnHeaderMap;
    private Map<String, String> colProviderIdsMap;

    @BeforeEach
    void setUp() {
        columns = new JSONArray();
        columnIdsStr = new StringBuilder();
        providerIdsMap = new HashMap<>();
        columnHeaderWithColMap = new HashMap<>();
        columnHeaderMap = new HashMap<>();
        colProviderIdsMap = new HashMap<>();

        inputObject = new JSONObject();
        outputObject = new JSONObject();
        columnsArray = new JSONArray();
    }

    @Test
    void populateColProviderIdsMap_handlesException() {
        JSONArray columns = new JSONArray();
        // Intentionally leave columns empty to cause an exception when accessing index 0
        StringBuilder columnIdsStr = new StringBuilder();
        Map<String, String> providerIdsMap = new HashMap<>();
        Map<String, String> columnHeaderWithColMap = new HashMap<>();
        Map<String, String> columnHeaderMap = new HashMap<>();
        Map<String, String> colProviderIdsMap = new HashMap<>();

        // This should trigger an exception and hit the catch block
        StringBuilder result = org.springframework.test.util.ReflectionTestUtils.invokeMethod(
                getColumnProvidersHandler,
                "populateColProviderIdsMap",
                columns, columnIdsStr, providerIdsMap, columnHeaderWithColMap, columnHeaderMap, colProviderIdsMap, 0
        );

        // The result should be unchanged
        assertEquals("", result.toString());
    }

    @Test
    public void doExecute_returnsOutputObject_whenApiCallSucceeds() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        outputObject.put("columns", columnsArray);
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);

        JSONObject result = getColumnProvidersHandler.doExecute(inputObject);

        assertEquals(outputObject, result);
    }

    @Test
    public void doExecute_setsProviderMaps_whenApiCallReturnsData() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        JSONObject columnObject = new JSONObject();
        columnObject.put("PROV_COLUMN_ID", "col1");
        columnObject.put("PROVIDER_ID", "prov1");
        columnObject.put("Heading", "heading1");
        columnsArray.put(columnObject);
        outputObject.put("columns", columnsArray);
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);

        getColumnProvidersHandler.doExecute(inputObject);

        verify(configCache).setProviderIdsMap(eq("deploymentId"), anyMap());
        verify(configCache).setColumnIdMap(eq("deploymentId"), anyString());
        verify(configCache).setColumnHeaderMap(eq("deploymentId"), anyMap());
        verify(configCache).setColProviderIdsMap(eq("deploymentId"), anyMap());
        verify(configCache).setColumnHeaderWithColMap(eq("deploymentId"), anyMap());
    }

    @Test
    public void doExecute_handlesEmptyColumnsArray() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        outputObject.put("columns", new JSONArray());
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);

        JSONObject result = getColumnProvidersHandler.doExecute(inputObject);

        assertEquals(outputObject, result);
        verify(configCache).setProviderIdsMap(eq("deploymentId"), anyMap());
        verify(configCache).setColumnIdMap(eq("deploymentId"), anyString());
        verify(configCache).setColumnHeaderMap(eq("deploymentId"), anyMap());
        verify(configCache).setColProviderIdsMap(eq("deploymentId"), anyMap());
        verify(configCache).setColumnHeaderWithColMap(eq("deploymentId"), anyMap());
    }

    @Test
    public void doExecute_handlesException() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("Error"));

        JSONObject result = getColumnProvidersHandler.doExecute(inputObject);

        assertTrue(result.isEmpty());
    }


    @Test
    void populateColProviderIdsMap_populatesMapsCorrectly() {
        JSONObject columnObject = new JSONObject();
        columnObject.put(PROV_COLUMN_ID, "col1");
        columnObject.put(PROVIDER_ID, "prov1");
        columnObject.put("Heading", "heading1");
        columns.put(columnObject);

        StringBuilder result = ReflectionTestUtils.invokeMethod(getColumnProvidersHandler, "populateColProviderIdsMap", columns, columnIdsStr, providerIdsMap, columnHeaderWithColMap, columnHeaderMap, colProviderIdsMap, 0);

        assertEquals("col1", result.toString());
        assertEquals("col1@prov1", providerIdsMap.get("col1"));
        assertEquals("prov1", columnHeaderMap.get("heading1"));
        assertEquals("col1@prov1", columnHeaderWithColMap.get("heading1"));
        assertEquals("prov1", colProviderIdsMap.get("col1"));
    }


}