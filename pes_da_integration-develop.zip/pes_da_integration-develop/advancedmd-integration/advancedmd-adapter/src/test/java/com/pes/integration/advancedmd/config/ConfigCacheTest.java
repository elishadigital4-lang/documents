package com.pes.integration.advancedmd.config;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.pes.integration.component.RedisService;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
class ConfigCacheTest {

    @Mock
    private RedisService redisService;

    @InjectMocks
    private ConfigCache configCache;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(configCache, "redisService", redisService);
    }

    @Test
    void getContext_returnsCorrectContext() {
        String deploymentId = "testDeploymentId";
        String contextString = "{\"key\":\"value\"}";
        when(redisService.get(deploymentId + "_context")).thenReturn(contextString);

        JSONObject context = configCache.getContext(deploymentId);

        assertNotNull(context);
        assertEquals("value", context.getString("key"));
    }

    @Test
    void getContext_returnsNull_whenContextNotFound() {
        String deploymentId = "testDeploymentId";
        when(redisService.get(deploymentId + "_context")).thenReturn(null);

        JSONObject context = configCache.getContext(deploymentId);

        assertNull(context);
    }

    @Test
    void setContext_savesContextCorrectly() {
        String deploymentId = "testDeploymentId";
        int ttl = 3600;
        JSONObject context = new JSONObject();
        context.put("key", "value");

        configCache.setContext(deploymentId, ttl, context);

        verify(redisService).saveWithTtl(deploymentId + "_context", context.toString(), ttl);
    }

    @Test
    void getSyncRunTimeMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        String syncRunTime = "2023-01-01T00:00:00Z";
        configCache.setSyncRunTimeMap(deploymentId, syncRunTime);

        String result = configCache.getSyncRunTimeMap(deploymentId);

        assertEquals(syncRunTime, result);
    }

    @Test
    void getSyncRunTimeMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        String result = configCache.getSyncRunTimeMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getPatientSyncRunTimeMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        String syncRunTime = "2023-01-01T00:00:00Z";
        configCache.setPatientSyncRunTimeMap(deploymentId, syncRunTime);

        String result = configCache.getPatientSyncRunTimeMap(deploymentId);

        assertEquals(syncRunTime, result);
    }

    @Test
    void getPatientSyncRunTimeMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        String result = configCache.getPatientSyncRunTimeMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getServerTimeZoneMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        String timezone = "UTC";
        configCache.setServerTimeZoneMap(deploymentId, timezone);

        String result = configCache.getServerTimeZoneMap(deploymentId);

        assertEquals(timezone, result);
    }

    @Test
    void getServerTimeZoneMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        String result = configCache.getServerTimeZoneMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getProviderIdsMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        Map<String, String> providerIdMap = new HashMap<>();
        providerIdMap.put("provider1", "id1");
        configCache.setProviderIdsMap(deploymentId, providerIdMap);

        Map<String, String> result = configCache.getProviderIdsMap(deploymentId);

        assertEquals(providerIdMap, result);
    }

    @Test
    void getProviderIdsMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        Map<String, String> result = configCache.getProviderIdsMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getColumnIdMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        String columnId = "column1";
        configCache.setColumnIdMap(deploymentId, columnId);

        String result = configCache.getColumnIdMap(deploymentId);

        assertEquals(columnId, result);
    }

    @Test
    void getColumnIdMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        String result = configCache.getColumnIdMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getColumnHeaderMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        Map<String, String> columnHeaderMap = new HashMap<>();
        columnHeaderMap.put("header1", "value1");
        configCache.setColumnHeaderMap(deploymentId, columnHeaderMap);

        Map<String, String> result = configCache.getColumnHeaderMap(deploymentId);

        assertEquals(columnHeaderMap, result);
    }

    @Test
    void getColumnHeaderMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        Map<String, String> result = configCache.getColumnHeaderMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getLocationMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        Map<String, String> locationMap = new HashMap<>();
        locationMap.put("location1", "value1");
        configCache.setLocationMap(deploymentId, locationMap);

        Map<String, String> result = configCache.getLocationMap(deploymentId);

        assertEquals(locationMap, result);
    }

    @Test
    void getLocationMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        Map<String, String> result = configCache.getLocationMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getAppointmentTypeMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        Map<String, String> appointmentTypeMap = new HashMap<>();
        appointmentTypeMap.put("type1", "value1");
        configCache.setAppointmentTypeMap(deploymentId, appointmentTypeMap);

        Map<String, String> result = configCache.getAppointmentTypeMap(deploymentId);

        assertEquals(appointmentTypeMap, result);
    }

    @Test
    void getAppointmentTypeMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        Map<String, String> result = configCache.getAppointmentTypeMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getColProviderIdsMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        Map<String, String> colProviderIdsMap = new HashMap<>();
        colProviderIdsMap.put("provider1", "id1");
        configCache.setColProviderIdsMap(deploymentId, colProviderIdsMap);

        Map<String, String> result = configCache.getColProviderIdsMap(deploymentId);

        assertEquals(colProviderIdsMap, result);
    }

    @Test
    void getColProviderIdsMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        Map<String, String> result = configCache.getColProviderIdsMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getColumnHeaderWithColMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        Map<String, String> columnHeaderWithColMap = new HashMap<>();
        columnHeaderWithColMap.put("header1", "value1");
        configCache.setColumnHeaderWithColMap(deploymentId, columnHeaderWithColMap);

        Map<String, String> result = configCache.getColumnHeaderWithColMap(deploymentId);

        assertEquals(columnHeaderWithColMap, result);
    }

    @Test
    void getColumnHeaderWithColMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        Map<String, String> result = configCache.getColumnHeaderWithColMap(deploymentId);

        assertNull(result);
    }

    @Test
    void getAppointmentTypeColorMap_returnsCorrectValue() {
        String deploymentId = "testDeploymentId";
        Map<String, String> appointmentTypeColorMap = new HashMap<>();
        appointmentTypeColorMap.put("type1", "color1");
        configCache.setAppointmentTypeColorMap(deploymentId, appointmentTypeColorMap);

        Map<String, String> result = configCache.getAppointmentTypeColorMap(deploymentId);

        assertEquals(appointmentTypeColorMap, result);
    }

    @Test
    void getAppointmentTypeColorMap_returnsNull_whenNotSet() {
        String deploymentId = "testDeploymentId";

        Map<String, String> result = configCache.getAppointmentTypeColorMap(deploymentId);

        assertNull(result);
    }
}