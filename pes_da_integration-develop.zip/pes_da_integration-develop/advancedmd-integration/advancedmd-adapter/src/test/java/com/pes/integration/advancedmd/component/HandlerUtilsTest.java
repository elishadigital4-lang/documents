package com.pes.integration.advancedmd.component;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.advancedmd.handlers.GetAppointmentTypesHandler;
import com.pes.integration.advancedmd.handlers.GetColumnProvidersHandler;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.FileUtil;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.exceptions.IHubException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
public class HandlerUtilsTest {

    @Mock
    private ConfigCache configCache;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;

    @Mock
    private RedisService redisService;

    @Mock
    private GetColumnProvidersHandler getColumnProvidersHandler;

    @Mock
    private GetAppointmentTypesHandler getAppointmentTypesHandler;

    @InjectMocks
    private HandlerUtils handlerUtils;

    private String deploymentId;

    @BeforeEach
    public void setUp() {
        deploymentId = "testDeploymentId";
    }

    @Test
    void getColumnId_setsColumnAndReturnsColumnId_whenColumnHeaderMapIsEmpty_andIsColWithProvIsFalse() throws Exception {
        String deploymentId = "testDeploymentId";
        String code = "testCode";
        boolean isColWithProv = false;

        // First call returns null, second call returns a map with the code
        when(configCache.getColumnHeaderMap(deploymentId))
                .thenReturn(null)
                .thenReturn(Collections.singletonMap(code, "columnId"));

        String result = handlerUtils.getColumnId(code, deploymentId, isColWithProv);

        verify(getColumnProvidersHandler).doExecute(any(JSONObject.class));
        assertEquals("columnId", result);
    }

    @Test
    public void getColumnId_setsColumnAndReturnsColumnId_whenColumnHeaderWithColMapIsEmpty() throws Exception {
        String deploymentId = "testDeploymentId";
        String code = "testCode";
        boolean isColWithProv = true;

        // First call returns null, second call returns a map with the code
        when(configCache.getColumnHeaderWithColMap(deploymentId))
                .thenReturn(null)
                .thenReturn(Collections.singletonMap(code, "columnId"));

        String result = handlerUtils.getColumnId(code, deploymentId, isColWithProv);

        verify(getColumnProvidersHandler).doExecute(any(JSONObject.class));
        assertEquals("columnId", result);
    }

    @Test
    void getSyncTIme_logsError_whenRedisServiceThrowsException() throws Exception {
        HandlerUtils handlerUtils = new HandlerUtils();
        RedisService mockRedisService = mock(RedisService.class);
        // Inject mock redisService using reflection
        java.lang.reflect.Field redisField = HandlerUtils.class.getDeclaredField("redisService");
        redisField.setAccessible(true);
        redisField.set(handlerUtils, mockRedisService);

        String deploymentId = "testDeploymentId";
        String lastSyncTime = null;

        doThrow(new RuntimeException("Redis error")).when(mockRedisService).get(deploymentId);

        java.lang.reflect.Method method = HandlerUtils.class.getDeclaredMethod("getSyncTIme", String.class, String.class);
        method.setAccessible(true);
        Object result = method.invoke(handlerUtils, deploymentId, lastSyncTime);

        assertNull(result);
    }

    @Test
    public void getColumnStr_returnsColumnStr_whenColumnStrExists() throws IHubException {
        when(configCache.getColumnIdMap(deploymentId)).thenReturn("columnStr");

        String result = handlerUtils.getColumnStr(deploymentId);

        assertEquals("columnStr", result);
    }

    @Test
    public void getColumnStr_setsColumnAndReturnsColumnStr_whenColumnStrDoesNotExist() throws IHubException {
        when(configCache.getColumnIdMap(deploymentId)).thenReturn(null).thenReturn("columnStr");

        String result = handlerUtils.getColumnStr(deploymentId);

        verify(getColumnProvidersHandler).doExecute(any(JSONObject.class));
        assertEquals("columnStr", result);
    }

    @Test
    public void getApptTypeMap_returnsApptTypeMap_whenApptTypeMapExists() throws IHubException {
        Map<String, String> apptTypeMap = new HashMap<>();
        apptTypeMap.put("key", "value");
        when(configCache.getAppointmentTypeMap(deploymentId)).thenReturn(apptTypeMap);

        Map<String, String> result = handlerUtils.getApptTypeMap(deploymentId);

        assertEquals(apptTypeMap, result);
    }

    @Test
    public void getApptTypeMap_getsApptTypesAndReturnsApptTypeMap_whenApptTypeMapDoesNotExist() throws IHubException {
        when(configCache.getAppointmentTypeMap(deploymentId)).thenReturn(null).thenReturn(new HashMap<>());

        Map<String, String> result = handlerUtils.getApptTypeMap(deploymentId);

        verify(getAppointmentTypesHandler).doExecute(any(JSONObject.class));
        assertNotNull(result);
    }

    @Test
    public void getColProviderMap_returnsColProviderMap_whenColProviderMapExists() throws IHubException {
        Map<String, String> colProviderMap = new HashMap<>();
        colProviderMap.put("key", "value");
        when(configCache.getColProviderIdsMap(deploymentId)).thenReturn(colProviderMap);

        Map<String, String> result = handlerUtils.getColProviderMap(deploymentId);

        assertEquals(colProviderMap, result);
    }

    @Test
    public void getColProviderMap_setsColumnAndReturnsColProviderMap_whenColProviderMapDoesNotExist() throws IHubException {
        when(configCache.getColProviderIdsMap(deploymentId)).thenReturn(null).thenReturn(new HashMap<>());

        Map<String, String> result = handlerUtils.getColProviderMap(deploymentId);

        verify(getColumnProvidersHandler).doExecute(any(JSONObject.class));
        assertNotNull(result);
    }

    @Test
    public void isColWithProv_returnsTrue_whenIsColWithProvIsTrue() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("TRUE");

        boolean result = handlerUtils.isColWithProv(deploymentId, "epmPrefix");

        assertTrue(result);
    }

    @Test
    public void isColWithProv_returnsFalse_whenIsColWithProvIsFalse() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("FALSE");

        boolean result = handlerUtils.isColWithProv(deploymentId, "epmPrefix");

        assertFalse(result);
    }

    @Test
    public void getProviderMap_returnsProviderMap_whenProviderMapExists() throws IHubException {
        Map<String, String> providerMap = new HashMap<>();
        providerMap.put("key", "value");
        when(configCache.getProviderIdsMap(deploymentId)).thenReturn(providerMap);

        Map<String, String> result = handlerUtils.getProviderMap(deploymentId);

        assertEquals(providerMap, result);
    }

    @Test
    public void getProviderMap_setsColumnAndReturnsProviderMap_whenProviderMapDoesNotExist() throws IHubException {
        when(configCache.getProviderIdsMap(deploymentId)).thenReturn(null).thenReturn(new HashMap<>());

        Map<String, String> result = handlerUtils.getProviderMap(deploymentId);

        verify(getColumnProvidersHandler).doExecute(any(JSONObject.class));
        assertNotNull(result);
    }

    @Test
    public void getApptTypeColorMap_returnsApptTypeColorMap_whenApptTypeColorMapExists() throws IHubException {
        Map<String, String> apptTypeColorMap = new HashMap<>();
        apptTypeColorMap.put("key", "value");
        when(configCache.getAppointmentTypeColorMap(deploymentId)).thenReturn(apptTypeColorMap);

        Map<String, String> result = handlerUtils.getApptTypeColorMap(deploymentId);

        assertEquals(apptTypeColorMap, result);
    }

    @Test
    public void getApptTypeColorMap_getsApptTypesAndReturnsApptTypeColorMap_whenApptTypeColorMapDoesNotExist() throws IHubException {
        when(configCache.getAppointmentTypeColorMap(deploymentId)).thenReturn(null).thenReturn(new HashMap<>());

        Map<String, String> result = handlerUtils.getApptTypeColorMap(deploymentId);

        verify(getAppointmentTypesHandler).doExecute(any(JSONObject.class));
        assertNotNull(result);
    }

    @Test
    public void getSyncRunTime_returnsSyncRunTime_whenSyncRunTimeExists() throws IHubException {
        when(redisService.get(deploymentId)).thenReturn("syncTime");

        String result = handlerUtils.getSyncRunTime(deploymentId);

        assertEquals("syncTime", result);
    }

    @Test
    public void getSyncRunTime_returnsNull_whenSyncRunTimeDoesNotExist() throws IHubException {
        when(redisService.get(deploymentId)).thenReturn(null);

        String result = handlerUtils.getSyncRunTime(deploymentId);

        assertNull(result);
    }

    @Test
    public void getTimeZone_returnsTimeZone_whenTimeZoneExists() throws IHubException {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("timeZone");

        String result = handlerUtils.getTimeZone(deploymentId);

        assertEquals("timeZone", result);
    }

    @Test
    public void getTimeZone_returnsDefaultTimeZone_whenTimeZoneDoesNotExist() throws IHubException {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(null);
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("defaultTimeZone");

        String result = handlerUtils.getTimeZone(deploymentId);

        assertEquals("defaultTimeZone", result);
    }

    @Test
    public void getLastSuccessfulSyncDate_returnsLastSuccessfulSyncDate_whenLastSuccessfulSyncDateExists() throws IHubException {
        when(iHubDataServiceDelegator.getOrgLastSyncRunTime(anyString(), anyMap())).thenReturn("{\"last_sync_run_time\":\"syncDate\"}");

        String result = handlerUtils.getLastSuccessfulSyncDate(deploymentId);

        assertEquals("syncDate", result);
    }

    @Test
    public void getLastSuccessfulSyncDate_returnsNull_whenLastSuccessfulSyncDateDoesNotExist() throws IHubException {
        when(iHubDataServiceDelegator.getOrgLastSyncRunTime(anyString(), anyMap())).thenReturn("{\"last_sync_run_time\": \"\"}");

        String result = handlerUtils.getLastSuccessfulSyncDate(deploymentId);

        assertTrue(result.isEmpty());
    }

    @Test
    void getChangeApptRequestMappingJson_returnsCorrectJson() throws Exception {
        try (MockedStatic<FileUtil> fileUtilMockedStatic = mockStatic(FileUtil.class)) {
            String jsonString = "{\"key\":\"value\"}";
            fileUtilMockedStatic.when(() -> FileUtil.readFileAsString("am_change_appt_mapping.json")).thenReturn(jsonString);

            JSONObject result = HandlerUtils.getChangeApptRequestMappingJson();

            assertNotNull(result);
            assertEquals("value", result.getString("key"));
        }
    }

    @Test
    void getChangeApptRequestMappingJson_returnsEmptyJson_whenFileIsEmpty() throws Exception {
        try (MockedStatic<FileUtil> fileUtilMockedStatic = mockStatic(FileUtil.class)) {

            fileUtilMockedStatic.when(() -> FileUtil.readFileAsString("am_change_appt_mapping.json")).thenReturn("");

            JSONObject result = HandlerUtils.getChangeApptRequestMappingJson();

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void getColumnId_returnsCorrectColumnId_whenIsColWithProvIsTrue() throws Exception {
        String deploymentId = "testDeploymentId";
        String code = "testCode";
        boolean isColWithProv = true;
        Map<String, String> columnHeaderMap = new HashMap<>();
        columnHeaderMap.put(code, "columnId");
        when(configCache.getColumnHeaderWithColMap(deploymentId)).thenReturn(columnHeaderMap);

        String result = handlerUtils.getColumnId(code, deploymentId, isColWithProv);

        assertEquals("columnId", result);
    }

    @Test
    void getColumnId_returnsCorrectColumnId_whenIsColWithProvIsFalse() throws Exception {
        String deploymentId = "testDeploymentId";
        String code = "testCode";
        boolean isColWithProv = false;
        Map<String, String> columnHeaderMap = new HashMap<>();
        columnHeaderMap.put(code, "columnId");
        when(configCache.getColumnHeaderMap(deploymentId)).thenReturn(columnHeaderMap);

        String result = handlerUtils.getColumnId(code, deploymentId, isColWithProv);

        assertEquals("columnId", result);
    }

    @Test
    void setExternalPatientId_setsPatientIdCorrectly() throws Exception {
        JSONObject outputObject = new JSONObject();
        outputObject.put("patientId", "ext12345");

        HandlerUtils.setExternalPatientId(outputObject, "ext12345");

        assertEquals("ext12345", outputObject.getString("patientId"));
    }

    @Test
    void setExternalPatientId_doesNothing_whenExPatientIdIsEmpty() throws Exception {
        JSONObject outputObject = new JSONObject();
        outputObject.put(DocASAPConstants.Key.PATIENT_ID, "");

        HandlerUtils.setExternalPatientId(outputObject, "1234556");

        assertEquals("", outputObject.getString(DocASAPConstants.Key.PATIENT_ID));
    }
}