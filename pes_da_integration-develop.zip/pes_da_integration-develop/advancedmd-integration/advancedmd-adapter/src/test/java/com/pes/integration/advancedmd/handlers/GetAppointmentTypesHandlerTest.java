package com.pes.integration.advancedmd.handlers;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;

@ExtendWith(MockitoExtension.class)
public class GetAppointmentTypesHandlerTest {

    @Mock
    private AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    private ConfigCache configCache;

    @InjectMocks
    private GetAppointmentTypesHandler getAppointmentTypesHandler;

    private JSONObject inputObject;
    private JSONObject outputObject;
    private JSONArray apptTypesArray;

    @BeforeEach
    public void setUp() {
        inputObject = new JSONObject();
        outputObject = new JSONObject();
        apptTypesArray = new JSONArray();
    }

    @Test
    public void doExecute_returnsOutputObject_whenApiCallSucceeds() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        outputObject.put("appointment_types", apptTypesArray);
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);

        JSONObject result = getAppointmentTypesHandler.doExecute(inputObject);

        assertEquals(outputObject, result);
    }

    @Test
    public void doExecute_setsAppointmentTypeMaps_whenApiCallReturnsData() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        JSONObject apptTypeObject = new JSONObject();
        apptTypeObject.put("AppointmentTypeId", "ap_type12");
        apptTypeObject.put("ShortName", "ShortName");
        apptTypeObject.put("Color", "Color");
        apptTypesArray.put(apptTypeObject);
        outputObject.put("AppointmentTypes", apptTypesArray);
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);

        getAppointmentTypesHandler.doExecute(inputObject);

        verify(configCache).setAppointmentTypeMap(eq("deploymentId"), anyMap());
        verify(configCache).setAppointmentTypeColorMap(eq("deploymentId"), anyMap());
    }

    @Test
    public void doExecute_handlesEmptyAppointmentTypesArray() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        outputObject.put("appointment_types", new JSONArray());
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);

        JSONObject result = getAppointmentTypesHandler.doExecute(inputObject);

        assertEquals(outputObject, result);
        verify(configCache).setAppointmentTypeMap(eq("deploymentId"), anyMap());
        verify(configCache).setAppointmentTypeColorMap(eq("deploymentId"), anyMap());
    }

    @Test
    public void doExecute_handlesException() throws IHubException {
        inputObject.put(DEPLOYMENT_ID, "deploymentId");
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("Error"));

        JSONObject result = getAppointmentTypesHandler.doExecute(inputObject);

        assertTrue(result.isEmpty());
    }
}