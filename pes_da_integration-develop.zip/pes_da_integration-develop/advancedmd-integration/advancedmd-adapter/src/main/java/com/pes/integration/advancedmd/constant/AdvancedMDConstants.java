package com.pes.integration.advancedmd.constant;

public class AdvancedMDConstants {
	
	
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String TIME_FORMAT = "HH:mm";
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String DATE_TIME_FORMAT_AM_PM = "MM/dd/yyyy hh:mm:ss a";
	public static final String TIME_FORMAT_REALTIME = "MM/dd/yyyy hh:mma";
	public static final String TIME_FORMAT_AM_PM = "hh:mm a";
	public static final String DATE_TIME_FORMAT_WITHOUT_AM_PM = "MM/dd/yyyy HH:mm:ss";
	public static final String DOB_DATE_FORMAT = "MM/dd/yyyy";
	public static final String USR_ID = "userid";
	public static final String USR_PSWD = "password";
	public static final String OFFICE_CODE = "officecode";
	public static final String APP_NAME = "appname";
	public static final String LOGIN_URL = "login_url";
	public static final String LOGIN_CONSTANT = "/xmlrpc/processrequest.aspx";
	
	public static final String NEXT = "next";
	public static final String ID = "Id";
	public static final String TIME = "Time";
	public static final String START_TIME = "startTime";
	
	public static final String DEFAULT_CANCEL_REASON = "defcanreason";
	public static final String APPT_REASON = "apptReason";
	public static final String ALLOW_MULTIPLE_PATIENT = "allow_mul_pat";
	public static final String ALLOW_DUPLICATE_PATIENT = "allow_dup_pat";
	
	public static final String COLOR_CONFIG = "color";
	public static final String TRIGGER_PATIENT_FORMS = "trigger_patient_forms";
	public static final String SAVE_ACC_DISABLE_FORMS = "disable";
	public static final String SAVE_ACC_DISPLAY_FORMS = "display";
	public static final String SEND_INVITE_APP_ID = "applicationid";
	public static final String TRIGGER_PATIENT_FORMS_RETRYCOUNT = "patient_forms_retrycount";
	public static final String SUCCESS = "temp.success";
	public static final String ERROR_CODE = "PPMDResults.Error.Fault.detail.code";
	public static final String ERROR_DETAILS = "PPMDResults.Error.Fault.detail.description";
	public static final String ERROR_MESSAGE = "PPMDResults.Error.Fault.faultstring";
	// appointment status codes
	public static final String CODE_CANCELED = "D";
	public static final String CODE_NEW = "N";
	public static final String CODE_RESCHEDULED = "C";
	public static final String CODE_NO_SHOW = "noshowid";
	public static final String TIME_ZONE = "timezone";
	public static final String ONE = "1";
	public static final String RESULTS  = "Results";
	public static final String PPMD_RESULTS  = "PPMDResults";
	public static final String USER_CONTEXT  = "usercontext";
	public static final String ERROR  = "Error";

	public static final String SLOTID  = "SlotId";
	public static final String SET_INSURANCE = "set_insurance";
	public static final String REG_PATIENT_IN_DEPARTMENT = "Registerpatientindepartment";
	public static final String LOOKUP_DEPARTMENT_ID = "Lookupdepartmentid";

	public static final String BASE_URL = "https://api.advancemdhealth.com";
	public static final String VERSION = "version";
	public static final String CLIENT_ID = "clientid";
	public static final String CLIENT_SECRET = "clientsecret";

	public static final String CLASS_ANOT = "@class";

	private AdvancedMDConstants() {
	}
	
}
