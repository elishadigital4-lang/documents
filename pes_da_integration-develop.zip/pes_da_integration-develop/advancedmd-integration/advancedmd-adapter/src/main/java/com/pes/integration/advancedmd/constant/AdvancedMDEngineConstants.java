package com.pes.integration.advancedmd.constant;

/**
 * @author neetoo
 *
 */
public class AdvancedMDEngineConstants {
	public static final String EPM_NAME_PREFIX = "am";
	public static final String ADVANCEDMD_CONFIG = "advancedmdprop";

	public static final String DATE_FORMAT = "MM/dd/yyyy";

	public static final String TOKEN_URL = "token_url";
	public static final String OAUTH_VERSION = "oauth_ver";
	public static final String BLANK = "";
	public static final String COMMA=", ";

	public static final String AUTO="AUTO";
	public static final String N18="18";

	public static final String C="C";
	public static final String RETRY_COUNT = "retrycount";
	public static final String URL = "url";
	public static final String METHOD = "method";
	public static final String CLASS = "@class";
	public static final String NAME = "Name";
	public static final String REQUEST_MAPPING_KEY_NAME = "am_req_map";

	public static final String RESPONSE_MAPPING_KEY_NAME = "am_res_map";
	public static final String REQUEST_CONFIG_KEY_NAME = "am_req_conf";
	public static final String RESPONSE_CODES_MAPPING_KEY_NAME = "am_res_codes";
	public static final String END_POINT = "endpoint";
	public static final String EPM_TYPE = "advancedmd";
	public static final String EPM_CONFIG_GROUPS = "RunBaselineSync,Epic Properties,Filter Service Config";

	public static final String COLUMN_ID = "SchedulingData.Provider[0].ColumnId";
	public static final String APPT_EPISODE_ID = "SchedulingData.Provider[0].EpisodeId";
	public static final String EPISODE_ID = "Episodes[0].EpisodeId";
	public static final String VIEW= "temp.view";
	public static final String HIPPA_RELATIONSHIP = "DemographicData.PatientInformation[0].hipaarelationship";
	public static final String CHART = "DemographicData.PatientInformation[0].chart";
	public static final String OTHER_PHONE_TYPE = "DemographicData.PatientInformation[0].OtheryPhoneType";
	public static final String FNAME = "DemographicData.PatientInformation[0].PatientFirstName";
	public static final String LNAME = "DemographicData.PatientInformation[0].PatientLastName";
	public static final String INACTIVE = "DemographicData.PatientInformation[0].Inactive";
	public static final String DECEASED = "DemographicData.PatientInformation[0].Deceased";
	public static final String PROV_COLUMN_ID = "ColumnId";
	public static final String APPT_REASON_ID = "ApptReasonId";
	public static final String REASON_TYPE_VAL = "2";
	public static final String COLUMNS = "Columns";
	public static final String IS_HOLD_ONLY ="is_hold_only";
	public static final String BS_SLOT_INTERVAL = "slot_interval";
	public static final String IGNORE_APPT_NAME_MATCH = "ignore_match";
	public static final String HOLD_REASON_MAP = "hold_reason_map";
	public static final String EXCLUDE_STATUS_CODE = "ex_status_code";
	public static final String IS_HOLD_WITH_GEN ="is_hold_with_gen";
	public static final String IS_BLOCKED = "is_blocked";
	public static final String SLOT_ID = "SchedulingData.Schedule[0].SlotId";
	public static final String APPT_TEMPLATE_ID = "SchedulingData.Schedule[0].TemplateId";
	public static final String APPT_EXTERNAL_TEMPLATE_ID = "SchedulingData.Schedule[0].ExternalTemplateId";
	public static final String PORTAL_ID = "temp.portalId";
	public static final String APPLICATION_ID = "temp.applicationId";
	public static final String DISABLE_FLAG = "temp.portalId";
	public static final String DISPLAY_FLAG = "temp.portalId";
	public static final String FULLNAME = "temp.fullName";
	public static final String EMAIL = "temp.Email";
	public static final String ID ="temp.id";
	public static final String COMMENT ="temp.comment";
	public static final String DISPLAY ="temp.display";
	public static final String DISABLE ="temp.disable";
	public static final String MSG_TIME = "temp.msgtime";
	public static final String APPOINTMENT_SYNC = "appointment_sync";
	public static final String PAGE = "page";
	public static final String PAGE_COUNT = "pagecount";
	public static final String EFFECTIVE_DATE = "DemographicData.InsuranceInformation[0].EffectiveDate";
	public static final String RESP_PARTY_ID = "temp.resPartyId";

	public static final String CLIENT_LOCATIONS = "clientlocations";
	public static final String PRACTICE_ID = "practiceid";
	public static final String GENERIC_APPT_TYPE = "genapptype";
	public static final String LIMIT = "limit";
	public static final String USE_LOCAL_PROVIDER = "uselocalprovider";

	public static final String RUN_REALTIME_BY_FILTER = "realt_by_fil";
	public static final String ADD_INSURANCES_AT_BOTTOM = "add_to_bottom";
	public static final int MAX_INSURANCES_ALLOWED = 3;
	public static final String ATHENA_CONFIG = "athenaprop";
	public static final String GUARANTOR_RELATIONS = "guarRelation";
	public static final String SPACE = " ";
	public static final String INSURANCE_LOGIC = "inslogic";
	public static final String CONSENT_TO_EMAIL = "consenttoemail";
	public static final String CONSENT_TO_TEXT = "consenttotext";

	public static final String ERROR_WITH_MESSAGE="Error while calling advancedmd api with  Error message:: {} ";

	public static final String SUCCESS_MESSAGE ="Successfully fetched data for advancedmd Api for url {} ";


	public static final String ERROR_WITH_CODE="Error status code while calling advancedmd api is Status code:: {} and errorBody:: {}";

	public static final String CONFIG_NOT_SET= " Config not set for deploymentId ";
	public static final String TRUE = "true";

	private AdvancedMDEngineConstants() {
	}
}
