package com.pes.integration.advancedmd.api;

import static java.util.Arrays.stream;

/**
 * ENUM class to define different type of API names to be called.
 */
public enum ApiName {

  NEW_PATIENT("new_patient"),
  GET_PATIENT_DEMOGRAPHICS("get_patient_demographics"),
  GET_PATIENT_INSURANCE("get_patient_insurance"),

  CHANGED_PATIENTS("changed_patients"),
  CANCEL_APPOINTMENT("cancel_appointment"),
  BOOKED_APPOINTMENTS("booked_appointments"),
  OPEN_APPOINTMENTS("open_appointments"),
  NEW_APPOINTMENT("new_appointment"),
  GET_COLUMNS("get_columns"),
  GET_PATIENT("patient_search"),
  GET_LOCATIONS("get_locations"),
  GET_PROVIDERS("get_providers"),
  GET_PROVIDER_SCHEDULE("get_provider_schedule"),
  HOLD_APPOINTMENTS("hold_appointments"),
  CHANGED_APPOINTMENTS("changed_appointments"),
  GET_PATIENTS("patient_lookup"),
  GET_APPOINTMENT("get_appointment"),
  GET_EPISODES("get_episodes"),
  SET_PATIENT_INSURANCE("set_patient_insurance"),
  GET_APPOINTMENT_TYPES("get_appointment_types"),
  UPDATE_PATIENT("update_patient"),
  FREEZE_APPOINTMENT("freeze_appointment"),
  GET_APPOINTMENT_CANCEL_REASONS("get_appointment_cancel_reasons"),
  GET_PATIENT_VISIT_REASONS("get_patient_visit_reasons"),
  VERIFY_PATIENT_PRIVACY_INFORMATION("verify_patient_privacy_information"),
  ADD_CUSTOM_FIELDS("add_custom_fields"),
  UPDATE_APPOINTMENT_CHECKIN("update_appointment_checkin"),

  CHECK_IF_PATIENT_REGISTERED("check_if_patient_registered"),
  REGISTER_PATIENT_DPPT("register_patient_with_department"),
  CHECK_IF_PATIENT_INSURED("is_patient_insured"),
  GET_PAYMENTS("get_payments"),

  MOVE_APPOINTMENT("move_appointment"),
  AUTO_ASSIGN_FORMS("auto_assign_forms"),
  LOOKUP_PORTAL_ACCOUNT("lookup_patient_portal_account"),
  SEND_INVITATION("send_invitation"),
  SAVE_PORTAL_ACCOUNT("save_patient_portal_account"),
  RESCHEDULE_APPOINTMENT("reschedule_appointment");
  String key;

  ApiName(String key) {
    this.key = key;
  }

  public String getKey() {
    return key;
  }

  public ApiName getEnum(String apiName) {
    return stream(values()).filter(api -> api.getKey().equals(apiName)).findFirst().orElse(null);
  }
}
