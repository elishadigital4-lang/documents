package com.pes.integration.advancedmd.api;

import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.advancedmd.component.AdvancedmdClientCaller;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.jsonmapper.JsonFormatConverter;
import com.pes.integration.jsonmapper.JsonObjectTerser;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;

import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.*;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.constant.EngineConstants.METHOD;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.COLON;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.FORWARD_SLASH;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;

@Slf4j
@Service
public class AdvancedmdApiCaller extends BaseApiCaller {

    private static Map<String, AmdApi> apiMap = new HashMap<>();


    @Autowired
    ConfigCache configCache;

    @Value("${epm.engine.component_id}")
    String componentId;

    @Value("${application.token.ttl}")
    Integer tokenTtl;

    @Autowired
    AdvancedmdClientCaller advancedmdClientCaller;

    @Autowired
    DataCacheManager cacheManager;

    @Autowired
    RedisService redisService;



    private AmdApi getAmdApi(String deploymentId) throws IHubException {
        AmdApi amdApi = apiMap.getOrDefault(deploymentId, null);
        if (Objects.isNull(amdApi)) {
            return apiCaller(deploymentId);
        }
        return amdApi;
    }

    public AmdApi apiCaller(String deploymentId) throws IHubException {
        String userId = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, USR_ID);
        String password = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, USR_PSWD);
        String officeCode = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, OFFICE_CODE);
        String endpoint = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, END_POINT);
        String appName = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, APP_NAME);
        String loginUrl = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ADVANCEDMD_CONFIG, LOGIN_URL);
        AmdApi amdApi = new AmdApi(loginUrl, userId, password, officeCode, appName, endpoint, deploymentId);
        apiMap.put(deploymentId, amdApi);
        return amdApi;
    }

    public void initializeObject() throws IHubException {
        requestConfig = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX,ADVANCEDMD_CONFIG,
                REQUEST_CONFIG_KEY_NAME, false);
        requestMapping = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, ADVANCEDMD_CONFIG,
                REQUEST_MAPPING_KEY_NAME, false);
        responseMapping = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, ADVANCEDMD_CONFIG,
                RESPONSE_MAPPING_KEY_NAME, false);
    }

    @Override
    protected Object callApi(JSONObject apiConfig, JSONObject requestObject) throws IHubException {
        final String deploymentId = getValue(requestObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID).toString();
        requestObject.remove(DocASAPConstants.Key.DEPLOYMENT_ID);
        AmdApi amdApi = getAmdApi(deploymentId);
        String response = "";
        JSONObject context;
        String token=redisService.get(deploymentId+"advancedmd_token");
        JSONObject contextObj = configCache.getContext(deploymentId);
            if (isEmpty(token) || contextObj == null) {
                token=getToken(componentId,amdApi);
         }
        String method = apiConfig.getString(METHOD);
        String url = apiConfig.getString(URL);
        String classConf = "";
        if (apiConfig.has(CLASS)) {
            classConf = apiConfig.getString(CLASS);
        }
        try {
            if (!NullChecker.isEmpty(classConf)) {
                JsonUtils.setValue(requestObject, "@action", url);
                JsonUtils.setValue(requestObject, CLASS_ANOT, classConf);
            }
            String request = null;
            log.info("TokenLog {}",sanitizeForLog(token));
            if (requestObject.has("@class")) {
                String xmlRpcUrl = configCache.getContext(deploymentId).getString("@webserver");
                url = xmlRpcUrl + LOGIN_CONSTANT;
                JsonUtils.setValue(requestObject, USER_CONTEXT, configCache.getContext(deploymentId));
                requestObject.remove("deployment_id");
                request = getPpMdMsgJson(requestObject);
                buildUrl(url, JsonUtils.getMapFromJson(requestObject),amdApi);
                response = request(method, url, request, token);
            } else {
                url = buildUrl(url, JsonUtils.getMapFromJson(requestObject),amdApi);
                response = request(method, url, requestObject.toString(), token);
            }
            long startTime = System.currentTimeMillis();// Record the start time
            if (apiConfig.has("custome") && (apiConfig.getString("custome").equalsIgnoreCase("true"))) {
                JSONArray responseArray = new JSONArray(response);
                JSONObject obj = new JSONObject();
                obj.put(PPMD_RESULTS, responseArray);
                response = String.valueOf(obj);
            }
            long endTime = System.currentTimeMillis(); // Record the end time
            double executionTimeSeconds = (endTime - startTime) / 1000.0;
            String formattedExecutionTime = String.format("%.2f", executionTimeSeconds);
            log.info("Execution Time For AdvancedMD_Client_Caller Get_Data: {} seconds", formattedExecutionTime);

        } catch (IHubException ihe) {
            log.error("Error Response received for API {} ", ihe.getCause().getMessage());
            throw ihe;
        } catch (Exception e) {
            log.error("Error Response received for API {} ", e.getMessage());
            throw e;
        }
        response = createCustomResponse(response);
        Object json = new JSONTokener(response).nextValue();
        if (json instanceof JSONArray) {
            return new JSONArray(json.toString());
        }
        return new JSONObject(json.toString());
    }
    private  String request(String method, String url, String requestObject, String token) throws IHubException {
        saveDataAsynchronously("AMDEpmRequest", requestObject, new JSONObject(), "DA", "AmdApi");
        if(method.equalsIgnoreCase("GET")){
            return advancedmdClientCaller.getData(method, url, "", token);
        }
        return advancedmdClientCaller.getData(method, url, requestObject, token);
    }

    @Override
    protected void getMappingConfig(String deploymentId){
        /*
         * not needed for this implementation
         */
    }

    @Override
    protected JSONObject customizeResponseMapping(JSONObject apiResponseMapping, String apiName, Object inputObject) {
        return null;
    }

    private StringBuilder getNewUrl(StringTokenizer tokenizer, Map<String, String> parameters){
        StringBuilder newUrl = new StringBuilder();
        while (tokenizer.hasMoreTokens()) {
            String urlPart = tokenizer.nextToken();
            if (urlPart.startsWith(COLON)) {
                urlPart = parameters.get(urlPart);
                if (urlPart != null) {
                    parameters.remove(urlPart);
                }
            }
            (newUrl).append(FORWARD_SLASH).append(urlPart);
        }
        return newUrl;
    }
    private String buildUrl(String url, Map<String, String> parameters,AmdApi amdApi) {
        StringTokenizer tokenizer = new StringTokenizer(url, FORWARD_SLASH);
        StringBuilder newUrl = getNewUrl(tokenizer, parameters);
        if(newUrl.toString().contains("?")){
            int index = newUrl.toString().indexOf('?');
            String baseUrl =  newUrl.substring(0,index);
            Object[] keyArray = parameters.keySet().toArray();
            StringBuilder sb = new StringBuilder();
            for(int i = 0; i < keyArray.length; i++){
                String key = keyArray[i].toString();
                if(url.contains(key)){
                    if(i==0){
                        sb.append(String.format("?%s=%s", key, parameters.get(key)));
                    }else sb.append(String.format("&%s=%s", key, parameters.get(key)));
                }
            }
            newUrl = new StringBuilder(baseUrl + sb.toString());
        }
        return String.format("%s%s", amdApi.getEndpoint(), newUrl.toString());
    }

    private String getToken(String componentId,AmdApi amdApi) throws IHubException {
        log.info("Getting token with componentId :"+componentId+" and deploymentId :"+amdApi.getDeploymentId());
        JSONObject context;
        String token = null;
        String tokenStr = redisService.get(amdApi.getDeploymentId());
        log.info("tokenStr is :"+sanitizeForLog(tokenStr));
        if (!NullChecker.isEmpty(tokenStr)){
            context = new JSONObject(tokenStr);
            log.info(sanitizeForLog("before fetching context ::" + context));
            if (!NullChecker.isEmpty(context)) {
                token = context.getString("#text");
            } else {
                return getContextAndToken(componentId,amdApi);
            }
        } else {
            return getContextAndToken(componentId,amdApi);
        }
        return token;
    }

    private String getRedirectURL(String reqBody,String componentId,AmdApi amdApi) throws IHubException {
        log.info("Getting redirect URL");
        String response = advancedmdClientCaller.getRedirectURL("POST", amdApi.getLoginUrl(), reqBody, componentId);
        String webserverUrl = "";
        if (response != null) {
            JSONObject requestJSON = new JSONObject(response);
            JSONObject data = requestJSON.getJSONObject(PPMD_RESULTS);
            if (data.has(RESULTS)) {
                JSONObject resultJson = data.getJSONObject(RESULTS);
                JSONObject userContext = resultJson.getJSONObject(USER_CONTEXT);
                webserverUrl = userContext.getString("@webserver");
                webserverUrl = webserverUrl + LOGIN_CONSTANT;
            }
        }
        log.info(webserverUrl);
        return webserverUrl;
    }

    private String getContextAndToken(String componentId,AmdApi amdApi) throws IHubException {
        String serverTimezone;
        String token = null;
        JSONObject context;
        log.info("Getting context and token with ttl is : "+tokenTtl);
        JSONObject loginInput = new JSONObject();
        loginInput.accumulate("@action", "login");
        loginInput.accumulate("@class", "login");
        loginInput.accumulate("@username", amdApi.getUserId());
        loginInput.accumulate("@psw", amdApi.getPassword());
        loginInput.accumulate("@officecode", amdApi.getOfficeCode());
        loginInput.accumulate("@appname", amdApi.getAppName());
        String reqBody = getPpMdMsgJson(loginInput);
        String loginEndPoint = getRedirectURL(reqBody,componentId,amdApi);
        String response = advancedmdClientCaller.getRedirectURL("POST", loginEndPoint, reqBody,componentId);
        if (response != null) {
            JSONObject requestJSON = new JSONObject(response);
            JSONObject data = requestJSON.getJSONObject(PPMD_RESULTS);
            if (data.has(RESULTS)) {
                JSONObject resultJson = data.getJSONObject(RESULTS);
                String success = resultJson.getString("@success");
                if (success.equalsIgnoreCase(ONE)) {
                    context = resultJson.getJSONObject(USER_CONTEXT);
                    token = context.getString("#text");
                    serverTimezone = context.getString("@servertimezone");
                    configCache.setServerTimeZoneMap(amdApi.getDeploymentId(), serverTimezone);
                    configCache.setContext(amdApi.getDeploymentId(),tokenTtl, context);
                } else {
                    JSONObject error = data.getJSONObject("Error");
                    JSONObject fault = error.getJSONObject("Fault");
                    JSONObject detail = fault.getJSONObject("detail");
                    String errorMessage = detail.getString("source");
                    String detailedMessage = detail.getString("description");
                    log.error("Error received from AuthenticateToLogin API - "+ errorMessage+" "+detailedMessage);
                    throw new IHubException(INVALID_REQUEST.getErrorCode(), errorMessage +" "+ detailedMessage);
                }
            }
        }
        redisService.saveWithTtl(amdApi.getDeploymentId()+"advancedmd_token", token,
                tokenTtl);
        return token;
    }

    private String getPpMdMsgJson(JSONObject input) throws IHubException {
        JSONObject ppMdMsgJson = new JSONObject();
        JsonUtils.setValue(input, "@nocookie", ONE);
        ppMdMsgJson.accumulate("ppmdmsg", input);
        return ppMdMsgJson.toString();
    }
}
