package com.pes.integration.advancedmd.component;

import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.handlers.GetAppointmentTypesHandler;
import com.pes.integration.advancedmd.handlers.GetColumnProvidersHandler;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.factory.BaseHandlerFactory;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.FileUtil;
import com.pes.integration.utils.LogUtil;
import lombok.extern.slf4j.Slf4j;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;


import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.FilterDataService;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.core.runtime.IConfigurationElement;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.ADVANCEDMD_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;

import java.text.ParseException;
import java.util.*;


import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.CharacterConstants.COMMA;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PROVIDER_LIST;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.TRUE;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_LOADING_CONFIG;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.join;

/**
 * This class is responsible for carrying out common operations specific to all AdvancedMD Handlers
 */
@Slf4j
@Service
public class HandlerUtils {

    @Autowired
    DataCacheManager dataCacheManager;


    @Autowired
    IHubDataServiceDelegator iHubDataServiceDelegator;

    @Autowired
    ConfigCache configCache;
    @Autowired
    RedisService redisService;

    @Autowired
    GetColumnProvidersHandler getColumnProvidersHandler;

    @Autowired
    GetAppointmentTypesHandler getAppointmentTypesHandler;

    public String getColumnStr(String deploymentId) throws IHubException {
        String columnStr = configCache.getColumnIdMap(deploymentId);
        if (columnStr == null || columnStr.isEmpty()) {
            setColumn(deploymentId);
            columnStr = configCache.getColumnIdMap(deploymentId);
        }
        return columnStr;
    }

    public Map<String, String> getApptTypeMap(String deploymentId) throws IHubException {
        Map<String, String> apptTypeMap = configCache.getAppointmentTypeMap(deploymentId);
        if (apptTypeMap == null || apptTypeMap.isEmpty()) {
            getApptTypes(deploymentId);
            apptTypeMap = configCache.getAppointmentTypeMap(deploymentId);
        }
        return apptTypeMap;
    }

    //
    private void setColumn(String deploymentId) throws IHubException {
        JSONObject inputObject = new JSONObject();
        JsonUtils.setValue(inputObject, DEPLOYMENT_ID, deploymentId);
        getColumnProvidersHandler.doExecute(inputObject);
    }

    public Map<String, String> getColProviderMap(String deploymentId) throws IHubException {
        Map<String, String> colProviderIdsMap = configCache.getColProviderIdsMap(deploymentId);
        if (colProviderIdsMap == null || colProviderIdsMap.isEmpty()) {
            setColumn(deploymentId);
            colProviderIdsMap = configCache.getColProviderIdsMap(deploymentId);
        }
        return colProviderIdsMap;
    }

    public boolean isColWithProv(String deploymentId, String epmPrefix) throws IHubException {
        try {
            String isColWithProv = (String) dataCacheManager.getConfiguration(epmPrefix, deploymentId, ADVANCEDMD_CONFIG, "isColWithProv");
            return isColWithProv.equalsIgnoreCase(UtilitiesConstants.TRUE);
        } catch (IHubException e) {
            return false;
        }
    }

    public Map<String, String> getProviderMap(String deploymentId) throws IHubException {
        Map<String, String> providerIdsMap = configCache.getProviderIdsMap(deploymentId);
        if (providerIdsMap == null || providerIdsMap.isEmpty()) {
            setColumn(deploymentId);
            providerIdsMap = configCache.getProviderIdsMap(deploymentId);
        }
        return providerIdsMap;
    }

    private void getApptTypes(String deploymentId) throws IHubException {
        JSONObject inputObject = new JSONObject();
        JsonUtils.setValue(inputObject, DEPLOYMENT_ID, deploymentId);
        getAppointmentTypesHandler.doExecute(inputObject);
    }


  public static void setExternalPatientId(JSONObject outputObject,Object exPatientId) throws IHubException {
    log.info("exPatientId: "+ sanitizeForLog(String.valueOf(exPatientId)));
    if(!NullChecker.isEmpty(exPatientId)){
      JsonUtils.setValue(outputObject, DocASAPConstants.Key.PATIENT_ID, exPatientId.toString().substring(3));
    }
  }

    public Map<String, String> getApptTypeColorMap(String deploymentId) throws IHubException{

        Map<String, String> apptTypeColorMap = configCache.getAppointmentTypeColorMap(deploymentId);
        if (apptTypeColorMap == null || apptTypeColorMap.isEmpty()) {
            getApptTypes(deploymentId);
            apptTypeColorMap = configCache.getAppointmentTypeColorMap(deploymentId);
        }
        return apptTypeColorMap;
    }
    public String getSyncRunTime(String deploymentId) throws IHubException{
        log.info(deploymentId);
        String lastSyncTime = null;
        try{
            lastSyncTime = getSyncTIme(deploymentId, lastSyncTime);
            lastSyncTime = prepareDateAndTime(deploymentId, lastSyncTime);
        } catch(Exception e) {
            log.error("Error in getting next sync run time {}",e.getMessage());
        }
        return lastSyncTime;
    }

    private String getSyncTIme(String deploymentId, String lastSyncTime) {
        try {
            lastSyncTime = redisService.get(deploymentId);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return lastSyncTime;
    }

    private String prepareDateAndTime(String deploymentId, String lastSyncTime)
            throws IHubException, ParseException {
        String timezone;
        if(NullChecker.isEmpty(lastSyncTime)) {
            deploymentId = deploymentId.split("_")[0];
            timezone = getTimeZone(deploymentId);
            lastSyncTime = getSyncDateFromDB(deploymentId, lastSyncTime, timezone);
            if(NullChecker.isEmpty(lastSyncTime))
                lastSyncTime = getCurrentDateMinus2Mins(lastSyncTime, timezone);
            lastSyncTime = DateUtils.convertDateFormatWithTimeZone(lastSyncTime, AdvancedMDConstants.DATE_TIME_FORMAT_WITHOUT_AM_PM, AdvancedMDConstants.DATE_TIME_FORMAT_AM_PM,timezone);
        }
        return lastSyncTime;
    }

    private String getSyncDateFromDB(String deploymentId, String lastSyncTime, String timezone) {
        try {
            lastSyncTime = getLastSuccessfulSyncDate(deploymentId);
        }catch(Exception e) {
            log.info(e.getMessage());
            lastSyncTime = getCurrentDateMinus2Mins(lastSyncTime, timezone);
        }
        return lastSyncTime;
    }

    private  String getCurrentDateMinus2Mins(String lastSyncTime, String timezone) {
        try {
            lastSyncTime = DateUtils.getCurrentDateWithMinusMin(AdvancedMDConstants.DATE_TIME_FORMAT_WITHOUT_AM_PM, timezone, 2);
        }catch(Exception e) {log.info(e.getMessage());}
        return lastSyncTime;
    }

    public String getTimeZone(String deploymentId) throws IHubException{
        String timeZone = "";
        try{
            timeZone = (String) dataCacheManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.TIME_ZONE,false);
        } catch(Exception e){
            log.info("Org specific time zone not set for  deployment ID: " + deploymentId + ". Default would be used.");
            timeZone = (String) dataCacheManager.getStoredComponentConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.TIME_ZONE,false);
        }
        return timeZone;
    }

    public String getLastSuccessfulSyncDate(String deploymentId) throws IHubException {

        Map<String, String> requestHeaderParameters = new HashMap<>();
        requestHeaderParameters.put(UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
        requestHeaderParameters.put(UtilitiesConstants.JsonConstants.COMMAND_CODE, "123");

        String response = iHubDataServiceDelegator.getOrgLastSyncRunTime(deploymentId,requestHeaderParameters);
        JSONObject newObj = new JSONObject(response);
        return JsonUtils.getValue(newObj, "last_sync_run_time").toString();

    }

    public static JSONObject getChangeApptRequestMappingJson() throws IHubException{
        String propertyString = FileUtil.readFileAsString("am_change_appt_mapping.json");
        JSONObject changeApptMapJson = new JSONObject();
        if(!NullChecker.isEmpty(propertyString)){
            changeApptMapJson = new JSONObject(propertyString);
        }
        return changeApptMapJson;
    }



    public String getColumnId(String code, String deploymentId, boolean isColWithProv) throws IHubException{
        Map<String, String> columnHeaderMap = null;
        if(isColWithProv) {
            columnHeaderMap = configCache.getColumnHeaderWithColMap(deploymentId);
            if (columnHeaderMap == null || columnHeaderMap.isEmpty()) {
                setColumn(deploymentId);
                columnHeaderMap = configCache.getColumnHeaderWithColMap(deploymentId);
            }
        } else {
            columnHeaderMap = configCache.getColumnHeaderMap(deploymentId);
            if (columnHeaderMap == null || columnHeaderMap.isEmpty()) {
                setColumn(deploymentId);
                columnHeaderMap = configCache.getColumnHeaderMap(deploymentId);
            }
        }
        return columnHeaderMap.get(code);
    }


}
