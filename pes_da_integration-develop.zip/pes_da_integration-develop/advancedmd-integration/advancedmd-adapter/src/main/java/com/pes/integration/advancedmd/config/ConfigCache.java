package com.pes.integration.advancedmd.config;

import com.pes.integration.component.RedisService;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;


@Component
public class ConfigCache {
	private Map<String, Map<String,String>> locationMap = new HashMap<>();
	private Map<String, String> syncRunTimeMap = new HashMap<>();
	private Map<String, String> serverTimeZoneMap = new HashMap<>();
	private Map<String, String> patientSyncRunTimeMap = new HashMap<>();
	private Map<String, Map<String,String>> providerIdsMap = new HashMap<>();
	private Map<String, String> columnIdMap = new HashMap<>();
	private Map<String, Map<String,String>> columnHeaderMap = new HashMap<>();
	Map<String, Map<String, String>> appointmentTypeMap = new HashMap<>();
	private Map<String, Map<String,String>> columnHeaderWithColMap = new HashMap<>();
	private Map<String, Map<String, String>> appointmentTypeColorMap = new HashMap<>();
	
	
	private Map<String, Map<String,String>> colProviderIdsMap = new HashMap<>();

	@Autowired
	RedisService redisService;

	
	public JSONObject getContext(String deploymentId) {
		String context =  redisService.get(deploymentId+"_context");
		if(context != null ) {
			return new JSONObject(context);
		}
		return null;
	}

	public void setContext(String deploymentId,int ttl, JSONObject context) {
		redisService.saveWithTtl(deploymentId+"_context", context.toString(),ttl);
	}
	
	public String getSyncRunTimeMap(String deploymentId) {
		return syncRunTimeMap.get(deploymentId);
	}

	public void setSyncRunTimeMap(String deploymentId, String syncRunTime) {
		syncRunTimeMap.put(deploymentId, syncRunTime);
	}
	
	public String getPatientSyncRunTimeMap(String deploymentId) {
		return patientSyncRunTimeMap.get(deploymentId);
	}

	public void setPatientSyncRunTimeMap(String deploymentId, String syncRunTime) {
		patientSyncRunTimeMap.put(deploymentId, syncRunTime);
	}
	
	public String getServerTimeZoneMap(String deploymentId) {
		return serverTimeZoneMap.get(deploymentId);
	}

	public void setServerTimeZoneMap(String deploymentId, String timezone) {
		serverTimeZoneMap.put(deploymentId, timezone);
	}
	
	public Map<String, String> getProviderIdsMap(String deploymentId) {
		return providerIdsMap.get(deploymentId);
	}

	public void setProviderIdsMap(String deploymentId, Map<String, String> providerIdMap) {
		providerIdsMap.put(deploymentId, providerIdMap);
	}
	
	public String getColumnIdMap(String deploymentId) {
		return columnIdMap.get(deploymentId);
	}

	public void setColumnIdMap(String deploymentId, String timezone) {
		columnIdMap.put(deploymentId, timezone);
	}
	
	public Map<String, String> getColumnHeaderMap(String deploymentId) {
		return columnHeaderMap.get(deploymentId);
	}

	public void setColumnHeaderMap(String deploymentId, Map<String, String> map) {
		columnHeaderMap.put(deploymentId, map);
	}
	
	public Map<String, String> getLocationMap(String deploymentId) {
		return locationMap.get(deploymentId);
	}

	public void setLocationMap(String deploymentId, Map<String, String> map) {
		locationMap.put(deploymentId, map);
	}
	
	public Map<String, String> getAppointmentTypeMap(String deploymentId) {
		return appointmentTypeMap.get(deploymentId);
	}

	public void setAppointmentTypeMap(String deploymentId, Map<String, String> map) {
		appointmentTypeMap.put(deploymentId, map);
	}

	public Map<String, String> getColProviderIdsMap(String deploymentId) {
		return colProviderIdsMap.get(deploymentId);
	}

	public void setColProviderIdsMap(String deploymentId, Map<String, String> map) {
		colProviderIdsMap.put(deploymentId, map);
	}
	
	public Map<String, String> getColumnHeaderWithColMap(String deploymentId) {
		return columnHeaderWithColMap.get(deploymentId);
	}

	public void setColumnHeaderWithColMap(String deploymentId, Map<String, String> map) {
		columnHeaderWithColMap.put(deploymentId, map);
	}
	
	public Map<String, String> getAppointmentTypeColorMap(String deploymentId) {
		return appointmentTypeColorMap.get(deploymentId);
	}

	public void setAppointmentTypeColorMap(String deploymentId, Map<String, String> map) {
		appointmentTypeColorMap.put(deploymentId, map);
	}

}