package com.pes.integration.advancedmd.component;

import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


import static com.pes.integration.constant.UtilitiesConstants.*;

@Slf4j
@Component
public class EPMFilter {

  @Autowired
  DataCacheManager dataCacheManager;

  public List<String> getAllowedLocations(String deploymentId) {
    List<String> allowedLocations = new ArrayList<>();
    try {
      JSONArray filterArray = (JSONArray) dataCacheManager.getStoredProvidersConfig(
              AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, GENERIC_CONFIG, EPM_FILTERS, false);
      for (int i = 0; i < filterArray.length(); i++) {
        JSONObject filterObject = filterArray.getJSONObject(i);
        if (filterObject.has(LOCATION_ID)) {
          allowedLocations.add(filterObject.getString(LOCATION_ID));
        }
      }
    } catch (Exception e) {
      log.error("Error {} ", e.getMessage());
      //Allow all in case of exception.
    }
    return allowedLocations;
  }
}