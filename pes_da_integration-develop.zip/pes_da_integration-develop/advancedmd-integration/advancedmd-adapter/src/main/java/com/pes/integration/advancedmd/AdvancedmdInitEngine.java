package com.pes.integration.advancedmd;

import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.exceptions.IHubException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.*;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.constant.BaseEPMConstants.BASE_URL;
import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.UtilitiesConstants.*;

@Component
public class AdvancedmdInitEngine {

    @Autowired
    BaseInitEngine baseInitEngine;

    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    public void init() throws IHubException {
            String[] configTypes = {GENERIC_CONFIG, ADVANCEDMD_CONFIG,
                    ENVIRONMENT_CONFIG, FILTER_CONFIG};

            initialiseEPMConstants(AdvancedMDConstants.DATE_FORMAT,
                    DATE_TIME_FORMAT,
                    TIME_FORMAT,
                    BASE_URL,
                    AdvancedMDEngineConstants.TRUE,
                    EPM_NAME_PREFIX,
                    ADVANCEDMD_CONFIG,
                    RETRY_COUNT,
                    REQUEST_MAPPING_KEY_NAME,
                    RESPONSE_MAPPING_KEY_NAME,
                    REQUEST_CONFIG_KEY_NAME,
                    RESPONSE_CODES_MAPPING_KEY_NAME,
                    configTypes);
            baseInitEngine.initializeConfig(EPM_NAME_PREFIX, false);
            advancedmdApiCaller.initializeObject();

    }
}