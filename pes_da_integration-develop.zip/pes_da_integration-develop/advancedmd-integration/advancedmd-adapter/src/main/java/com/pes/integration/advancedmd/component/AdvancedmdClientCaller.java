package com.pes.integration.advancedmd.component;

import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.MetricsUtil.metricClientRequestCount;
import static com.pes.integration.utils.MetricsUtil.metricClientSuccessCount;
import static com.pes.integration.utils.MetricsUtil.metricClientErrorCount;
import static org.springframework.http.HttpMethod.valueOf;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Component
@Slf4j
public class AdvancedmdClientCaller {

    @Autowired
    WebClient webClient;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;
    public static final List<String> IGNORABLE_ERRORS = Arrays.asList("Client Error: Duplicate name/DOB found", "Requested appointment overlaps with existing appointment");

    @Observed(name = "integration.getRedirectURL", contextualName = "integration")
    public String getRedirectURL(String httpMethod, String url, String body, String componentId) {
        metricClientRequestCount(engineName, appDescription, httpMethod+" - "+ url);
        return webClient.method(valueOf(httpMethod))
                .uri(url)
                .headers(headers -> headers.set("Accept", "application/json"))
                .headers(headers -> headers.set("user-agent", "Application"))
              //  .headers(headers -> headers.set("component_id", componentId))
                .headers(headers -> headers.set(UtilitiesConstants.IS_EPM_REQUEST, UtilitiesConstants.TRUE))
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    ERROR_WITH_CODE,
                                    clientResponse.statusCode(), errorBody);
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(
                                    new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,
                                            errorBody));
                        }))
                .bodyToMono(String.class)
                .doOnError(ex ->
                {
                    log.error(
                            ERROR_WITH_MESSAGE, ex.getMessage());
                })
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                    log.info(SUCCESS_MESSAGE, url);
                }).block();
    }

    @Observed(name = "integration.getApiData", contextualName = "integration")
    public String getPostData(String httpMethod, String url, String body, String token) {
        metricClientRequestCount(engineName, appDescription, httpMethod+" - "+ url);
        return webClient.method(valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .headers(header -> {
                    header.setBearerAuth(token);
                })
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    ERROR_WITH_CODE,
                                    clientResponse.statusCode(), errorBody);
                                metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(
                                    new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,
                                            errorBody));
                        }))
                .bodyToMono(String.class)
                .doOnError(ex -> {
                    log.error(
                            ERROR_WITH_MESSAGE, ex.getMessage());
                })
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                    log.info(SUCCESS_MESSAGE, url);
                }).block();
    }


    @Observed(name = "integration.getApiData", contextualName = "integration")
    public String getData(String httpMethod, String url, String body, String token) {
        metricClientRequestCount(engineName, appDescription, httpMethod+" - "+ url);
        return webClient.method(valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .headers(header -> {
                    header.setBearerAuth(token);
                })
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    "Error status code while calling advancedmd api is Status code:: {} and errorBody:: {} with TokenLog {}",
                                    clientResponse.statusCode(), errorBody, sanitizeForLog(token));
                                metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(
                                    new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,
                                            errorBody));
                        }))
                .bodyToMono(String.class)
                .onErrorMap(ex -> {
                    log.error(
                            ERROR_WITH_MESSAGE, ex.getMessage());
                    return new IHubException(StatusCodes.EPM_INTERNAL_ERROR, ex.getMessage(),"");
                })
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                    log.info(SUCCESS_MESSAGE, sanitizeForLog(url));
                }).block();
    }
}
