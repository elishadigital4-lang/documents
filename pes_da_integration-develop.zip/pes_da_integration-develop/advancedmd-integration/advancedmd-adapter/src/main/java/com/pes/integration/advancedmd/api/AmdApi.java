package com.pes.integration.advancedmd.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AmdApi {

    String loginUrl;
    String userId;
    String password;
    String officeCode;
    String appName;
    String endpoint;
    String deploymentId;
}
