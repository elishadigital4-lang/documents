package com.pes.integration.advancedmd.handlers;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.api.ApiName.GET_COLUMNS;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.COLUMNS;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.PROV_COLUMN_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.PROVIDER_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;

@Service
@Slf4j
public class GetColumnProvidersHandler extends BaseHandler {

	@Autowired
	AdvancedmdApiCaller advancedmdApiCaller ;

	@Autowired
	ConfigCache configCache;

	@Override
	public JSONObject doExecute(JSONObject inputObject) throws IHubException {
		log.info("GetColumnProvidersHandler::doExecute");
		JSONObject outputObject = new JSONObject();
		try {
			String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
			outputObject = advancedmdApiCaller.call(deploymentId, GET_COLUMNS.getKey(), inputObject, "");
			JSONArray columns = (JSONArray) JsonUtils.getValue(outputObject, COLUMNS);
			outputObject.clear();
			StringBuilder columnIdsStr = new StringBuilder();
			Map<String, String> providerIdsMap = new HashMap<>();
			Map<String, String> columnHeaderWithColMap = new HashMap<>();
			Map<String, String> columnHeaderMap = new HashMap<>();
			Map<String,String> colProviderIdsMap = new HashMap<>();
			if (columns != null) {
				for (int i = 0; i < columns.length(); i++) {
					columnIdsStr = populateColProviderIdsMap(columns, columnIdsStr, providerIdsMap,
							columnHeaderWithColMap, columnHeaderMap, colProviderIdsMap, i);
				}
			}
			log.info("Provider Map after insertion "+providerIdsMap);
			configCache.setProviderIdsMap(deploymentId, providerIdsMap);
			configCache.setColumnIdMap(deploymentId, columnIdsStr.toString());
			configCache.setColumnHeaderMap(deploymentId, columnHeaderMap);
			configCache.setColProviderIdsMap(deploymentId, colProviderIdsMap);
			configCache.setColumnHeaderWithColMap(deploymentId, columnHeaderWithColMap);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return outputObject;
	}

	private StringBuilder populateColProviderIdsMap(JSONArray columns, StringBuilder columnIdsStr,
													Map<String, String> providerIdsMap, Map<String, String> columnHeaderWithColMap,
													Map<String, String> columnHeaderMap, Map<String, String> colProviderIdsMap, int i) {
		try {
			JSONObject columnObject = columns.getJSONObject(i);
			String columnId = null;
			String providerId = null;
			try {
				columnId = JsonUtils.getValue(columnObject, PROV_COLUMN_ID).toString();
				providerId = JsonUtils.getValue(columnObject, PROVIDER_ID).toString();
			} catch (NullPointerException e) {
				log.info("error in getting the columnId or providerId {} ", e.getMessage());
			}
			String heading = JsonUtils.getValue(columnObject, "Heading").toString();
				log.info("Customizing in the provider id ( "+columnId, columnId + CharacterConstants.ATMARK + providerId+" )");
				providerIdsMap.put(columnId, columnId + CharacterConstants.ATMARK + providerId);
				columnHeaderMap.put(heading, providerId);
				columnHeaderWithColMap.put(heading, columnId + CharacterConstants.ATMARK + providerId);
				colProviderIdsMap.put(columnId, providerId);
			if (i + 1 == columns.length()) {
				columnIdsStr = columnIdsStr.append(columnId);
			} else columnIdsStr = columnIdsStr.append(columnId).append("-");
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return columnIdsStr;
	}
}
