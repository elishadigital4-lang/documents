package com.pes.integration.advancedmd.handlers;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.api.ApiName.GET_APPOINTMENT_TYPES;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_TYPE_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_TYPES;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;

/**
 * This class implements handling of getting the list of providers.
 *
 * @author rkushwah
 */

@Slf4j
@Service
public class GetAppointmentTypesHandler extends BaseHandler {

    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    @Autowired
    ConfigCache configCache;

    @Override
    public JSONObject doExecute(JSONObject inputObject) {
        JSONObject outputObject = new JSONObject();
        try {
            String deploymentId = (String) JsonUtils.getValue(inputObject, DEPLOYMENT_ID);
            JsonUtils.setValue(inputObject, "appttype", BLANK);
            inputObject.remove("deployment_id");
            outputObject = advancedmdApiCaller.call(deploymentId, GET_APPOINTMENT_TYPES.getKey(), inputObject, "");
            JSONArray apptTypesArray = (JSONArray) JsonUtils.getValue(outputObject, APPOINTMENT_TYPES);
            Map<String, String> appointmentTypeMap = new HashMap<>();
            Map<String, String> appointmentTypeColorMap = new HashMap<>();
            if (!NullChecker.isEmpty(apptTypesArray)) {
                for (int i = 0; i < apptTypesArray.length(); i++) {
                    JSONObject apptTypeObject = apptTypesArray.getJSONObject(i);
                    String apptTypeId = ((String) JsonUtils.getValue(apptTypeObject, APPOINTMENT_TYPE_ID)).substring(7); // ap_type12
                    String name = (String) JsonUtils.getValue(apptTypeObject, "ShortName");
                    String color = (String) JsonUtils.getValue(apptTypeObject, "Color");
                    appointmentTypeMap.put(name, apptTypeId);
                    appointmentTypeColorMap.put(apptTypeId, color);
                }
            }
            configCache.setAppointmentTypeMap(deploymentId, appointmentTypeMap);
            configCache.setAppointmentTypeColorMap(deploymentId, appointmentTypeColorMap);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return outputObject;
    }
}
