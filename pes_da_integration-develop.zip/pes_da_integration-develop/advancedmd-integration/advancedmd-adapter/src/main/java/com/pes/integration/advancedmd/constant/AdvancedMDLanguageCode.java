package com.pes.integration.advancedmd.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum AdvancedMDLanguageCode{		
	UNKNOWN(0),
	ABKHAZIAN(1),
	AFAR(2),
	AFRIKAANS(3),
	AKAN(4),
	ALBANIAN(5),
	AMHARIC(6),
	ARABIC(7),
	ARAGONESE(8),
	ARMENIAN(9),
	ASSAMESE(10),
	AVARIC(11),
	AVESTAN(12),
	AYMARA(13),
	AZERBAIJANI(14),
	BAMBARA(15),
	BASHKIR(16),
	BASQUE(17),
	BELARUSIAN(18),
	BENGALI(19),	
	BISLAMA(21),	
	BOSNIAN(23),
	BRETON(24),
	BULGARIAN(25),
	BURMESE(26),
	CATALAN(27),	
	CHAMORRO(29),
	CHECHEN(30),
	CHICHEWA(31),
	CHINESE(32),	
	CHUVASH(34),
	CORNISH(35),
	CORSICAN(36),
	CREE(37),
	CROATIAN(38),
	CZECH(39),
	DANISH(40),
	DECLINED_TO_SPECIFY(186),
	DUTCH(42),
	DIVEHI(41),
	DZONGKHA(43),
	ENGLISH(44),
	ESPERANTO(45),
	ESTONIAN(46),
	FAROESE(48),
	FIJIAN(49),
	EWE(47),
	FINNISH(50),
	FRENCH(51),
	FULAH(52),
	GAELIC(53),
	GALICIAN(54),
	GANDA(55),
	GEORGIAN(56),
	GERMAN(57),	
	GUARANI(59),
	GUJARATI(60),
	HAITIAN(61),
	HAUSA(62),
	HEBREW(63),
	HERERO(64),
	HINDI(65),
	HMONG(187),
	HUNGARIAN(67),
	ICELANDIC(68),
	IDO(69),
	IGBO(70),
	INDONESIAN(71),
	INTERLINGUA(72),
	INTERLINGUE(73),
	INUKTITUT(74),
	INUPIAQ(75),
	IRISH(76),
	ITALIAN(77),
	JAPANESE(78),
	SPANISH(149);	

	int key;
	AdvancedMDLanguageCode(int key){
		this.key= key;
	}
	
	public int getKey(){
		return key;
	}
	public static AdvancedMDLanguageCode getEnum(int type) {
		log.info("get Enum for type: {}", type);
		AdvancedMDLanguageCode result = null;
		for(AdvancedMDLanguageCode api : values()){
			if(api.getKey()== type){
				result = api;
				break;
			}
		}
		log.info("result: {}", result);
		return result;
	}
}
