package com.pes.integration.advancedmd;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.KafkaService;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InitEngineTest {

    @InjectMocks
    private InitEngine initEngine;
    @Mock
    DataCacheManager cacheManager;
    @Mock
    private AdvancedmdInitEngine advancedmdInitEngine;
    @Mock
    KafkaService kafkaService;
    @Test
    void initCallsAdvancedmdInitEngineInit() throws IHubException {
        doNothing().when(advancedmdInitEngine).init();
        doReturn(new JSONObject()).when(cacheManager).getRedisConfig(any());
        doNothing().when(kafkaService).createTopicAndListener(any(),any(),any());
        initEngine.init();
        verify(advancedmdInitEngine, times(1)).init();
    }

}