package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;

import static com.pes.integration.advancedmd.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.*;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.ADVANCEDMD_CONFIG;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.DOB;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.SUCCESS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NewPatientHandlerServiceTest {

    @InjectMocks
    @Spy
    NewPatientHandlerService newPatientHandlerService;

    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    DataTransactionService dataTransactionService;

    @Mock
    DataCacheManager dataCacheManager;

    @Mock
    HandlerUtils handlerUtils;

    @Mock
    MatchPatientHandler matchPatientHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetPatientInsuranceInfo_Exception() throws Exception {
        String deploymentId = "testDeploymentId";
        JSONObject inputObject = new JSONObject();
        inputObject.put("deployment_id", deploymentId);

        // Force advancedmdApiCaller.call to throw an exception
        when(advancedmdApiCaller.call(eq(deploymentId), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), eq(inputObject), anyString()))
                .thenThrow(new RuntimeException("API error"));

        // Act
        JSONObject result = newPatientHandlerService.getPatientInsuranceInfo(deploymentId, inputObject);

        // Assert
        assertNull(result); // insuranceResponse should be null
    }

    @Test
    void testDoExecuteValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedJsonUtils.when(() -> JsonUtils.setValue(any(), any(), any())).thenAnswer(invocation -> invocation);
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");
//                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation",new JSONArray()));
                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("PatientFirstName", "11"))));

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    JSONObject demographicsResponse = new JSONObject();
                    demographicsResponse.put("dob", "2000-01-01");

                    JSONObject insuranceResponse = new JSONObject();
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);

                    doReturn(createPatientResponse).when(newPatientHandlerService).createNewPatient(any());
                    when(newPatientHandlerService.getPatientDemographics(any())).thenReturn(demographicsResponse);
                    when(newPatientHandlerService.getPatientInsuranceInfo(any())).thenReturn(insuranceResponse);
                    when(newPatientHandlerService.prepareResponse(any(), any())).thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(), anyString()))
                            .thenReturn(demographicsResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(), anyString()))
                            .thenReturn(insuranceResponse);
                    doNothing().when(dataTransactionService).logData(any(), eq(CREATE_PATIENT.getKey()), eq(SUCCESS.getKey()),
                            anyString());

                    // Act
                    JSONObject result = newPatientHandlerService.doExecute(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                }
            }
        }
    }

    @Test
    void testSetNotificationPreferenceInResponseObject_exception() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject responseObject = new JSONObject();

        // Use reflection to access the private method
        Method method = NewPatientHandlerService.class.getDeclaredMethod("setNotificationPreferenceInResponseObject", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        // Simulate exception by passing a JSONObject that will cause copyKey to throw
        // For example, pass nulls to trigger a NullPointerException
        method.invoke(newPatientHandlerService, null, null);

        // No assertion needed, just ensure no exception escapes and log is called
    }

    @Test
    public void getPatMatchingLayerPriConfStr_exception() throws Exception {
        String deploymentId = "testDeploymentId";
        // Mock the exception
        when(dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenThrow(new RuntimeException("Config not found"));

        Method method = NewPatientHandlerService.class.getDeclaredMethod("getPatMatchingLayerPriConfStr", String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(newPatientHandlerService, deploymentId);

        assertNull(result);
    }

    @Test
    public void getPatMatchingAlgoConfigStr_exception() throws Exception {
        String deploymentId = "testDeploymentId";
        // Mock the exception
        when(dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenThrow(new RuntimeException("Config not found"));

        Method method = NewPatientHandlerService.class.getDeclaredMethod("getPatMatchingAlgoConfigStr", String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(newPatientHandlerService, deploymentId);

        assertEquals("", result);
    }

    @Test
    void testDoExecute_DobParseException() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedJsonUtils.when(() -> JsonUtils.setValue(any(), any(), any())).thenAnswer(invocation -> invocation);
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");
                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("PatientFirstName", "11"))));

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    JSONObject demographicsResponse = new JSONObject();
                    demographicsResponse.put("dob", "2000-01-01");

                    JSONObject insuranceResponse = new JSONObject();
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);

                    doReturn(createPatientResponse).when(newPatientHandlerService).createNewPatient(any());
                    when(newPatientHandlerService.getPatientDemographics(any())).thenReturn(demographicsResponse);
                    when(newPatientHandlerService.getPatientInsuranceInfo(any())).thenReturn(insuranceResponse);
                    when(newPatientHandlerService.prepareResponse(any(), any())).thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(), anyString()))
                            .thenReturn(demographicsResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(), anyString()))
                            .thenReturn(insuranceResponse);
                    doNothing().when(dataTransactionService).logData(any(), eq(CREATE_PATIENT.getKey()), eq(SUCCESS.getKey()),
                            anyString());

                    // Mock convertDateFormat to throw ParseException
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(EPM_DATE_FORMAT), eq(DOCASAP_DATE_FORMAT)))
                            .thenThrow(new ParseException("Invalid date", 0));

                    // Act & Assert
                    JSONObject result = newPatientHandlerService.doExecute(inputObject);
                    assertNotNull(result); // Should not throw, just log info
                }
            }
        }
    }

    @Test
    public void createNewPatient_throwsException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deployment_id", "testDeploymentId");

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("testDeploymentId");
            when(matchPatientHandler.processMatchPatient(any(), any())).thenThrow(new RuntimeException("API error"));

            try {
                newPatientHandlerService.createNewPatient(inputObject);
                fail("Expected IHubException to be thrown");
            } catch (IHubException e) {
                assertEquals("API error", e.getMessage());
                assertEquals(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getStatusCode());
            }
        }
    }

    @Test
    void testCreateNewPatient() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.FIRST_NAME))).thenReturn("John");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.LAST_NAME))).thenReturn("Doe");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.MIDDLE_NAME))).thenReturn("ff");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("testResourceId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_PATIENT_ID))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);
                    when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                    when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                            any(), eq(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG),
                            eq(ALLOW_DUPLICATE_PATIENT), eq(false))).thenReturn("true");
                    // Act
                    JSONObject result = newPatientHandlerService.createNewPatient(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                    assertEquals("tPatientId", result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("ExternalPatientId"));
                    verify(advancedmdApiCaller, times(1)).call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString());
                }
            }
        }
    }

    @Test
    void testGetPatientDemographics() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("12345");

            // Arrange
            String deploymentId = "testDeploymentId";
            JSONObject createPatientResponse = new JSONObject();
            createPatientResponse.put("patient_id", "12345");

            JSONObject inputObject = new JSONObject();
            inputObject.put("deployment_id", deploymentId);
            inputObject.put("first_name", "John");
            inputObject.put("last_name", "Doe");
            inputObject.put("middle_name", "M");
            inputObject.put("dob", "2000-01-01");
            inputObject.put("gender", "M");

            JSONObject demographicsResponse = new JSONObject();
            demographicsResponse.put("patient_id", "12345");

            when(advancedmdApiCaller.call(eq(deploymentId), eq(GET_PATIENT_DEMOGRAPHICS.getKey()), eq(createPatientResponse), eq("GET_PATIENT_DEMOGRAPHICS")))
                    .thenReturn(demographicsResponse);

            // Act
            JSONObject result = newPatientHandlerService.getPatientDemographics(deploymentId, createPatientResponse, inputObject);

            // Assert
            assertNotNull(result);
            assertEquals("12345", result.getString("patient_id"));
            verify(advancedmdApiCaller, times(1)).call(eq(deploymentId), eq(GET_PATIENT_DEMOGRAPHICS.getKey()), eq(createPatientResponse), eq("GET_PATIENT_DEMOGRAPHICS"));
        }
    }

    @Test
    void testGetPatientInsuranceInfo() throws IHubException {
        // Arrange
        String deploymentId = "testDeploymentId";
        JSONObject inputObject = new JSONObject();
        inputObject.put("deployment_id", deploymentId);

        JSONObject insuranceResponse = new JSONObject();
        insuranceResponse.put("insurance_id", "67890");

        when(advancedmdApiCaller.call(eq(deploymentId), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), eq(inputObject), anyString()))
                .thenReturn(insuranceResponse);

        // Act
        JSONObject result = newPatientHandlerService.getPatientInsuranceInfo(deploymentId, inputObject);

        // Assert
        assertNotNull(result);
        assertEquals("67890", result.getString("insurance_id"));
        verify(advancedmdApiCaller, times(1)).call(eq(deploymentId), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), eq(inputObject), anyString());
    }

    @Test
    public void isDuplicatePatAllowed_exception() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_DUPLICATE_PATIENT), eq(false))).thenThrow(new IHubException(new IHubErrorCode("33"), "test"));
        Method isDuplicatePatAllowed = getMethod("isDuplicatePatAllowed", String.class);
        Boolean result = (Boolean) isDuplicatePatAllowed.invoke(newPatientHandlerService, deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_DUPLICATE_PATIENT), eq(false));
        Assertions.assertFalse(result);
    }

    @Test
    public void isMultiplePatAllowed_exception() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false))).thenThrow(new IHubException(new IHubErrorCode("33"), "test"));
        Method isMultiplePatAllowed = getMethod("isMultiplePatAllowed", String.class);
        Boolean result = (Boolean) isMultiplePatAllowed.invoke(newPatientHandlerService, deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false));
        Assertions.assertFalse(result);
    }

    @Test
    public void isMultiplePatAllowed() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false))).thenReturn("true");
        Method isMultiplePatAllowed = getMethod("isMultiplePatAllowed", String.class);
        Boolean result = (Boolean) isMultiplePatAllowed.invoke(newPatientHandlerService, deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false));
        Assertions.assertTrue(result);
    }

    @Test
    public void multiplePatientError_true() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false))).thenReturn("true");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("error_code", "123");
        when(advancedmdApiCaller.call(eq(deploymentId), eq(ApiName.NEW_PATIENT.getKey()), any(), eq("NewPatient"))).thenReturn(jsonObject);
        Method multiplePatientError = getMethod("multiplePatientError", JSONObject.class, JSONObject.class, String.class);
        JSONObject result = (JSONObject) multiplePatientError.invoke(newPatientHandlerService, new JSONObject(), new JSONObject(), deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false));
        Assertions.assertEquals("123", result.get("error_code"));
    }

    @Test
    public void multiplePatientError_false() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false))).thenReturn("false");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("error_code", "123");
        when(advancedmdApiCaller.call(eq(deploymentId), eq(ApiName.NEW_PATIENT.getKey()), any(), eq("NewPatient"))).thenReturn(jsonObject);
        Method multiplePatientError = getMethod("multiplePatientError", JSONObject.class, JSONObject.class, String.class);
        JSONObject result = (JSONObject) multiplePatientError.invoke(newPatientHandlerService, new JSONObject(), new JSONObject(), deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(ALLOW_MULTIPLE_PATIENT), eq(false));
        Assertions.assertEquals("2001", result.get("error_code"));
    }

    @Test
    public void validateDob_error() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                        eq(EPM_DATE_FORMAT))).thenThrow(new ParseException("test", 1));

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("invalid");

                Assertions.assertThrows(IHubException.class, () -> newPatientHandlerService.validateDob(new JSONObject()));
            }
        }
    }

    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = NewPatientHandlerService.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

    @Test
    void testGetPatientDemographics_NormalFlow() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        String deploymentId = "depId";
        JSONObject createPatientResponse = new JSONObject();
        createPatientResponse.put("patient_id", "p123");
        JSONObject inputObject = new JSONObject();
        inputObject.put("first_name", "John");
        inputObject.put("last_name", "Doe");
        inputObject.put("middle_name", "M");
        inputObject.put("dob", "2000-01-01");
        inputObject.put("gender", "M");

        JSONObject demographicResponse = new JSONObject();
        AdvancedmdApiCaller mockApiCaller = mock(AdvancedmdApiCaller.class);
        ReflectionTestUtils.setField(service, "advancedmdApiCaller", mockApiCaller);

        when(mockApiCaller.call(eq(deploymentId), anyString(), eq(createPatientResponse), anyString()))
                .thenReturn(demographicResponse);

        try (MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class)) {
            jsonUtils.when(() -> JsonUtils.copyKey(anyString(), any(), any())).thenAnswer(invocation -> null);
            jsonUtils.when(() -> JsonUtils.setValue(any(), anyString(), any())).thenAnswer(invocation -> null);
            jsonUtils.when(() -> JsonUtils.getValue(eq(createPatientResponse), eq("patient_id"))).thenReturn("p123");

            Method method = NewPatientHandlerService.class.getDeclaredMethod("getPatientDemographics", String.class, JSONObject.class, JSONObject.class);
            method.setAccessible(true);

            JSONObject result = (JSONObject) method.invoke(service, deploymentId, createPatientResponse, inputObject);
            assertNotNull(result);
        }
    }

    @Test
    void testDoExecuteValidInputs_ihubException() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenThrow(new RuntimeException("test"));
                    mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DOB), any())).thenAnswer(invocation -> invocation);
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");
//                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation",new JSONArray()));
                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("PatientFirstName", "11"))));

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    JSONObject demographicsResponse = new JSONObject();
                    demographicsResponse.put("dob", "2000-01-01");

                    JSONObject insuranceResponse = new JSONObject();
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);

                    doReturn(createPatientResponse).when(newPatientHandlerService).createNewPatient(any());
                    when(newPatientHandlerService.getPatientDemographics(any())).thenReturn(demographicsResponse);
                    when(newPatientHandlerService.getPatientInsuranceInfo(any())).thenReturn(insuranceResponse);
                    when(newPatientHandlerService.prepareResponse(any(), any())).thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(), anyString()))
                            .thenReturn(demographicsResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(), anyString()))
                            .thenReturn(insuranceResponse);
                    doNothing().when(dataTransactionService).logData(any(), eq(CREATE_PATIENT.getKey()), eq(SUCCESS.getKey()),
                            anyString());

                    // Act
                    JSONObject result = newPatientHandlerService.doExecute(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                }
            }
        }
    }

    @Test
    void testDoExecuteValidInputs_parseException() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn("test");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DOB), any())).thenAnswer(invocation -> invocation);
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");
//                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation",new JSONArray()));
                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("PatientFirstName", "11"))));

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    JSONObject demographicsResponse = new JSONObject();
                    demographicsResponse.put("dob", "2000-01-01");

                    JSONObject insuranceResponse = new JSONObject();
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);

                    doReturn(createPatientResponse).when(newPatientHandlerService).createNewPatient(any());
                    when(newPatientHandlerService.getPatientDemographics(any())).thenReturn(demographicsResponse);
                    when(newPatientHandlerService.getPatientInsuranceInfo(any())).thenReturn(insuranceResponse);
                    when(newPatientHandlerService.prepareResponse(any(), any())).thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(), anyString()))
                            .thenReturn(demographicsResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(), anyString()))
                            .thenReturn(insuranceResponse);
                    doNothing().when(dataTransactionService).logData(any(), eq(CREATE_PATIENT.getKey()), eq(SUCCESS.getKey()),
                            anyString());

                    // Act
                    JSONObject result = newPatientHandlerService.doExecute(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                }
            }
        }
    }

    @Test
    void testDoExecuteValidInputs_temp_error() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenThrow(new RuntimeException("test"));
                    mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DOB), any())).thenAnswer(invocation -> invocation);
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");
//                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation",new JSONArray()));
                    inputObject.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("PatientFirstName", "11"))));

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");
                    createPatientResponse.put("error_detail", "12345");

                    JSONObject demographicsResponse = new JSONObject();
                    demographicsResponse.put("dob", "2000-01-01");

                    JSONObject insuranceResponse = new JSONObject();
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);

                    doReturn(createPatientResponse).when(newPatientHandlerService).createNewPatient(any());
                    when(newPatientHandlerService.getPatientDemographics(any())).thenReturn(demographicsResponse);
                    when(newPatientHandlerService.getPatientInsuranceInfo(any())).thenReturn(insuranceResponse);
                    when(newPatientHandlerService.prepareResponse(any(), any())).thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(), anyString()))
                            .thenReturn(demographicsResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(), anyString()))
                            .thenReturn(insuranceResponse);
                    doNothing().when(dataTransactionService).logData(any(), eq(CREATE_PATIENT.getKey()), eq(SUCCESS.getKey()),
                            anyString());

                    // Act
                    JSONObject result = newPatientHandlerService.doExecute(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                }
            }
        }
    }

    @Test
    void testCreateNewPatient_empty() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.FIRST_NAME))).thenReturn("John");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.LAST_NAME))).thenReturn("Doe");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.MIDDLE_NAME))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("testResourceId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_PATIENT_ID))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);
                    when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                    when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                            any(), eq(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG),
                            eq(ALLOW_DUPLICATE_PATIENT), eq(false))).thenReturn("true");
                    // Act
                    JSONObject result = newPatientHandlerService.createNewPatient(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                    assertEquals("tPatientId", result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("ExternalPatientId"));
                    verify(advancedmdApiCaller, times(1)).call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString());
                }
            }
        }
    }

    @Test
    void testCreateNewPatient_Patient_id() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.FIRST_NAME))).thenReturn("John");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.LAST_NAME))).thenReturn("Doe");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.MIDDLE_NAME))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("testResourceId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_PATIENT_ID))).thenReturn("7965");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");

                    JSONObject createPatientResponse = new JSONObject("{\n" +
                            "  \"appointment_sync\": [\n" +
                            "    {\n" +
                            "      \"message_status\": \"recfromda\",\n" +
                            "      \"AppId\": \"DIRECT-CONSUMER\",\n" +
                            "      \"ResponseMode\": \"Sync\",\n" +
                            "      \"is_new\": true,\n" +
                            "      \"retry_message\": false,\n" +
                            "      \"message_control_id\": \"9a61c0ad-6361-476c-9b00-d7e9b92d1ae1\",\n" +
                            "      \"message_type\": \"UpdatePatient\",\n" +
                            "      \"message_received_time\": \"2024-09-06T19:17:32.237795100\",\n" +
                            "      \"deployment_id\": \"747292^0001\"\n" +
                            "    }\n" +
                            "  ]\n" +
                            "}");


                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);
                    when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                    when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                            any(), eq(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG),
                            eq(ALLOW_DUPLICATE_PATIENT), eq(false))).thenReturn("true");
                    // Act
                    JSONObject result = newPatientHandlerService.createNewPatient(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                    assertEquals("tPatientId", result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("ExternalPatientId"));
                }
            }
        }
    }

    @Test
    void testCreateNewPatient_temp_error_code() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.FIRST_NAME))).thenReturn("John");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.LAST_NAME))).thenReturn("Doe");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.MIDDLE_NAME))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("testResourceId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_PATIENT_ID))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn("error_code");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    // Arrange
                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.NEW_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(matchPatientHandler.processMatchPatient(any(), any())).thenReturn(createPatientResponse);
                    when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                    when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                            any(), eq(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG),
                            eq(ALLOW_DUPLICATE_PATIENT), eq(false))).thenReturn("true");
                    // Act
                    JSONObject result = newPatientHandlerService.createNewPatient(inputObject);
                    System.out.println(result);
                    // Assert
                    assertNotNull(result);
                }
            }
        }
    }

}