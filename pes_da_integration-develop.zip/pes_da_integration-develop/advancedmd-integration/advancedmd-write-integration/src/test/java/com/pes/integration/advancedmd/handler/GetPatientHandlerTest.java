package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GetPatientHandlerTest {

    @InjectMocks
    GetPatientHandler getPatientHandler;

    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteValidInput() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        JSONObject responseObject = new JSONObject();
        responseObject.put("patientId", "12345");

        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(responseObject);

        JSONObject result = getPatientHandler.doExecute(inputObject);

        assertNotNull(result);
        assertEquals("12345", result.getString("patientId"));
        assertFalse(result.has("pagecount"));
        assertFalse(result.has("page"));
    }

    @Test
    void doExecuteHandlesException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenThrow(new RuntimeException("Test Exception"));

        Assertions.assertThrows(IHubException.class, () -> getPatientHandler.doExecute(inputObject));

    }

    @Test
    void doExecuteMissingDeploymentId() throws IHubException {
        JSONObject inputObject = new JSONObject();

        assertThrows(IHubException.class, () -> getPatientHandler.doExecute(inputObject));

    }
}