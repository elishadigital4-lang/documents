package com.pes.integration.advancedmd.service;

import com.pes.integration.advancedmd.handler.CancelAppointmentsHandlerService;
import com.pes.integration.advancedmd.handler.NewAppointmentHandlerService;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.enums.FlowStatus.CREATED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProcessAppointmentsServiceTest {

    @InjectMocks
    ProcessAppointmentsService processAppointmentsService;

    @Mock
    DataTransactionService dataTransactionService;

    @Mock
    NewAppointmentHandlerService newAppointmentHandlerService;

    @Mock
    CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createAppointmentValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("status", "success");

        when(newAppointmentHandlerService.doExecute(any())).thenReturn(response);
        doNothing().when(dataTransactionService).logData(any(), eq(CREATE_APPOINTMENT.getKey()), eq(CREATED.getKey()), eq("iHub Create Appointment Request Message"));

        JSONObject result = processAppointmentsService.createAppointment(input);

        assertNotNull(result);
        assertEquals("success", result.getString("status"));
        verify(dataTransactionService, times(2)).logData(any(JSONObject.class), anyString(), anyString(), anyString());
        verify(newAppointmentHandlerService, times(1)).doExecute(any());
    }

    @Test
    void cancelAppointmentValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("status", "success");

        when(cancelAppointmentsHandlerService.doExecute(any())).thenReturn(response);
        doNothing().when(dataTransactionService).logData(any(), eq(CREATE_APPOINTMENT.getKey()), eq(CREATED.getKey()), eq("iHub Cancel Appointment Request Message"));

        JSONObject result = processAppointmentsService.cancelAppointment(input);

        assertNotNull(result);
        assertEquals("success", result.getString("status"));
        verify(dataTransactionService, times(1)).logData(any(JSONObject.class), anyString(), anyString(), anyString());
        verify(cancelAppointmentsHandlerService, times(1)).doExecute(any());
    }

}