package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.InvocationTargetException;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
class CancelAppointmentsHandlerServiceTest {

    @InjectMocks
    @Spy
    CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    DataCacheManager dataCacheManager;

    @Mock
    BaseHandler baseHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteValid() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deploymentId", "testDeploymentId");

        JSONObject outputObject = new JSONObject();
        outputObject.put("temp", new JSONObject());
        doAnswer(invocation -> outputObject).when(cancelAppointmentsHandlerService).cancelAppointment(inputObject);

        doAnswer(invocation -> outputObject).when(cancelAppointmentsHandlerService).prepareResponse(any(), any());

        JSONObject result = cancelAppointmentsHandlerService.doExecute(inputObject);

        assertNotNull(result);
        assertTrue(result.has("temp"));
    }

    @Test
    void doExecuteValid_NotTemp() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deploymentId", "testDeploymentId");

        JSONObject outputObject = new JSONObject();
        outputObject.put("NotTemp", new JSONObject());
        doAnswer(invocation -> outputObject).when(cancelAppointmentsHandlerService).cancelAppointment(inputObject);

        doAnswer(invocation -> outputObject).when(cancelAppointmentsHandlerService).prepareResponse(any(), any());

        JSONObject result = cancelAppointmentsHandlerService.doExecute(inputObject);
        System.out.println(result.toString());
        assertNotNull(result);
        assertTrue(result.has("NotTemp"));
    }


    @Test
    void cancelAppointmentValid() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        inputObject.put("appointmentId", "12345");

        JSONObject requestObject = new JSONObject();
        requestObject.put("responseKey", "responseValue");

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("defaultCancelReason");
        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(requestObject);

        JSONObject result = cancelAppointmentsHandlerService.cancelAppointment(inputObject);

        assertNotNull(result);
        assertEquals("responseValue", result.getString("responseKey"));
    }

    @Test
    void cancelAppointmentHandlesException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        inputObject.put("appointmentId", "12345");

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("defaultCancelReason");
        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenThrow(new RuntimeException("Test Exception"));

        assertThrows(IHubException.class, () -> cancelAppointmentsHandlerService.cancelAppointment(inputObject));

    }
}