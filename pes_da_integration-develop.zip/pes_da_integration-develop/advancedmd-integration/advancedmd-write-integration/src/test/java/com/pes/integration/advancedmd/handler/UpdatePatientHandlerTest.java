package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.PhoneNumberUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.DOB;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class UpdatePatientHandlerTest {
    @InjectMocks
    @Spy
    UpdatePatientHandler updatePatientHandler;

    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void updatePatientAddress_reflection() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.UPDATE_PATIENT_ADDRESS))).thenReturn("1");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.STREET1))).thenReturn("123 Main St");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.STREET2))).thenReturn("Apt 4B");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.CITY))).thenReturn("Springfield");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.SATE))).thenReturn("IL");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.ZIP))).thenReturn("62704");

            JSONObject inputObject = new JSONObject();
            JSONObject patientObject = new JSONObject();

            Method updatePatientAddress = UpdatePatientHandler.class.getDeclaredMethod("updatePatientAddress", JSONObject.class, JSONObject.class);
            updatePatientAddress.setAccessible(true);

            Assertions.assertDoesNotThrow(() -> updatePatientAddress.invoke(updatePatientHandler, inputObject, patientObject));
        }
    }

    @Test
    void doExecuteValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DocASAPConstants.DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.UPDATE_PATIENT_CPHONE))).thenReturn("1");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.UPDATE_PATIENT_WPHONE))).thenReturn("1");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.UPDATE_PATIENT_HPHONE))).thenReturn("1");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.UPDATE_PATIENT_EMAIL))).thenReturn("");
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    JSONObject inputObject = new JSONObject();
                    inputObject.put("deployment_id", "testDeploymentId");
                    inputObject.put("dob", "2000-01-01");

                    JSONObject createPatientResponse = new JSONObject();
                    createPatientResponse.put("temp.error_code", "null");
                    createPatientResponse.put("patient_id", "12345");

                    JSONObject demographicsResponse = new JSONObject();
                    demographicsResponse.put("dob", "2000-01-01");

                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.UPDATE_PATIENT.getKey()), any(), anyString()))
                            .thenReturn(createPatientResponse);
                    when(advancedmdApiCaller.call(anyString(), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), anyString()))
                            .thenReturn(demographicsResponse);

                    JSONObject result = updatePatientHandler.doExecute(inputObject);
                    System.out.println(result);
                    assertNotNull(result);
                    assertEquals("testDeploymentId", result.getJSONObject("data").getJSONArray("appointment_sync").getJSONObject(0).getString("deployment_id"));
                    assertEquals("2000-01-01", result.getJSONObject("data").getJSONArray("appointment_sync").getJSONObject(0).getString("dob"));
                    verify(advancedmdApiCaller, times(1)).call(anyString(), eq(ApiName.UPDATE_PATIENT.getKey()), any(), anyString());
                    verify(advancedmdApiCaller, times(1)).call(anyString(), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), anyString());
                }
            }
        }
    }

    @Test
    void doExecute_throwsIHubException() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), any())).thenReturn("dummy");
            JSONObject inputObject = new JSONObject();
            inputObject.put("deployment_id", "testDeploymentId");
            inputObject.put("dob", "2000-01-01");

            when(advancedmdApiCaller.call(anyString(), eq(ApiName.UPDATE_PATIENT.getKey()), any(), anyString()))
                    .thenThrow(new IHubException(new IHubErrorCode("99"), "Simulated exception"));

            IHubException thrown = assertThrows(IHubException.class, () -> {
                updatePatientHandler.doExecute(inputObject);
            });
            assertEquals("Simulated exception", thrown.getMessage());
        }
    }

    @Test
    public void updatePatientEmail() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.UPDATE_PATIENT_EMAIL))).thenReturn("1");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.EMAIL))).thenReturn("test@email.com");

            Method updatePatientEmail = getMethod("updatePatientEmail", Object.class, JSONObject.class);
            Assertions.assertDoesNotThrow(() -> updatePatientEmail.invoke(updatePatientHandler, new JSONObject(), new JSONObject()));

        }
    }

    @Test
    public void updatePatientEmail_exception() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.UPDATE_PATIENT_EMAIL))).thenReturn("1");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.EMAIL))).thenReturn("test@email.com");
            mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DocASAPConstants.Key.EMAIL), any())).thenThrow(new IHubException(new IHubErrorCode("22"), "test exception"));

            Method updatePatientEmail = getMethod("updatePatientEmail", Object.class, JSONObject.class);
            Assertions.assertThrows(InvocationTargetException.class,() -> updatePatientEmail.invoke(updatePatientHandler, new JSONObject(), new JSONObject()));

        }
    }

    @Test
    public void setKeyValue_exception() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), any())).thenReturn("1");
            mockedJsonUtils.when(() -> JsonUtils.setValue(any(), any(), any())).thenThrow(new IHubException(new IHubErrorCode("22"), "test exception"));

            Method setKeyValue = getMethod("setKeyValue", Object.class, JSONObject.class, String.class);
            Assertions.assertThrows(InvocationTargetException.class,() -> setKeyValue.invoke(updatePatientHandler, new JSONObject(), new JSONObject(), ""));

        }
    }

    @Test
    public void checkIfFlagValid_exception() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), any())).thenThrow(new RuntimeException("test exception"));

            Method checkIfFlagValid = getMethod("checkIfFlagValid", Object.class, String.class);
            Assertions.assertThrows(InvocationTargetException.class,() -> checkIfFlagValid.invoke(updatePatientHandler, new JSONObject(), ""));

        }
    }

    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = UpdatePatientHandler.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }
}