package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;

import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.LAST_NAME;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MatchPatientHandlerTest {

    @InjectMocks
    MatchPatientHandler matchPatientHandler;

    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    DataCacheManager cacheManager;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testIsSingleMatch() throws IHubException {
        MatchPatientHandler matchPatientHandler = new MatchPatientHandler();
        boolean result = matchPatientHandler.isSingleMatch();
        assertFalse(result, "isSingleMatch should return false");
    }

    @Test
    void getMatchPatientInactiveConfig_handlesException() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        java.lang.reflect.Field cacheManagerField = MatchPatientHandler.class.getDeclaredField("cacheManager");
        cacheManagerField.setAccessible(true);
        cacheManagerField.set(handler, mockCacheManager);

        when(mockCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenThrow(new IHubException(null, "Test Exception"));

        java.lang.reflect.Method method = MatchPatientHandler.class.getDeclaredMethod("getMatchPatientInactiveConfig", String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(handler, "deploymentId");
        assertFalse(result, "Should return false when IHubException is thrown");
    }

    @Test
    void readPageConfig_handlesException() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        java.lang.reflect.Field cacheManagerField = MatchPatientHandler.class.getDeclaredField("cacheManager");
        cacheManagerField.setAccessible(true);
        cacheManagerField.set(handler, mockCacheManager);

        doThrow(new RuntimeException("Config error")).when(mockCacheManager)
                .getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean());

        java.lang.reflect.Method method = MatchPatientHandler.class.getDeclaredMethod("readPageConfig", String.class, String.class, String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(handler, "deploymentId", "configGroup", "confKey");
        assertEquals("0", result);
    }

    @Test
    void getPatientsValidInput() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        JSONObject outputObject = new JSONObject();
        outputObject.put(AdvancedMDEngineConstants.PAGE_COUNT, 2);
        outputObject.put("appointmentSync", new JSONArray());
        outputObject.put("appointment_sync", new JSONArray());

        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(outputObject);

        JSONObject result = matchPatientHandler.getPatients(inputObject);
        System.out.println(result.toString());
        assertNotNull(result);
        assertTrue(result.has("appointment_sync"));
        assertTrue(result.has("appointmentSync"));
    }

    @Test
    void getPatientsMultiplePages() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        JSONObject firstPageOutput = new JSONObject();
        firstPageOutput.put("pageCount", 2);
        firstPageOutput.put("appointmentSync", new JSONArray());

        JSONObject secondPageOutput = new JSONObject();
        secondPageOutput.put("appointmentSync", new JSONArray());

        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString()))
                .thenReturn(firstPageOutput)
                .thenReturn(secondPageOutput);

        JSONObject result = matchPatientHandler.getPatients(inputObject);

        assertNotNull(result);
        assertTrue(result.has("pageCount"));
        assertTrue(result.has("appointmentSync"));
    }

    @Test
    void getPatientsHandlesException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenThrow(new IHubException(new IHubErrorCode("12"), "Test Exception"));

        JSONObject result = matchPatientHandler.getPatients(inputObject);

        assertNotNull(result);
        assertTrue(result.has("Error"));
        assertEquals("Test Exception", result.getString("Error"));
    }

    @Test
    void getPatientDemographicsDetailsValidInput_lastname_empty() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(FIRST_NAME))).thenReturn(" Doe, John");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(PATIENT_ID))).thenReturn("PATIENT_ID");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(EMAIL))).thenReturn("john.doe@example.com");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(MOBILE_PHONE))).thenReturn("1234567890");
                JSONArray patientsArray = new JSONArray();
                JSONObject patientObject = new JSONObject();
                patientObject.put(FIRST_NAME, " Doe,John");
                patientObject.put("patientId", "12345");
                patientsArray.put(patientObject);

                JSONObject apiResponse = new JSONObject();
                apiResponse.put("inactive", "false");
                apiResponse.put("deceased", "false");
                apiResponse.put("email", "john.doe@example.com");
                apiResponse.put("mobilePhone", "1234567890");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
                when(cacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX), any(),
                        eq(UtilitiesConstants.GENERIC_CONFIG), eq(UtilitiesConstants.INACTIVE_PAT_CONF), eq(false))).thenReturn(UtilitiesConstants.FALSE);

                JSONArray result = matchPatientHandler.getPatientDemographicsDetails(patientsArray);
                System.out.println(result.toString());
                assertNotNull(result);
                assertEquals(1, result.length());
                JSONObject resultPatient = result.getJSONObject(0).getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
                System.out.println(resultPatient);
                assertEquals(" John", resultPatient.getString("PatientFirstName"));
                assertEquals("", resultPatient.getString("PatientLastName"));
                assertEquals("john.doe@example.com", resultPatient.getString("Email"));
                assertEquals("1234567890", resultPatient.getString("CellPhone"));
            }
        }
    }

    @Test
    void getPatientDemographicsDetailsValidInput_Firstname_empty() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(FIRST_NAME))).thenReturn("Doe, John");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(PATIENT_ID))).thenReturn("PATIENT_ID");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(EMAIL))).thenReturn("john.doe@example.com");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(MOBILE_PHONE))).thenReturn("1234567890");
                JSONArray patientsArray = new JSONArray();
                JSONObject patientObject = new JSONObject();
                patientObject.put(FIRST_NAME, "Doe, John");
                patientObject.put("patientId", "12345");
                patientsArray.put(patientObject);

                JSONObject apiResponse = new JSONObject();
                apiResponse.put("inactive", "false");
                apiResponse.put("deceased", "false");
                apiResponse.put("email", "john.doe@example.com");
                apiResponse.put("mobilePhone", "1234567890");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
                when(cacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX), any(),
                        eq(UtilitiesConstants.GENERIC_CONFIG), eq(UtilitiesConstants.INACTIVE_PAT_CONF), eq(false))).thenReturn(UtilitiesConstants.FALSE);

                JSONArray result = matchPatientHandler.getPatientDemographicsDetails(patientsArray);
                System.out.println(result.toString());
                assertNotNull(result);
                assertEquals(1, result.length());
                JSONObject resultPatient = result.getJSONObject(0).getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
                System.out.println(resultPatient);
                assertEquals("", resultPatient.getString("PatientFirstName"));
                assertEquals("Doe", resultPatient.getString("PatientLastName"));
                assertEquals("john.doe@example.com", resultPatient.getString("Email"));
                assertEquals("1234567890", resultPatient.getString("CellPhone"));
            }
        }
    }


    @Test
    void testFormatDob_NormalFlow() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        JSONObject patientObject = new JSONObject();
        patientObject.put("dob", "01/01/2000");

        try (MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> dateUtils = mockStatic(DateUtils.class)) {

            jsonUtils.when(() -> JsonUtils.getValue(patientObject, DocASAPConstants.Key.DOB)).thenReturn("01/01/2000");
            dateUtils.when(() -> DateUtils.convertDateFormat("01/01/2000", AdvancedMDConstants.DOB_DATE_FORMAT, AdvancedMDConstants.DATE_FORMAT))
                    .thenReturn("2000-01-01");
            jsonUtils.when(() -> JsonUtils.setValue(patientObject, DocASAPConstants.Key.DOB, "2000-01-01")).thenAnswer(invocation -> null);

            ReflectionTestUtils.invokeMethod(handler, "formatDob", patientObject);

            jsonUtils.verify(() -> JsonUtils.setValue(patientObject, DocASAPConstants.Key.DOB, "2000-01-01"), times(1));
        }
    }

    @Test
    void testFormatDob_ParseExceptionFlow() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        JSONObject patientObject = new JSONObject();
        patientObject.put("dob", "invalid-date");

        try (MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> dateUtils = mockStatic(DateUtils.class)) {

            jsonUtils.when(() -> JsonUtils.getValue(patientObject, DocASAPConstants.Key.DOB)).thenReturn("invalid-date");
            dateUtils.when(() -> DateUtils.convertDateFormat("invalid-date", AdvancedMDConstants.DOB_DATE_FORMAT, AdvancedMDConstants.DATE_FORMAT))
                    .thenThrow(new ParseException("Invalid date", 0));
            // Should set the original dob value if parsing fails
            jsonUtils.when(() -> JsonUtils.setValue(patientObject, DocASAPConstants.Key.DOB, "invalid-date")).thenAnswer(invocation -> null);

            ReflectionTestUtils.invokeMethod(handler, "formatDob", patientObject);

            jsonUtils.verify(() -> JsonUtils.setValue(patientObject, DocASAPConstants.Key.DOB, "invalid-date"), times(1));
        }
    }


}