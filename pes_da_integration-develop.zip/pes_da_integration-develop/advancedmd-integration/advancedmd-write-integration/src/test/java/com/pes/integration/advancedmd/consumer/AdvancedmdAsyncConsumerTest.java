package com.pes.integration.advancedmd.consumer;

import com.pes.integration.publisher.Publisher;
import com.pes.integration.service.AsyncConsumerService;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.service.ProcessRequestMessageService;
import com.pes.integration.service.ValidationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class AdvancedmdAsyncConsumerTest {

    @InjectMocks
    AdvancedmdAsyncConsumer advancedmdAsyncConsumer;

    @Mock
    AsyncConsumerService asyncConsumerService;

    @Value("${kafka.sync.data.topic}")
    private String syncDataTopic = "testSyncDataTopic";

    private static final Logger log = LoggerFactory.getLogger(AdvancedmdAsyncConsumer.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Manually set the syncDataTopic value
        advancedmdAsyncConsumer.syncDataTopic = syncDataTopic;
    }

    @Test
    void testConsumeAsyncMessage() {
        String payload = "testPayload";

        advancedmdAsyncConsumer.consumeAsyncMessage(payload);

        verify(asyncConsumerService, times(1)).processAsyncMessage(syncDataTopic, payload);
        // Verify log message if necessary
    }

    @Test
    void testListen() {
        String topic = "testTopic.d2e";
        String message = "testMessage";
        String expectedTopic = "testTopic.e2d";

        advancedmdAsyncConsumer.listen(topic, message);

        verify(asyncConsumerService, times(1)).processAsyncMessage(expectedTopic, message);
        // Verify log message if necessary
    }
}