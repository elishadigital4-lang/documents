package com.pes.integration.advancedmd.service;

import com.pes.integration.advancedmd.handler.GetPatientHandler;
import com.pes.integration.advancedmd.handler.NewPatientHandlerService;
import com.pes.integration.advancedmd.handler.UpdatePatientHandler;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.CREATED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

class ProcessPatientServiceTest {


    @Mock
    NewPatientHandlerService newPatientHandlerService;

    @Mock
    UpdatePatientHandler updatePatientHandler;

    @Mock
    DataTransactionService dataTransactionService;

    @Mock
    GetPatientHandler getPatientsHandler;

    @InjectMocks
    ProcessPatientService processPatientService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getPatient_returnsNull() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject result = processPatientService.getPatient(input);

        assertNull(result, "The getPatient method should return null.");
    }

    @Test
    void createPatient() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("status", "success");

        when(newPatientHandlerService.doExecute(any())).thenReturn(response);
        doNothing().when(dataTransactionService).logData(any(), eq(CREATE_APPOINTMENT.getKey()), eq(CREATED.getKey()), eq("iHub Create Appointment Request Message"));

        JSONObject result = processPatientService.createPatient(input);

        assertNotNull(result);
        assertEquals("success", result.getString("status"));
        verify(dataTransactionService, times(2)).logData(any(JSONObject.class), anyString(), anyString(), anyString());
        verify(newPatientHandlerService, times(1)).doExecute(any());
    }

    @Test
    void createPatient_exception() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("status", "success");

        when(newPatientHandlerService.doExecute(any())).thenThrow(new IHubException(new IHubErrorCode("11"), "ERROR"));
        doNothing().when(dataTransactionService).logData(any(), eq(CREATE_APPOINTMENT.getKey()), eq(CREATED.getKey()), eq("iHub Create Appointment Request Message"));

        Assertions.assertThrows(IHubException.class, () -> processPatientService.createPatient(input));

        verify(dataTransactionService, times(2)).logData(any(JSONObject.class), anyString(), anyString(), anyString());
        verify(newPatientHandlerService, times(1)).doExecute(any());
    }

    @Test
    void updatePatient() throws IHubException {

        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("status", "success");

        when(updatePatientHandler.doExecute(any())).thenReturn(response);
        doNothing().when(dataTransactionService).logData(any(), eq(UPDATE_PATIENT.getKey()), eq(CREATED.getKey()), eq("iHub Create Appointment Request Message"));

        JSONObject result = processPatientService.updatePatient(input);

        assertNotNull(result);
        assertEquals("success", result.getString("status"));
        verify(dataTransactionService, times(1)).logData(any(JSONObject.class), anyString(), anyString(), anyString());
        verify(updatePatientHandler, times(1)).doExecute(any());
    }

    @Test
    void updatePatient_exception() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("status", "success");

        when(updatePatientHandler.doExecute(any())).thenThrow(new IHubException(new IHubErrorCode("11"), "ERROR"));
        doNothing().when(dataTransactionService).logData(any(), eq(UPDATE_PATIENT.getKey()), eq(CREATED.getKey()), eq("iHub Create Appointment Request Message"));

        Assertions.assertThrows(IHubException.class, () -> processPatientService.updatePatient(input));

        verify(dataTransactionService, times(2)).logData(any(JSONObject.class), anyString(), anyString(), anyString());
        verify(updatePatientHandler, times(1)).doExecute(any());
    }

    @Test
    void searchPatientValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("temp", new JSONObject());

        when(getPatientsHandler.doExecute(any())).thenReturn(response);

        JSONObject result = processPatientService.searchPatient(input);

        assertNotNull(result);
        assertTrue(result.has("data"));
        assertTrue(result.getJSONObject("data").has("temp"));
        verify(dataTransactionService, times(1)).logData(any(JSONObject.class), eq("SEARCH_PATIENT"), eq("CREATED"), anyString());
    }

    @Test
    void searchPatientHandlesException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointmentSync", appointmentSync);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        when(getPatientsHandler.doExecute(any())).thenThrow(new IHubException(new IHubErrorCode("33"), "Test Exception"));

        assertThrows(IHubException.class, () -> processPatientService.searchPatient(input));
        verify(dataTransactionService, times(1)).logData(any(JSONObject.class), eq("SEARCH_PATIENT"), eq("CREATED"), anyString());
    }


}