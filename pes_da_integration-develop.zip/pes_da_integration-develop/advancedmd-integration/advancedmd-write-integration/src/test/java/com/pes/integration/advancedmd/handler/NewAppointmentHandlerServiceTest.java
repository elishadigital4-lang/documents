package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.*;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.SLOT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.FIRST_NAME;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NewAppointmentHandlerServiceTest {

    @InjectMocks
    NewAppointmentHandlerService newAppointmentHandlerService;

    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    DataCacheManager dataCacheManager;

    @Mock
    HandlerUtils handlerUtils;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testIsColWithProvFalse() throws Exception {
        // Arrange
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String templateId = "template123";
        JSONObject inputObject = new JSONObject();
        inputObject.put("slotId", "template123");

        // Use Reflection to access the private method
        Method method = NewAppointmentHandlerService.class.getDeclaredMethod("isColWithProvFalse", String.class, Object.class);
        method.setAccessible(true);

        // Act
        Object result = method.invoke(service, templateId, inputObject);

        // Assert
        assertNotNull(result);
        JSONObject resultJson = (JSONObject) result;
        assertEquals("template123", resultJson.getString("slotId"));
    }

    @Test
    void sendInvitation_exception_catchBlock() throws Exception {
        // Arrange
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        int retry = 1;
        String portalId = "portalId";
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";

        // Use reflection to access the private method
        Method method = NewAppointmentHandlerService.class.getDeclaredMethod("sendInvitation", int.class, String.class, Object.class, String.class);
        method.setAccessible(true);

        // Set up outputObject field via reflection
        Field outputField = NewAppointmentHandlerService.class.getDeclaredField("outputObject");
        outputField.setAccessible(true);
        outputField.set(service, new JSONObject());

        // Mock advancedmdApiCaller to throw exception
        Field apiCallerField = NewAppointmentHandlerService.class.getDeclaredField("advancedmdApiCaller");
        apiCallerField.setAccessible(true);
        AdvancedmdApiCaller mockApiCaller = mock(AdvancedmdApiCaller.class);
        when(mockApiCaller.call(any(), any(), any(), any())).thenThrow(new RuntimeException("test exception"));
        apiCallerField.set(service, mockApiCaller);

        // Act & Assert: Should not throw, just log error and call emptyOutputErrors
        assertDoesNotThrow(() -> method.invoke(service, retry, portalId, inputObject, deploymentId));
    }

    @Test
    void setPatientInsurance_exception() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        // Prepare input that will cause an exception (e.g., missing DEPLOYMENT_ID)
        JSONObject input = new JSONObject();
        Method method = NewAppointmentHandlerService.class.getDeclaredMethod("setPatientInsurance", Object.class);
        method.setAccessible(true);
        // Should not throw, just log error
        assertDoesNotThrow(() -> method.invoke(service, input));
    }

    @Test
    void createNewAppointmentValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DocASAPConstants.DATE_TIME_FORMAT),
                        eq(AdvancedMDConstants.DATE_TIME_FORMAT))).thenReturn("202301010000");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_TIMING_START))).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.VISIT_TYPE))).thenReturn("tele");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_TEMPLATE_ID))).thenReturn("templateId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("name@mail");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("move_appt"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_status_code"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("appointmentId1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.FULLNAME))).thenReturn("John Doe");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.EMAIL))).thenReturn("JohnDoe@test.com");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.ID))).thenReturn("PatientPortalId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_CODE))).thenReturn("404");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_DETAILS))).thenReturn("Error Details");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_MESSAGE))).thenReturn("Error Message");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_DURATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.INSURANCE_INFORMATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.RESP_PARTY_ID))).thenReturn("respPartyId");

                JSONObject input = new JSONObject();
                input.put(DEPLOYMENT_ID, "testDeploymentId");
                input.put("appointmentTimingStart", "2023-10-10T10:00:00");
                input.put("visitType", "tele");

                JSONObject apiResponse = new JSONObject();
                apiResponse.put("appointmentId", "12345");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
                when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                when(advancedmdApiCaller.call(any(), eq(ApiName.SET_PATIENT_INSURANCE.getKey()), any(), eq("SetPatientInsurance")))
                        .thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.SEND_INVITATION.getKey()),
                        any(), eq("SendInvitation"))).thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.LOOKUP_PORTAL_ACCOUNT.getKey()),
                        any(), eq("LookUpPatientPortalAccount"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                        anyString(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(AdvancedMDConstants.COLOR_CONFIG),
                        eq(false))).thenReturn("");

                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS), eq(false))).thenReturn(true);
                when(advancedmdApiCaller.call(
                        any(), eq(ApiName.MOVE_APPOINTMENT.getKey()),
                        any(), eq("MoveAppointment"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(), eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS_RETRYCOUNT), eq(false)))
                        .thenReturn(3);
                JSONObject result = newAppointmentHandlerService.createNewAppointment(input);

                assertNotNull(result);
            }
        }
    }

    @Test
    void createNewAppointmentValidInput_2() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DocASAPConstants.DATE_TIME_FORMAT),
                        eq(AdvancedMDConstants.DATE_TIME_FORMAT))).thenReturn("202301010000");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_TIMING_START))).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.VISIT_TYPE))).thenReturn("tele");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_TEMPLATE_ID))).thenReturn("templateId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("name@mail");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("move_appt"))).thenReturn("2");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_status_code"))).thenReturn(null);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("appointmentId1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.FULLNAME))).thenReturn("John Doe");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.EMAIL))).thenReturn("JohnDoe@test.com");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.ID))).thenReturn("PatientPortalId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_CODE))).thenReturn("404");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_DETAILS))).thenReturn("Error Details");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_MESSAGE))).thenReturn("Error Message");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_DURATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.INSURANCE_INFORMATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.RESP_PARTY_ID))).thenReturn("respPartyId");

                JSONObject input = new JSONObject();
                input.put(DEPLOYMENT_ID, "testDeploymentId");
                input.put("appointmentTimingStart", "2023-10-10T10:00:00");
                input.put("visitType", "tele");

                JSONObject apiResponse = new JSONObject();
                apiResponse.put("appointmentId", "12345");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
                when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                when(advancedmdApiCaller.call(any(), eq(ApiName.SET_PATIENT_INSURANCE.getKey()), any(), eq("SetPatientInsurance")))
                        .thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.SEND_INVITATION.getKey()),
                        any(), eq("SendInvitation"))).thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.LOOKUP_PORTAL_ACCOUNT.getKey()),
                        any(), eq("LookUpPatientPortalAccount"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                        anyString(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(AdvancedMDConstants.COLOR_CONFIG),
                        eq(false))).thenReturn("");

                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS), eq(false))).thenReturn("true");
                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), any(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(SET_INSURANCE), eq(false))).thenReturn("true");
                when(advancedmdApiCaller.call(
                        any(), eq(ApiName.MOVE_APPOINTMENT.getKey()),
                        any(), eq("MoveAppointment"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(), eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS_RETRYCOUNT), eq(false)))
                        .thenReturn(3);
                JSONObject result = newAppointmentHandlerService.createNewAppointment(input);
                System.out.println(result);
                assertNotNull(result);
                assertEquals("2023-10-10T10:00:00", result.getString("appointmentTimingStart"));
                assertEquals("testDeploymentId", result.getString("deployment_id"));
                assertEquals("respPartyId", result.getJSONObject("DemographicData")
                        .getJSONArray("InsuranceInformation").getJSONObject(0)
                        .getString("SubscriberId"));
                assertEquals("name@mail", result.getJSONObject("SchedulingData")
                        .getJSONArray("Provider").getJSONObject(0)
                        .getString("ResourceId"));
                assertEquals("JohnDoe@test.com", result.getJSONObject("temp").getString("Email"));
                assertEquals("John Doe", result.getJSONObject("temp").getString("fullName"));
                assertEquals("PatientPortalId", result.getJSONObject("temp").getString("portalId"));
            }
        }
    }

    @Test
    public void rescheduleAppointment() throws NoSuchMethodException, IHubException {
        String deploymentId = "1234";
        JSONObject jsonObject = new JSONObject();
        when(advancedmdApiCaller.call(anyString(), eq(ApiName.MOVE_APPOINTMENT.getKey()), any(), eq("MoveAppointment"))).thenReturn(jsonObject);
        Method rescheduleAppointment = getMethod("rescheduleAppointment", String.class, Object.class);
        Assertions.assertDoesNotThrow(() -> rescheduleAppointment.invoke(newAppointmentHandlerService, deploymentId, jsonObject));
        verify(advancedmdApiCaller, times(1)).call(deploymentId, ApiName.MOVE_APPOINTMENT.getKey(), jsonObject, "MoveAppointment");

    }

    @Test
    public void rescheduleAppointment_exception() throws NoSuchMethodException, IHubException {
        String deploymentId = "1234";
        JSONObject jsonObject = new JSONObject();
        when(advancedmdApiCaller.call(anyString(), eq(ApiName.MOVE_APPOINTMENT.getKey()), any(), eq("MoveAppointment"))).thenThrow(new RuntimeException("test"));
        Method rescheduleAppointment = getMethod("rescheduleAppointment", String.class, Object.class);
        Assertions.assertDoesNotThrow(() -> rescheduleAppointment.invoke(newAppointmentHandlerService, deploymentId, jsonObject));
        verify(advancedmdApiCaller, times(1)).call(deploymentId, ApiName.MOVE_APPOINTMENT.getKey(), jsonObject, "MoveAppointment");

    }


    @Test
    public void getPatientFormsFlag_exception() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(TRIGGER_PATIENT_FORMS), eq(false))).thenThrow(new IHubException(new IHubErrorCode("33"), "test"));
        Method getPatientFormsFlag = getMethod("getPatientFormsFlag", String.class);
        Boolean result = (Boolean) getPatientFormsFlag.invoke(newAppointmentHandlerService, deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(TRIGGER_PATIENT_FORMS), eq(false));
        Assertions.assertFalse(result);
    }

    @Test
    public void readPatientFormRetryCount() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(any(), eq(deploymentId), eq(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG), eq(TRIGGER_PATIENT_FORMS_RETRYCOUNT), eq(false))).thenReturn("3");
        Method getPatientFormsFlag = getMethod("readPatientFormRetryCount", String.class);
        Integer result = (Integer) getPatientFormsFlag.invoke(newAppointmentHandlerService, deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG), eq(TRIGGER_PATIENT_FORMS_RETRYCOUNT), eq(false));
        Assertions.assertEquals(3, result);
    }

    @Test
    public void readConfig() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(any(), eq(deploymentId), any(), any(), eq(false))).thenThrow(new RuntimeException("error"));
        Method readConfig = getMethod("readConfig", String.class, String.class, String.class);
        String result = (String) readConfig.invoke(newAppointmentHandlerService, "", "", deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(any(), eq(deploymentId), any(), any(), eq(false));
        Assertions.assertEquals("0", result);
    }

    @Test
    public void emptyOutputErrors() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.TempKey.ERROR_MESSAGE))).thenReturn("errorMessage");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.TempKey.ERROR_DETAIL))).thenReturn("errorDetails");
            mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DocASAPConstants.TempKey.ERROR_MESSAGE), any())).thenAnswer(invocation -> null);
            mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DocASAPConstants.TempKey.ERROR_DETAIL), any())).thenAnswer(invocation -> null);

            Method emptyOutputErrors = getMethod("emptyOutputErrors");
            Assertions.assertDoesNotThrow(() -> emptyOutputErrors.invoke(newAppointmentHandlerService));
        }
    }

    @Test
    public void savePortalId() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_DETAILS))).thenReturn("errorMessage");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_MESSAGE))).thenReturn("errorDetails");
            mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DocASAPConstants.TempKey.ERROR_MESSAGE), any())).thenAnswer(invocation -> null);
            mockedJsonUtils.when(() -> JsonUtils.setValue(any(), eq(DocASAPConstants.TempKey.ERROR_DETAIL), any())).thenAnswer(invocation -> null);
            JSONObject jsonObject = new JSONObject();
            Method savePortalId = getMethod("savePortalId", Object.class, String.class);
            String deploymentId = "1234";
            Assertions.assertDoesNotThrow(() -> savePortalId.invoke(newAppointmentHandlerService,jsonObject, deploymentId));
        }
    }

    @Test
    public void isSetInsurance_exception() throws NoSuchMethodException, IHubException, InvocationTargetException, IllegalAccessException {
        String deploymentId = "1234";
        when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(SET_INSURANCE), eq(false))).thenThrow(new IHubException(new IHubErrorCode("33"), "test"));
        Method isSetInsurance = getMethod("isSetInsurance", String.class);
        Boolean result = (Boolean) isSetInsurance.invoke(newAppointmentHandlerService, deploymentId);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq(deploymentId), eq(ADVANCEDMD_CONFIG), eq(SET_INSURANCE), eq(false));
        Assertions.assertFalse(result);
    }
    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = NewAppointmentHandlerService.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

    @Test
    void createNewAppointmentValidInput_TemplateId() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DocASAPConstants.DATE_TIME_FORMAT),
                        eq(AdvancedMDConstants.DATE_TIME_FORMAT))).thenReturn("202301010000");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_TIMING_START))).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.VISIT_TYPE))).thenReturn("tele");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_TEMPLATE_ID))).thenReturn("templateId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("name@mail");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("move_appt"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_status_code"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("appointmentId1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.FULLNAME))).thenReturn("John Doe");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.EMAIL))).thenReturn("JohnDoe@test.com");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.ID))).thenReturn("PatientPortalId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_CODE))).thenReturn("404");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_DETAILS))).thenReturn("Error Details");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_MESSAGE))).thenReturn("Error Message");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_DURATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.INSURANCE_INFORMATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.RESP_PARTY_ID))).thenReturn("respPartyId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_EXTERNAL_TEMPLATE_ID))).thenReturn("12345");

                JSONObject input = new JSONObject();
                input.put(DEPLOYMENT_ID, "testDeploymentId");
                input.put("appointmentTimingStart", "2023-10-10T10:00:00");
                input.put("visitType", "tele");

                JSONObject apiResponse = new JSONObject();
                apiResponse.put("appointmentId", "12345");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
                when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                when(advancedmdApiCaller.call(any(), eq(ApiName.SET_PATIENT_INSURANCE.getKey()), any(), eq("SetPatientInsurance")))
                        .thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.SEND_INVITATION.getKey()),
                        any(), eq("SendInvitation"))).thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.LOOKUP_PORTAL_ACCOUNT.getKey()),
                        any(), eq("LookUpPatientPortalAccount"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                        anyString(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(AdvancedMDConstants.COLOR_CONFIG),
                        eq(false))).thenReturn("");

                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS), eq(false))).thenReturn(true);
                when(advancedmdApiCaller.call(
                        any(), eq(ApiName.MOVE_APPOINTMENT.getKey()),
                        any(), eq("MoveAppointment"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(), eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS_RETRYCOUNT), eq(false)))
                        .thenReturn(3);
                JSONObject result = newAppointmentHandlerService.createNewAppointment(input);

                assertNotNull(result);
            }
        }
    }

    @Test
    void createNewAppointmentValidInput_ExternalTemplateId() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DocASAPConstants.DATE_TIME_FORMAT),
                        eq(AdvancedMDConstants.DATE_TIME_FORMAT))).thenReturn("202301010000");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_TIMING_START))).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.VISIT_TYPE))).thenReturn("tele");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_TEMPLATE_ID))).thenReturn("templateId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("name@mail");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("move_appt"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_status_code"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("appointmentId1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.FULLNAME))).thenReturn("John Doe");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.EMAIL))).thenReturn("JohnDoe@test.com");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.ID))).thenReturn("PatientPortalId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_CODE))).thenReturn("404");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_DETAILS))).thenReturn("Error Details");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_MESSAGE))).thenReturn("Error Message");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_DURATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.INSURANCE_INFORMATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.RESP_PARTY_ID))).thenReturn("respPartyId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_EXTERNAL_TEMPLATE_ID))).thenReturn(null);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_TEMPLATE_ID))).thenReturn("12345");

                JSONObject input = new JSONObject();
                input.put(DEPLOYMENT_ID, "testDeploymentId");
                input.put("appointmentTimingStart", "2023-10-10T10:00:00");
                input.put("visitType", "tele");

                JSONObject apiResponse = new JSONObject();
                apiResponse.put("appointmentId", "12345");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
                when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                when(advancedmdApiCaller.call(any(), eq(ApiName.SET_PATIENT_INSURANCE.getKey()), any(), eq("SetPatientInsurance")))
                        .thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.SEND_INVITATION.getKey()),
                        any(), eq("SendInvitation"))).thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.LOOKUP_PORTAL_ACCOUNT.getKey()),
                        any(), eq("LookUpPatientPortalAccount"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                        anyString(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(AdvancedMDConstants.COLOR_CONFIG),
                        eq(false))).thenReturn("");

                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS), eq(false))).thenReturn(true);
                when(advancedmdApiCaller.call(
                        any(), eq(ApiName.MOVE_APPOINTMENT.getKey()),
                        any(), eq("MoveAppointment"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(), eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS_RETRYCOUNT), eq(false)))
                        .thenReturn(3);
                JSONObject result = newAppointmentHandlerService.createNewAppointment(input);

                assertNotNull(result);
            }
        }
    }

    @Test
    void createNewAppointment_Exception() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DocASAPConstants.DATE_TIME_FORMAT),
                        eq(AdvancedMDConstants.DATE_TIME_FORMAT))).thenReturn("202301010000");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_TIMING_START))).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.VISIT_TYPE))).thenReturn("tele");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_TEMPLATE_ID))).thenReturn("templateId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("name@mail");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("move_appt"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_status_code"))).thenReturn("1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("appointmentId1");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.FULLNAME))).thenReturn("John Doe");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.EMAIL))).thenReturn("JohnDoe@test.com");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.ID))).thenReturn("PatientPortalId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_CODE))).thenReturn("404");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_DETAILS))).thenReturn("Error Details");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDConstants.ERROR_MESSAGE))).thenReturn("Error Message");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_DURATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.INSURANCE_INFORMATION))).thenReturn("30");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.RESP_PARTY_ID))).thenReturn("respPartyId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_EXTERNAL_TEMPLATE_ID))).thenReturn(null);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AdvancedMDEngineConstants.APPT_TEMPLATE_ID))).thenReturn(null);

                JSONObject input = new JSONObject();
                input.put(DEPLOYMENT_ID, "testDeploymentId");
                input.put("appointmentTimingStart", "2023-10-10T10:00:00");
                input.put("visitType", "tele");

                JSONObject apiResponse = new JSONObject();
                apiResponse.put("appointmentId", "12345");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
                when(handlerUtils.isColWithProv(any(), eq(EPM_NAME_PREFIX))).thenReturn(true);
                when(advancedmdApiCaller.call(any(), eq(ApiName.SET_PATIENT_INSURANCE.getKey()), any(), eq("SetPatientInsurance")))
                        .thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.SEND_INVITATION.getKey()),
                        any(), eq("SendInvitation"))).thenReturn(new JSONObject());
                when(advancedmdApiCaller.call(any(), eq(ApiName.LOOKUP_PORTAL_ACCOUNT.getKey()),
                        any(), eq("LookUpPatientPortalAccount"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(AdvancedMDEngineConstants.EPM_NAME_PREFIX),
                        anyString(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(AdvancedMDConstants.COLOR_CONFIG),
                        eq(false))).thenReturn("");

                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(),
                        eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS), eq(false))).thenReturn(true);
                when(advancedmdApiCaller.call(
                        any(), eq(ApiName.MOVE_APPOINTMENT.getKey()),
                        any(), eq("MoveAppointment"))).thenReturn(new JSONObject());
                when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX),
                        any(), eq(ADVANCEDMD_CONFIG),
                        eq(TRIGGER_PATIENT_FORMS_RETRYCOUNT), eq(false)))
                        .thenReturn(3);

                assertThrows(Exception.class, () -> {
                    newAppointmentHandlerService.createNewAppointment(input);
                });
            }
        }
    }

    @Test
    void testIsColWithProvTrue_WithTemplateId() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String resourceString = "colId@resId";
        String templateId = "template123";
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<NullChecker> nullChecker = mockStatic(com.pes.integration.utils.NullChecker.class);
             MockedStatic<JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {

            nullChecker.when(() -> NullChecker.isEmpty(templateId)).thenReturn(false);
            jsonUtils.when(() -> JsonUtils.setValue(any(), eq(AdvancedMDEngineConstants.COLUMN_ID), eq(templateId))).thenAnswer(invocation -> null);
            jsonUtils.when(() -> JsonUtils.setValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID), eq("resId"))).thenAnswer(invocation -> null);

            Object result = ReflectionTestUtils.invokeMethod(service, "isColWithProvTrue", resourceString, templateId, inputObject);

            jsonUtils.verify(() -> JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COLUMN_ID, templateId), times(1));
            jsonUtils.verify(() -> JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPT_RESOURCE_ID, "resId"), times(1));
            assertEquals(inputObject, result);
        }
    }

    @Test
    void testIsColWithProvTrue_WithoutTemplateId() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String resourceString = "colId@resId";
        String templateId = "";
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<NullChecker> nullChecker = mockStatic(com.pes.integration.utils.NullChecker.class);
             MockedStatic<JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {

            nullChecker.when(() -> NullChecker.isEmpty(templateId)).thenReturn(true);
            jsonUtils.when(() -> JsonUtils.setValue(any(), eq(AdvancedMDEngineConstants.COLUMN_ID), eq("colId"))).thenAnswer(invocation -> null);
            jsonUtils.when(() -> JsonUtils.setValue(any(), eq(DocASAPConstants.Key.APPT_RESOURCE_ID), eq("resId"))).thenAnswer(invocation -> null);

            Object result = ReflectionTestUtils.invokeMethod(service, "isColWithProvTrue", resourceString, templateId, inputObject);

            jsonUtils.verify(() -> JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COLUMN_ID, "colId"), times(1));
            jsonUtils.verify(() -> JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPT_RESOURCE_ID, "resId"), times(1));
            assertEquals(inputObject, result);
        }
    }

    @Test
    void testIsColWithProvFalse_WithTemplateId() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String templateId = "template123";
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<NullChecker> nullChecker = mockStatic(NullChecker.class);
             MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class)) {

            nullChecker.when(() -> NullChecker.isEmpty(templateId)).thenReturn(false);
            jsonUtils.when(() -> JsonUtils.setValue(any(), eq(SLOT_ID), eq(templateId))).thenAnswer(invocation -> null);
            jsonUtils.when(() -> JsonUtils.getValue(any(), eq(SLOT_ID))).thenReturn(templateId);

            Object result = ReflectionTestUtils.invokeMethod(service, "isColWithProvFalse", templateId, inputObject);

            jsonUtils.verify(() -> JsonUtils.setValue(inputObject, SLOT_ID, templateId), times(1));
            assertEquals(inputObject, result);
        }
    }

    @Test
    void testIsColWithProvFalse_WithoutTemplateId() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String templateId = "";
        JSONObject inputObject = new JSONObject();

        String slotIdValue = "abc-123";
        try (MockedStatic<NullChecker> nullChecker = mockStatic(com.pes.integration.utils.NullChecker.class);
             MockedStatic<JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {

            nullChecker.when(() -> NullChecker.isEmpty(templateId)).thenReturn(true);
            jsonUtils.when(() -> JsonUtils.getValue(any(), eq(SLOT_ID))).thenReturn(slotIdValue);
            jsonUtils.when(() -> JsonUtils.setValue(any(), eq(SLOT_ID), eq("abc"))).thenAnswer(invocation -> null);

            Object result = ReflectionTestUtils.invokeMethod(service, "isColWithProvFalse", templateId, inputObject);

            jsonUtils.verify(() -> JsonUtils.setValue(inputObject, SLOT_ID, "abc"), times(1));
            assertEquals(inputObject, result);
        }
    }

    @Test
    void testGetColorConfig_IHubExceptionThrown_ColorConfigFromMap() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String deploymentId = "dep1";
        JSONObject inputObject = new JSONObject();
        inputObject.put("eventReasonId", "reason1");

        // Mock dependencies
        DataCacheManager mockDataManager = mock(DataCacheManager.class);
        HandlerUtils mockHandlerUtils = mock(HandlerUtils.class);
        ReflectionTestUtils.setField(service, "dataManager", mockDataManager);
        ReflectionTestUtils.setField(service, "handlerUtils", mockHandlerUtils);

        // Simulate exception from dataManager
        when(mockDataManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenThrow(new IHubException(null, "fail"));

        // Mock static NullChecker and JsonUtils
        try (MockedStatic<NullChecker> nullChecker = mockStatic(NullChecker.class);
             MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class)) {

            nullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(true);
            jsonUtils.when(() -> JsonUtils.getValue(any(), eq(com.pes.integration.constant.DocASAPConstants.Key.EVENT_REASON_ID)))
                    .thenReturn("reason1");

            Map<String, String> colorMap = new HashMap<>();
            colorMap.put("reason1", "blue");
            when(mockHandlerUtils.getApptTypeColorMap(deploymentId)).thenReturn(colorMap);

            String result = (String) ReflectionTestUtils.invokeMethod(service, "getColorConfig", deploymentId, inputObject);
            assertEquals("blue", result);
        }
    }

    @Test
    void testIsMoveAppt_ExceptionThrown_ReturnsFalse() {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("move_appt")))
                    .thenThrow(new RuntimeException("error"));

            boolean result = (boolean) ReflectionTestUtils.invokeMethod(service, "isMoveAppt", inputObject);
            assertFalse(result);
        }
    }

    @Test
    void testSendInvitation_RetryPositive_ErrorFieldsSet() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        String portalId = "portalId";
        String deploymentId = "depId";
        int retry = 1;

        // Set outputObject field
        ReflectionTestUtils.setField(service, "outputObject", new JSONObject());

        // Mock advancedmdApiCaller
        AdvancedmdApiCaller mockApiCaller = mock(AdvancedmdApiCaller.class);
        ReflectionTestUtils.setField(service, "advancedmdApiCaller", mockApiCaller);

        JSONObject inviteResponse = new JSONObject();
        inviteResponse.put("errorCode", "404");
        inviteResponse.put("errorDetails", "details");
        inviteResponse.put("errorMessage", "msg");
        when(mockApiCaller.call(eq(deploymentId), anyString(), any(), anyString())).thenReturn(inviteResponse);

        try (MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> dateUtils = mockStatic(DateUtils.class);
             MockedStatic<NullChecker> nullChecker = mockStatic(NullChecker.class)) {

            dateUtils.when(() -> DateUtils.getCurrentDate(any(), any(), anyInt())).thenReturn("20230101");
            jsonUtils.when(() -> JsonUtils.setValue(any(), any(), any())).thenAnswer(invocation -> null);
            jsonUtils.when(() -> JsonUtils.getValue(inviteResponse, AdvancedMDConstants.ERROR_CODE)).thenReturn("404");
            jsonUtils.when(() -> JsonUtils.getValue(inviteResponse, AdvancedMDConstants.ERROR_DETAILS)).thenReturn("details");
            jsonUtils.when(() -> JsonUtils.getValue(inviteResponse, AdvancedMDConstants.ERROR_MESSAGE)).thenReturn("msg");
            nullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(true);

            // Use reflection to invoke private method
            assertDoesNotThrow(() -> ReflectionTestUtils.invokeMethod(service, "sendInvitation", retry, portalId, inputObject, deploymentId));
        }
    }

    @Test
    void testSendInvitation_RetryNegative_EmptyOutputErrorsCalled() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        String portalId = "portalId";
        String deploymentId = "depId";
        int retry = -1;

        ReflectionTestUtils.setField(service, "outputObject", new JSONObject());

        try (MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> dateUtils = mockStatic(DateUtils.class)) {

            dateUtils.when(() -> DateUtils.getCurrentDate(any(), any(), anyInt())).thenReturn("20230101");
            jsonUtils.when(() -> JsonUtils.setValue(any(), any(), any())).thenAnswer(invocation -> null);

            // Should not throw, just call emptyOutputErrors
            assertDoesNotThrow(() -> ReflectionTestUtils.invokeMethod(service, "sendInvitation", retry, portalId, inputObject, deploymentId));
        }
    }

    @Test
    void testSendInvitation_ExceptionThrown_EmptyOutputErrorsCalled() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        String portalId = "portalId";
        String deploymentId = "depId";
        int retry = 1;

        ReflectionTestUtils.setField(service, "outputObject", new JSONObject());

        AdvancedmdApiCaller mockApiCaller = mock(AdvancedmdApiCaller.class);
        ReflectionTestUtils.setField(service, "advancedmdApiCaller", mockApiCaller);

        when(mockApiCaller.call(any(), any(), any(), any())).thenThrow(new RuntimeException("test"));

        try (MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> dateUtils = mockStatic(DateUtils.class)) {

            dateUtils.when(() -> DateUtils.getCurrentDate(any(), any(), anyInt())).thenReturn("20230101");
            jsonUtils.when(() -> JsonUtils.setValue(any(), any(), any())).thenAnswer(invocation -> null);

            assertDoesNotThrow(() -> ReflectionTestUtils.invokeMethod(service, "sendInvitation", retry, portalId, inputObject, deploymentId));
        }
    }


    @Test
    void testSavePortalId_ErrorFieldsPresent_ReturnsEmptyString() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";

        // Set outputObject field
        ReflectionTestUtils.setField(service, "outputObject", new JSONObject());

        // Mock advancedmdApiCaller
        AdvancedmdApiCaller mockApiCaller = mock(AdvancedmdApiCaller.class);
        ReflectionTestUtils.setField(service, "advancedmdApiCaller", mockApiCaller);

        JSONObject response = new JSONObject();
        when(mockApiCaller.call(eq(deploymentId), anyString(), any(), anyString())).thenReturn(response);

        try (MockedStatic<JsonUtils> jsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> dateUtils = mockStatic(DateUtils.class);
             MockedStatic<NullChecker> nullChecker = mockStatic(NullChecker.class)) {

            dateUtils.when(() -> DateUtils.getCurrentDate(any(), any(), anyInt())).thenReturn("20230101");
            jsonUtils.when(() -> JsonUtils.setValue(any(), any(), any())).thenAnswer(invocation -> null);
            jsonUtils.when(() -> JsonUtils.getValue(response, AdvancedMDConstants.ERROR_CODE)).thenReturn("404");
            jsonUtils.when(() -> JsonUtils.getValue(response, AdvancedMDConstants.ERROR_DETAILS)).thenReturn("details");
            jsonUtils.when(() -> JsonUtils.getValue(response, AdvancedMDConstants.ERROR_MESSAGE)).thenReturn("msg");
            nullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);

            // readConfig returns dummy value
            Method method = NewAppointmentHandlerService.class.getDeclaredMethod("savePortalId", Object.class, String.class);
            method.setAccessible(true);

            String result = (String) method.invoke(service, inputObject, deploymentId);
            assertEquals("", result);
        }
    }

}