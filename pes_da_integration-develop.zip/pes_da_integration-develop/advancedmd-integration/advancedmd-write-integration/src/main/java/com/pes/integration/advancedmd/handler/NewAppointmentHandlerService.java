package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractNewAppointmentHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.APPT_EXTERNAL_TEMPLATE_ID;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@Slf4j
@Service(value = "NewAppt")
public class NewAppointmentHandlerService extends AbstractNewAppointmentHandler {

    @Autowired
    HandlerUtils handlerUtils;

    public JSONObject requestObject;

    public Object outputObject;

    @Autowired
    DataCacheManager dataManager;

    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    private static final String CONFIGURATION_NOT_FOUND = " Configuration not found for deploymentId : {}";

    @Override
    public JSONObject createNewAppointment(Object inputObject) throws IHubException {

        try {
            Object appointmentId;
            String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
            String date = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START);
            String apptTime = DateUtils.convertDateFormat(date, DocASAPConstants.DATE_TIME_FORMAT, AdvancedMDConstants.DATE_TIME_FORMAT);

            JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START, apptTime);
            String visitType = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.VISIT_TYPE);
            if (!NullChecker.isEmpty(visitType) && visitType.equals("tele")) {
                JsonUtils.setValue(inputObject, DocASAPConstants.Key.IS_TELEMEDICINE, true);
            }
            String resourceString = "";
            String templateId = templateId(inputObject);

            if (handlerUtils.isColWithProv(deploymentId, EPM_NAME_PREFIX)) {
                resourceString = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.APPT_RESOURCE_ID);
                inputObject = isColWithProvTrue(resourceString, templateId, inputObject);
            } else {
                inputObject = isColWithProvFalse(templateId, inputObject);
            }
            JsonUtils.setValue(inputObject, "Color", getColorConfig(deploymentId, inputObject));

            if (isMoveAppt(inputObject))
                rescheduleAppointment(deploymentId, inputObject);
            else {
                JSONObject episodeJson;
                episodeJson = advancedmdApiCaller.call(deploymentId, ApiName.GET_EPISODES.getKey(), inputObject, "getEpisodes");
                Object episodeErrorCode =JsonUtils.getValue(episodeJson, "temp.error_code");
                if(episodeErrorCode==null) {
                    JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.APPT_EPISODE_ID, JsonUtils.getValue(episodeJson, AdvancedMDEngineConstants.EPISODE_ID));
                    outputObject = advancedmdApiCaller.call(deploymentId, ApiName.NEW_APPOINTMENT.getKey(), inputObject, "NewAppointment");
                }else{
                    inputObject=episodeErrorCode;
                    return new JSONObject(inputObject.toString());
                }
            }
            Object errorCode =JsonUtils.getValue(outputObject, "temp.error_status_code");
            if (errorCode == null){
                appointmentId = JsonUtils.getValue(outputObject, DocASAPConstants.Key.APPOINTMENT_ID);
                inputObject = generateResponse(appointmentId, inputObject, deploymentId, resourceString, date);
            }else {
                Object errorMessage = getValue(outputObject, "temp.error_message");
                if(errorMessage !=null){
                    throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), errorMessage.toString());
                }
                inputObject=outputObject;
            }
        } catch (Exception e) {
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), e.toString());

        }
        return new JSONObject(inputObject.toString());
    }

    private String templateId(Object inputObject) throws IHubException {
        String templateId = "";
        Object externalTemplateId = JsonUtils.getValue(inputObject, APPT_EXTERNAL_TEMPLATE_ID);
        Object templateIdObj = JsonUtils.getValue(inputObject, AdvancedMDEngineConstants.APPT_TEMPLATE_ID);

        if(!NullChecker.isEmpty(externalTemplateId)) {
            templateId = !externalTemplateId.toString().equals("null") ? externalTemplateId.toString() : EMPTY;
        } else if (!NullChecker.isEmpty(templateIdObj)) {
            templateId = !templateIdObj.toString().equals("null") ? templateIdObj.toString() : EMPTY;
        } else {
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), "Either ExternalTemplateId or TemplateId should be present to process the booking flow");
        }
        return templateId;
    }

    private Object isColWithProvTrue(String resourceString, String templateId, Object inputObject) throws IHubException {
        String[] resourceSplitArr = resourceString.split(UtilitiesConstants.CharacterConstants.ATMARK);
        if (!NullChecker.isEmpty(templateId)) {
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COLUMN_ID, templateId);
        } else {
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COLUMN_ID, resourceSplitArr[0]);
        }
        JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPT_RESOURCE_ID, resourceSplitArr[1]);
        return inputObject;
    }

    private Object isColWithProvFalse(String templateId, Object inputObject) throws IHubException {
        if (!NullChecker.isEmpty(templateId)) {
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.SLOT_ID, templateId);
        } else {
            String slotId = (String) JsonUtils.getValue(inputObject, AdvancedMDEngineConstants.SLOT_ID);
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.SLOT_ID, slotId.substring(0, slotId.indexOf('-')));
        }
        log.info("slotId:: " + sanitizeForLog(String.valueOf(JsonUtils.getValue(inputObject, AdvancedMDEngineConstants.SLOT_ID))));

        return inputObject;
    }

    private Object generateResponse(Object appointmentId, Object inputObject, String deploymentId, String resourceString, String date) throws IHubException {
        boolean triggerPatientForms = getPatientFormsFlag(deploymentId);
        log.info("appointmentId  : " + appointmentId + " triggerPatientForms flag value :" + triggerPatientForms);
        if (!NullChecker.isEmpty(appointmentId) && triggerPatientForms) {
            JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPOINTMENT_ID, appointmentId);
            int retry = readPatientFormRetryCount(deploymentId);
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.FULLNAME,
                    String.valueOf(JsonUtils.getValue(outputObject, AdvancedMDEngineConstants.FULLNAME)));
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.EMAIL,
                    String.valueOf(JsonUtils.getValue(outputObject, AdvancedMDEngineConstants.EMAIL)));
            String portalId = lookupPatientPortalId(deploymentId, inputObject);
            if (!NullChecker.isEmpty(portalId)) {
                sendInvitation(retry, portalId, inputObject, deploymentId);
            } else {
                sendInvitation(retry, savePortalId(inputObject, deploymentId), inputObject, deploymentId);
            }
        } else {
            log.info("trigger patient forms not configured and required.");
        }

        if (handlerUtils.isColWithProv(deploymentId, EPM_NAME_PREFIX)) {
            JsonUtils.setValue(outputObject, DocASAPConstants.Key.APPT_RESOURCE_ID, resourceString);
            JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPT_RESOURCE_ID, resourceString);
        }

        Object duration = JsonUtils.getValue(outputObject, DocASAPConstants.Key.APPOINTMENT_DURATION);
        if (!NullChecker.isEmpty(duration))
            JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPOINTMENT_DURATION, duration);

        JsonUtils.setValue(outputObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START, date);
        JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START, date);
        Object insuranceInfo = JsonUtils.getValue(inputObject, DocASAPConstants.Key.INSURANCE_INFORMATION);
        if (!NullChecker.isEmpty(insuranceInfo) && isSetInsurance(deploymentId)) {
            setPatientInsurance(inputObject);
        }
        JsonUtils.setValue(inputObject, DocASAPConstants.Key.APPOINTMENT_ID, appointmentId.toString());

        return inputObject;
    }

    private String getColorConfig(String deploymentId, Object inputObject) throws IHubException {

        String colorConfig = "";
        try {
            colorConfig = String.valueOf(dataManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX,deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG,AdvancedMDConstants.COLOR_CONFIG, false));
        } catch (IHubException e) {
            log.info(AdvancedMDConstants.COLOR_CONFIG + "Color Config not set for deploymentId "+deploymentId);
        }
        if(NullChecker.isEmpty(colorConfig)) {
            String reasonId = (String)JsonUtils.getValue(inputObject, DocASAPConstants.Key.EVENT_REASON_ID);
            Map<String, String> apptTypeColorMap = handlerUtils.getApptTypeColorMap(deploymentId);
            colorConfig = apptTypeColorMap.get(reasonId);
        }
        return colorConfig;
    }

    private boolean isMoveAppt(Object inputObject){
        boolean isMoved = false;
        try {
            Object moveAppt = JsonUtils.getValue(inputObject, "move_appt");
            log.info("move_appt::"+ moveAppt.equals(1));
            return moveAppt.equals(1);
        } catch (Exception e) {
            isMoved = false;
        }
        return isMoved;
    }

    private void rescheduleAppointment(String deploymentId,Object inputObject) throws IHubException{
        log.info(deploymentId);
        try {
            JsonUtils.setValue(inputObject, "SchedulingData.Schedule[0].ExApptId",  JsonUtils.getValue(inputObject, DocASAPConstants.Key.APPOINTMENT_ID));
            requestObject = advancedmdApiCaller.call(deploymentId, ApiName.MOVE_APPOINTMENT.getKey(), inputObject, "MoveAppointment");
        } catch(Exception e) {
            log.error("Error in reschedule appointment"+e.getMessage());
        }
    }

    private boolean getPatientFormsFlag(String deploymentId) throws IHubException{
        boolean triggerPatientForm = false;
        try {
            String triggerForm = (String)dataManager.getStoredProvidersConfig(EPM_NAME_PREFIX,deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.TRIGGER_PATIENT_FORMS,false);
            triggerPatientForm = triggerForm.equalsIgnoreCase(UtilitiesConstants.TRUE);
        } catch (IHubException e) {
            log.info(AdvancedMDConstants.TRIGGER_PATIENT_FORMS + CONFIGURATION_NOT_FOUND, deploymentId);
            triggerPatientForm = false;
        }
        return triggerPatientForm;
    }

    private int readPatientFormRetryCount(String deploymentId) {
        int retryCount = 1;
        try{
            String retryCountStr = (String)dataManager.getStoredProvidersConfig(EPM_NAME_PREFIX,deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.TRIGGER_PATIENT_FORMS_RETRYCOUNT,false);
            retryCount = Integer.parseInt(retryCountStr);
        }catch(Exception e){
            //do nothing default value will be considered
        }
        return retryCount;
    }

    private String lookupPatientPortalId(String deploymentId, Object inputObject) throws IHubException {

        JSONObject lookupResponseObject;
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.MSG_TIME,DateUtils.getCurrentDate(AdvancedMDConstants.DATE_TIME_FORMAT, "", 0));
        lookupResponseObject=advancedmdApiCaller.call(deploymentId, ApiName.LOOKUP_PORTAL_ACCOUNT.getKey(), inputObject, "LookUpPatientPortalAccount");
        return (String) JsonUtils.getValue(lookupResponseObject, AdvancedMDEngineConstants.ID);
    }

    private void sendInvitation(int retry, String portalId,Object inputObject,String deploymentId) throws IHubException {

        JSONObject inviteResponseObject = new JSONObject();
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.MSG_TIME,DateUtils.getCurrentDate(AdvancedMDConstants.DATE_TIME_FORMAT, "", 0));
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.PORTAL_ID, portalId);
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.APPLICATION_ID, readConfig(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.SEND_INVITE_APP_ID,deploymentId));
        try {
            if(retry >= 0) {
                inviteResponseObject=advancedmdApiCaller.call(deploymentId, ApiName.SEND_INVITATION.getKey(), inputObject,"SendInvitation");
                String error = (String) JsonUtils.getValue(inviteResponseObject, AdvancedMDConstants.ERROR_CODE);
                String errorDetails = (String) JsonUtils.getValue(inviteResponseObject,AdvancedMDConstants.ERROR_DETAILS);
                String errorMessage = (String) JsonUtils.getValue(inviteResponseObject,AdvancedMDConstants.ERROR_MESSAGE);
                if ((!NullChecker.isEmpty(error) || !NullChecker.isEmpty(errorDetails)
                        || !NullChecker.isEmpty(errorMessage))) {
                    JsonUtils.setValue(outputObject, DocASAPConstants.TempKey.ERROR_MESSAGE, error+" "+errorMessage);
                    JsonUtils.setValue(outputObject, DocASAPConstants.TempKey.ERROR_DETAIL, errorDetails);
                }
            }else {
                emptyOutputErrors();
            }
        } catch (Exception e) {
            emptyOutputErrors();
            log.error(e.getMessage());
        }
    }

    private String readConfig(String pConfigGroup, String pConfKey,String deploymentId) throws IHubException {
        log.info(deploymentId);
        try {
            return (String) dataManager.getStoredProvidersConfig(EPM_NAME_PREFIX,deploymentId, pConfigGroup, pConfKey,false);
        } catch (Exception e) {
            log.info(pConfKey + CONFIGURATION_NOT_FOUND,  deploymentId);
            return "0";
        }
    }

    private void emptyOutputErrors() throws IHubException {
        String errorMsg = (String) JsonUtils.getValue(outputObject, DocASAPConstants.TempKey.ERROR_MESSAGE);
        String errorDetail = (String) JsonUtils.getValue(outputObject, DocASAPConstants.TempKey.ERROR_DETAIL);
        if(errorMsg!=null || errorDetail!=null) {
            JsonUtils.setValue(outputObject, DocASAPConstants.TempKey.ERROR_MESSAGE, null);
            JsonUtils.setValue(outputObject, DocASAPConstants.TempKey.ERROR_DETAIL, null);
        }
    }

    private String savePortalId(Object inputObject,String deploymentId) throws IHubException {

        JSONObject saveAccountResponseObject;
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.MSG_TIME,
                DateUtils.getCurrentDate(AdvancedMDConstants.DATE_TIME_FORMAT, "", 0));
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COMMENT, "");
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.DISPLAY,
                readConfig(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.SAVE_ACC_DISPLAY_FORMS,deploymentId));
        JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.DISABLE,
                readConfig(AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.SAVE_ACC_DISABLE_FORMS,deploymentId));
        saveAccountResponseObject=advancedmdApiCaller.call(deploymentId, ApiName.SAVE_PORTAL_ACCOUNT.getKey(), inputObject, "SavePortalAccount");
        String error = (String) JsonUtils.getValue(saveAccountResponseObject, AdvancedMDConstants.ERROR_CODE);
        String errorDetails = (String) JsonUtils.getValue(saveAccountResponseObject, AdvancedMDConstants.ERROR_DETAILS);
        String errorMessage = (String) JsonUtils.getValue(saveAccountResponseObject, AdvancedMDConstants.ERROR_MESSAGE);
        if ((!NullChecker.isEmpty(error) || !NullChecker.isEmpty(errorDetails) || !NullChecker.isEmpty(errorMessage))) {
            JsonUtils.setValue(outputObject, DocASAPConstants.TempKey.ERROR_MESSAGE, error + " " + errorMessage);
            JsonUtils.setValue(outputObject, DocASAPConstants.TempKey.ERROR_DETAIL, errorDetails);
            return "";
        }
        return (String) JsonUtils.getValue(saveAccountResponseObject, AdvancedMDEngineConstants.ID);

    }

    private boolean isSetInsurance(String deploymentId){
        boolean isSetInsurance = false;
        try {
            String setInsVal = (String)dataManager.getStoredProvidersConfig(EPM_NAME_PREFIX,deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.SET_INSURANCE,false);
            isSetInsurance = setInsVal.equalsIgnoreCase(UtilitiesConstants.TRUE);
        } catch (IHubException e) {
            log.info(AdvancedMDConstants.SET_INSURANCE + CONFIGURATION_NOT_FOUND,  deploymentId);
            isSetInsurance = false;
        }
        return isSetInsurance;
    }

    private void setPatientInsurance(Object inputObject) {
        String deploymentId = String.valueOf(JsonUtils.getValue(inputObject, DEPLOYMENT_ID));
        try {
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.EFFECTIVE_DATE, DateUtils.getCurrentDate(DocASAPConstants.DOCASAP_DATE_FORMAT, "", 0));
            JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.HIPPA_RELATIONSHIP, "18");
            String respPartyId = String.valueOf(JsonUtils.getValue(outputObject, AdvancedMDEngineConstants.RESP_PARTY_ID));
            JsonUtils.setValue(inputObject, DocASAPConstants.Key.INS_SUBSCRIBER_ID, respPartyId);
            requestObject = advancedmdApiCaller.call(deploymentId, ApiName.SET_PATIENT_INSURANCE.getKey(), inputObject,"SetPatientInsurance");
        } catch (Exception e) {
            log.error("Error in setPatientInsurance() "+e.getMessage());
        }
    }

}