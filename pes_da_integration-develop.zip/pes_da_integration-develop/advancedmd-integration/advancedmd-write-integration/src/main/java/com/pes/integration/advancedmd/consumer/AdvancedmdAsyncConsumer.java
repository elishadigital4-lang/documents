package com.pes.integration.advancedmd.consumer;

import com.pes.integration.service.AsyncConsumerService;
import com.pes.integration.service.impl.KafkaServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AdvancedmdAsyncConsumer extends KafkaServiceImpl {

  @Value("${kafka.sync.data.topic}")
  String syncDataTopic;

  @Autowired
  AsyncConsumerService asyncConsumerService;
  @KafkaListener(topics = "${kafka.async.topic}",
          groupId = "${kafka.config.group.id}", containerFactory = "sampleListListener")
  public void consumeAsyncMessage(@Payload(required = false) String payload) {
    log.info("received Async event on epm topic");
    asyncConsumerService.processAsyncMessage(syncDataTopic, payload);
  }

  @Override
  public void listen(String topic, String message) {
    log.info("received Async event on topic= {}", topic);
    String orgSyncDataTopic = topic.replace("d2e", "e2d");
    asyncConsumerService.processAsyncMessage(orgSyncDataTopic, message);
  }
}
