package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractCancelAppointmentsHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_OBJECT;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;

@Slf4j
@Service(value = "CancelAppt")
public class CancelAppointmentsHandlerService extends AbstractCancelAppointmentsHandler {

    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    @Override
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = cancelAppointment(inputObject);
        if(outputObject.has("temp")){
            return prepareResponse(inputObject, outputObject);
        }else {
            JSONObject responseObject = new JSONObject();
            setValue(responseObject, APPOINTMENT_OBJECT, inputObject);
            return prepareResponse(inputObject, responseObject);
        }

    }
    @Override
    public JSONObject cancelAppointment(JSONObject inputObject) throws IHubException {
        JSONObject requestObject = new JSONObject();

        try {
            String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
            JsonUtils.setValue(inputObject, DocASAPConstants.Key.EVENT_REASON_ID, dataCacheManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX,
                    deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.DEFAULT_CANCEL_REASON, false));
            JsonUtils.setValue(inputObject, "SchedulingData.Schedule[0].ExApptId",  JsonUtils.getValue(inputObject, DocASAPConstants.Key.APPOINTMENT_ID));
            requestObject = advancedmdApiCaller.call(deploymentId,ApiName.CANCEL_APPOINTMENT.getKey(), inputObject, "CancelAppointment");
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new IHubException(StatusCodes.EPM_INTERNAL_ERROR, e.getMessage(), e.getMessage());
        }
        return requestObject;
    }
}
