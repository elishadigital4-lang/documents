package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service(value = "UpdatePatient")
public class UpdatePatientHandler extends BaseHandler {


    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    @Override
    @Observed(name = "integration.advancedmdUpdateNewPatient", contextualName = "integration")
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        JSONObject dataObject = new JSONObject();
        JSONObject responseObject = new JSONObject();
        JSONObject requestObject = new JSONObject();
        try {

            PhoneNumberUtils.handlePhoneNumberD2E((JSONObject) inputObject);
            PhoneNumberUtils.handlePhoneNumberFromFlag((JSONObject) inputObject);


            String externalPatientId = JsonUtils.getValue(inputObject, DocASAPConstants.Key.PATIENT_ID).toString();
            JSONObject patientObject = new JSONObject();
            JsonUtils.setValue(patientObject, DocASAPConstants.Key.PATIENT_ID, externalPatientId);
            responseObject = new JSONObject();


            String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
            JsonUtils.setValue(patientObject, DocASAPConstants.Key.DEPLOYMENT_ID, deploymentId);
            // PROD-59177
            JsonUtils.copyKey(UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, inputObject, patientObject);
            JsonUtils.copyKey(UtilitiesConstants.JsonConstants.MESSAGE_TYPE, inputObject, patientObject);

            if (!NullChecker.isEmpty(JsonUtils.getValue(inputObject, DocASAPConstants.Key.UPDATE_PATIENT_EMAIL)))
                updatePatientEmail(inputObject, patientObject);

            updatePatientPhone(inputObject, patientObject);
            updatePatientAddress(inputObject, patientObject);

            requestObject = advancedmdApiCaller.call(deploymentId, ApiName.UPDATE_PATIENT.getKey(), patientObject, "UpdatePatient");
            responseObject = advancedmdApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), patientObject, String.valueOf(responseObject));
            PhoneNumberUtils.handlePhoneNumbersE2D(inputObject);
            JsonUtils.setValue(responseObject, DocASAPConstants.TempKey.TEMP, null);
            dataObject.put("data", new JSONObject().put("appointment_sync", new JSONArray().put(inputObject)));
        } catch (IHubException ihe) {
            log.error("Error in updating the patient {} ", ihe.getMessage());
            throw ihe;
        }
        return dataObject;
    }

    private void updatePatientAddress(JSONObject inputObject, JSONObject patientObject) {
        try {
            Object updatePatientAddressFlag = JsonUtils.getValue(inputObject, DocASAPConstants.Key.UPDATE_PATIENT_ADDRESS);
            if (!NullChecker.isEmpty(updatePatientAddressFlag)
                    && (updatePatientAddressFlag.toString()).equals(AdvancedMDConstants.ONE)) {
                String address1 = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.STREET1);
                String address2 = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.STREET2);
                String city = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.CITY);
                String state = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.SATE);
                String zip = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.ZIP);

                if (!NullChecker.isEmpty(address1))
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.STREET1, address1);
                if (!NullChecker.isEmpty(address2))
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.STREET2, address2);
                if (!NullChecker.isEmpty(city))
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.CITY, city);
                if (!NullChecker.isEmpty(state))
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.SATE, state);
                if (!NullChecker.isEmpty(zip))
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.ZIP, zip);
            }
        } catch (IHubException e) {
            log.error("EXCEPTION:: UpdatePatientAddress flow - while setting up Address {} ",e.getMessage());
        }
    }


    private void updatePatientEmail(Object inputObject, JSONObject patientObject) throws IHubException {

        Object updatePatientEmailFlag = JsonUtils.getValue(inputObject, DocASAPConstants.Key.UPDATE_PATIENT_EMAIL);
        if (!NullChecker.isEmpty(updatePatientEmailFlag)
                && (updatePatientEmailFlag.toString()).equals(AdvancedMDConstants.ONE)) {
            String email = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.EMAIL);
            try {
                JsonUtils.setValue(patientObject, DocASAPConstants.Key.EMAIL, email);
            } catch (IHubException e) {
                log.error("EXCEPTION:: UpdatePatientEmail flow - while setting up email {} ",e.getMessage());
                throw new IHubException(StatusCodes.EPM_INTERNAL_ERROR, e.getMessage(), e.getMessage());
            }
        }
    }

    private void updatePatientPhone(Object inputObject, JSONObject patientObject) throws IHubException {
        if (checkIfFlagValid(inputObject, DocASAPConstants.Key.UPDATE_PATIENT_CPHONE))
            setKeyValue(inputObject, patientObject, DocASAPConstants.Key.MOBILE_PHONE);
        if (checkIfFlagValid(inputObject, DocASAPConstants.Key.UPDATE_PATIENT_WPHONE))
            setKeyValue(inputObject, patientObject, DocASAPConstants.Key.WORK_PHONE);
        if (checkIfFlagValid(inputObject, DocASAPConstants.Key.UPDATE_PATIENT_HPHONE))
            setKeyValue(inputObject, patientObject, DocASAPConstants.Key.HOME_PHONE);

    }

    private boolean checkIfFlagValid(Object inputObject, String testKey) throws IHubException {
        try {
            if (!NullChecker.isEmpty(JsonUtils.getValue(inputObject, testKey))) {
                Object updatePhoneFlag = JsonUtils.getValue(inputObject, testKey);
                if (!NullChecker.isEmpty(updatePhoneFlag)
                        && (updatePhoneFlag.toString()).equals(AdvancedMDConstants.ONE)) {
                    return true;
                }
            }
        } catch (Exception ex) {
            log.error(
                    "EXCEPTION:: UpdatePatientPhone flow - While checking the validity of the following updatePatient flag:"
                            + testKey);
            ex.printStackTrace();
            throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, ex.getMessage(), ex.getMessage());
        }
        return false;
    }

    private void setKeyValue(Object inputObject, JSONObject patientObject, String setKey) throws IHubException {
        String value = (String) JsonUtils.getValue(inputObject, setKey);
        try {
            JsonUtils.setValue(patientObject, setKey, value);
        } catch (IHubException e) {
            log.error("EXCEPTION:: UpdatePatientPhone flow - while setting up Phone");
            e.printStackTrace();
            throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getMessage(), e.getMessage());
        }
    }
}