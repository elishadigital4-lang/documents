package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.advancedmd.api.ApiName.GET_PATIENT;
import static com.pes.integration.advancedmd.api.ApiName.GET_PATIENTS;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;


@Slf4j
@Service
public class GetPatientHandler extends BaseHandler {

  @Autowired
  AdvancedmdApiCaller advancedmdApiCaller;



  @Override
  @Observed(name = "integration.advancedmdGetPatient", contextualName = "integration")
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    JSONObject outputObject = null;
    try {
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      outputObject = advancedmdApiCaller.call(deploymentId,GET_PATIENT.getKey(), inputObject, "");
      outputObject.remove("pagecount");
      outputObject.remove("page");
    } catch (Exception e) {
      log.error(e.getMessage());
      throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getMessage(), e.getMessage());
    }
    return outputObject;
  }
}

