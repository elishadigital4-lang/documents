package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractMatchPatientHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.*;

import static com.pes.integration.advancedmd.api.ApiName.GET_PATIENT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.COMMA;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.StatusCodes.MULTIPLE_PATIENT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.util.Arrays.asList;
import static java.util.stream.IntStream.range;

@Slf4j
@Service
public class MatchPatientHandler extends AbstractMatchPatientHandler {

    @Autowired
    protected DataCacheManager cacheManager;

    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    String deploymentId;

    @Override
    public JSONObject getPatients(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        this.deploymentId=deploymentId;
        log.info("DeploymentId in MatchPatient :{}",deploymentId);
        try {
            setValue(inputObject, AdvancedMDEngineConstants.PAGE, readPageConfig(deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDEngineConstants.PAGE));
            outputObject = advancedmdApiCaller.call(deploymentId, GET_PATIENT.getKey(), inputObject, "patient_search");
            String pageCountVal = String.valueOf(getValue(outputObject, AdvancedMDEngineConstants.PAGE_COUNT));
            JSONArray data;
            if (((JSONObject) outputObject).has(AdvancedMDEngineConstants.APPOINTMENT_SYNC)) {
                data = ((JSONObject) outputObject).getJSONArray(AdvancedMDEngineConstants.APPOINTMENT_SYNC);
                processnextPageGetPatients(inputObject, outputObject, pageCountVal, data);
            }
            setValue(inputObject, AdvancedMDEngineConstants.PAGE, null);
        } catch (IHubException e) {
            log.error("Error {} ", e.getMessage());
            outputObject.put("Error", e.getMessage());
        }
        return outputObject;
    }


    public JSONArray getPatientDemographicsDetails(JSONArray patientsArray) throws IHubException {
    log.info("Started getPatientDemographicsDetails.");
        JSONArray finalPatientsArray = new JSONArray();
        if(!NullChecker.isEmpty(patientsArray)){
            for (int i = 0; i < patientsArray.length(); i++) {
                JSONObject patientObject = patientsArray.getJSONObject(i);
                String name =  (String) JsonUtils.getValue(patientObject, DocASAPConstants.Key.FIRST_NAME);
                String[] nameSplitArr = name.split(CharacterConstants.COMMA);
                //PROD-34743
                String lName = nameSplitArr[0];
                String fName = nameSplitArr[1];
                String[] lOrFnameSplitArr = null;
                if (lName.contains(" ")) {
                    lOrFnameSplitArr = lName.split(" ");
                    setValue(patientObject, DocASAPConstants.Key.FIRST_NAME, fName);
                    setValue(patientObject, DocASAPConstants.Key.LAST_NAME, lOrFnameSplitArr[0]);
                } else if (fName.contains(" ")) {
                    lOrFnameSplitArr = fName.split(" ");
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.FIRST_NAME, lOrFnameSplitArr[0]);
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.LAST_NAME, lName);
                }else {
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.FIRST_NAME, fName);
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.LAST_NAME, lName);
                }
                formatDob(patientObject);
                JSONObject inputJson = new JSONObject();
                JSONObject outputJson;
                Object exPatientId = JsonUtils.getValue(patientObject, DocASAPConstants.Key.PATIENT_ID);
                if(!NullChecker.isEmpty(exPatientId)){
                    JsonUtils.setValue(inputJson, DocASAPConstants.Key.PATIENT_ID, exPatientId.toString().substring(3));
                }
                outputJson=advancedmdApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputJson, "get_patient_demographics");
                String inactive = (String)JsonUtils.getValue(outputJson, AdvancedMDEngineConstants.INACTIVE);
                String deceased = (String)JsonUtils.getValue(outputJson, AdvancedMDEngineConstants.DECEASED);
                String email =  (String)JsonUtils.getValue(outputJson, DocASAPConstants.Key.EMAIL);
                String cellPhone =  (String)JsonUtils.getValue(outputJson, DocASAPConstants.Key.MOBILE_PHONE);
                JsonUtils.setValue(patientObject, DocASAPConstants.Key.MOBILE_PHONE, cellPhone);
                JsonUtils.setValue(patientObject, DocASAPConstants.Key.EMAIL, email);
                if(checkPatientID(inactive,deceased)){
                    log.info(exPatientId+" patient is inactive or deceased ");
                } else finalPatientsArray.put(patientObject);
            }
        }
        return finalPatientsArray;
    }

    public boolean checkPatientID(String inactive, String deceased) throws IHubException {
        return (getMatchPatientInactiveConfig(deploymentId) && !(NullChecker.isEmpty(inactive) && NullChecker.isEmpty(deceased)));
    }

    @Override
    public boolean isSingleMatch() throws IHubException {
        return false;
    }

    private String readPageConfig(String deploymentId, String configGroup, String confKey) throws IHubException {
    log.info("Inside readPageConfig method of MatchPatientHandler : deploymentId is : "+deploymentId+" and configGroup is : "+configGroup+" and confKey is "+confKey);
        try {
            return (String) cacheManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, configGroup, confKey, false);
        } catch (Exception e) {
            log.info(confKey + " Config not set for deploymentId " + deploymentId);
            return "0";
        }
    }

    private void processnextPageGetPatients(JSONObject inputObject, JSONObject outputObject, String pageCount, JSONArray data) throws IHubException {
        JSONObject respObj;
        JSONArray remPageData;
        if (Integer.valueOf(pageCount) > 1) {
            for (int page = 2; page <= Integer.valueOf(pageCount); page++) {
                setValue(inputObject, AdvancedMDEngineConstants.PAGE, String.valueOf(page));
                respObj= advancedmdApiCaller.call(deploymentId, GET_PATIENT.getKey(), inputObject, "patient_search");
                if ((respObj).has(AdvancedMDEngineConstants.APPOINTMENT_SYNC)) {
                    remPageData = (respObj).getJSONArray(AdvancedMDEngineConstants.APPOINTMENT_SYNC);
                    for (Object remObject : remPageData) {
                        data.put(remObject);
                    }
                }
                setValue(outputObject, AdvancedMDEngineConstants.APPOINTMENT_SYNC, data);
                setValue(inputObject, AdvancedMDEngineConstants.PAGE, null);
                setValue(outputObject, AdvancedMDEngineConstants.PAGE, null);
                setValue(outputObject, AdvancedMDEngineConstants.PAGE_COUNT, null);
            }
        }

    }

    private void formatDob(JSONObject patientObject) throws IHubException {
        String dob = (String) JsonUtils.getValue(patientObject, DocASAPConstants.Key.DOB);
        try {
            dob = DateUtils.convertDateFormat(dob, AdvancedMDConstants.DOB_DATE_FORMAT, AdvancedMDConstants.DATE_FORMAT);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        JsonUtils.setValue(patientObject, DocASAPConstants.Key.DOB, dob);
    }


    private boolean getMatchPatientInactiveConfig(String deploymentId) throws IHubException{
        try {
            String config = (String) cacheManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.INACTIVE_PAT_CONF,false);
            return config.equalsIgnoreCase(UtilitiesConstants.TRUE);
        } catch (IHubException e) {
            return false;
        }
    }
}
