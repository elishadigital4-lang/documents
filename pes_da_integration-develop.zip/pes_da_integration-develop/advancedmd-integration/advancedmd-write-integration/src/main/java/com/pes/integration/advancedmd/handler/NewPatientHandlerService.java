package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractNewPatientHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.Key.DA_PATIENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.DOB;
import static com.pes.integration.constant.DocASAPConstants.Key.MESSAGE_TYPE;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP_PATIENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.Flow.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.enums.FlowStatus.SUCCESS;
import static com.pes.integration.enums.StatusCodes.MULTIPLE_PATIENT;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static com.pes.integration.utils.PhoneNumberUtils.handlePhoneNumberD2E;
import static com.pes.integration.utils.PhoneNumberUtils.handlePhoneNumbersE2D;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;

@Slf4j
@Service(value = "NewPatient")
public class NewPatientHandlerService extends AbstractNewPatientHandler {

    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    String externalPatientId;

    JSONObject insuranceObject;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    DataCacheManager dataManager;

    @Autowired
    MatchPatientHandler matchPatientHandler;


    @Override
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        {
            JSONObject outputObject = new JSONObject();
            JSONObject responseObject;
            handlePhoneNumberD2E(inputObject);
            validateDob(inputObject);
            JSONObject createPatientResponse = createNewPatient(inputObject);
            Object error = getValue(createPatientResponse, "temp.error_code");
            if (error == null) {
                copyKey(DA_PATIENT_ID, inputObject, outputObject);
                String patientId = null;
                try {
                    patientId = (String) getValue(createPatientResponse, Key.PATIENT_ID);
                } catch (Exception e1) {
                    log.info("createPatientResponse: {}  with error {} ", sanitizeForLog(String.valueOf(createPatientResponse)), e1.getMessage());
                }
                log.debug("externalPatientId: {} " , sanitizeForLog(patientId));
                setValue(createPatientResponse, TEMP_PATIENT_ID, patientId);
                if (patientId != null) {
                    JSONObject demographicsResponse = getPatientDemographics(inputObject.getString("deployment_id"), createPatientResponse, inputObject);
                    copyKey(DEPLOYMENT_ID, inputObject, demographicsResponse);
                    JSONObject insuranceResponse = getPatientInsuranceInfo(inputObject.getString("deployment_id"), demographicsResponse);
                    copyKey(INSURANCE_INFORMATION, insuranceResponse, demographicsResponse);
                    outputObject = demographicsResponse;
                    updateObjectValue(inputObject, outputObject);
                    handlePhoneNumbersE2D(outputObject);
                    try {
                        String dob = getValue(outputObject, DOB).toString();
                        dob = convertDateFormat(dob, EPM_DATE_FORMAT, DOCASAP_DATE_FORMAT);
                        setValue(outputObject, DOB, dob);
                        outputObject.remove("temp");
                    } catch (IHubException e) {
                        log.error("Error in {}, error message : {}", ApiName.NEW_PATIENT.getKey(), e.getMessage());
                        throw e;
                    } catch (ParseException e) {
                        log.info("DOB received was invalid or null.");
                    }
                }
                setNotificationPreferenceInResponseObject(inputObject, outputObject);
                if (createPatientResponse.has("error_detail")) {
                    outputObject.put("Error", createPatientResponse.optString("error_detail"));
                }
                responseObject = prepareResponse(inputObject, outputObject);
                JSONObject response = new JSONObject();
                setValue(response, APPOINTMENT_OBJECT, responseObject);
                dataTransactionService.logData(response, CREATE_PATIENT.getKey(), SUCCESS.getKey(),
                        "iHub Create Patient Successful");
                return response;
            }
            responseObject = prepareResponse(inputObject, createPatientResponse);
            JSONObject response = new JSONObject();
            setValue(response, APPOINTMENT_OBJECT, responseObject);
            dataTransactionService.logData(response, CREATE_PATIENT.getKey(), SUCCESS.getKey(),
                    "iHub Create Patient Successful");
            return responseObject;

        }
    }
    @Override
    @Observed(name = "integration.advancedmdCreateNewPatient", contextualName = "integration")
    public JSONObject createNewPatient(JSONObject inputObject) throws IHubException {
        log.info("Started createNewPatient.");
        JSONObject outputObject = new JSONObject();
        JSONObject patientResponse = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        try {
            outputObject = matchPatient(inputObject, deploymentId);
            var patientId = getValue(outputObject, APPOINTMENT_PATIENT_ID);
            PhoneNumberUtils.handlePhoneNumberFromFlag(inputObject);
            Object error = getValue(outputObject, DocASAPConstants.TempKey.ERROR_STATUS_CODE);
            if ((isNull(patientId) || patientId.equals(0)) && !MULTIPLE_PATIENT.getKey().equals(error)) {
                String fName = (String) getValue(inputObject, Key.FIRST_NAME);
                String lName = (String) getValue(inputObject, Key.LAST_NAME);
                Object mName = getValue(inputObject, Key.MIDDLE_NAME);
                String name = "";
                if (!NullChecker.isEmpty(mName) && !mName.toString().trim().equals(BLANK)) {
                    name = lName + SPACE + mName + COMMA + fName;
                } else
                    name = lName + COMMA + fName;
                setValue(inputObject, Key.FIRST_NAME, name);
                outputObject.clear();
                outputObject = setConstants(inputObject, deploymentId);
                Object newPatientErrorCode = JsonUtils.getValue(outputObject, "temp.error_code");
                if (newPatientErrorCode != null) {
                    return outputObject;
                }
                setValue(inputObject, Key.FIRST_NAME, fName);
            } else if (!isEmpty(error) && MULTIPLE_PATIENT.getKey()
                    .equals(error)) {
                outputObject=multiplePatientError(inputObject, outputObject, deploymentId);
            } else {
                setValue(inputObject, Key.PATIENT_ID, patientId);
                patientResponse = outputObject.getJSONArray(APPOINTMENT_SYNC).getJSONObject(0);
                Object exPatientId = JsonUtils.getValue(patientResponse, DocASAPConstants.Key.PATIENT_ID);
                log.info("external patient id :{}", sanitizeForLog(exPatientId.toString()));
                HandlerUtils.setExternalPatientId(patientResponse,exPatientId);
                return patientResponse;
            }
            Object exPatientId = JsonUtils.getValue(outputObject, DocASAPConstants.Key.PATIENT_ID);
            log.info("external patient id :{}", sanitizeForLog(exPatientId.toString()));
            HandlerUtils.setExternalPatientId(outputObject,exPatientId);
        } catch (Exception e) {
            log.error("Error occured while creating patient {} ", e.getMessage());
            throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getMessage(), e.getMessage());
        }
        return outputObject;
    }

    private JSONObject setConstants(JSONObject inputObject, String deploymentId) throws IHubException {
        setValue(inputObject, AdvancedMDEngineConstants.CHART, AUTO);
        setValue(inputObject, AdvancedMDEngineConstants.HIPPA_RELATIONSHIP, N18);
        setValue(inputObject, AdvancedMDEngineConstants.OTHER_PHONE_TYPE, C);
        if (handlerUtils.isColWithProv(deploymentId, EPM_NAME_PREFIX)) {
            String resourceId = (String) getValue(inputObject, Key.APPT_RESOURCE_ID);
            if (!NullChecker.isEmpty(resourceId)) {
                setValue(inputObject, Key.APPT_RESOURCE_ID, resourceId.substring(resourceId.indexOf('@') + 1));
            }
        }
        if (isDuplicatePatAllowed(deploymentId)) {
            setValue(inputObject, "temp.force", "1");
        }
        setValue(inputObject, Key.LANGUAGE_PREFERENCE, "44");
        return advancedmdApiCaller.call(deploymentId,ApiName.NEW_PATIENT.getKey(), inputObject, "NewPatient");
    }

    @Override
    public JSONObject getPatientDemographics(JSONObject inputObject) throws IHubException {
        return null;
    }

    private JSONObject getSearchPatientObject(JSONObject inputObject) throws IHubException {
        JSONObject searchPatientJson = new JSONObject();
        copyKey(JsonConstants.DEMOGRAPHIC_DATA, inputObject, searchPatientJson);
        copyKey(DEPLOYMENT_ID, inputObject, searchPatientJson);
        copyKey(MESSAGE_CONTROL_ID, inputObject, searchPatientJson);
        copyKey(JsonConstants.MESSAGE_TYPE, inputObject, searchPatientJson);
        searchPatientJson.put("flowName", CREATE_PATIENT.getKey());
        return searchPatientJson;
    }

    public JSONObject getPatientDemographics(String deploymentId, JSONObject createPatientResponse, JSONObject inputObject)
            throws IHubException {
        JSONObject demographicResponse = null;
        try {
            demographicResponse = advancedmdApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), createPatientResponse, GET_PATIENT_DEMOGRAPHICS.getKey());
            JsonUtils.copyKey(Key.FIRST_NAME, inputObject, demographicResponse);
            JsonUtils.copyKey(Key.LAST_NAME, inputObject, demographicResponse);
            JsonUtils.copyKey(Key.MIDDLE_NAME, inputObject, demographicResponse);
            JsonUtils.copyKey(DOB, inputObject, demographicResponse);
            JsonUtils.copyKey(Key.GENDER, inputObject, demographicResponse);
            externalPatientId = JsonUtils.getValue(createPatientResponse, Key.PATIENT_ID).toString();
        } catch (Exception e) {
            log.error(String.valueOf(e));
        }
        JsonUtils.copyKey(DA_PATIENT_ID, inputObject, demographicResponse);
        JsonUtils.copyKey(JsonConstants.SCHEDULING_DATA, inputObject, demographicResponse);
        JsonUtils.setValue(demographicResponse, Key.PATIENT_ID, externalPatientId);

        return demographicResponse;
    }

    @Override
    public JSONObject getPatientInsuranceInfo(JSONObject inputObject)
            throws IHubException {
        return null;
    }

    public JSONObject getPatientInsuranceInfo(String deploymentId, JSONObject inputObject)
            throws IHubException {
        JSONObject insuranceResponse = null;
        try {
            insuranceResponse = advancedmdApiCaller.call(deploymentId, ApiName.GET_PATIENT_INSURANCE.getKey(), inputObject, "");
        } catch (Exception e) {
            log.error(String.valueOf(e));
        }
        JsonUtils.copyKey(Key.INSURANCE_INFORMATION, insuranceObject, inputObject);

        return insuranceResponse;
    }

    private boolean isDuplicatePatAllowed(String deploymentId) {

        try {
            String isDuplicatePat = dataManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.ALLOW_DUPLICATE_PATIENT, false).toString();
            return isDuplicatePat.equalsIgnoreCase(AdvancedMDEngineConstants.TRUE);
        } catch (IHubException e) {
            log.error(AdvancedMDConstants.ALLOW_DUPLICATE_PATIENT + "Duplicate patient config not set.");
            return false;
        }
    }


    private JSONObject multiplePatientError(JSONObject inputObject, JSONObject matchPatientResponse, String deploymentId) throws IHubException {
        if (isMultiplePatAllowed(deploymentId)) {
            matchPatientResponse.clear();
            matchPatientResponse=advancedmdApiCaller.call(deploymentId, ApiName.NEW_PATIENT.getKey(), inputObject, "NewPatient");
        } else {
            setValue(matchPatientResponse, DocASAPConstants.TempKey.ERROR_MESSAGE, "Multiple matching patients detected");
            setValue(matchPatientResponse, Key.ERROR_CODE, StatusCodes.MULTIPLE_PATIENT.getKey());
            log.error("Found multiple matching patients.");
        }
        return matchPatientResponse;
    }

    private boolean isMultiplePatAllowed(String deploymentId) {

        try {
            String isAllowMulPat = (String) dataManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.ALLOW_MULTIPLE_PATIENT, false);
            return isAllowMulPat.equalsIgnoreCase(UtilitiesConstants.TRUE);
        } catch (IHubException e) {
            log.error(AdvancedMDConstants.ALLOW_DUPLICATE_PATIENT + "Multiple matching patients flow config not set.");
            return false;
        }
    }

    private void setNotificationPreferenceInResponseObject(JSONObject inputObject,
                                                           JSONObject responseObject) {
        try {
            copyKey(EMAIL_NOTIFICATION_STATUS, inputObject, responseObject);
            copyKey(TEXT_NOTIFICATION_STATUS, inputObject, responseObject);
            copyKey(VOICE_NOTIFICATION_STATUS, inputObject, responseObject);
        } catch (Exception e) {
            log.error("Error occurred while notification preference {} ", e.getMessage());
        }
    }

    private void updateObjectValue(JSONObject inputObject, JSONObject outputObject)
            throws IHubException {
        copyKey(DEPLOYMENT_ID, inputObject, outputObject);
        copyKey(MESSAGE_CONTROL_ID, inputObject, outputObject);
        copyKey(MESSAGE_TYPE, inputObject, outputObject);
    }

    public void validateDob(JSONObject inputObject) throws IHubException {
        try {
            String dob = getValue(inputObject, DOB).toString();
            dob = convertDateFormat(dob, DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT);
            setValue(inputObject, DOB, dob);
        } catch (ParseException e) {
            log.error("Error {} .", e.getMessage());
            throw new IHubException(DATA_VALIDATION_ERROR.getErrorCode(), "DOB was invalid or null.");
        }
    }

    private JSONObject matchPatient(JSONObject inputObject, String deploymentId)
            throws IHubException {
        JSONObject matchPatientObject = new JSONObject();
        matchPatientObject.put("patMatchingLayerPriConfStr", getPatMatchingLayerPriConfStr(deploymentId));
        matchPatientObject.put("patMatchingAlgoConfigStr", getPatMatchingAlgoConfigStr(deploymentId));
        return matchPatientHandler.processMatchPatient(getSearchPatientObject(inputObject), matchPatientObject);

    }

    private String getPatMatchingLayerPriConfStr(String deploymentId) {
        String patMatchingLayerPriConfStr = null;
        try {
            patMatchingLayerPriConfStr = (String) dataManager.getStoredProvidersConfig(
                    BaseEPMConstants.EPM_NAME_PREFIX, deploymentId, GENERIC_CONFIG,
                    PAT_MATCHING_LAYER_PRIORITY_CONFIG,
                    false);
        } catch (Exception e) {
            log.error(
                    "Patient matching layers priority configuration is not set for org: " + deploymentId);
        }
        return patMatchingLayerPriConfStr;
    }

    private String getPatMatchingAlgoConfigStr(String deploymentId) {
        String patMatchingAlgoConfigStr = EMPTY;
        try {
            patMatchingAlgoConfigStr = (String) dataManager.getStoredProvidersConfig(
                    BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                    GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false);
        } catch (Exception e) {
            log.error("Patient Matching Algo Config is not set for org: " + deploymentId
                    + ", default will be used");
        }
        return patMatchingAlgoConfigStr;
    }

}