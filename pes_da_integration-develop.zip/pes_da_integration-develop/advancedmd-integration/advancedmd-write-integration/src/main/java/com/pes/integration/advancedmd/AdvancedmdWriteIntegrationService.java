package com.pes.integration.advancedmd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.retry.annotation.EnableRetry;

@EnableCaching
@EnableRetry
@EnableMongoRepositories(basePackages = "com.pes.integration")
@ComponentScan(basePackages = {"com.pes.integration", "com.docasap"})
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
@DependsOn("appConfigurationService")
public class AdvancedmdWriteIntegrationService {
    public static void main(String[] args) {
        SpringApplication.run(AdvancedmdWriteIntegrationService.class, args);
    }
}