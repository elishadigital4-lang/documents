package com.pes.integration.advancedmd.utils;

import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.dto.AvailabilityRequest;
import io.netty.handler.codec.DateFormatter;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.PROV_COLUMN_ID;
import static com.pes.integration.constant.DocASAPConstants.DATE_TIME_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.BOOKED_APPOINTMENTS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_TIME;

public class SampleDataGenerator {

    public static AvailabilityRequest createSampleAvailabilityRequest() {
        AvailabilityRequest request = new AvailabilityRequest();
        request.setDeploymentId("deployment123");
        request.setSliceId("slice123");
        request.setAppointmentType("type123");
        request.setStartDate("2023-01-01");
        request.setEndDate("2023-01-02");
        request.setMessageControlId("msg123");
        request.setTotalSlices("10");
        request.setIndex("1");
        request.setEntityId(null);
        request.setEntityType(null);
        request.setFlow("flow123");
        return request;
    }

    public static JSONObject createJSONObject(){
        JSONObject sampleObject = new JSONObject();
        sampleObject.put("name", "John Doe");
        sampleObject.put("age", 30);
        sampleObject.put("city", "New York");

        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("temp", LocalDateTime.now().format(DateTimeFormatter.ofPattern(AdvancedMDConstants.DATE_TIME_FORMAT)));
        appointmentObject.put(PROV_COLUMN_ID, 1);
        appointmentObject.put("ReasonType", "2");

        // Creating a sample JSONArray
        JSONArray sampleArray = new JSONArray();
        sampleArray.put(appointmentObject);

        // Adding the JSONArray to the JSONObject
        sampleObject.put(BOOKED_APPOINTMENTS, sampleArray);
        return sampleObject;
    }
}