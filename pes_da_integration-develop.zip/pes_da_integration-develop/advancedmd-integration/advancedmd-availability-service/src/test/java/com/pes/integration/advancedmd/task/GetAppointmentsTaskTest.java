package com.pes.integration.advancedmd.task;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.PROV_COLUMN_ID;
import static com.pes.integration.advancedmd.utils.SampleDataGenerator.createJSONObject;
import static com.pes.integration.advancedmd.utils.SampleDataGenerator.createSampleAvailabilityRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class GetAppointmentsTaskTest {

    private final DataCacheManager dataCacheManager = Mockito.mock(DataCacheManager.class);
    private final AvailabilityRequest availabilityRequest = createSampleAvailabilityRequest();
    private final AdvancedmdApiCaller advancedMdApiCaller = Mockito.mock(AdvancedmdApiCaller.class);
    private final HandlerUtils handlerUtils = Mockito.mock(HandlerUtils.class);
    private final ConfigCache configCache = Mockito.mock(ConfigCache.class);
    private GetAppointmentsTask getAppointmentsTask;

    @BeforeEach
    void setUp() {
        JSONObject availableTimeRequest = new JSONObject();
        availableTimeRequest.put("startDate", "2023-01-01");
        availableTimeRequest.put("endDate", "2023-01-02");
        availableTimeRequest.put("provider", "provider1");
        availableTimeRequest.put("epmPrefix", "EPM");
        getAppointmentsTask = new GetAppointmentsTask(availableTimeRequest, advancedMdApiCaller, handlerUtils, configCache, dataCacheManager, availabilityRequest);
    }

    @Test
    void getExcludeStatusConfigValid() throws Exception {
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("10,11,12");

        List<String> result = getAppointmentsTask.getExcludeStatusConfig();

        assertEquals(Arrays.asList("10", "11", "12"), result);
    }

    @Test
    void getExcludeStatusConfigHandlesException() throws Exception {
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenThrow(new RuntimeException("Test Exception"));

        List<String> result = getAppointmentsTask.getExcludeStatusConfig();

        assertEquals(0, result.size());
    }

    @Test
    void getOpenAppointmentsValidRequest() throws Exception {
        when(handlerUtils.getColumnStr(anyString())).thenReturn("column1-column2");
        when(handlerUtils.isColWithProv(anyString(), anyString())).thenReturn(true);
        when(handlerUtils.getProviderMap(anyString())).thenReturn(Map.of("1", "value1"));
        when(advancedMdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(createJSONObject());
        when(dataCacheManager.getConfiguration(any(), any(), any(), any())).thenReturn("10");

        JSONArray result = getAppointmentsTask.getOpenAppointments();

        assertEquals(0, result.length());
    }

    @Test
    void getOpenAppointmentsHandlesException() throws Exception {
        when(handlerUtils.getColumnStr(anyString())).thenThrow(new RuntimeException("Test Exception"));

        JSONArray result = getAppointmentsTask.getOpenAppointments();

        assertEquals(0, result.length());
    }

    @Test
    void getBookAppointmentsValidRequest() throws Exception {
        when(handlerUtils.getColumnStr(anyString())).thenReturn("column1-column2");
        when(handlerUtils.isColWithProv(anyString(), anyString())).thenReturn(true);
        when(handlerUtils.getProviderMap(anyString())).thenReturn(null);
        when(advancedMdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(new JSONObject());

        JSONArray result = getAppointmentsTask.getBookAppointments("deploymentId");

        assertEquals(0, result.length());
    }

    @Test
    void getBookAppointmentsHandlesException() throws Exception {
        when(handlerUtils.getColumnStr(anyString())).thenThrow(new RuntimeException("Test Exception"));

        JSONArray result = getAppointmentsTask.getBookAppointments("deploymentId");

        assertEquals(0, result.length());
    }

    @Test
    void chunkTheColumnIDsValidRequest() throws Exception {
        when(advancedMdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(new JSONObject());

        JSONArray result = getAppointmentsTask.chunkTheColumnIDs("column1-column2", "apiName", new JSONObject());

        assertEquals(0, result.length());
    }

    @Test
    void chunkTheColumnIDsHandlesException() throws Exception {
        when(advancedMdApiCaller.call(anyString(), anyString(), any(), anyString())).thenThrow(new RuntimeException("Test Exception"));

        JSONArray result = getAppointmentsTask.chunkTheColumnIDs("column1-column2", "apiName", new JSONObject());

        assertEquals(0, result.length());
    }


    @Test
    void setSlotIdValidRequest() throws Exception {
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(PROV_COLUMN_ID, "column1");
        appointmentObject.put(DocASAPConstants.Key.PROVIDER_ID, "prr");
        appointmentObject.put(DocASAPConstants.Key.LOCATION_ID, "lov");

        JSONObject result = getAppointmentsTask.setSlotId(appointmentObject, "2023-01-01");

        assertEquals("column1-aprr_lov_2023-01-01", result.getString(AdvancedMDConstants.SLOTID));
    }

    @Test
    void shouldIgnoreApptNameMatchReturnsTrue() throws Exception {
        doReturn("true").when(dataCacheManager).getConfiguration(any(), any(), any(), any());

        boolean result = getAppointmentsTask.shouldIgnoreApptNameMatch();

        assertEquals(true, result);
    }

    @Test
    void shouldIgnoreApptNameMatchReturnsFalse() throws Exception {
        doReturn("false").when(dataCacheManager).getConfiguration(any(), any(), any(), any());

        boolean result = getAppointmentsTask.shouldIgnoreApptNameMatch();

        assertEquals(false, result);
    }


    @Test
    void isHoldReturnsTrue() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("true");

        boolean result = getAppointmentsTask.isHold("configKey", "deploymentId");

        assertEquals(true, result);
    }

    @Test
    void isHoldReturnsFalse() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("false");

        boolean result = getAppointmentsTask.isHold("configKey", "deploymentId");

        assertEquals(false, result);
    }

    @Test
    void isHoldHandlesException() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenThrow(new IHubException(new IHubErrorCode("2"), "Test Exception"));

        boolean result = getAppointmentsTask.isHold("configKey", "deploymentId");

        assertEquals(false, result);
    }

//    @Test
//    void populateBookedAppointmentsArrayValid() throws Exception {
//        JSONArray bookedAppointmentsArray = new JSONArray();
//        JSONArray appointmentsArray = new JSONArray();
//        Map<String, String> providerIdsMap = new HashMap<>();
//        providerIdsMap.put("column1", "provider1");
//        List<String> statusIdList = Arrays.asList("10", "11", "12");
//
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put("temp", LocalDateTime.now().format(DateTimeFormatter.ofPattern(AdvancedMDConstants.DATE_TIME_FORMAT)));
//        appointmentObject.put(PROV_COLUMN_ID, 1);
//        appointmentObject.put("ReasonType", "2");
//        appointmentObject.put("ApptStatus", "15");
//        appointmentsArray.put(appointmentObject);
//
//        getAppointmentsTask.populateBookedAppointmentsArray(bookedAppointmentsArray, appointmentsArray, providerIdsMap, statusIdList, 0);
//
//        assertEquals(1, bookedAppointmentsArray.length());
//    }
//
//    @Test
//    void populateBookedAppointmentsArrayExcludeStatus() throws Exception {
//        JSONArray bookedAppointmentsArray = new JSONArray();
//        JSONArray appointmentsArray = new JSONArray();
//        Map<String, String> providerIdsMap = new HashMap<>();
//        providerIdsMap.put("column1", "provider1");
//        List<String> statusIdList = Arrays.asList("10", "11", "12");
//
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put("PROV_COLUMN_ID", "column1");
//        appointmentObject.put("ApptStatus", "10");
//        appointmentsArray.put(appointmentObject);
//
//        getAppointmentsTask.populateBookedAppointmentsArray(bookedAppointmentsArray, appointmentsArray, providerIdsMap, statusIdList, 0);
//
//        assertEquals(0, bookedAppointmentsArray.length());
//    }
//
//    @Test
//    void prepareHoldSlotsValid() throws Exception {
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put(DocASAPConstants.TempKey.START_TIME, "2023-01-01T10:00:00");
//        appointmentObject.put(PROV_COLUMN_ID, "column1");
//        appointmentObject.put(DocASAPConstants.Key.APPT_REASON, "reason1");
//
//        JSONArray bookedAppointmentsArray = new JSONArray();
//        boolean isColWithProv = true;
//        String startDate = "2023-01-01";
//
//        Map<String, String> apptTypeMap = new HashMap<>();
//        apptTypeMap.put("reason1", "apptType1");
//        appointmentObject.put("PROV_COLUMN_ID", "column1");
//        appointmentObject.put("ApptStatus", "10");
//        bookedAppointmentsArray.put(appointmentObject);
//        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("15");
//        when(handlerUtils.getApptTypeMap(anyString())).thenReturn(apptTypeMap);
//
//        JSONArray result = getAppointmentsTask.prepareHoldSlots(appointmentObject, bookedAppointmentsArray, isColWithProv, startDate);
//
//        assertEquals(0, result.length());
//    }
//
//    @Test
//    void prepareHoldSlotsValid_shouldIgnoreApptNameMatch() throws Exception {
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put(DocASAPConstants.TempKey.START_TIME, "2023-01-01T10:00:00");
//        appointmentObject.put(PROV_COLUMN_ID, "column1");
//        appointmentObject.put(DocASAPConstants.Key.APPT_REASON, "reason1");
//
//        JSONArray bookedAppointmentsArray = new JSONArray();
//        boolean isColWithProv = true;
//        String startDate = "2023-01-01";
//
//        Map<String, String> apptTypeMap = new HashMap<>();
//        apptTypeMap.put("reason1", "apptType1");
//        appointmentObject.put("PROV_COLUMN_ID", "column1");
//        appointmentObject.put("ApptStatus", "10");
//        bookedAppointmentsArray.put(appointmentObject);
//        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("false");
//        when(handlerUtils.getApptTypeMap(anyString())).thenReturn(apptTypeMap);
//
//        JSONArray result = getAppointmentsTask.prepareHoldSlots(appointmentObject, bookedAppointmentsArray, isColWithProv, startDate);
//
//        assertEquals(1, result.length());
//    }
//
//    @Test
//    void prepareHoldSlotsHandlesException() throws Exception {
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put(DocASAPConstants.TempKey.START_TIME, "2023-01-01T10:00:00");
//        appointmentObject.put(PROV_COLUMN_ID, "column1");
//        appointmentObject.put(DocASAPConstants.Key.APPT_REASON, "reason1");
//
//        JSONArray bookedAppointmentsArray = new JSONArray();
//        boolean isColWithProv = true;
//        String startDate = "2023-01-01";
//
//        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenThrow(new IHubException(new IHubErrorCode("12"),"Test Exception"));
//
//        JSONArray result = getAppointmentsTask.prepareHoldSlots(appointmentObject, bookedAppointmentsArray, isColWithProv, startDate);
//
//        assertEquals(0, result.length());
//    }
//    @Test
//    void setOpenAppointmentsArrayValid() throws Exception {
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put("PROV_COLUMN_ID", "column1");
//        appointmentObject.put("APPT_REASON_ID", "reason1");
//
//        JSONArray openAppointmentsArray = new JSONArray();
//        boolean isColWithProv = true;
//        String startDate = "2023-01-01";
//        String apptTypeIdsString = "apptType1";
//
//        boolean result = getAppointmentsTask.setOpenAppointmentsArray(appointmentObject, isColWithProv, openAppointmentsArray, startDate, false, apptTypeIdsString);
//
//        assertEquals(1, openAppointmentsArray.length());
//        assertEquals("reason1", openAppointmentsArray.getJSONObject(0).getString("APPT_REASON_ID"));
//    }


}