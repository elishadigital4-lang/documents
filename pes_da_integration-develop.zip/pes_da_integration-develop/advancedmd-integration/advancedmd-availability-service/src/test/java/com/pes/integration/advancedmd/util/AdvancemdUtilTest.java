package com.pes.integration.advancedmd.util;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.exceptions.IHubException;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.pes.integration.constant.EpmConstant.ENDDATE;
import static com.pes.integration.constant.EpmConstant.STARTDATE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AdvancemdUtilTest {

    @Mock
    private AdvancedmdApiCaller advancedmdApiCaller;

    private JSONObject inputParam;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        inputParam = new JSONObject();
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-02");
        inputParam.put("SchedulingData.Provider[0].LocationId", "location123");
        inputParam.put("SchedulingData.Provider[0].ResourceId", "resource123");
    }

    @Test
    void openAppointments_validInput_returnsAppointments() throws InvalidResourceException, IHubException {
        JSONObject response = new JSONObject();
        response.put("data", "someData");
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(response);

        JSONObject result = AdvancemdUtil.openAppointments("deployment123", advancedmdApiCaller, inputParam);

        assertNotNull(result);
        assertTrue(result.has("response"));
        assertEquals(2, result.getJSONArray("response").length());
    }


    @Test
    void openAppointments_emptyResponse_returnsEmptyArray() throws InvalidResourceException, IHubException {
        JSONObject response = new JSONObject();
        when(advancedmdApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(response);

        JSONObject result = AdvancemdUtil.openAppointments("deployment123", advancedmdApiCaller, inputParam);

        assertNotNull(result);
        assertTrue(result.has("response"));
        assertEquals(2, result.getJSONArray("response").length());
    }

    @Test
    void getInputObject_validInput_returnsCorrectObject() {
        JSONObject result = AdvancemdUtil.getInputObject(inputParam);

        assertNotNull(result);
        assertTrue(result.has("SchedulingData"));
        assertTrue(result.has("temp"));
        assertEquals("2023-01-01", result.getJSONObject("temp").getString("start_date"));
    }

    @Test
    void getInputObject_missingResourceId_returnsObjectWithoutProvider() {
        inputParam.remove("SchedulingData.Provider[0].ResourceId");

        JSONObject result = AdvancemdUtil.getInputObject(inputParam);

        assertNotNull(result);
        assertTrue(result.has("temp"));
        assertFalse(result.getJSONObject("SchedulingData").has("Provider"));
    }
}