package com.pes.integration.advancedmd.task;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.PROV_COLUMN_ID;
import static com.pes.integration.constant.EpmConstant.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.UtilitiesConstants.PROVIDER_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
class PrepareOpenSlotsTaskTest {

    private AdvancedmdApiCaller advancedmdApiCaller = Mockito.mock(AdvancedmdApiCaller.class);

    private HandlerUtils handlerUtils = Mockito.mock(HandlerUtils.class);

    private ConfigCache configCache = Mockito.mock(ConfigCache.class);

    private DataCacheManager dataCacheManager = Mockito.mock(DataCacheManager.class);

    private FileUploader fileUploader = Mockito.mock(FileUploader.class);

    private EventTracker trackEvents = Mockito.mock(EventTracker.class);

    private AvailabilityRequest availabilityRequest = Mockito.mock(AvailabilityRequest.class);

    private PrepareOpenSlotsTask prepareOpenSlotsTask;

    JSONArray columns = new JSONArray();

    @BeforeEach
    void setUp() throws IOException {
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("temp", LocalDateTime.now().format(DateTimeFormatter.ofPattern(AdvancedMDConstants.DATE_TIME_FORMAT)));
        appointmentObject.put(PROV_COLUMN_ID, 1);
        appointmentObject.put("ReasonType", "2");
        appointmentObject.put("columnId", "1");
        appointmentObject.put(PROVIDER_ID, "1");
        appointmentObject.put("workDays", "6651676");
        appointmentObject.put("apptTimingStart", LocalTime.now().format(DateTimeFormatter.ofPattern("HHmm")));
        appointmentObject.put("apptTimingEnd", LocalTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("HHmm")));
        appointmentObject.put("date", LocalDate.now().format(DateTimeFormatter.ofPattern(DOCASAP_DATE_FORMAT)));

        columns.put(appointmentObject);
        JSONObject inputObject = new JSONObject();
        inputObject.put("startDate", "2023-01-01");
        inputObject.put("endDate", "2023-01-02");
        inputObject.put("epmPrefix", "EPM");
        inputObject.put("appointmentPath", Files.createTempDirectory("temp").toAbsolutePath().toString());
        prepareOpenSlotsTask = spy(new PrepareOpenSlotsTask(advancedmdApiCaller, inputObject, fileUploader, trackEvents, availabilityRequest, handlerUtils, configCache, dataCacheManager));
    }


    @Test
    void getValid() throws Exception {
        try (MockedConstruction<GetAppointmentsTask> mocked = mockConstruction(GetAppointmentsTask.class, (mock, context) -> {
            when(mock.getOpenAppointments()).thenReturn(columns);
        })) {
            try (MockedConstruction<GetColumnsTask> mockedGetColumnsTask = mockConstruction(GetColumnsTask.class, (mock, context) -> {
                when(mock.getColumns(any())).thenReturn(columns);
                when(mock.extractOpenSlotsFromResponse(any(), any())).thenReturn(columns);
            })) {
                JSONArray openAppointmentsArray = new JSONArray();
                openAppointmentsArray.put(new JSONObject().put("apptTimingStart", "2023-01-01T10:00:00"));
                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(new JSONObject().put("data", openAppointmentsArray));
                doNothing().when(fileUploader).uploadFile(any(), any(), any(), any());
                doNothing().when(prepareOpenSlotsTask).trackEventToNifi(any(), any(), any(), any(), any(), any());
                doReturn("-1").when(availabilityRequest).getIndex();
                doReturn("123").when(availabilityRequest).getDeploymentId();
                doReturn("false").when(dataCacheManager).getConfiguration(any(), any(), any(), any());

                assertDoesNotThrow(() -> prepareOpenSlotsTask.get());

            }
        }
    }


    @Test
    void trackEventToNifiValid() {
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "1";
        String fragmentId = "fragmentId";
        Map<String, Object> payload = new HashMap<>();
        payload.put("key", "value");

        when(availabilityRequest.getMessageControlId()).thenReturn("messageControlId");
        when(availabilityRequest.getAppointmentType()).thenReturn("appointmentType");
        when(availabilityRequest.getSliceId()).thenReturn("sliceId");
        when(availabilityRequest.getDeploymentId()).thenReturn("deploymentId");
        when(availabilityRequest.getTotalSlices()).thenReturn("totalSlices");
        when(availabilityRequest.getEntityType()).thenReturn("entityType");
        when(availabilityRequest.getEntityId()).thenReturn("entityId");
        when(availabilityRequest.getFlow()).thenReturn("flow");

        prepareOpenSlotsTask.trackEventToNifi(trackEvents, availabilityRequest, dataflowStatus, totalFragments, fragmentId, payload);

        ArgumentCaptor<NifiTrackingEvent> eventCaptor = ArgumentCaptor.forClass(NifiTrackingEvent.class);
        verify(trackEvents, times(1)).trackEventToNifi(eventCaptor.capture());

        NifiTrackingEvent capturedEvent = eventCaptor.getValue();
        assertEquals(dataflowStatus.toString(), capturedEvent.getFlowPoint());
        assertEquals("messageControlId", capturedEvent.getMessageControlId());
        assertEquals("appointmentType", capturedEvent.getAppointmentType());
        assertEquals("sliceId", capturedEvent.getSliceId());
        assertEquals("deploymentId", capturedEvent.getDeploymentId());
        assertEquals(totalFragments, capturedEvent.getTotalFragments());
        assertEquals(fragmentId, capturedEvent.getFragmentId());
        assertEquals("totalSlices", capturedEvent.getTotalSlices());
        assertEquals(payload, capturedEvent.getPayload());
        assertEquals("entityType", capturedEvent.getEntityType());
        assertEquals("entityId", capturedEvent.getEntityId());
        assertEquals("flow", capturedEvent.getFlow());
    }
}