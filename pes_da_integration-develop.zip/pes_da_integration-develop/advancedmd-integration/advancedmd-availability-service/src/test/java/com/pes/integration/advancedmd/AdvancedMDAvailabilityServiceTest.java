package com.pes.integration.advancedmd;

import com.pes.integration.adapter.Utils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AdvancedMDAvailabilityServiceTest {

    @InjectMocks
    AdvancedMDAvailabilityService advancedMDAvailabilityService;
    @Test
    void main() {
        try (MockedStatic<SpringApplication> mocked = mockStatic(SpringApplication.class)) {
            mocked.when(() -> SpringApplication.run(AdvancedMDAvailabilityService.class, null)).thenAnswer(invocation -> null);
            AdvancedMDAvailabilityService.main(null);
        }

        }
}