package com.pes.integration.advancedmd.task;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.InvalidIdException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.text.ParseException;

import static com.pes.integration.constant.DocASAPConstants.Key.BOOKED_APPOINTMENTS;
import static com.pes.integration.constant.EpmConstant.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RealTimeOpenSlotsTaskTest {

    @Mock
    private AdvancedmdApiCaller advancedmdApiCaller;

    private RealTimeOpenSlotsTask realTimeOpenSlotsTask;
    private JSONObject inputObject;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        inputObject = new JSONObject();
        inputObject.put("startDate", "2023-01-01");
        inputObject.put("endDate", "2023-01-02");
        inputObject.put("SchedulingData.Provider[0].LocationId", "location123");
        inputObject.put("SchedulingData.Provider[0].ResourceId", "resource123");
        realTimeOpenSlotsTask = new RealTimeOpenSlotsTask("deployment123", advancedmdApiCaller, inputObject);
    }

    @Test
    void extractSlots_validInput_returnsTransformedAppointmentss() throws ParseException {
        // Arrange
        JSONObject outputObject = new JSONObject();
        JSONArray responseArray = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointment.put("ReasonType", AdvancedMDEngineConstants.REASON_TYPE_VAL);
        appointment.put("Duration", 30);
        appointment.put("ColumnId", "slot123");
        appointment.put("temp", new JSONObject().put("start_time", "2023-01-01T10:00:00"));
        appointment.put(APPTREASON_ID, "reason123");
        responseArray.put(new JSONObject().put(BOOKED_APPOINTMENTS, new JSONArray().put(appointment)));
        outputObject.put("filteredResponse", responseArray);

        JSONObject inputParam = new JSONObject();
        inputParam.put("SchedulingData.Provider[0].LocationId", "location123");
        inputParam.put("SchedulingData.Provider[0].ResourceId", "resource123");

        // Act
        JSONArray result = RealTimeOpenSlotsTask.extractSlots(outputObject, inputParam);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.length());
        JSONObject transformedAppointment = result.getJSONObject(0);
        assertEquals("minutes", transformedAppointment.getString(DURATION_UNIT_KEY));
        assertEquals(30, transformedAppointment.getInt("duration"));
        assertEquals("slot123", transformedAppointment.getString("slotId"));
        assertEquals("location123", transformedAppointment.getString(LOCATION_ID_KEY));
        assertEquals("resource123", transformedAppointment.getString(PROVIDER_ID_KEY));
        assertEquals("reason123", transformedAppointment.getString(REASON_ID_KEY));
        assertEquals("1000", transformedAppointment.getString(START_TIME));
        assertEquals("20230101", transformedAppointment.getString(DATE_KEY));
    }

    @Test
    void transformOpenAppointment_validInput_returnsTransformedObject() throws ParseException {
        // Arrange
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("Duration", 30);
        appointmentObject.put("ColumnId", "slot123");
        appointmentObject.put("temp", new JSONObject().put("start_time", "2023-01-01T10:00:00"));
        appointmentObject.put("ReasonType", AdvancedMDEngineConstants.REASON_TYPE_VAL);
        appointmentObject.put(APPTREASON_ID, "reason123");

        JSONObject inputParam = new JSONObject();
        inputParam.put("SchedulingData.Provider[0].LocationId", "location123");
        inputParam.put("SchedulingData.Provider[0].ResourceId", "resource123");

        // Act
        JSONObject result = RealTimeOpenSlotsTask.transformOpenAppointment(appointmentObject, inputParam);

        // Assert
        assertNotNull(result);
        assertEquals("minutes", result.getString(DURATION_UNIT_KEY));
        assertEquals(30, result.getInt("duration"));
        assertEquals("slot123", result.getString("slotId"));
        assertEquals("location123", result.getString(LOCATION_ID_KEY));
        assertEquals("resource123", result.getString(PROVIDER_ID_KEY));
        assertEquals("reason123", result.getString(REASON_ID_KEY));
        assertEquals("1000", result.getString(START_TIME));
        assertEquals("20230101", result.getString(DATE_KEY));
    }

    @Test
    void get_validResponse_returnsOpenAppointments() throws Exception {
        JSONObject responseObject = new JSONObject();
        JSONArray responseArray = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointment.put("ReasonType", "someReasonType");
        appointment.put("Duration", 30);
        appointment.put("ColumnId", "slot123");
        appointment.put("temp", new JSONObject().put("start_time", "2023-01-01T10:00:00"));
        responseArray.put(new JSONObject().put("BOOKED_APPOINTMENTS", new JSONArray().put(appointment)));
        responseObject.put("response", responseArray);

        when(advancedmdApiCaller.call(anyString(),any(), any(JSONObject.class),anyString())).thenReturn(responseObject);

        JSONArray result = realTimeOpenSlotsTask.get();

        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void get_invalidIdException_throwsEpmApiCallerException() throws Exception {
        when(advancedmdApiCaller.call(anyString(),any(), any(JSONObject.class),anyString())).thenThrow(new InvalidIdException("Invalid ID"));

        assertThrows(EpmApiCallerException.class, () -> realTimeOpenSlotsTask.get());
    }

    @Test
    void get_emptyResponse_returnsEmptyArray() throws Exception {
        JSONObject responseObject = new JSONObject();
        responseObject.put("response", new JSONArray());

        when(advancedmdApiCaller.call(anyString(),any(), any(JSONObject.class),anyString())).thenReturn(responseObject);

        JSONArray result = realTimeOpenSlotsTask.get();

        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void extractSlots_missingReasonType_returnsEmptyArray() throws ParseException {
        JSONObject outputObject = new JSONObject();
        JSONArray responseArray = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointment.put("Duration", 30);
        appointment.put("ColumnId", "slot123");
        appointment.put("temp", new JSONObject().put("start_time", "2023-01-01T10:00:00"));
        responseArray.put(new JSONObject().put("BOOKED_APPOINTMENTS", new JSONArray().put(appointment)));
        outputObject.put("filteredResponse", responseArray);

        JSONArray result = RealTimeOpenSlotsTask.extractSlots(outputObject, inputObject);

        assertNotNull(result);
        assertEquals(0, result.length());
    }
}