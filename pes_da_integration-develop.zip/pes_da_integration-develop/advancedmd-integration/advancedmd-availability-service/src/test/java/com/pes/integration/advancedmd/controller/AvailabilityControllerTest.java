package com.pes.integration.advancedmd.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.advancedmd.service.open.impl.OpenAppointmentServiceImpl;
import com.pes.integration.dto.RealTimeRequest;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class AvailabilityControllerTest {
    @Mock
    private OpenAppointmentServiceImpl openAppointmentService;

    @InjectMocks
    private AvailabilityController availabilityController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getRealTimeData_validRequest_returnsOpenAppointments() throws JsonProcessingException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setMessageControlId("12345");
        realTimeRequest.setStartDate("2025-01-01");
        realTimeRequest.setEndDate("2025-01-02");
        realTimeRequest.setDeploymentId("deployment123");
        JSONObject openAppointments = new JSONObject();
        openAppointments.put("data", "realtime data");

        when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class))).thenReturn(openAppointments);

        ResponseEntity<Object> response = availabilityController.getRealTimeData(realTimeRequest);

        assertEquals(HttpStatusCode.valueOf(200), response.getStatusCode());
        assertEquals(openAppointments.toString(), response.getBody());
    }


    @Test
    void getRealTimeData_nullRequest_throwsException() {
        assertThrows(NullPointerException.class, () -> {
            availabilityController.getRealTimeData(null);
        });
    }
}