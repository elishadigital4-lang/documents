package com.pes.integration.advancedmd.service.open.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.task.PrepareOpenSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.ADVANCEDMD_CONFIG;
import static com.pes.integration.advancedmd.utils.SampleDataGenerator.createSampleAvailabilityRequest;
import static com.pes.integration.constant.EpmConstant.MAX_POOL_SIZE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpenAppointmentServiceImplTest {

    @Mock
    private FileUploader fileUploader;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private ConfigCache configCache;
    @Mock
    private EventTracker trackEvents;
    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    protected ObjectMapper objectMapper;
    @InjectMocks
    @Spy
    private OpenAppointmentServiceImpl openAppointmentService;
    @Mock
    private AdvancedmdApiCaller advancedMdApiCaller;

    private AvailabilityRequest availabilityRequest;
    private Map<String, JSONArray> providerLocationMap;

    @BeforeEach
    void setUp() {
        availabilityRequest = createSampleAvailabilityRequest();
        providerLocationMap = new HashMap<>();
    }

    @Test
    void fetchOpenAppointmentsValidRequest() throws Exception {
        doNothing().when(trackEvents).trackEvent(any(), any(), any(), any());
        PrepareOpenSlotsTask prepareOpenSlotsTask = mock(PrepareOpenSlotsTask.class);
        doNothing().when(prepareOpenSlotsTask).get();
        doReturn(prepareOpenSlotsTask).when(openAppointmentService).getPrepareOpenSlotsTask(any(), any(), any());

        openAppointmentService.fetchOpenAppointments(advancedMdApiCaller, availabilityRequest, providerLocationMap, "EPM");

        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
    }

    @Test
    void getColumnsValid() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-02");

        JSONObject response = new JSONObject();
        JSONArray columns = new JSONArray();
        JSONObject provider = new JSONObject();
        provider.put("ProviderId", "123");
        columns.put(provider);
        response.put("Columns", columns);

        doReturn(response).when(advancedMdApiCaller).call(any(), any(), any(), any());

        JSONArray result = openAppointmentService.getColumns(availabilityRequest);

        assertNotNull(result);
        assertEquals(1, result.length());
        assertEquals("123", result.optString(0));
    }

    @Test
    void getColumns_Exception() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-02");

        JSONObject response = new JSONObject();
        JSONArray columns = new JSONArray();
        JSONObject provider = new JSONObject();
        provider.put("ProviderId", "123");
        columns.put(provider);
        response.put("Columns", columns);

        doThrow(new IHubException(new IHubErrorCode("222"), "Test Error")).when(advancedMdApiCaller).call(any(), any(), any(), any());
        JSONArray jsonArray = openAppointmentService.getColumns(availabilityRequest);
        Assertions.assertEquals(0, jsonArray.length());
        Assertions.assertEquals(new JSONArray().toString(), jsonArray.toString());
    }

    @Test
    public void getAvailability() throws JsonProcessingException {
        doNothing().when(openAppointmentService).fetchOpenAppointments(any(), any(), any(), any());
        JSONArray array = openAppointmentService.getAvailability(new AvailabilityRequest(), new HashMap<>(), "EPM");
        Assertions.assertNull(array);
    }

    @Test
    public void getRealTimeAvailability() throws JsonProcessingException {
        JSONObject jsonObject = openAppointmentService.getRealTimeAvailability(new RealTimeRequest());
        Assertions.assertNotNull(jsonObject);
    }

    @Test
    public void getPrepareOpenSlotsTask() throws IOException {

        JSONObject inputObject = new JSONObject();
        inputObject.put("startDate", "2023-01-01");
        inputObject.put("endDate", "2023-01-02");
        inputObject.put("epmPrefix", "EPM");
        inputObject.put("appointmentPath", Files.createTempDirectory("temp").toAbsolutePath().toString());
        PrepareOpenSlotsTask openSlotsTask = openAppointmentService.getPrepareOpenSlotsTask(new AdvancedmdApiCaller(), new AvailabilityRequest(), inputObject);
        Assertions.assertNotNull(openSlotsTask);
    }

    @Test
    public void getMaxPoolSize() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        Method getMaxPoolSize = getMethod("getMaxPoolSize", String.class, String.class);
        when(dataCacheManager.getConfiguration("EPM", "ID", ADVANCEDMD_CONFIG, MAX_POOL_SIZE)).thenReturn("10");
        String invoke = (String) getMaxPoolSize.invoke(openAppointmentService, "ID", "EPM");

        Assertions.assertEquals("10", invoke);
    }

    @Test
    public void getMaxPoolSize_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        Method getMaxPoolSize = getMethod("getMaxPoolSize", String.class, String.class);
        when(dataCacheManager.getConfiguration("EPM", "ID", ADVANCEDMD_CONFIG, MAX_POOL_SIZE)).thenThrow(new IHubException(new IHubErrorCode("10"), "error"));

        String invoke = (String) getMaxPoolSize.invoke(openAppointmentService, "ID", "EPM");

        Assertions.assertNull(invoke);
    }

    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

}