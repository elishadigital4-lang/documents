package com.pes.integration.advancedmd.service.booked.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.service.open.impl.OpenAppointmentServiceImpl;
import com.pes.integration.advancedmd.task.PrepareBookedSlotsTask;
import com.pes.integration.advancedmd.task.PrepareOpenSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.ADVANCEDMD_CONFIG;
import static com.pes.integration.advancedmd.utils.SampleDataGenerator.createSampleAvailabilityRequest;
import static com.pes.integration.constant.EpmConstant.MAX_POOL_SIZE;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookedAppointmentServiceImplTest {

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private AdvancedmdApiCaller advancedMdApiCaller;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private ConfigCache configCache;

    @Mock
    private DataCacheManager dataCacheManager;

    @InjectMocks
    @Spy
    private BookedAppointmentServiceImpl bookedAppointmentService;

    private AvailabilityRequest availabilityRequest;
    private Map<String, JSONArray> providerLocationMap;

    @Mock
    protected ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        availabilityRequest = createSampleAvailabilityRequest();
        providerLocationMap = new HashMap<>();
    }

    @Test
    void fetchBookedAppointmentsValidRequest() throws Exception {
        doNothing().when(trackEvents).trackEvent(any(), any(), any(), any());
        PrepareBookedSlotsTask prepareBookedSlotsTask = mock(PrepareBookedSlotsTask.class);
        doNothing().when(prepareBookedSlotsTask).get();
        doReturn(prepareBookedSlotsTask).when(bookedAppointmentService).getPrepareBookedSlotsTask(any(), any());

        bookedAppointmentService.fetchBookedAppointments("2023-01-01", "2023-01-02", providerLocationMap, availabilityRequest, "EPM");

        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
    }

    @Test
    void fetchBookedAppointmentsInvalidDateFormat() {
        assertThrows(EpmApiCallerException.class, () -> {
            bookedAppointmentService.fetchBookedAppointments("invalid-date", "2023-01-02", providerLocationMap, availabilityRequest, "EPM");
        });
    }

    @Test
    void fetchBookedAppointmentsThrowsEpmApiCallerException() throws Exception {
        assertThrows(EpmApiCallerException.class, () -> {
            bookedAppointmentService.fetchBookedAppointments("2023-01111", "2023-01-02", providerLocationMap, availabilityRequest, "EPM");
        });
    }
    @Test
    public void getMaxPoolSize() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        Method getMaxPoolSize = getMethod("getMaxPoolSize", String.class, String.class);
        when(dataCacheManager.getConfiguration("EPM", "ID", ADVANCEDMD_CONFIG, MAX_POOL_SIZE)).thenReturn("10");
        String invoke = (String) getMaxPoolSize.invoke(bookedAppointmentService, "ID", "EPM");

        Assertions.assertEquals("10", invoke);
    }

    @Test
    public void getAvailability() throws JsonProcessingException {
        doNothing().when(bookedAppointmentService).fetchBookedAppointments(any(),any(), any(), any(), any());
        JSONArray array = bookedAppointmentService.getAvailability(new AvailabilityRequest(), new HashMap<>(), "EPM");
        Assertions.assertNull(array);
    }

    @Test
    public void getRealTimeAvailability() {
        JSONObject jsonObject = bookedAppointmentService.getRealTimeAvailability(new RealTimeRequest());
        Assertions.assertNull(jsonObject);
    }
    @Test
    public void getPrepareBookedSlotsTask() throws IOException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("startDate", "2023-01-01");
        inputObject.put("endDate", "2023-01-02");
        inputObject.put("epmPrefix", "EPM");
        inputObject.put("appointmentPath", Files.createTempDirectory("temp").toAbsolutePath().toString());

        PrepareBookedSlotsTask openSlotsTask = bookedAppointmentService.getPrepareBookedSlotsTask(new AvailabilityRequest(), inputObject);
        Assertions.assertNotNull(openSlotsTask);
    }
    @Test
    public void getMaxPoolSize_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        Method getMaxPoolSize = getMethod("getMaxPoolSize", String.class, String.class);
        when(dataCacheManager.getConfiguration("EPM", "ID", ADVANCEDMD_CONFIG, MAX_POOL_SIZE)).thenThrow(new IHubException(new IHubErrorCode("10"), "error"));

        String invoke = (String) getMaxPoolSize.invoke(bookedAppointmentService, "ID", "EPM");

        Assertions.assertNull(invoke);
    }

    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = BookedAppointmentServiceImpl.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }
}