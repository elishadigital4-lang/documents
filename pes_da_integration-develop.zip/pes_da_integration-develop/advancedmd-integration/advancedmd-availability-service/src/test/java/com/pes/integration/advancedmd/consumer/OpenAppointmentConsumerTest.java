package com.pes.integration.advancedmd.consumer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.adapter.Utils;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.repository.RedisRepository;
import com.pes.integration.service.AppointmentService;
import org.json.JSONArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.pes.integration.advancedmd.utils.SampleDataGenerator.createSampleAvailabilityRequest;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpenAppointmentConsumerTest {

    @Mock
    private AppointmentService openAppointmentService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private RedisRepository terminateBaselineRepository;

    @InjectMocks
    private OpenAppointmentConsumer openAppointmentConsumer;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void consumeValidRequest() throws Exception {
        try (MockedStatic<Utils> mocked = mockStatic(Utils.class)) {
            mocked.when(() -> Utils.isTerminatedBaseline(any(), any(), any())).thenReturn(false);
            String request = "{\"messageControlId\":\"123\"}";
            AvailabilityRequest availabilityRequest = createSampleAvailabilityRequest();
            availabilityRequest.setMessageControlId("123");
            when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);
            when(openAppointmentService.getAppointments(availabilityRequest, AdvancedMDEngineConstants.EPM_NAME_PREFIX)).thenReturn(new JSONArray());

            openAppointmentConsumer.consume(request);

            verify(openAppointmentService, times(1)).getAppointments(availabilityRequest, AdvancedMDEngineConstants.EPM_NAME_PREFIX);
            verify(objectMapper, times(1)).readValue(request, AvailabilityRequest.class);
        }
    }

    @Test
    void consumeInvalidJsonRequest() throws Exception {
        try (MockedStatic<Utils> mocked = mockStatic(Utils.class)) {
            mocked.when(() -> Utils.trackOpenSliceError(any(), any(), any())).thenAnswer(invocation -> null);

            String request = "invalid json";
            when(objectMapper.readValue(request, AvailabilityRequest.class)).thenThrow(JsonProcessingException.class);

            openAppointmentConsumer.consume(request);

            verify(objectMapper, times(1)).readValue(request, AvailabilityRequest.class);
            verify(openAppointmentService, times(0)).getAppointments(any(), any());
            mocked.verify(() -> Utils.trackOpenSliceError(any(), any(), any()), times(1));
        }
    }

    @Test
    void consumeTerminatedBaseline() throws Exception {
        try (MockedStatic<Utils> mocked = mockStatic(Utils.class)) {
            mocked.when(() -> Utils.isTerminatedBaseline(any(), any(), any())).thenReturn(true);

            String request = "{\"messageControlId\":\"123\"}";
            AvailabilityRequest availabilityRequest = new AvailabilityRequest();
            availabilityRequest.setMessageControlId("123");

            when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);

            openAppointmentConsumer.consume(request);

            verify(openAppointmentService, times(0)).getAppointments(any(), any());
        }
    }

    @Test
    void consumeThrowsException() throws Exception {
        try (MockedStatic<Utils> mocked = mockStatic(Utils.class)) {
            mocked.when(() -> Utils.isTerminatedBaseline(any(), any(), any())).thenReturn(false);
            mocked.when(() -> Utils.trackOpenSliceError(any(), any(), any())).thenAnswer(invocation -> null);

            String request = "{\"messageControlId\":\"123\"}";
            AvailabilityRequest availabilityRequest = new AvailabilityRequest();
            availabilityRequest.setMessageControlId("123");

            when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);
            doThrow(new RuntimeException("Test Exception")).when(openAppointmentService).getAppointments(any(), any());

            openAppointmentConsumer.consume(request);

            mocked.verify(() -> Utils.trackOpenSliceError(any(), any(), any()), times(1));
        }
    }
}