package com.pes.integration.advancedmd.task;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.DATE_TIME_FORMAT;
import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.TIME_FORMAT;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.RESPONSE_CODES_MAPPING_KEY_NAME;
import static com.pes.integration.advancedmd.utils.SampleDataGenerator.createJSONObject;
import static com.pes.integration.constant.BaseEPMConstants.BASE_URL;
import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class GetColumnsTaskTest {

    private AdvancedmdApiCaller advancedMdApiCaller = Mockito.mock(AdvancedmdApiCaller.class);

    private HandlerUtils handlerUtils= Mockito.mock(HandlerUtils.class);

    private ConfigCache configCache = Mockito.mock(ConfigCache.class);

    private GetColumnsTask getColumnsTask;

    @BeforeEach
    void setUp() {
        String[] configTypes = {GENERIC_CONFIG, ADVANCEDMD_CONFIG,
                ENVIRONMENT_CONFIG, FILTER_CONFIG};
        initialiseEPMConstants(AdvancedMDConstants.DATE_FORMAT,
                DATE_TIME_FORMAT,
                TIME_FORMAT,
                BASE_URL,
                AdvancedMDEngineConstants.TRUE,
                EPM_NAME_PREFIX,
                ADVANCEDMD_CONFIG,
                RETRY_COUNT,
                REQUEST_MAPPING_KEY_NAME,
                RESPONSE_MAPPING_KEY_NAME,
                REQUEST_CONFIG_KEY_NAME,
                RESPONSE_CODES_MAPPING_KEY_NAME,
                configTypes);
        JSONObject availableTimeRequest = new JSONObject();
        availableTimeRequest.put("startDate", "2024-09-26");
        availableTimeRequest.put("endDate", "2023-01-02");
        availableTimeRequest.put("epmPrefix", "EPM");
        getColumnsTask = new GetColumnsTask(availableTimeRequest, advancedMdApiCaller, handlerUtils, configCache);
    }

    @Test
    void getColumnsValid() throws Exception {
        JSONObject response = createJSONObject();
        JSONArray columns = new JSONArray();
        columns.put("test");
        response.put(COLUMNS, columns);
        when(advancedMdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(response);

        JSONArray result = getColumnsTask.getColumns("deploymentId");

        assertEquals(columns, result);
    }

    @Test
    void getColumnsHandlesException() throws Exception {
        when(advancedMdApiCaller.call(anyString(), anyString(), any(), anyString())).thenThrow(new IHubException(new IHubErrorCode("22"),"Test Exception"));

        assertThrows(IHubException.class, () -> getColumnsTask.getColumns("deploymentId"));
    }

    @Test
    void extractOpenSlotsFromResponseValid() throws Exception {
        JSONArray columns = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("temp", LocalTime.now().format(DateTimeFormatter.ofPattern(AdvancedMDConstants.TIME_FORMAT)));
        appointmentObject.put(PROV_COLUMN_ID, 1);
        appointmentObject.put("ReasonType", "2");
        appointmentObject.put("columnId", "1");
        appointmentObject.put(PROVIDER_ID, "1");
        appointmentObject.put("workDays", "6651676");
        appointmentObject.put("apptTimingStart", LocalTime.now().format(DateTimeFormatter.ofPattern("HHmm")));
        appointmentObject.put("apptTimingEnd", LocalTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("HHmm")));
        columns.put(appointmentObject);
        when(handlerUtils.isColWithProv(anyString(), anyString())).thenReturn(true);

        JSONArray result = getColumnsTask.extractOpenSlotsFromResponse(columns, "deploymentId");

        assertEquals(columns.toString(),result.toString());
    }

    @Test
    void extractOpenSlotsFromResponseValid_isColWithProv_false() throws Exception {
        JSONArray columns = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("temp", LocalTime.now().format(DateTimeFormatter.ofPattern(AdvancedMDConstants.TIME_FORMAT)));
        appointmentObject.put(PROV_COLUMN_ID, 1);
        appointmentObject.put("ReasonType", "2");
        appointmentObject.put("columnId", "1");
        appointmentObject.put(PROVIDER_ID, "1");
        appointmentObject.put("workDays", "6651676");
        appointmentObject.put("apptTimingStart", LocalTime.now().format(DateTimeFormatter.ofPattern("HHmm")));
        appointmentObject.put("apptTimingEnd", LocalTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("HHmm")));
        columns.put(appointmentObject);
        when(handlerUtils.isColWithProv(anyString(), anyString())).thenReturn(false);

        JSONArray result = getColumnsTask.extractOpenSlotsFromResponse(columns, "deploymentId");

        assertEquals(columns.toString(),result.toString());
    }

    @Test
    void extractOpenSlotsFromResponseHandlesException() throws Exception {
        JSONArray columns = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("temp", LocalDateTime.now().format(DateTimeFormatter.ofPattern(AdvancedMDConstants.DATE_TIME_FORMAT)));
        appointmentObject.put(PROV_COLUMN_ID, 1);
        appointmentObject.put("ReasonType", "2");
        appointmentObject.put("columnId", "1");
        appointmentObject.put(PROVIDER_ID, "1");
        appointmentObject.put("workDays", "6651676");
        appointmentObject.put("apptTimingStart", LocalTime.now().format(DateTimeFormatter.ofPattern("HHmm")));
        appointmentObject.put("apptTimingEnd", LocalTime.now().plusHours(1).format(DateTimeFormatter.ofPattern("HHmm")));
        columns.put(appointmentObject);
        when(handlerUtils.isColWithProv(anyString(), anyString())).thenThrow(new IHubException(new IHubErrorCode("22"),"Test Exception"));

        assertThrows(IHubException.class, () -> getColumnsTask.extractOpenSlotsFromResponse(columns, "deploymentId"));
    }

//    @Test
//    void getDayOfWeekValid() {
//        int dayOfWeek = getColumnsTask.getDayOfWeek("2023-01-01", "yyyy-MM-dd");
//
//        assertEquals(Calendar.SUNDAY, dayOfWeek);
//    }
//
//    @Test
//    void getDayOfWeekInvalidDate() {
//        int dayOfWeek = getColumnsTask.getDayOfWeek("invalid-date", "yyyy-MM-dd");
//
//        assertEquals(0, dayOfWeek);
//    }
}