package com.pes.integration.advancedmd.task;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;

import java.io.File;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static java.util.Objects.nonNull;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class PrepareBookedSlotsTask implements Supplier<Void> {

  private Map<String, Object> payload = new HashMap<>();
  private String startDate;
  private String endDate;
  private String dataLocation;
  private String epmPrefix;
  private EventTracker trackEvents;
  private FileUploader fileUploader;
  private AdvancedmdApiCaller advancedmdApiCaller;
  private AvailabilityRequest availabilityRequest;
  private List<String> bookedStatuses;
  private Map<String, String> contextMap = getCopyOfContextMap();

  private ConfigCache configCache;
  private DataCacheManager dataCacheManager;
  private HandlerUtils handlerUtils;

  public PrepareBookedSlotsTask(AdvancedmdApiCaller advancedmdApiCaller, JSONObject inputObject,
                                FileUploader fileUploader, EventTracker trackEvents,
                                AvailabilityRequest availabilityRequest, HandlerUtils handlerUtils,
                                ConfigCache configCache, DataCacheManager dataCacheManager) {
    this.startDate = inputObject.getString(STARTDATE);
    this.endDate = inputObject.getString(ENDDATE);
    this.epmPrefix = inputObject.optString("epmPrefix");
    this.dataLocation = inputObject.getString(APPOINTMENT_PATH);
    this.advancedmdApiCaller = advancedmdApiCaller;
    this.fileUploader = fileUploader;
    this.trackEvents = trackEvents;
    this.availabilityRequest = availabilityRequest;
    this.handlerUtils = handlerUtils;
    this.configCache = configCache;
    this.dataCacheManager = dataCacheManager;
  }

  @Override
  public Void get() {
    Map<String, File> appointmentDataFiles = new HashMap<>();
    try {
      JSONObject bookedApptOutput = getBookedAppointment();
      uploadBookedFiles(appointmentDataFiles, bookedApptOutput);
      trackEventToNifi(trackEvents, availabilityRequest,
              getBookedDataFlowNifiStatus(availabilityRequest), MDC.get(TOTAL_FRAGMENTS), "",
              payload);
    } catch (Exception e) {
      log.error("Error in getting the booked slots " + e.getMessage());
      trackBookedSliceError(availabilityRequest,trackEvents,"Error in getting the booked slots");
    } finally {
      deleteFiles(appointmentDataFiles);
    }
    return null;
  }

  private JSONObject getBookedAppointment() throws Exception {
    JSONArray bookedAppointmentsArray = bookedAppointments();
    log.info("Booked api called ");
    return getBookedAppointmentObject(bookedAppointmentsArray);
  }

  private void uploadBookedFiles(Map<String, File> appointmentDataFiles,
      JSONObject bookedApptOutput) {
    appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
        prepareBookedFile(bookedApptOutput, availabilityRequest));
    fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
        availabilityRequest.getAppointmentType(), availabilityRequest.getSliceId(),
        appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
  }

  private JSONObject getBookedAppointmentObject(JSONArray bookedAppointmentsArray) {
    JSONObject openApptOutput = new JSONObject();
    openApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
    openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
    openApptOutput.put(TOTAL_COUNT, bookedAppointmentsArray.length());
    openApptOutput.put(DATA, bookedAppointmentsArray);
    return openApptOutput;
  }

  private JSONArray extractBookedSlotsFromResponse(JSONArray bookedApptArray) throws Exception {
    log.info("Extracting Open Appointments from response " + bookedApptArray);
    JSONArray bookedAppointmentsArray = new JSONArray();
    if (nonNull(bookedApptArray)) {
      for (Object appointmentObject : bookedApptArray) {
        JSONObject outAppt = transformBookedAppointment(new JSONObject(appointmentObject.toString()));
        bookedAppointmentsArray.put(outAppt);
      }
    }
    return bookedAppointmentsArray;
  }

  private JSONObject transformBookedAppointment(JSONObject appointmentObject) throws ParseException {
    JSONObject bookedAppointment = new JSONObject();
    bookedAppointment.put(PROVIDER_ID_KEY, appointmentObject.opt(PROVIDER_ID));
    bookedAppointment.put(REASON_ID_KEY, appointmentObject.opt(APPTREASON_ID));
    bookedAppointment.put(START_TIME, appointmentObject.opt("apptTimingStart"));
    bookedAppointment.put(LOCATION_ID_KEY, appointmentObject.opt(LOCATION_ID));
    bookedAppointment.put(DURATION, String.valueOf(appointmentObject.opt("Duration")));
    bookedAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
    bookedAppointment.put("slotId", appointmentObject.opt("ExternalApptId"));
    String date = appointmentObject.optString("date");
    bookedAppointment.put(DATE_KEY, convertDateFormat(date.trim(), DOCASAP_DATE_FORMAT, DATE_TIME_FORMAT));
    return bookedAppointment;
  }
  private File prepareBookedFile(JSONObject apptresponse, AvailabilityRequest availabilityRequest) {
    return prepareFile(apptresponse.toString(),
        dataLocation + availabilityRequest.getMessageControlId() + SLASH
            + availabilityRequest.getSliceId(),
        SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
  }

  private JSONArray bookedAppointments() throws Exception {
    JSONArray bookedAppointmentsArray = new JSONArray();
    JSONArray bookedAppointments = new GetAppointmentsTask(buildRequest(), advancedmdApiCaller, handlerUtils, configCache, dataCacheManager, availabilityRequest)
            .getBookAppointments(availabilityRequest.getDeploymentId());
     return bookedAppointmentsArray.putAll(extractBookedSlotsFromResponse(bookedAppointments));
  }
    private JSONObject buildRequest() {
        JSONObject availableTimeRequest = new JSONObject();
        availableTimeRequest.put("epmPrefix", epmPrefix);
        availableTimeRequest.put("startDate", startDate);
        availableTimeRequest.put("endDate", endDate);
        return availableTimeRequest;
    }

  public void trackEventToNifi(EventTracker trackEvents, AvailabilityRequest availabilityRequest,
                               DataflowStatus dataflowStatus, String totalFragments, String fragmentId,
                               Map<String, Object> payload) {
    NifiTrackingEvent nifiEvent = NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
            .messageControlId(availabilityRequest.getMessageControlId())
            .appointmentType(availabilityRequest.getAppointmentType())
            .sliceId(availabilityRequest.getSliceId())
            .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
            .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices()).payload(payload)
            .entityType(availabilityRequest.getEntityType()).entityId(availabilityRequest.getEntityId())
            .flow(availabilityRequest.getFlow()).build();
    trackEvents.trackEventToNifi(nifiEvent);
  }
}