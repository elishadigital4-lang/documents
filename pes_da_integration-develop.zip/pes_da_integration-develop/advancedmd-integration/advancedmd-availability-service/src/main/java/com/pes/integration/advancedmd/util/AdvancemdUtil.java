package com.pes.integration.advancedmd.util;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.pes.integration.advancedmd.api.ApiName.HOLD_APPOINTMENTS;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_RESOURCE_ID;
import static com.pes.integration.constant.EpmConstant.ENDDATE;
import static com.pes.integration.constant.EpmConstant.STARTDATE;

@Slf4j
public class AdvancemdUtil {

    private AdvancemdUtil(){
        // To avoid sonar issue
    }

    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String PRACTICE_ID = "practiceid";
    public static final String DEPLOYMENTID = "deploymentId";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";

    public static JSONObject openAppointments(String deploymentId, AdvancedmdApiCaller advancedmdApiCaller, JSONObject inputParam)
            throws InvalidResourceException, IHubException {
        JSONObject openAppointmentRequest = getInputObject(inputParam);
        JSONArray openAppointmentsArray = new JSONArray();

        LocalDate startDate = LocalDate.parse(inputParam.getString(STARTDATE), DateTimeFormatter.ofPattern(YYYY_MM_DD));
        LocalDate endDate = LocalDate.parse(inputParam.getString(ENDDATE), DateTimeFormatter.ofPattern(YYYY_MM_DD));

        for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
            openAppointmentRequest.getJSONObject("temp").put("start_date", date.format(DateTimeFormatter.ofPattern(YYYY_MM_DD)));
            JSONObject response = advancedmdApiCaller.call(deploymentId, HOLD_APPOINTMENTS.getKey(), openAppointmentRequest, "");
            openAppointmentsArray.put(response);
        }
        return new JSONObject().put("response", openAppointmentsArray);
    }

    public static JSONObject getInputObject(JSONObject inputParam) {
        JSONObject openAppointmentRequest = new JSONObject();
        JSONObject providerObj;
        JSONObject provider = new JSONObject();

        JSONObject tempObj = new JSONObject();
        tempObj.put("start_date", inputParam.getString(STARTDATE));
        String[] splitColumnId = inputParam.optString(APPT_RESOURCE_ID).split("@");
        if (inputParam.has(APPT_RESOURCE_ID)) {
            providerObj = new JSONObject();
            providerObj.put("ColumnId", splitColumnId[0]);
            JSONArray providerArray = new JSONArray();
            providerArray.put(providerObj);
            provider.put("Provider", providerArray);
        }
        tempObj.put("view", "day");
        openAppointmentRequest.put("SchedulingData", provider);
        openAppointmentRequest.put("temp", tempObj);
        return openAppointmentRequest;
    }


}
