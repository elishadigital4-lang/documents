package com.pes.integration.advancedmd.task;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import com.pes.integration.constant.EpmConstant;

import java.text.ParseException;
import java.util.*;

import static com.pes.integration.advancedmd.api.ApiName.HOLD_APPOINTMENTS;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.APPT_REASON_ID;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.PROV_COLUMN_ID;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.VIEW;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_DATE;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.Number.ONE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
public class GetAppointmentsTask {

  private String startDate;
  private String endDate;
  private String provider;
  private String epmPrefix;
  private AdvancedmdApiCaller advancedMdApiCaller;

  private HandlerUtils handlerUtils;

  private ConfigCache configCache;

  private DataCacheManager dataCacheManager;

  private AvailabilityRequest availabilityRequest;

  public GetAppointmentsTask(JSONObject availableTimeRequest, AdvancedmdApiCaller advancedMdApiCaller,
                             HandlerUtils handlerUtils, ConfigCache configCache,
                             DataCacheManager dataCacheManager, AvailabilityRequest availabilityRequest ) {
    this.startDate = availableTimeRequest.optString("startDate");
    this.endDate = availableTimeRequest.optString("endDate");
    this.provider = availableTimeRequest.optString("provider");
    this.epmPrefix = availableTimeRequest.optString("epmPrefix");
    this.advancedMdApiCaller = advancedMdApiCaller;
    this.handlerUtils = handlerUtils;
    this.configCache = configCache;
    this.dataCacheManager = dataCacheManager;
    this.availabilityRequest = availabilityRequest;
  }

   List<String> getExcludeStatusConfig() {
    List<String> excludeStatusList = new ArrayList<>();
    try {
      String excludeStatusIdsStr = (String) dataCacheManager.getStoredComponentConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDEngineConstants.EXCLUDE_STATUS_CODE, false);
      if (!NullChecker.isEmpty(excludeStatusIdsStr))
        excludeStatusList = Arrays.asList(excludeStatusIdsStr.split(","));
    } catch (Exception e) {
      log.error("Error in fetching config " + AdvancedMDEngineConstants.EXCLUDE_STATUS_CODE + e);
    }
    return excludeStatusList;
  }

  public JSONArray getOpenAppointments() {
    JSONObject inputObject = new JSONObject();
    JSONArray bookedAppointmentsArray = new JSONArray();
    JSONArray openAppointmentsArray = new JSONArray();
    log.info(availabilityRequest.getDeploymentId());
    try {
      JsonUtils.setValue(inputObject, START_DATE, startDate);
      JsonUtils.setValue(inputObject, VIEW, "day");
      JsonUtils.setValue(inputObject, DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
      String columnIdsStr = handlerUtils.getColumnStr(availabilityRequest.getDeploymentId());
      log.info("Column String {}" , columnIdsStr);
      Map<String, String> providerIdsMap = null;
      boolean isColWithProv = handlerUtils.isColWithProv(availabilityRequest.getDeploymentId(), epmPrefix);
      log.info("isColWithProv " + isColWithProv);
      if (isColWithProv) providerIdsMap = handlerUtils.getProviderMap(availabilityRequest.getDeploymentId());
      log.info("Provider Ids Map " + providerIdsMap);
      JSONArray holdApptsArray = chunkTheColumnIDs(columnIdsStr, HOLD_APPOINTMENTS.getKey(), inputObject);
      JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COLUMN_ID, columnIdsStr);
      if (holdApptsArray != null) {
        for (int i = 0; i < holdApptsArray.length(); i++) {
          populateHoldAppointmentsArray(startDate, bookedAppointmentsArray, openAppointmentsArray,
                  providerIdsMap, isColWithProv, holdApptsArray, i);
        }
      }
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return openAppointmentsArray;
  }

  private String chunkSubstring(int index, String[] columnIDArr, int chunkSize) {
    if (index >= columnIDArr.length) return BLANK;
    StringBuilder chunk = new StringBuilder();
    while (index < columnIDArr.length && chunkSize > 0) {
      chunk.append(columnIDArr[index++]).append(HYPHEN);
      chunkSize--;
    }
    int chunkLen = chunk.length();
    if (chunkLen > 0 && chunk.charAt(chunk.length() - 1) == MINUS) {
      chunk.deleteCharAt(chunk.length() - 1);
    }
    return String.valueOf(chunk);
  }

   JSONArray chunkTheColumnIDs(String columnIDs, String apiName, JSONObject inputObject) {
    JSONArray apptsArray = new JSONArray();
    JSONObject outputObject;
    try {
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      String[] columnIDsArr = columnIDs.split(HYPHEN);
      log.info("Deployment id and column string in chunk " + deploymentId + ", " + Arrays.toString(columnIDsArr));
      int start = 0;
      int chunkSize = 200;
      int columnIDsLen = columnIDsArr.length;
      log.info("Chunk size " + chunkSize + ",  column Id length " + columnIDsLen);
      while (start < columnIDsLen) {
        String columnIDChunk = chunkSubstring(start, columnIDsArr, chunkSize);
        log.info("Loop running upto columnIds Length " + start + ", " + columnIDChunk);
        if (columnIDChunk.equals(BLANK)) break;
        start += chunkSize;
        JsonUtils.setValue(inputObject, DocASAPConstants.Key.PROV_COLUMN_ID, columnIDChunk);
        outputObject = advancedMdApiCaller.call(deploymentId, apiName, inputObject, "");
        JSONArray tempHoldAppt = (JSONArray) getValue(outputObject, BOOKED_APPOINTMENTS);
        if (!NullChecker.isEmpty(tempHoldAppt)) {
          for (Object temp : tempHoldAppt) {
            apptsArray.put(temp);
          }
        }
        outputObject.clear();
      }
    } catch (Exception e1) {
      log.error("In chunk column " +e1.getMessage());
    }
    return apptsArray;
  }

  private void populateBookedAppointmentsArray(JSONArray bookedAppointmentsArray, JSONArray appointmentsArray,
                                               Map<String, String> providerIdsMap, List<String> statusIdList, int i) {
    try {
      JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
      appointmentObject = getBookedAppointmentObj(appointmentObject, providerIdsMap);
      String columnId = getValue(appointmentObject, PROV_COLUMN_ID).toString();
      if (!NullChecker.isEmpty(columnId))
        JsonUtils.setValue(appointmentObject, TEMPLATE_ID, columnId);
      Object status = getValue(appointmentObject, "ApptStatus");
      log.debug("status id" + status);
      if (status != null && !statusIdList.contains(status.toString())) {

        bookedAppointmentsArray.put(appointmentObject); // appt will be excluded if status = 10,11,12
      } else log.debug("removed");
    } catch (Exception e) {
      log.error("Booked Appointments array is empty");
      log.error(e.getMessage());
    }
  }

  private JSONObject getBookedAppointmentObj(JSONObject appointmentObject, Map<String, String> map) {
    try {
      JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.BASELINE_DURATION_UNIT, DocASAPConstants.DURATION_UNIT_MINUTES);
      String timeString = getValue(appointmentObject, DocASAPConstants.TempKey.START_TIME).toString();
      String docasapTime = DateUtils.convertDateFormat(timeString.trim(), AdvancedMDConstants.DATE_TIME_FORMAT, DocASAPConstants.TIME_FORMAT);
      String docasapDate = DateUtils.convertDateFormat(timeString.trim(), AdvancedMDConstants.DATE_TIME_FORMAT, DocASAPConstants.DOCASAP_DATE_FORMAT);
      JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.BASELINE_TIMING_START, docasapTime);
      JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.DATE, docasapDate);
      String columnId = getValue(appointmentObject, PROV_COLUMN_ID).toString();
      //JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.PROVIDER_ID, map.get(columnId));
      JsonUtils.setValue(appointmentObject, EpmConstant.PROVIDER_ID, map.get(columnId));
      JsonUtils.setValue(appointmentObject, DocASAPConstants.TempKey.TEMP, null);
    } catch (IHubException | ParseException e) {
      log.error("Error in converting time format", e);
    }
    return appointmentObject;
  }

  private void populateHoldAppointmentsArray(String startDate, JSONArray bookedAppointmentsArray,
                                             JSONArray openAppointmentsArray, Map<String, String> providerIdsMap, boolean isColWithProv,
                                             JSONArray holdApptsArray, int i) {
    try {
      JSONObject appointmentObject = holdApptsArray.getJSONObject(i);
      appointmentObject = getBookedAppointmentObj(appointmentObject, providerIdsMap);
      String columnId = getValue(appointmentObject, PROV_COLUMN_ID).toString();
      log.info("Column id "+columnId);
      if (!NullChecker.isEmpty(columnId))
        JsonUtils.setValue(appointmentObject, TEMPLATE_ID, columnId);
      String reasonType = getValue(appointmentObject, "ReasonType").toString();
      if (AdvancedMDEngineConstants.REASON_TYPE_VAL.equals(reasonType)) {
        openAppointmentsArray.putAll(prepareHoldSlots(appointmentObject, bookedAppointmentsArray, isColWithProv, startDate));
      } else {
        JsonUtils.setValue(appointmentObject, AdvancedMDEngineConstants.IS_BLOCKED, UtilitiesConstants.TRUE);
        bookedAppointmentsArray.put(appointmentObject);
      }
    } catch (Exception e) {
      log.error("Hold/Block Appointments array is empty");
      log.error(e.getMessage());
    }
  }

  private JSONArray prepareHoldSlots(JSONObject appointmentObject, JSONArray bookedAppointmentsArray, boolean isColWithProv, String startDate) throws IHubException {
    log.info("Preparing hold slots");
    JSONArray openAppointmentsArray = new JSONArray();
    String slotInterval = null;
    try {
      slotInterval = dataCacheManager.getConfiguration(AdvancedMDEngineConstants.EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), UtilitiesConstants.GENERIC_CONFIG, AdvancedMDEngineConstants.BS_SLOT_INTERVAL);
    } catch (Exception e) {
      log.error("slot_interval config is not set or malformed for " + availabilityRequest.getDeploymentId());
    }
    try {
      if (!NullChecker.isEmpty(slotInterval)) {
        JsonUtils.setValue(appointmentObject, AdvancedMDEngineConstants.BS_SLOT_INTERVAL, slotInterval);
      }
      if (!shouldIgnoreApptNameMatch()) {
        String apptReasonNameStr = getValue(appointmentObject, DocASAPConstants.Key.APPT_REASON).toString();
        Map<String, String> appointmentTypeMap = handlerUtils.getApptTypeMap(availabilityRequest.getDeploymentId());
        Map<String, String> appointmentTypeMapCopy = new HashMap<>();
        for (Map.Entry<String, String> entrySet : appointmentTypeMap.entrySet()) {
          appointmentTypeMapCopy.put(entrySet.getKey().toLowerCase(), entrySet.getValue());
        }
        String apptTypeId = appointmentTypeMapCopy.get(apptReasonNameStr.trim().toLowerCase());
        if (!NullChecker.isEmpty(apptTypeId)) {
          JsonUtils.setValue(appointmentObject, "ExternalApptId", null);
          JsonUtils.setValue(appointmentObject, APPT_REASON_ID, apptTypeId);
          if (!isColWithProv) setSlotId(appointmentObject, startDate);
          openAppointmentsArray.put(appointmentObject);
        } else {
          JsonUtils.setValue(appointmentObject, AdvancedMDEngineConstants.IS_BLOCKED, UtilitiesConstants.TRUE);
          bookedAppointmentsArray.put(appointmentObject);
        }
      } else {
        updateAppointmentTypes(appointmentObject, isColWithProv, openAppointmentsArray, startDate);
      }
    } catch (Exception e) {
      log.error(e.getMessage());
    }

    return openAppointmentsArray;
  }

   boolean shouldIgnoreApptNameMatch() {
    try {
      String splitByProv = dataCacheManager.getConfiguration(AdvancedMDEngineConstants.EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(),
              AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDEngineConstants.IGNORE_APPT_NAME_MATCH);
      return !splitByProv.equalsIgnoreCase(UtilitiesConstants.FALSE);
    } catch (IHubException e) {
      return true;
    }
  }

  private List<String> getHoldReasonMapConfig(String deploymentId) {
    List<String> holdReasonWithAptTypes = new ArrayList<>();
    try {
      String apptTypesStr = dataCacheManager.getConfiguration(AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDEngineConstants.HOLD_REASON_MAP);
      if (!NullChecker.isEmpty(apptTypesStr))
        holdReasonWithAptTypes = Arrays.asList(apptTypesStr.split(","));
    } catch (Exception e) {
      log.error("Error in fetching config " + AdvancedMDEngineConstants.HOLD_REASON_MAP + e);
    }
    return holdReasonWithAptTypes;
  }

   JSONObject setSlotId(JSONObject appointmentObject, String startDate) throws IHubException {
    String columnId = getValue(appointmentObject, PROV_COLUMN_ID).toString();
    String profileId = getValue(appointmentObject, DocASAPConstants.Key.PROVIDER_ID) + "_";
    Object facilityId = getValue(appointmentObject, DocASAPConstants.Key.LOCATION_ID);

    if (NullChecker.isEmpty(facilityId)) facilityId = "0_";
    else facilityId = facilityId + "_";
    JsonUtils.setValue(appointmentObject, AdvancedMDConstants.SLOTID, columnId + "-a" + profileId + facilityId + startDate);
    log.info(AdvancedMDConstants.SLOTID + getValue(appointmentObject, AdvancedMDConstants.SLOTID));
    return appointmentObject;
  }

  private void updateAppointmentTypes(JSONObject appointmentObject, boolean isColWithProv, JSONArray openAppointmentsArray, String startDate) throws IHubException {
    List<String> holdReasonWithAptTypes = getHoldReasonMapConfig(availabilityRequest.getDeploymentId());
    boolean isAdded = false;
    if (!NullChecker.isEmpty(holdReasonWithAptTypes)) {
      for (int j = 0; j < holdReasonWithAptTypes.size(); j++) {
        String holdReasonWithAptTypeIds = holdReasonWithAptTypes.get(j);

        Object apptReasonId = getValue(appointmentObject, APPT_REASON_ID);
        if (holdReasonWithAptTypeIds.contains(":")) {
          int index = holdReasonWithAptTypes.get(j).indexOf(":");
          String holdReasonId = holdReasonWithAptTypes.get(j).substring(0, index);
          String apptTypeIdsString = holdReasonWithAptTypes.get(j).substring(index + 1);
          if (holdReasonId != null && apptReasonId != null && holdReasonId.equalsIgnoreCase(apptReasonId.toString()) &&
                  (isHold(AdvancedMDEngineConstants.IS_HOLD_ONLY, availabilityRequest.getDeploymentId()) || isHold(AdvancedMDEngineConstants.IS_HOLD_WITH_GEN, availabilityRequest.getDeploymentId()))) {
            isAdded = setOpenAppointmentsArray(appointmentObject, isColWithProv, openAppointmentsArray,
                    startDate, isAdded, apptTypeIdsString);
          }
        }
      }
    }
  }

  private boolean setOpenAppointmentsArray(JSONObject appointmentObject, boolean isColWithProv,
                                           JSONArray openAppointmentsArray, String startDate, boolean isAdded, String apptTypeIdsString) {
    try {
      JsonUtils.setValue(appointmentObject, APPT_REASON_ID, apptTypeIdsString);
      JsonUtils.setValue(appointmentObject, "ExternalApptId", null);
      if (!isColWithProv) setSlotId(appointmentObject, startDate);

      openAppointmentsArray.put(appointmentObject);
      isAdded = true;

    } catch (IHubException e) {
      log.error(e.getMessage());
    }
    return isAdded;
  }

  /**
   * Fetching the two db configs(is_hold_only and is_hold_with_gen) from client level config table.
   *
   * @param pConfigKey
   * @return
   */
   boolean isHold(String pConfigKey, String deploymentId) {
    try {
      return dataCacheManager.getConfiguration(
                      AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId,
                      AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, pConfigKey)
              .equalsIgnoreCase(UtilitiesConstants.TRUE);
    } catch (IHubException e) {
      return false;
    }
  }

  public JSONArray getBookAppointments(String deploymentId) {
    JSONObject inputObject = new JSONObject();
    JSONArray bookedAppointmentsArray = new JSONArray();
    log.info(deploymentId);
    try {
      //String startDate = (String) JsonUtils.getValue(inputObject, START_DATE);
      //startDate = DateUtils.convertDateFormat(startDate, BaseEPMConstants.EPM_DATE_FORMAT, DATE_FORMAT);
      JsonUtils.setValue(inputObject, START_DATE, startDate);
      JsonUtils.setValue(inputObject, VIEW, "day");
      JsonUtils.setValue(inputObject, DEPLOYMENT_ID, availabilityRequest.getDeploymentId());

      JSONArray openAppointmentsArray = new JSONArray();
      String columnIdsStr = handlerUtils.getColumnStr(deploymentId);

      JSONArray appointmentsArray = chunkTheColumnIDs(columnIdsStr, ApiName.BOOKED_APPOINTMENTS.getKey(), inputObject);
      JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COLUMN_ID, columnIdsStr);
      Map<String, String> providerIdsMap = null;
      boolean isColWithProv = handlerUtils.isColWithProv(deploymentId, epmPrefix);
      if (isColWithProv) providerIdsMap = handlerUtils.getProviderMap(deploymentId);
      else providerIdsMap = handlerUtils.getColProviderMap(deploymentId);
      if (appointmentsArray != null) {
        List<String> statusIdList = getExcludeStatusConfig();
        for (int i = 0; i < appointmentsArray.length(); i++) {
          populateBookedAppointmentsArray(bookedAppointmentsArray, appointmentsArray, providerIdsMap,
                  statusIdList, i);
        }
      }
      JSONArray holdApptsArray = chunkTheColumnIDs(columnIdsStr, HOLD_APPOINTMENTS.getKey(), inputObject);
      JsonUtils.setValue(inputObject, AdvancedMDEngineConstants.COLUMN_ID, columnIdsStr);
      if (holdApptsArray != null) {
        for (int i = 0; i < holdApptsArray.length(); i++) {
          populateHoldAppointmentsArray(startDate, bookedAppointmentsArray, openAppointmentsArray,
                  providerIdsMap, isColWithProv, holdApptsArray, i);
        }
      }
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return bookedAppointmentsArray;
  }
}
