package com.pes.integration.advancedmd.task;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.util.Map;
import java.util.function.Supplier;

import static com.pes.integration.advancedmd.util.AdvancemdUtil.openAppointments;
import static com.pes.integration.constant.DocASAPConstants.Key.BOOKED_APPOINTMENTS;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.MdcUtil.setContext;
import static java.lang.String.format;
import static java.util.Objects.nonNull;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class RealTimeOpenSlotsTask implements Supplier<JSONArray> {

    private static final String ERROR_PROCESSING_DATA = "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";

    private String startDate;
    private String endDate;
    private String providerId;
    private JSONObject inputParam;
    private AdvancedmdApiCaller advancedmdApiCaller;
    private Map<String, String> contextMap = getCopyOfContextMap();
    private String deploymentId;


    public RealTimeOpenSlotsTask(String deploymentId, AdvancedmdApiCaller advancedmdApiCaller, JSONObject inputObject) {
        this.deploymentId = deploymentId;
        this.startDate = inputObject.getString(STARTDATE);
        this.endDate = inputObject.getString(ENDDATE);
        this.advancedmdApiCaller = advancedmdApiCaller;
        this.inputParam = inputObject;

    }

    @Override
    public JSONArray get() {
        setContext(contextMap);
        JSONArray openAppointmentsArray = new JSONArray();
        JSONObject filteredObject;
        try {
            JSONObject responseObject = openAppointments(deploymentId, advancedmdApiCaller, inputParam);
            JSONArray resultArray = new JSONArray();
            JSONArray jsonArray = responseObject.optJSONArray("response");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (!jsonObject.isEmpty()) {
                    resultArray.put(jsonObject);
                }
            }
            filteredObject = new JSONObject().put("filteredResponse", resultArray);
            openAppointmentsArray.putAll(extractSlots(filteredObject, inputParam));

        } catch (InvalidIdException ide) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ide.getMessage());
            log.error(escapeJava(exceptionDetails));

            throw new EpmApiCallerException(exceptionDetails);
        } catch (EpmApiCallerException | InvalidResourceException | IHubException ee) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ee.getMessage());
            log.error(escapeJava(exceptionDetails));
            throw new EpmApiCallerException(exceptionDetails);
        }
        return openAppointmentsArray;
    }

    public static JSONArray extractSlots(JSONObject outputObject, JSONObject inputParam) {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray responseArray = outputObject.optJSONArray("filteredResponse");
        String requestLocationId = inputParam.getString("SchedulingData.Provider[0].LocationId");
        if (nonNull(responseArray)) {
            responseArray.forEach(responseObject -> {
                JSONObject response = new JSONObject(responseObject.toString());
                JSONArray appointmentsArray = response.optJSONArray(BOOKED_APPOINTMENTS);
                if (nonNull(appointmentsArray)) {
                    appointmentsArray.forEach(appointmentObject -> {
                        JSONObject apptObject = new JSONObject(appointmentObject.toString());
                        try {
                                if (apptObject.has("ReasonType")
                                        && apptObject.optString("ReasonType").equals(AdvancedMDEngineConstants.REASON_TYPE_VAL)) {
                                    openAppointmentsArray.put(transformOpenAppointment(apptObject, inputParam));
                                }
                        } catch (ParseException e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            });
        }
        return openAppointmentsArray;
    }


    public static JSONObject transformOpenAppointment(JSONObject appointmentObject, JSONObject inputParam) throws ParseException {
        JSONObject openAppointment = new JSONObject();
        openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
        openAppointment.put("duration", appointmentObject.opt("Duration"));
        openAppointment.put("slotId", appointmentObject.opt("ColumnId"));
        openAppointment.put(LOCATION_ID_KEY, inputParam.getString("SchedulingData.Provider[0].LocationId"));
        openAppointment.put(PROVIDER_ID_KEY, inputParam.getString("SchedulingData.Provider[0].ResourceId"));
        openAppointment.put(REASON_ID_KEY, appointmentObject.optString(APPTREASON_ID));
        String startTime = (String) appointmentObject.optJSONObject("temp").opt("start_time");
        openAppointment.put(START_TIME,
                convertDateFormat(startTime.trim(), DATE_TIME_FORMAT, DOCASAP_TIME_FORMAT));
        openAppointment.put(DATE_KEY, convertDateFormat(startTime.trim(), DATE_TIME_FORMAT, DOCASAP_DATE_FORMAT));
        return openAppointment;
    }
}
