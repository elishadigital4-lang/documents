package com.pes.integration.advancedmd.task;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.advancedmd.api.ApiName.GET_COLUMNS;
import static com.pes.integration.advancedmd.constant.AdvancedMDConstants.TIME_FORMAT;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.COLUMNS;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.PROV_COLUMN_ID;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.DocASAPConstants.DURATION_UNIT_MINUTES;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.END_TIME;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_TIME;
import static com.pes.integration.constant.UtilitiesConstants.PROVIDER_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.DateUtils.convertDateFormat;

@Slf4j
public class GetColumnsTask {

  private String startDate;
  private String endDate;

  private String epmPrefix;
  private AdvancedmdApiCaller advancedMdApiCaller;

  private HandlerUtils handlerUtils;

  private ConfigCache configCache;

  public GetColumnsTask(JSONObject availableTimeRequest, AdvancedmdApiCaller advancedMdApiCaller,HandlerUtils handlerUtils, ConfigCache configCache) {
    this.startDate = availableTimeRequest.optString("startDate");
    this.endDate = availableTimeRequest.optString("endDate");
    this.epmPrefix = availableTimeRequest.optString("epmPrefix");
    this.advancedMdApiCaller = advancedMdApiCaller;
    this.handlerUtils = handlerUtils;
    this.configCache = configCache;
  }
  public JSONArray getColumns(String deploymentId) throws IHubException {
    JSONObject response = advancedMdApiCaller.call(deploymentId, GET_COLUMNS.getKey(), getColumIdRequest(), "");
    JSONArray columns = (JSONArray) getValue(response, COLUMNS);
    log.info("get column api called for open appointments");
    return columns;
  }
  private int getDayOfWeek(String dateStr, String dateFormat) {
    DateFormat format = new SimpleDateFormat(dateFormat);
    Date date = null;
    try {
      date = format.parse(dateStr);
    } catch (ParseException e) {
      log.info(e.getMessage());
    }
    Calendar c = Calendar.getInstance();
    if (date != null) {
      c.setTime(date);
    }
    return c.get(Calendar.DAY_OF_WEEK);
  }

  public JSONArray extractOpenSlotsFromResponse(JSONArray columns, String deploymentId) throws IHubException {
    JSONArray openAppointmentsArray = new JSONArray();
    int dayOfWeek =  getDayOfWeek(startDate, BaseEPMConstants.EPM_DATE_FORMAT);
    Map<String,String> providerIdsMap = new HashMap<>();
    if(columns!=null){
      boolean  isColWithProv = handlerUtils.isColWithProv(deploymentId, epmPrefix);
      for (int i = 0; i < columns.length(); i++) {
        getProviderIdsMap(openAppointmentsArray, columns, startDate, dayOfWeek, providerIdsMap, isColWithProv,
                i);
      }
    }
    configCache.setProviderIdsMap(deploymentId, providerIdsMap);
    return openAppointmentsArray;
  }
  private JSONObject getColumIdRequest() {
    JSONObject availableTimeRequest = new JSONObject();
    availableTimeRequest.put(AdvancedMDEngineConstants.VIEW, "day");
    availableTimeRequest.put("startDate", startDate);
    availableTimeRequest.put("endDate", endDate);
    return availableTimeRequest;
  }

  private void getProviderIdsMap(JSONArray openAppointmentsArray, JSONArray columns, String startDate, int dayOfWeek,
                                 Map<String, String> providerIdsMap, boolean isColWithProv, int i) {
    try{
      JSONObject appointmentObject = columns.getJSONObject(i);
      String columnId = getValue(appointmentObject, PROV_COLUMN_ID).toString();
      if(!NullChecker.isEmpty(columnId))
        setValue(appointmentObject, TEMPLATE_ID, columnId);
      String providerId = getValue(appointmentObject, PROVIDER_ID).toString();
      if(!NullChecker.isEmpty(providerId) && !StringUtils.isEmpty(providerId)){
        providerIdsMap.put(columnId, columnId+ ATMARK +providerId);
        String workingDays = getValue(appointmentObject, "workDays").toString();
        CharSequence s = workingDays.subSequence(dayOfWeek-2, dayOfWeek-1);
        if(s.equals("1")){
          isColWithProvValidation(startDate, isColWithProv, appointmentObject, columnId, providerId);
          log.info("SlotId:: "+ getValue(appointmentObject, "slotId"));
          appointmentObject = getOpenAppointmentObj(appointmentObject);
          String startTime = (String) getValue(appointmentObject, "apptTimingStart");
          String endTime = (String) getValue(appointmentObject, "apptTimingEnd");
          setValue(appointmentObject, APPOINTMENT_TYPE_DURATION, getDuration(startTime, endTime, "HHmm"));
          openAppointmentsArray.put(appointmentObject);
        }
      }
    }catch(Exception e){
      log.error(e.getMessage());
    }
  }

  private void isColWithProvValidation(String startDate, boolean isColWithProv, JSONObject appointmentObject,
                                       String columnId, String providerId) throws IHubException {
    if(isColWithProv) setValue(appointmentObject, PROVIDER_ID, columnId+ ATMARK +providerId);
    else {
      Object facilityId = getValue(appointmentObject, DocASAPConstants.Key.LOCATION_ID);
      if(NullChecker.isEmpty(facilityId)) facilityId="0_" ;
      else facilityId = facilityId+"_";
      setValue(appointmentObject, "SlotId", columnId+"-a"+providerId+"_"+facilityId+startDate);
    }
  }

  private static int getDuration(String startTime, String endTime, String timeFormat) throws ParseException {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();

    SimpleDateFormat sdf = new SimpleDateFormat(timeFormat);
    Date date = sdf.parse(startTime);
    cal1.setTime(date);
    date = sdf.parse(endTime);
    cal2.setTime(date);
    return (int)((cal2.getTimeInMillis() - cal1.getTimeInMillis()) / (1000 * 60));
  }

  private JSONObject getOpenAppointmentObj(JSONObject appointmentObject){
    try {
      Object locationId = getValue(appointmentObject, "locationId");
      if(NullChecker.isEmpty(locationId))
        setValue(appointmentObject, "locationId", null);

      String startTimeString = getValue(appointmentObject, START_TIME).toString();
      String docasapStartTime = convertDateFormat(startTimeString, TIME_FORMAT, DocASAPConstants.TIME_FORMAT);
      String endTimeString = getValue(appointmentObject, END_TIME).toString();
      String docasapEndTime = convertDateFormat(endTimeString, TIME_FORMAT, DocASAPConstants.TIME_FORMAT);
      setValue(appointmentObject, BASELINE_TIMING_START, docasapStartTime);
      setValue(appointmentObject, APPT_TIMING_END, docasapEndTime);
      setValue(appointmentObject, BASELINE_DURATION_UNIT, DURATION_UNIT_MINUTES);
      setValue(appointmentObject, DocASAPConstants.TempKey.TEMP, null);
    } catch (IHubException | ParseException e) {
      log.error(e.getMessage());
    }
    return appointmentObject;
  }

}
