package com.pes.integration.advancedmd.service.open.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.task.PrepareOpenSlotsTask;
import com.pes.integration.advancedmd.task.RealTimeOpenSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.NullChecker;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.*;
import static com.pes.integration.advancedmd.util.AdvancemdUtil.*;
import static com.pes.integration.advancedmd.util.AdvancemdUtil.DATE_FORMAT;
import static com.pes.integration.advancedmd.util.AdvancemdUtil.PRACTICE_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_RESOURCE_ID;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.String.format;
import static java.lang.Thread.currentThread;
import static java.util.Objects.nonNull;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static java.util.stream.Collectors.toList;


@Qualifier(OPEN_APPOINTMENT)
@Slf4j
@Service
public class OpenAppointmentServiceImpl extends AppointmentService {

	private static final String REQUEST_RECEIVED = "Open Appointment request has been received with input %s";
	private static final String REASON_ID = "reason_id";

	@Value("${application.data.path}")
	private String dataLocation;

	@Value("${configuration.api.threadsize}")
	private String threadSize;

	@Autowired
	private FileUploader fileUploader;

	@Autowired
	private EventTracker trackEvents;

	@Autowired
	AdvancedmdApiCaller advancedMdApiCaller;

	@Autowired
	HandlerUtils handlerUtils;

	@Autowired
	ConfigCache configCache;

	@Autowired
	DataCacheManager dataCacheManager;


	@Override
	public JSONArray getAvailability(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap, String epmPrefix) throws JsonProcessingException {
		fetchOpenAppointments(advancedMdApiCaller, availabilityRequest, providerLocationMap, epmPrefix);
		return null;
	}

	@Override
	public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
		JSONArray openAppointmentsArray = new JSONArray();
		if (nonNull(realTimeRequest.getEntityId())) {
			List<Object> list = (List<Object>) realTimeRequest.getEntityId();
			try {
				JSONArray providerLocList =
						new JSONArray(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(list));
				providerLocList.forEach(obj -> {
					JSONObject inputParam = null;
					try {
						inputParam = getRealTimeInputObject(realTimeRequest, new JSONObject(obj.toString()));
					} catch (IHubException e) {
						throw new RuntimeException(e);
					}
					openAppointmentsArray.putAll(
							new RealTimeOpenSlotsTask(inputParam.getString(DEPLOYMENTID), advancedMdApiCaller,inputParam).get());
				});
			} catch (JSONException | JsonProcessingException e) {
				log.error("error in getting provider/location list from request {} ", e.getMessage());
				throw new EpmApiCallerException(
						"error in getting provider/location list from request " + e.getMessage());
			}
		}
		return getOpenAppointmentObject(openAppointmentsArray, realTimeRequest);
	}

	private JSONObject getRealTimeInputObject(RealTimeRequest realTimeRequest, JSONObject provLocObj) throws IHubException {
		JSONObject inputParameter = new JSONObject();
		inputParameter.putOpt(APPT_LOCATION_ID, provLocObj.opt("locationId"));
		inputParameter.putOpt(APPT_RESOURCE_ID, provLocObj.opt("providerId"));
		inputParameter.putOpt(REASON_ID, provLocObj.opt("reasonId"));
		inputParameter.put(DEPLOYMENT_ID, realTimeRequest.getDeploymentId());
		inputParameter.put(STARTDATE, realTimeRequest.getStartDate());
		inputParameter.put(ENDDATE, realTimeRequest.getEndDate());
		return inputParameter;
	}

	 void fetchOpenAppointments(AdvancedmdApiCaller advancedMdApiCaller,
									   AvailabilityRequest availabilityRequest,
									   Map<String, JSONArray> providerLocationMap,
									   String epmPrefix) throws JsonProcessingException {
		DateFormat result = getDateFormat(availabilityRequest);
		JSONObject inputObject = getInputObject(result.startDate(), result.endDate(), epmPrefix);
		if (availabilityRequest.getIndex().equals(String.valueOf(FIRST_INDEX))) {
			trackEvents.trackEvent(availabilityRequest, OPEN_APPOINTMENT_PROCESSING_STARTED,
					format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
					getFragmentsDetails(availabilityRequest));
		}
		getPrepareOpenSlotsTask(advancedMdApiCaller, availabilityRequest, inputObject).get();

	}

	 PrepareOpenSlotsTask getPrepareOpenSlotsTask(AdvancedmdApiCaller advancedMdApiCaller, AvailabilityRequest availabilityRequest, JSONObject inputObject) {
		return new PrepareOpenSlotsTask(advancedMdApiCaller,
				inputObject, fileUploader, trackEvents, availabilityRequest, handlerUtils, configCache, dataCacheManager);
	}

	@NonNull
	private static DateFormat getDateFormat(AvailabilityRequest availabilityRequest) {
		String startDate;
		String endDate;
		try {
			startDate = convertDateFormat(availabilityRequest.getStartDate(), AdvancedMDConstants.DATE_FORMAT, DATE_FORMAT);
			endDate = convertDateFormat(availabilityRequest.getEndDate(), AdvancedMDConstants.DATE_FORMAT, DATE_FORMAT);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
		DateFormat result = new DateFormat(startDate, endDate);
		return result;
	}

	private record DateFormat(String startDate, String endDate) {
	}

	private JSONObject getInputObject(String startDate, String endDate, String epmPrefix) {
		JSONObject inputObject = new JSONObject();
		inputObject.put(STARTDATE, startDate);
		inputObject.put(ENDDATE, endDate);
		inputObject.put(APPOINTMENT_PATH, dataLocation);
		inputObject.put("epmPrefix", epmPrefix);
		return inputObject;
	}


	private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest) {
		Map<String, Object> providerDetails = new HashMap<>();
		providerDetails.put(TOTAL_FRAGMENTS, 1);
		providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
		MDC.put(TOTAL_FRAGMENTS, String.valueOf(1));
		return providerDetails;
	}

	private String getMaxPoolSize(String deploymentId, String epmPrefix) {
		try {
			return dataCacheManager.getConfiguration(epmPrefix, deploymentId, ADVANCEDMD_CONFIG, MAX_POOL_SIZE);
		} catch (IHubException e) {
			log.error("Error in getting the max pool size " + e.getMessage());
			return null;
		}
	}

	public JSONArray getColumns(AvailabilityRequest availabilityRequest) {
		JSONObject response = null;
		try {
			response = advancedMdApiCaller.call(availabilityRequest.getDeploymentId(), "get_columns", getColumIdRequest(availabilityRequest), "");
		} catch (IHubException e) {
			log.error("Error in processing the provider list {} ", e.getMessage());
			return new JSONArray();
		}
		JSONArray providers = (JSONArray) JsonUtils.getValue(response, "Columns");
		JSONArray provider = new JSONArray();
		if(!providers.isEmpty())
			provider.put(providers.getJSONObject(0).get("ProviderId"));

		return provider;
	}

	private JSONObject getColumIdRequest(AvailabilityRequest availabilityRequest) {
		JSONObject availableTimeRequest = new JSONObject();
		availableTimeRequest.put("temp.view", "day");
		availableTimeRequest.put("startDate", availabilityRequest.getStartDate());
		availableTimeRequest.put("endDate", availabilityRequest.getEndDate());
		availableTimeRequest.put("provider", "");
		return availableTimeRequest;
	}

}
