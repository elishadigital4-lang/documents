package com.pes.integration.advancedmd.task;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.adapter.Utils;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.FileUtil;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import static com.pes.integration.adapter.Utils.getOpenDataFlowNifiStatus;
import static com.pes.integration.adapter.Utils.trackOpenSliceError;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.ADVANCEDMD_CONFIG;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.IS_HOLD_ONLY;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static java.lang.String.format;
import static java.util.Objects.nonNull;
import static org.slf4j.MDC.getCopyOfContextMap;
import static org.slf4j.MDC.setContextMap;

@Slf4j
public class PrepareOpenSlotsTask implements Supplier<Void> {

  private static final String ERROR_PROCESSING_DATA =
          "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";
  public static final String FRAGMENT_ID = "providerId";

  private String startDate;
  private String endDate;
  private String dataLocation;
  private String epmPrefix;
  private EventTracker trackEvents;
  private FileUploader fileUploader;
  private AdvancedmdApiCaller advancedMdApiCaller;
  private AvailabilityRequest availabilityRequest;
  private Map<String, Object> payload = new HashMap<>();
  private Map<String, String> contextMap = getCopyOfContextMap();

  private HandlerUtils handlerUtils;

  private ConfigCache configCache;

  private  DataCacheManager dataCacheManager;


  public PrepareOpenSlotsTask(AdvancedmdApiCaller advancedMdApiCaller, JSONObject openRequest,
                              FileUploader fileUploader, EventTracker trackEvents,
                              AvailabilityRequest availabilityRequest, HandlerUtils handlerUtils,
                              ConfigCache configCache, DataCacheManager dataCacheManager) {

    this.startDate = openRequest.getString(STARTDATE);
    this.endDate = openRequest.getString(ENDDATE);
    this.dataLocation = openRequest.getString("appointmentPath");
    this.epmPrefix = openRequest.optString("epmPrefix");
    this.advancedMdApiCaller = advancedMdApiCaller;
    this.fileUploader = fileUploader;
    this.trackEvents = trackEvents;
    this.availabilityRequest = availabilityRequest;
    this.handlerUtils = handlerUtils;
    this.configCache=configCache;
    this.dataCacheManager = dataCacheManager;
   // this.payload = payload;
  }
  @Override
  public Void get() {
    Map<String, File> appointmentDataFiles = new HashMap<>();
    try {
      setContextMap(contextMap);
      JSONObject openApptOutput = getOpenAppointment();
      uploadFiles(appointmentDataFiles, openApptOutput);
      trackEventToNifi(trackEvents, availabilityRequest,
              getOpenDataFlowNifiStatus(availabilityRequest), MDC.get(TOTAL_FRAGMENTS), FRAGMENT_ID,
              payload);
    } catch (JsonProcessingException e) {
      log.error("error  while tracking the request {}", e.getMessage());
      throw new EpmApiCallerException("error while tracking the request");
    } catch (EpmApiCallerException ee) {
      log.error("Error in getting the open slotId " + ee.getMessage());
      trackOpenSliceError(availabilityRequest, trackEvents, ee.getMessage());
    } finally {
      deleteFiles(appointmentDataFiles);
    }
    return null;
  }
  private boolean isHoldOnly(String deploymentId) {
    try {
      String isHoldOnly = dataCacheManager.getConfiguration(epmPrefix, deploymentId, ADVANCEDMD_CONFIG, IS_HOLD_ONLY);
      return isHoldOnly.equalsIgnoreCase(UtilitiesConstants.TRUE);
    } catch (IHubException e) {
      return false;
    }
  }

  private JSONObject buildRequest() {
    JSONObject availableTimeRequest = new JSONObject();
    availableTimeRequest.put("epmPrefix", epmPrefix);
    availableTimeRequest.put("startDate", startDate);
    availableTimeRequest.put("endDate", endDate);
    return availableTimeRequest;
  }

  private JSONObject getOpenAppointment() throws JsonProcessingException {
    JSONArray openAppointmentsArray = new JSONArray();
    JSONObject openApptOutput;
    try {
      if (!isHoldOnly(availabilityRequest.getDeploymentId())) {
         GetColumnsTask columnsTask  = new GetColumnsTask(buildRequest(), advancedMdApiCaller, handlerUtils, configCache);
        JSONArray columns =  columnsTask.getColumns(availabilityRequest.getDeploymentId());
        openAppointmentsArray = columnsTask.extractOpenSlotsFromResponse(columns, availabilityRequest.getDeploymentId());
      }
      JSONArray openAppointments = new GetAppointmentsTask(buildRequest(), advancedMdApiCaller, handlerUtils, configCache, dataCacheManager, availabilityRequest)
              .getOpenAppointments();
      openAppointmentsArray.putAll(openAppointments);
      openAppointmentsArray = extractOpenSlotsFromResponse(openAppointmentsArray);
      openApptOutput = getOpenAppointmentObject(openAppointmentsArray);
    } catch (InvalidIdException | EpmApiCallerException e) {
      String exceptionDetails =
          format(ERROR_PROCESSING_DATA, startDate, endDate, FRAGMENT_ID, e.getMessage());
      log.error(exceptionDetails);
      Utils.trackOpenFragmentError(availabilityRequest, trackEvents, FRAGMENT_ID, exceptionDetails);
      throw new EpmApiCallerException(exceptionDetails);
    } catch (Exception e) {
      throw new EpmApiCallerException(e.getMessage());
    }
      return openApptOutput;
  }

  private JSONArray extractOpenSlotsFromResponse(JSONArray outApptArray) throws Exception {
    log.info("Extracting Open Appointments from response " + outApptArray);
    JSONArray openAppointmentsArray = new JSONArray();
    if (nonNull(outApptArray)) {
      for (Object appointmentObject : outApptArray) {
        JSONObject outAppt = transformOpenAppointment(new JSONObject(appointmentObject.toString()));
        openAppointmentsArray.put(outAppt);
      }
    }
    return openAppointmentsArray;
  }
  private JSONObject transformOpenAppointment(JSONObject appointmentObject) throws Exception {
    JSONObject openAppointment = new JSONObject();
    openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
    openAppointment.put(DURATION, String.valueOf(appointmentObject.opt("Duration")));
//    openAppointment.put("templateId", appointmentObject.opt("templateId"));
    openAppointment.put(SLOT_INTERVAL, appointmentObject.opt(SLOT_INTERVAL_KEY));
    openAppointment.put(LOCATION_ID_KEY, appointmentObject.opt(LOCATION_ID));
    openAppointment.put(PROVIDER_ID_KEY, appointmentObject.opt(PROVIDER_ID));
    openAppointment.put(REASON_ID_KEY, appointmentObject.opt(APPTREASON_ID));
    openAppointment.put(START_TIME, appointmentObject.opt("apptTimingStart"));
    String date = appointmentObject.optString("date");
    openAppointment.put(DATE_KEY, convertDateFormat(date.trim(), DOCASAP_DATE_FORMAT, DATE_TIME_FORMAT));
    return openAppointment;
  }
  private JSONObject getOpenAppointmentObject(JSONArray openAppointmentsArray) {
    JSONObject openApptOutput = new JSONObject();
    openApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
    openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
    openApptOutput.put(TOTAL_COUNT, openAppointmentsArray.length());
    openApptOutput.put(DATA, openAppointmentsArray);
    return openApptOutput;
  }
  private File prepareOpenAppointmentFile(JSONObject apptresponse, AvailabilityRequest availabilityRequest) {
    return FileUtil.prepareFile(apptresponse.toString(),
            dataLocation + availabilityRequest.getMessageControlId() + SLASH
                    + availabilityRequest.getSliceId() + SLASH + FRAGMENT_ID,
            SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
  }

  private void uploadFiles(Map<String, File> appointmentDataFiles, JSONObject openApptOutput) {
    appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
            prepareOpenAppointmentFile(openApptOutput, availabilityRequest));
    fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
            availabilityRequest.getAppointmentType(),
            availabilityRequest.getSliceId() + SLASH + FRAGMENT_ID,
            appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
  }
  
  public void trackEventToNifi(EventTracker trackEvents, AvailabilityRequest availabilityRequest,
                               DataflowStatus dataflowStatus, String totalFragments, String fragmentId,
                               Map<String, Object> payload) {
    NifiTrackingEvent nifiEvent = NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
            .messageControlId(availabilityRequest.getMessageControlId())
            .appointmentType(availabilityRequest.getAppointmentType())
            .sliceId(availabilityRequest.getSliceId())
            .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
            .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices()).payload(payload)
            .entityType(availabilityRequest.getEntityType()).entityId(availabilityRequest.getEntityId())
            .flow(availabilityRequest.getFlow()).build();
    trackEvents.trackEventToNifi(nifiEvent);
  }

}
