package com.pes.integration.advancedmd.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.advancedmd.service.open.impl.OpenAppointmentServiceImpl;
import com.pes.integration.dto.EngineAppInfo;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.service.AvailabilityOperations;
import jakarta.validation.Valid;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import static com.pes.integration.constant.EpmConstant.MESSAGE_CONTROL_ID;
import static org.springframework.http.HttpStatus.OK;

@RestController
public class AvailabilityController implements AvailabilityOperations {
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;

    @Autowired
    private OpenAppointmentServiceImpl openAppointmentService;

    @Override
    public ResponseEntity<Object> getRealTimeData(@Valid RealTimeRequest realTimeRequest)
            throws JsonProcessingException {
        AvailabilityOperations.validateInput(realTimeRequest, new EngineAppInfo(engineName, appDescription));
        MDC.put(MESSAGE_CONTROL_ID, realTimeRequest.getMessageControlId());
        JSONObject openAppointments = openAppointmentService.getRealTimeAvailability(realTimeRequest);
        return new ResponseEntity<>(openAppointments.toString(), OK);
    }
}