package com.pes.integration.advancedmd.service.booked.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.task.PrepareBookedSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;

import static com.pes.integration.adapter.Utils.trackBookedFragmentError;
import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.ADVANCEDMD_CONFIG;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.String.format;
import static java.lang.Thread.currentThread;
import static java.util.Objects.nonNull;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static java.util.stream.Collectors.toList;

@Qualifier(BOOKED_APPOINTMENT)
@Slf4j
@Service
public class BookedAppointmentServiceImpl extends AppointmentService {

    private static final String REQUEST_RECEIVED = "Booked request has been received with input %s";
    private static final int TOTAL_BOOKED_CALLS = 1;
    private static final String ERROR_PROCESSING_DATA =
            "Error in processing the data for booked appointment slot, Details:- Start Date : %s, End date: %s with error %s";

    @Value("${application.data.path}")
    private String dataLocation;

    @Autowired
    private FileUploader fileUploader;

    @Autowired
    private EventTracker trackEvents;

    @Autowired
    AdvancedmdApiCaller advancedMdApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    ConfigCache configCache;

    @Autowired
    DataCacheManager dataCacheManager;

    @Value("${configuration.api.threadsize}")
    private String threadSize;

    @Override
    public JSONArray getAvailability(AvailabilityRequest availabilityRequest,
                                     Map<String, JSONArray> providerLocationMap,
                                     String epmPrefix) throws JsonProcessingException {
        String startDate = availabilityRequest.getStartDate();
        String endDate = availabilityRequest.getEndDate();
        fetchBookedAppointments(startDate, endDate, providerLocationMap, availabilityRequest, epmPrefix);
        return null;
    }

    @Override
    public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
        return null;
    }

    public void fetchBookedAppointments(String startDate,
                                        String endDate,
                                        Map<String, JSONArray> providerLocationMap,
                                        AvailabilityRequest availabilityRequest,
                                        String epmPrefix
    ) throws JsonProcessingException {
        try {
            startDate = convertDateFormat(startDate, DATE_FORMAT, AdvancedMDConstants.DATE_FORMAT);
            endDate = convertDateFormat(endDate, DATE_FORMAT, AdvancedMDConstants.DATE_FORMAT);
        } catch (ParseException e) {
            throw new EpmApiCallerException(e.getMessage());
        }

/*        JSONArray providerList = new JSONArray();
        String maxPoolSize;
        if (nonNull(availabilityRequest.getEntityId())) {
            providerList.put(availabilityRequest.getEntityId());
            maxPoolSize = String.valueOf(ONE);
        } else {
            if (providerList != null && providerList.length() > 0) {
                providerList = providerLocationMap.get(PROVIDER_ID_LIST);
            }
            String configuredPoolSize = getMaxPoolSize(availabilityRequest.getDeploymentId(), epmPrefix);
            maxPoolSize = !isEmpty(configuredPoolSize) ? configuredPoolSize : threadSize;
        }*/
        JSONObject inputObject = getInputObject(startDate, endDate, epmPrefix);
        if (availabilityRequest.getIndex().equals(String.valueOf(FIRST_INDEX))) {
            trackEvents.trackEvent(availabilityRequest, BOOKED_APPOINTMENT_PROCESSING_STARTED,
                    format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
                    getFragmentsDetails(availabilityRequest));
        }

        PrepareBookedSlotsTask prepareBookedSlotsTask = getPrepareBookedSlotsTask(availabilityRequest, inputObject);
        prepareBookedSlotsTask.get();

/*        ExecutorService executorService = newFixedThreadPool(parseInt(maxPoolSize));
        List<CompletableFuture<Void>> bookedApptFutureList = new ArrayList<>();
        try {
            if (NullChecker.isEmpty(providerList) || providerList.isEmpty()) {
                log.error("Provider list is empty");
                inputObject.put("provider", "");
                bookedApptFutureList.add(CompletableFuture.supplyAsync(new PrepareBookedSlotsTask(advancedMdApiCaller,
                        inputObject, fileUploader, trackEvents, availabilityRequest, handlerUtils, configCache, dataCacheManager), executorService));
            } else {
                providerList.forEach(provider -> {
                    inputObject.put("provider", provider.toString());
                    bookedApptFutureList.add(CompletableFuture.supplyAsync(new PrepareBookedSlotsTask(advancedMdApiCaller,
                            inputObject, fileUploader, trackEvents, availabilityRequest, handlerUtils, configCache, dataCacheManager), executorService));
                });
            }
            CompletableFuture<Void> bookedApptAllFutures = CompletableFuture
                    .allOf(bookedApptFutureList.toArray(new CompletableFuture[bookedApptFutureList.size()]));
            CompletableFuture<List<Void>> bookedApptAllCompletableFuture = bookedApptAllFutures.thenApply(
                    future -> bookedApptFutureList.stream().map(CompletableFuture::join).collect(toList()));
            CompletableFuture<List<Void>> bookedApptCompletableFuture = bookedApptAllCompletableFuture
                    .toCompletableFuture();

            bookedApptCompletableFuture.get();
        } catch (InvalidIdException e) {
            String message = format(ERROR_PROCESSING_DATA, startDate, endDate, e.getMessage());
            log.error(message);
            trackBookedFragmentError(availabilityRequest, trackEvents, message);
        } catch (EpmApiCallerException ee) {
            String message = "Error in getting the booked appointment slot " + ee.getMessage();
            log.error(message);
            trackBookedFragmentError(availabilityRequest, trackEvents, message);
        } catch (ExecutionException ee) {
            log.error("Error in getting the slotId " + ee);
            throw new EpmApiCallerException("Error in getting the slot " + ee.getMessage());
        } catch (InterruptedException ie) {
            log.error("Error in getting the slotId " + ie);
            currentThread().interrupt();
        } finally {
            executorService.shutdown();
        }*/
    }

   public PrepareBookedSlotsTask getPrepareBookedSlotsTask(AvailabilityRequest availabilityRequest, JSONObject inputObject) {
        return new PrepareBookedSlotsTask(advancedMdApiCaller,
                inputObject, fileUploader, trackEvents, availabilityRequest, handlerUtils, configCache, dataCacheManager);
    }

    private JSONObject getInputObject(String startDate, String endDate, String epmPrefix) {
        JSONObject inputParameter = new JSONObject();
        inputParameter.put(STARTDATE, startDate);
        inputParameter.put(ENDDATE, endDate);
        inputParameter.put(APPOINTMENT_PATH, "appointment/");
        inputParameter.put("epmPrefix", epmPrefix);
        return inputParameter;
    }

    private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest) {
        Map<String, Object> providerDetails = new HashMap<>();
        providerDetails.put(TOTAL_FRAGMENTS, 1);
        providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        MDC.put(TOTAL_FRAGMENTS, String.valueOf(1));
        return providerDetails;
    }

    private String getMaxPoolSize(String deploymentId, String epmPrefix) {
        try {
            return dataCacheManager.getConfiguration(epmPrefix, deploymentId, ADVANCEDMD_CONFIG, MAX_POOL_SIZE);
        } catch (IHubException e) {
            return null;
        }
    }
}