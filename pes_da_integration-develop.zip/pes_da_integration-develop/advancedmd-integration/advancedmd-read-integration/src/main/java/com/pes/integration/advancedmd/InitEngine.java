package com.pes.integration.advancedmd;

import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.KafkaService;
import com.pes.integration.service.RefreshBaseInitEngine;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class InitEngine implements RefreshBaseInitEngine {

  @Value("${kafka.sync.data.topic}")
  String syncTopicName;

  @Value("${kafka.config.group.id}")
  String groupId;

  @Autowired
  KafkaService kafkaService;

  @Autowired
  DataCacheManager cacheManager;

  @Autowired
  AdvancedmdInitEngine advancedmdInitEngine;

  @PostConstruct
  public void init() throws IHubException {
    advancedmdInitEngine.init();
    kafkaService.createTopicAndListener(cacheManager.getRedisConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX).toString(),
        syncTopicName, groupId);
  }
}