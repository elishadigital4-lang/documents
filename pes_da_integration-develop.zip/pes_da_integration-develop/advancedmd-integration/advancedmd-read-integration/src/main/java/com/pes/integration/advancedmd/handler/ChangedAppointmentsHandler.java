
package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.component.RedisService;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.EngineConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractE2DSyncHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.MessageControlIdGenerator;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;

import java.text.ParseException;
import java.util.Map;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service(value = "ChangedAppt")
public class ChangedAppointmentsHandler extends AbstractE2DSyncHandler {

    JSONObject requestObject;

    @Autowired
    RedisService redisService;
    @Autowired
    HandlerUtils handlerUtils;
    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    @Autowired
    ConfigCache configCache;
    @Autowired
    GetLocationsHandler getLocationsHandler;

    @Override
    protected JSONObject getChangedAppointments(JSONObject inputObject) throws IHubException {

        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        buildInput(inputObject);
        requestObject = advancedmdApiCaller.call(deploymentId,ApiName.CHANGED_APPOINTMENTS.getKey(), inputObject, "ChangeAppointment");
        requestObject.remove("temp");
        String currentDate = setSyncRunTime(deploymentId);
        log.info("current pull time "+ sanitizeForLog(inputObject.getString(DocASAPConstants.TempKey.LAST_PULLED)) + " next pull time: "+currentDate + " ::deploymentId:: "+deploymentId);
        return requestObject;
    }

    private String setSyncRunTime(String deploymentId) throws IHubException {
        String currentDate = "";
        try {
            String timezone = handlerUtils.getTimeZone(deploymentId);
            currentDate = DateUtils.getCurrentDate(AdvancedMDConstants.DATE_TIME_FORMAT_WITHOUT_AM_PM,
                    timezone, 0);
            redisService.save(deploymentId + EngineConstants.REDIS_CHANED_APPOINTMENT_KEY,
                    currentDate);
        } catch (Exception e) {
            log.info(e.getMessage());
            throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getMessage(), e.getMessage());
        }
        return currentDate;
    }

    @Override
    protected JSONArray buildE2DSyncObject(JSONArray appointmentsArray, JSONObject inputObject, String deploymentId) throws IHubException {

        log.info(deploymentId);
        JSONArray newAppointmentsArray = new JSONArray();
        for (int i = 0;i<appointmentsArray.length();i++) {
            JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
            Object appointmentStatus = JsonUtils.getValue(appointmentObject, DocASAPConstants.TempKey.APPOINTMENT_STATUS);
            String messageType = null;
            String noShowId = "";
            if(appointmentStatus.equals(AdvancedMDConstants.CODE_CANCELED))
            {
                messageType = HandlerType.CANCEL_APPOINTMENT.getKey();
            } else if (appointmentStatus.equals(AdvancedMDConstants.CODE_NEW))
            {
                messageType = HandlerType.NEW_APPOINTMENT.getKey();
            } else if(appointmentStatus.equals(AdvancedMDConstants.CODE_RESCHEDULED)){
                noShowId = (String)dataCacheManager.getStoredProvidersConfig(AdvancedMDEngineConstants.EPM_NAME_PREFIX, deploymentId, AdvancedMDEngineConstants.ADVANCEDMD_CONFIG, AdvancedMDConstants.CODE_NO_SHOW,false);
                Object status = JsonUtils.getValue(appointmentObject, "SchedulingData.Schedule[0].ApptStatus");
                if(!NullChecker.isEmpty(status) && status.toString().equals(noShowId)){
                    messageType = HandlerType.NO_SHOW_APPOINTMENT.getKey();
                } else messageType = HandlerType.RESCHEDULE_APPOINTMENT.getKey();
            }
            String startDateTime = formatStartDateTime(appointmentObject);
            JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START, startDateTime);
            setResourceId(appointmentObject,deploymentId);
            setApptLocationsId(appointmentObject,deploymentId);
            handlePhoneNumbersE2D(appointmentObject);
            formatDob(appointmentObject);
            JsonUtils.setValue(appointmentObject, DocASAPConstants.TempKey.TEMP, null);
            JsonUtils.setValue(appointmentObject, UtilitiesConstants.JsonConstants.MESSAGE_TYPE, messageType);
            String messageControlId = MessageControlIdGenerator.generateMessageControlId();
            JsonUtils.setValue(appointmentObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
            JsonUtils.setValue(appointmentObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, messageControlId);
            if (messageType != null)
            {newAppointmentsArray.put(appointmentObject);}
        }
        return newAppointmentsArray;
    }

    @Override
    protected JSONArray applyFilter(String deploymentId, JSONArray appointmentsArray) {
        return appointmentsArray;
    }

    @Override
    protected void postE2DSyncAction(JSONArray appointmentsArray,String deploymentId) {
        // this method is kept intentionally null.
        // We can ignore this vulnerability.
    }

    @Override
    protected boolean isNewOrg(String deploymentId) throws IHubException {
        return false;
    }

    @Override
    protected void updateIsNewOrgConfig(String deploymentId) throws IHubException {
        // this method is kept intentionally null.
        // We can ignore this vulnerability.
    }

    private void buildInput(JSONObject inputObject) throws IHubException{
        try{
            JSONObject mappingJson = HandlerUtils.getChangeApptRequestMappingJson();
            JsonUtils.setValue(inputObject, "temp", mappingJson);
        } catch (Exception e){
            log.error(e.getMessage());
        }
    }

    private String formatStartDateTime(JSONObject appointmentObject) {
        String dateTime = (String) JsonUtils.getValue(appointmentObject, DocASAPConstants.TempKey.START_DATE)+" "+(String) JsonUtils.getValue(appointmentObject, DocASAPConstants.TempKey.START_TIME);
        String startDateTime = null;
        try {
            startDateTime = DateUtils.convertDateFormat(dateTime, AdvancedMDConstants.TIME_FORMAT_REALTIME, DocASAPConstants.DATE_TIME_FORMAT);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return startDateTime;
    }

    private void setResourceId(JSONObject appointmentObject,String deploymentId) {
        try {
            boolean  isColWithProv = handlerUtils.isColWithProv(deploymentId,EPM_NAME_PREFIX); // do it

            JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.APPT_RESOURCE_ID, handlerUtils.getColumnId(JsonUtils.getValue(appointmentObject, "SchedulingData.Schedule[0].Columnheading").toString().trim(), deploymentId, isColWithProv));

            JsonUtils.setValue(appointmentObject,"SchedulingData.Schedule[0].Columnheading",null);
        } catch (Exception e) {
            log.error("Error in setting up ResourceId:: "+deploymentId);
        }
    }

    private void setApptLocationsId(JSONObject appointmentObject,String deploymentId) {
        try {
            JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.APPT_LOCATION_ID, getLocationId(JsonUtils.getValue(appointmentObject, "SchedulingData.Schedule[0].FacilityCode").toString().trim(), deploymentId));
            JsonUtils.setValue(appointmentObject,"SchedulingData.Schedule[0].FacilityCode",null);
        } catch (Exception e) {
            log.error("Error in setting up LocationId:: "+deploymentId);
        }
    }

    private void handlePhoneNumbersE2D(JSONObject appointmentObject) {
        try {
            PhoneNumberUtils.handlePhoneNumbersE2D(appointmentObject);
        } catch (Exception e) {

            log.error("Error in phone no handling "+e.getMessage());
        }
    }

    private void formatDob(JSONObject appointmentObject) {
        String dob = null;
        try {
            Object dobObj = JsonUtils.getValue(appointmentObject, DocASAPConstants.Key.DOB);
            log.info("dobObj:: "+dobObj);
            if (!NullChecker.isEmpty(dobObj)) {
                dob = (String) dobObj;
                dob = DateUtils.convertDateFormat(dob, AdvancedMDConstants.DATE_TIME_FORMAT, DocASAPConstants.DOCASAP_DATE_FORMAT);
                JsonUtils.setValue(appointmentObject, DocASAPConstants.Key.DOB, dob);
            }
        } catch (Exception e) {
            log.info("DOB received was invalid or null: " + dob);
            log.error(e.getMessage());
        }
    }

    public String getLocationId(String code, String deploymentId) throws IHubException{
        Map<String, String> locationMap =  configCache.getLocationMap(deploymentId);
        if (locationMap == null || locationMap.isEmpty()) {
            setLocation(deploymentId);
            locationMap = configCache.getLocationMap(deploymentId);
        }
        return locationMap.get(code);
    }

    private void setLocation(String deploymentId) throws IHubException{
        JSONObject outputObject = new JSONObject();
        JSONObject inputObject = new JSONObject();
        JsonUtils.setValue(inputObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
        getLocationsHandler.doExecute(inputObject);
        outputObject.clear();
    }
}
