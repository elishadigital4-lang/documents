package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants;
import com.pes.integration.component.RedisService;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.EngineConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractE2DSyncPatientHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.MessageControlIdGenerator;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service(value = "ChangedPatient")
public class ChangedPatientsHandler extends AbstractE2DSyncPatientHandler {


    JSONObject requestObject;

    @Autowired
    RedisService redisService;
    @Autowired
    HandlerUtils handlerUtils;
    @Autowired
    AdvancedmdApiCaller advancedmdApiCaller;

    @Override
    protected JSONObject getChangedPatients(JSONObject inputObject) throws IHubException {

        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        log.info(deploymentId);
        String lastPatientSyncDate = handlerUtils.getSyncRunTime(deploymentId+ EngineConstants.REDIS_CHANED_PATIENT_KEY);
        JsonUtils.setValue(inputObject, DocASAPConstants.TempKey.LAST_PULLED, lastPatientSyncDate);
        requestObject = advancedmdApiCaller.call(deploymentId, ApiName.CHANGED_PATIENTS.getKey(), inputObject, "ChangedPatients");
        String currentDate = setSyncRunTime(deploymentId);
        log.info("current pull time "+ lastPatientSyncDate + " next pull time: "+ currentDate + " ::deploymentId:: "+deploymentId);
        return requestObject;
    }

    private String setSyncRunTime(String deploymentId) throws IHubException {
        String currentDate = "";
        try {
            String timezone = handlerUtils.getTimeZone(deploymentId);
            currentDate = DateUtils.getCurrentDate(AdvancedMDConstants.DATE_TIME_FORMAT_WITHOUT_AM_PM,
                    timezone, 0);
            redisService.save(deploymentId + EngineConstants.REDIS_CHANED_PATIENT_KEY,
                    currentDate);
        } catch (Exception e) {
            log.info(e.getMessage());
            throw  new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getMessage(), e.getMessage());
        }
        return currentDate;
    }

    @Override
    protected JSONArray buildE2DSyncObject(JSONArray appointmentsArray, String deploymentId) throws IHubException {
        log.info(deploymentId);
        JSONArray newPatientsArray = new JSONArray();
        for (int i = 0; i < appointmentsArray.length(); i++) {
            JSONObject inputJson = new JSONObject();
            JSONObject outputJson;
            JSONObject patientObject = appointmentsArray.getJSONObject(i);

            String patientId = (String)JsonUtils.getValue(patientObject, DocASAPConstants.Key.PATIENT_ID);
            Object patientStatus = JsonUtils.getValue(patientObject, "temp.patient_status");
            JsonUtils.setValue(inputJson, DocASAPConstants.Key.PATIENT_ID, patientId);
            outputJson=advancedmdApiCaller.call(deploymentId,ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputJson, "GetPatientDemographics");
            setFullName(outputJson);
            String messageType = null;

            if (patientStatus.equals(AdvancedMDConstants.CODE_NEW))				{
                messageType = HandlerType.NEW_PATIENT.getKey();
            } else if(patientStatus.equals(AdvancedMDConstants.CODE_RESCHEDULED)){

                String inactive = (String)JsonUtils.getValue(outputJson, AdvancedMDEngineConstants.INACTIVE);
                String deceased = (String)JsonUtils.getValue(outputJson, AdvancedMDEngineConstants.DECEASED);

                if(!NullChecker.isEmpty(inactive) || !NullChecker.isEmpty(deceased)){
                    log.info(patientId+" patient is inactive ");
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.PRIOR_PATIENT_ID, patientId);
                    JsonUtils.setValue(patientObject, DocASAPConstants.Key.PATIENT_ID, "");
                    messageType = HandlerType.MERGE_PATIENTS.getKey();
                } else messageType = HandlerType.UPDATE_PATIENT.getKey();
            }
            formatDob(outputJson);
            JsonUtils.copyKey("DemographicData", outputJson, patientObject);
            JsonUtils.setValue(patientObject, DocASAPConstants.TempKey.TEMP, null);
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.MESSAGE_TYPE, messageType);

            String messageControlId = MessageControlIdGenerator.generateMessageControlId();
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, messageControlId);
            if (messageType != null) {newPatientsArray.put(patientObject);}
        }
        return newPatientsArray;

    }

    private void formatDob(JSONObject outputJson) throws IHubException {
        try {
            String dob = (String) JsonUtils.getValue(outputJson, DocASAPConstants.Key.DOB);
            dob = DateUtils.convertDateFormat(dob, AdvancedMDConstants.DOB_DATE_FORMAT, DocASAPConstants.DOCASAP_DATE_FORMAT);
            JsonUtils.setValue(outputJson, DocASAPConstants.Key.DOB, dob);
        } catch (IHubException e) {
            log.error(e.getMessage());
            throw e;
        } catch (Exception e) {
            log.info("DOB received was invalid or null.");
            log.error(e.getMessage());
        }
    }

    @Override
    protected JSONArray applyFilter(JSONArray appointmentsArray) {
        return appointmentsArray;
    }

    @Override
    protected void postE2DSyncAction(JSONArray appointmentsArray) {
        // this method is kept intentionally null.
        // We can ignore this vulnerability.
    }

    @Override
    protected boolean isNewOrg() throws IHubException {
        return false;
    }

    @Override
    protected void updateIsNewOrgConfig() throws IHubException {
        // this method is kept intentionally null.
        // We can ignore this vulnerability.
    }

    private void setFullName(JSONObject outputJson) {
        try {
            String name = (String)JsonUtils.getValue(outputJson, AdvancedMDEngineConstants.FNAME);
            JsonUtils.setValue(outputJson, AdvancedMDEngineConstants.FNAME, name.substring(name.indexOf(',')+1));
            JsonUtils.setValue(outputJson, AdvancedMDEngineConstants.LNAME, name.substring(0,name.indexOf(',')));
            Object exPatientId = JsonUtils.getValue(outputJson, DocASAPConstants.Key.PATIENT_ID);
            HandlerUtils.setExternalPatientId(outputJson,exPatientId);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }
}
