//=====================================================================
// GetProvidersHandler.java
// Copyright � 2016, DocASAP
// All Rights Reserved
//=====================================================================

package com.pes.integration.advancedmd.handler;

import java.util.HashMap;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.api.ApiName;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;


@Slf4j
@Service
public class GetLocationsHandler extends BaseHandler {
	
	@Autowired
	AdvancedmdApiCaller advancedmdApiCaller;

	@Autowired
	HandlerUtils handlerUtils;

	JSONObject requestObject;

	@Autowired
	ConfigCache configCache;

	@Override
	public JSONObject doExecute(JSONObject inputObject) throws IHubException {
		{
			String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
			try {

				requestObject = advancedmdApiCaller.call(deploymentId,ApiName.GET_LOCATIONS.getKey(), inputObject, "GetLocations");
			} catch (Exception e) {
				log.error(e.getMessage());
				throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getMessage(), e.getMessage());
			}
			HashMap<String, String> locationsMap = new HashMap<>();
			JSONArray locationsArray = ((JSONObject) requestObject).getJSONArray("Locations");
			if (locationsArray != null) {
				for (Object location : locationsArray) {
					try {
						JSONObject locationsObject = (JSONObject)location;
						String locationId = (String) JsonUtils.getValue(locationsObject, "LocationId");
						String locationCode = (String)JsonUtils.getValue(locationsObject, "Code");
						if (!NullChecker.isEmpty(locationId) && !NullChecker.isEmpty(locationCode)) {
							locationsMap.put(locationCode, locationId);
						}
					} catch (Exception e) {
						log.error(e.getMessage());
						throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getMessage(), e.getMessage());
					}
				}
			}
			configCache.setLocationMap(deploymentId, locationsMap);
			return requestObject;
		}
	}
}
