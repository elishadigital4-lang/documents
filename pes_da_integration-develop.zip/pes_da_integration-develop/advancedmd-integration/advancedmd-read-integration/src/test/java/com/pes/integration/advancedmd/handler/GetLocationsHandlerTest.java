package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

class GetLocationsHandlerTest {

    @InjectMocks
    GetLocationsHandler getLocationsHandler;

    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    HandlerUtils handlerUtils;

    @Mock
    ConfigCache configCache;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void doExecuteValid() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {

            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("testDeploymentId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("deploymentId", "testDeploymentId");

            JSONObject responseObject = new JSONObject();
            JSONArray locationsArray = new JSONArray();
            JSONObject location = new JSONObject();
            location.put("LocationId", "123");
            location.put("Code", "LOC123");
            locationsArray.put(location);
            responseObject.put("Locations", locationsArray);

            when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(responseObject);

            JSONObject result = getLocationsHandler.doExecute(inputObject);

            assertNotNull(result);
            assertEquals(responseObject, result);
        }
    }

    @Test
    public void doExecute_throwsException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deploymentId", "testDeploymentId");

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("testDeploymentId");
            when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString()))
                    .thenThrow(new RuntimeException("API error"));

            try {
                getLocationsHandler.doExecute(inputObject);
            } catch (IHubException e) {
                assertEquals("API error", e.getMessage());
                assertEquals(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getStatusCode());
            }
        }
    }

    @Test
    public void doExecute_locationParsingThrowsException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deploymentId", "testDeploymentId");

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("testDeploymentId");

            JSONObject responseObject = new JSONObject();
            JSONArray locationsArray = new JSONArray();
            JSONObject location = new JSONObject();
            location.put("LocationId", "123");
            location.put("Code", "LOC123");
            locationsArray.put(location);
            responseObject.put("Locations", locationsArray);

            when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(responseObject);

            // Simulate exception when parsing location
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq("LocationId")))
                    .thenThrow(new RuntimeException("Location parsing error"));

            try {
                getLocationsHandler.doExecute(inputObject);
            } catch (IHubException e) {
                assertEquals("Location parsing error", e.getMessage());
                assertEquals(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, e.getStatusCode());
            }
        }
    }

}