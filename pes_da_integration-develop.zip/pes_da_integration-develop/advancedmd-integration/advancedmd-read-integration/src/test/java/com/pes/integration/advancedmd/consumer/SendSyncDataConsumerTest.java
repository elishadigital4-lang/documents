package com.pes.integration.advancedmd.consumer;

import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SendSyncDataConsumerTest {

    @InjectMocks
    @Spy
    SendSyncDataConsumer sendSyncDataConsumer;


    @Mock
    SyncDataConsumerService syncDataConsumerService;

    @Test
    void consumeSendSyncDataMessage() {
        doNothing().when(syncDataConsumerService).processSendSyncData("Test Message");
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Assertions.assertDoesNotThrow(() -> sendSyncDataConsumer.consumeSendSyncDataMessage("Test Message"));
            verify(syncDataConsumerService, times(1)).processSendSyncData(anyString());
        }

    }

    @Test
    void consumeSendSyncDataMessage_exception() {
        doThrow(new RuntimeException("Test error")).when(syncDataConsumerService).processSendSyncData("Test Message");
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Assertions.assertDoesNotThrow(() -> sendSyncDataConsumer.consumeSendSyncDataMessage("Test Message"));
            verify(syncDataConsumerService, times(1)).processSendSyncData(anyString());
        }

    }

    @Test
    void listen() {
        doNothing().when(syncDataConsumerService).processSendSyncData("Test Message");
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Assertions.assertDoesNotThrow(() -> sendSyncDataConsumer.listen("tst-topic", "Test Message"));
            verify(syncDataConsumerService, times(1)).processSendSyncData(anyString());
        }

    }

    @Test
    void listen_message_empty() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Assertions.assertDoesNotThrow(() -> sendSyncDataConsumer.listen("tst-topic", ""));
            verify(syncDataConsumerService, times(0)).processSendSyncData(anyString());
        }

    }

    @Test
    void listen_exception() {
        doThrow(new RuntimeException("Test error")).when(syncDataConsumerService).processSendSyncData("Test Message");
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Assertions.assertDoesNotThrow(() -> sendSyncDataConsumer.listen("tst-topic", "Test Message"));
            verify(syncDataConsumerService, times(1)).processSendSyncData(anyString());
        }

    }
}