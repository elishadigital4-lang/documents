package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.component.RedisService;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

class ChangedPatientsHandlerTest {

    @InjectMocks
    ChangedPatientsHandler changedPatientsHandler;

    @Mock
    HandlerUtils handlerUtils;
    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;
    @Mock
    RedisService redisService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void getChangedPatientsValid() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {

            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn(AdvancedMDConstants.CODE_RESCHEDULED);
            JSONObject inputObject = new JSONObject();
            inputObject.put("deploymentId", "testDeploymentId");

            when(handlerUtils.getSyncRunTime(anyString())).thenReturn("2023-01-01T00:00:00");
            when(handlerUtils.getTimeZone(anyString())).thenReturn("UTC");
            when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(new JSONObject().put("key", "value"));
            doNothing().when(redisService).save(anyString(), anyString());

            JSONObject result = changedPatientsHandler.getChangedPatients(inputObject);

            assertNotNull(result);
            assertEquals("value", result.getString("key"));
        }
    }

    @Test
    public void setSyncRunTime_throwsException() throws Exception {
        Method setSyncRunTime = getMethod("setSyncRunTime", String.class);
        when(handlerUtils.getTimeZone(anyString())).thenThrow(new RuntimeException("Timezone error"));
        try {
            setSyncRunTime.invoke(changedPatientsHandler, "ID");
            fail("Expected IHubException to be thrown");
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            assertTrue(cause instanceof IHubException);
            assertEquals("Timezone error", cause.getMessage());
            assertEquals(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, ((IHubException) cause).getStatusCode());
        }
    }

    @Test
    public void setSyncRunTime() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
            String currentDate = LocalDate.now().toString();
            mockedHandlerUtils.when(() -> DateUtils.getCurrentDate(any(), any(),
                    anyInt())).thenReturn(currentDate);
            TimeZone timeZone = Calendar.getInstance().getTimeZone();
            String string = timeZone.toString();
            when(handlerUtils.getTimeZone("ID")).thenReturn(string);
            doNothing().when(redisService).save(any(), any());
            Method setSyncRunTime = getMethod("setSyncRunTime", String.class);
            String date = (String) setSyncRunTime.invoke(changedPatientsHandler, "ID");

            Assertions.assertEquals(currentDate, date);
            verify(handlerUtils, times(1)).getTimeZone("ID");
            verify(redisService, times(1)).save(any(), any());

        }
    }

    @Test
    public void buildE2DSyncObjectValid_CODE_NEW() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn(AdvancedMDConstants.CODE_NEW);
                JSONArray appointmentsArray = new JSONArray();
                JSONObject patientObject = new JSONObject();
                patientObject.put("temp.patient_status", AdvancedMDConstants.CODE_NEW);
                patientObject.put("DemographicData", new JSONObject().put("key", "value"));
                appointmentsArray.put(patientObject);

                String deploymentId = "testDeploymentId";

                JSONObject inputJson = new JSONObject();
                inputJson.put(DocASAPConstants.Key.PATIENT_ID, "12345");

                JSONObject outputJson = new JSONObject();
                outputJson.put(DocASAPConstants.Key.DOB, "2023-01-01T00:00:00");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(outputJson);

                JSONArray result = changedPatientsHandler.buildE2DSyncObject(appointmentsArray, deploymentId);

                assertNotNull(result);
                assertEquals(1, result.length());
                assertEquals(AdvancedMDConstants.CODE_NEW, result.getJSONObject(0).getString("temp.patient_status"));
            }
        }
    }

    @Test
    public void buildE2DSyncObjectValid_CODE_RESCHEDULED() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn(AdvancedMDConstants.CODE_RESCHEDULED);
                JSONArray appointmentsArray = new JSONArray();
                JSONObject patientObject = new JSONObject();
                patientObject.put("temp.patient_status", AdvancedMDConstants.CODE_RESCHEDULED);
                patientObject.put("DemographicData", new JSONObject().put("key", "value"));
                appointmentsArray.put(patientObject);

                String deploymentId = "testDeploymentId";

                JSONObject inputJson = new JSONObject();
                inputJson.put(DocASAPConstants.Key.PATIENT_ID, "12345");

                JSONObject outputJson = new JSONObject();
                outputJson.put(DocASAPConstants.Key.DOB, "2023-01-01T00:00:00");

                when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(outputJson);

                JSONArray result = changedPatientsHandler.buildE2DSyncObject(appointmentsArray, deploymentId);

                assertNotNull(result);
                assertEquals(1, result.length());
                assertEquals(AdvancedMDConstants.CODE_RESCHEDULED, result.getJSONObject(0).getString("temp.patient_status"));
            }
        }
    }

    @Test
    void formatDob() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("2023-01-01T00:00:00");
                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                JSONObject inputObject = new JSONObject();
                Method formatDob = getMethod("formatDob", JSONObject.class);
                Assertions.assertDoesNotThrow(() -> formatDob.invoke(changedPatientsHandler, inputObject));
            }
        }

    }

    @Test
    void formatDob_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("2023-01-01T00:00:00");
                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenThrow(new ParseException("test", 1));
                JSONObject inputObject = new JSONObject();
                Method formatDob = getMethod("formatDob", JSONObject.class);
                Assertions.assertDoesNotThrow(() -> formatDob.invoke(changedPatientsHandler, inputObject));
            }
        }

    }


    @Test
    public void applyFilter() {
        JSONArray inputObject = new JSONArray();
        JSONArray result = changedPatientsHandler.applyFilter( inputObject);
        assertEquals(inputObject, result);
    }

    @Test
    public void postE2DSyncAction() {
        JSONArray inputObject = new JSONArray();
        assertDoesNotThrow(() -> changedPatientsHandler.postE2DSyncAction(inputObject));
    }

    @Test
    public void updateIsNewOrgConfig() {
        assertDoesNotThrow(() -> changedPatientsHandler.updateIsNewOrgConfig());
    }

    @Test
    public void isNewOrg() throws IHubException {
        Assertions.assertFalse(changedPatientsHandler.isNewOrg());
    }
    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = ChangedPatientsHandler.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }
}