package com.pes.integration.advancedmd.handler;

import com.pes.integration.advancedmd.api.AdvancedmdApiCaller;
import com.pes.integration.advancedmd.component.HandlerUtils;
import com.pes.integration.advancedmd.config.ConfigCache;
import com.pes.integration.advancedmd.constant.AdvancedMDConstants;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.PhoneNumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Map;
import java.util.TimeZone;

import static com.pes.integration.advancedmd.constant.AdvancedMDEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ChangedAppointmentsHandlerTest {

    @InjectMocks
    ChangedAppointmentsHandler changedAppointmentsHandler;


    @Mock
    RedisService redisService;
    @Mock
    HandlerUtils handlerUtils;
    @Mock
    AdvancedmdApiCaller advancedmdApiCaller;

    @Mock
    ConfigCache configCache;
    @Mock
    GetLocationsHandler getLocationsHandler;
    @Mock
    public DataCacheManager dataCacheManager;


    @Test
    public void buildE2DSyncObjectValid_CODE_CANCELED() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn(AdvancedMDConstants.CODE_CANCELED);
                JSONArray appointmentsArray = new JSONArray();
                JSONObject appointmentObject = new JSONObject();
                appointmentObject.put("temp.appointment_status", AdvancedMDConstants.CODE_CANCELED);
                appointmentObject.put("temp.start_date", "2023-01-01");
                appointmentObject.put("temp.start_time", "10:00 AM");
                appointmentsArray.put(appointmentObject);

                JSONObject inputObject = new JSONObject();
                String deploymentId = "testDeploymentId";

                when(handlerUtils.isColWithProv(anyString(), anyString())).thenReturn(true);
                when(handlerUtils.getColumnId(anyString(), anyString(), anyBoolean())).thenReturn("resourceId");

                JSONArray result = changedAppointmentsHandler.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);

                assertNotNull(result);
                assertEquals(1, result.length());
                System.out.println(result);
                assertEquals(AdvancedMDConstants.CODE_CANCELED, result.getJSONObject(0).getString("temp.appointment_status"));
            }
        }
    }

    @Test
    void buildInput_exception() throws Exception {
        try (MockedStatic<HandlerUtils> mockedHandlerUtils = mockStatic(HandlerUtils.class)) {
            mockedHandlerUtils.when(HandlerUtils::getChangeApptRequestMappingJson)
                    .thenThrow(new RuntimeException("Test Exception"));
            JSONObject inputObject = new JSONObject();
            Method buildInput = ChangedAppointmentsHandler.class.getDeclaredMethod("buildInput", JSONObject.class);
            buildInput.setAccessible(true);
            assertDoesNotThrow(() -> buildInput.invoke(changedAppointmentsHandler, inputObject));
        }
    }

    @Test
    public void buildE2DSyncObjectValid_CODE_NEW() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn(AdvancedMDConstants.CODE_NEW);
                JSONArray appointmentsArray = new JSONArray();
                JSONObject appointmentObject = new JSONObject();
                appointmentObject.put("temp.appointment_status", AdvancedMDConstants.CODE_NEW);
                appointmentObject.put("temp.start_date", "2023-01-01");
                appointmentObject.put("temp.start_time", "10:00 AM");
                appointmentsArray.put(appointmentObject);

                JSONObject inputObject = new JSONObject();
                String deploymentId = "testDeploymentId";

                when(handlerUtils.isColWithProv(anyString(), anyString())).thenReturn(true);
                when(handlerUtils.getColumnId(anyString(), anyString(), anyBoolean())).thenReturn("resourceId");

                JSONArray result = changedAppointmentsHandler.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);

                assertNotNull(result);
                assertEquals(1, result.length());
                System.out.println(result);
                assertEquals(AdvancedMDConstants.CODE_NEW, result.getJSONObject(0).getString("temp.appointment_status"));
            }
        }
    }

    @Test
    public void buildE2DSyncObjectValid_CODE_RESCHEDULED() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {

                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn(AdvancedMDConstants.CODE_RESCHEDULED);
                JSONArray appointmentsArray = new JSONArray();
                JSONObject appointmentObject = new JSONObject();
                appointmentObject.put("temp.appointment_status", AdvancedMDConstants.CODE_RESCHEDULED);
                appointmentObject.put("temp.start_date", "2023-01-01");
                appointmentObject.put("temp.start_time", "10:00 AM");
                appointmentsArray.put(appointmentObject);

                JSONObject inputObject = new JSONObject();
                String deploymentId = "testDeploymentId";

                when(handlerUtils.isColWithProv(anyString(), anyString())).thenReturn(true);
                when(handlerUtils.getColumnId(anyString(), anyString(), anyBoolean())).thenReturn("resourceId");
                when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("rescheduledId");
                JSONArray result = changedAppointmentsHandler.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);

                assertNotNull(result);
                assertEquals(1, result.length());
                System.out.println(result);
                assertEquals(AdvancedMDConstants.CODE_RESCHEDULED, result.getJSONObject(0).getString("temp.appointment_status"));
            }
        }
    }

    @Test
    void getChangedAppointmentsValid() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put("temp.last_pulled", "2023-01-01T00:00:00");
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        when(handlerUtils.getTimeZone(anyString())).thenReturn("UTC");
        when(advancedmdApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(new JSONObject().put("key", "value"));

        JSONObject result = changedAppointmentsHandler.getChangedAppointments(inputObject);

        assertNotNull(result);
        assertEquals("value", result.getString("key"));
    }

    @Test
    public void setSyncRunTime() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        TimeZone timeZone = Calendar.getInstance().getTimeZone();
        String string = timeZone.toString();
        when(handlerUtils.getTimeZone("ID")).thenReturn(string);
        doNothing().when(redisService).save(any(), any());
        Method setSyncRunTime = getMethod("setSyncRunTime", String.class);
        String date = (String) setSyncRunTime.invoke(changedAppointmentsHandler, "ID");

        Assertions.assertNotNull(date);
        verify(handlerUtils, times(1)).getTimeZone("ID");
        verify(redisService, times(1)).save(any(), any());
    }

    @Test
    public void setSyncRunTime_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        when(handlerUtils.getTimeZone("ID")).thenThrow(new RuntimeException("test"));
        Method setSyncRunTime = getMethod("setSyncRunTime", String.class);
        InvocationTargetException invocationTargetException = assertThrows(InvocationTargetException.class, () -> setSyncRunTime.invoke(changedAppointmentsHandler, "ID"));
        Assertions.assertTrue(invocationTargetException.getCause() instanceof Exception);

    }

    @Test
    public void applyFilter() {
        JSONArray inputObject = new JSONArray();
        JSONArray result = changedAppointmentsHandler.applyFilter("ID", inputObject);
        assertEquals(inputObject, result);
    }

    @Test
    public void postE2DSyncAction() {
        JSONArray inputObject = new JSONArray();
        assertDoesNotThrow(() -> changedAppointmentsHandler.postE2DSyncAction(inputObject, "ID"));
    }

    @Test
    public void updateIsNewOrgConfig() {
        assertDoesNotThrow(() -> changedAppointmentsHandler.updateIsNewOrgConfig("ID"));
    }

    @Test
    public void isNewOrg() throws IHubException {
        Assertions.assertFalse(changedAppointmentsHandler.isNewOrg("ID"));
    }

    @Test
    void buildInputValid() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject inputObject = new JSONObject();
        JSONObject mappingJson = new JSONObject().put("key", "value");

        Method buildInput = getMethod("buildInput", JSONObject.class);
        buildInput.invoke(changedAppointmentsHandler, inputObject);


        assertNotNull(inputObject.get("temp"));
    }

    @Test
    void formatStartDateTime() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("2023-01-01T00:00:00");
                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(), any())).thenReturn("2023-01-01T00:00:00");
                JSONObject inputObject = new JSONObject();

                Method formatStartDateTime = getMethod("formatStartDateTime", JSONObject.class);
                String dateStartTime = String.valueOf(formatStartDateTime.invoke(changedAppointmentsHandler, inputObject));

                assertEquals("2023-01-01T00:00:00", dateStartTime);
            }
        }
    }

    @Test
    void formatStartDateTime_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("2023-01-01T00:00:00");
                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(), any())).thenThrow(new ParseException("test", 1));
                JSONObject inputObject = new JSONObject();

                Method formatStartDateTime = getMethod("formatStartDateTime", JSONObject.class);
                String dateStartTime = String.valueOf(formatStartDateTime.invoke(changedAppointmentsHandler, inputObject));

                assertEquals("null", dateStartTime);
            }
        }
    }

    @Test
    void setResourceId() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("TEST VALUE");
            JSONObject inputObject = new JSONObject();
            when(handlerUtils.isColWithProv("ID", EPM_NAME_PREFIX)).thenReturn(true);
            when(handlerUtils.getColumnId(any(), any(), anyBoolean())).thenReturn("12345");
            Method formatStartDateTime = getMethod("setResourceId", JSONObject.class, String.class);
            Assertions.assertDoesNotThrow(() -> formatStartDateTime.invoke(changedAppointmentsHandler, inputObject, "ID"));

        }

    }

    @Test
    void setResourceId_setResourceId_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("TEST VALUE");
            JSONObject inputObject = new JSONObject();
            when(handlerUtils.isColWithProv("ID", EPM_NAME_PREFIX)).thenReturn(true);
            when(handlerUtils.getColumnId(any(), any(), anyBoolean())).thenThrow(new RuntimeException("12345"));
            Method formatStartDateTime = getMethod("setResourceId", JSONObject.class, String.class);
            Assertions.assertDoesNotThrow(() -> formatStartDateTime.invoke(changedAppointmentsHandler, inputObject, "ID"));

        }

    }

    @Test
    void setApptLocationsId() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("TEST VALUE");
            JSONObject inputObject = new JSONObject();
            Method setApptLocationsId = getMethod("setApptLocationsId", JSONObject.class, String.class);
            Assertions.assertDoesNotThrow(() -> setApptLocationsId.invoke(changedAppointmentsHandler, inputObject, "ID"));

        }

    }

    @Test
    void setApptLocationsId_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenThrow(new RuntimeException("Test"));
            JSONObject inputObject = new JSONObject();
            Method setApptLocationsId = getMethod("setApptLocationsId", JSONObject.class, String.class);
            Assertions.assertDoesNotThrow(() -> setApptLocationsId.invoke(changedAppointmentsHandler, inputObject, "ID"));

        }

    }

    @Test
    void handlePhoneNumbersE2D() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        try (MockedStatic<PhoneNumberUtils> mockedJsonUtils = mockStatic(PhoneNumberUtils.class)) {
            mockedJsonUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any()));
            JSONObject inputObject = new JSONObject();
            Method handlePhoneNumbersE2D = getMethod("handlePhoneNumbersE2D", JSONObject.class);
            Assertions.assertDoesNotThrow(() -> handlePhoneNumbersE2D.invoke(changedAppointmentsHandler, inputObject));

        }

    }


    @Test
    void handlePhoneNumbersE2D_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {

        try (MockedStatic<PhoneNumberUtils> mockedJsonUtils = mockStatic(PhoneNumberUtils.class)) {
            mockedJsonUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any())).thenThrow(new RuntimeException("Test"));
            JSONObject inputObject = new JSONObject();
            Method handlePhoneNumbersE2D = getMethod("handlePhoneNumbersE2D", JSONObject.class);
            Assertions.assertDoesNotThrow(() -> handlePhoneNumbersE2D.invoke(changedAppointmentsHandler, inputObject));

        }

    }

    @Test
    void formatDob() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("2023-01-01T00:00:00");
                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenReturn("2023-01-01T00:00:00");
                JSONObject inputObject = new JSONObject();
                Method formatDob = getMethod("formatDob", JSONObject.class);
                Assertions.assertDoesNotThrow(() -> formatDob.invoke(changedAppointmentsHandler, inputObject));
            }
        }

    }

    @Test
    void formatDob_exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString())).thenReturn("2023-01-01T00:00:00");
                mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), any(),
                        any())).thenThrow(new ParseException("test", 1));
                JSONObject inputObject = new JSONObject();
                Method formatDob = getMethod("formatDob", JSONObject.class);
                Assertions.assertDoesNotThrow(() -> formatDob.invoke(changedAppointmentsHandler, inputObject));
            }
        }

    }

    @Test
    void getLocationId() throws IHubException {
        when(configCache.getLocationMap("12345")).thenReturn(Map.of("code", "value1234"));
        String code = changedAppointmentsHandler.getLocationId("code", "12345");
        assertEquals("value1234", code);
    }

    @Test
    void getLocationId_empty_locationMap() throws IHubException {
        when(configCache.getLocationMap("12345")).thenReturn(Map.of());
        when(getLocationsHandler.doExecute(any())).thenReturn(new JSONObject().put("code", "value1234"));
        String code = changedAppointmentsHandler.getLocationId("code", "12345");
        assertNull(code);
    }

    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = ChangedAppointmentsHandler.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

}