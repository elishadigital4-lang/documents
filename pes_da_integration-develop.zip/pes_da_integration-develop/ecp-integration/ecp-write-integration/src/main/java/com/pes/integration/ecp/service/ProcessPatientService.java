package com.pes.integration.ecp.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.ecp.dto.BaseResponse;
import com.pes.integration.ecp.handler.UpdatePatientHandler;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.*;

@Slf4j
@Service
public class ProcessPatientService{
    @Autowired
    @Qualifier("UpdatePatient")
    UpdatePatientHandler updatePatientHandler;

    @Autowired
    DataTransactionService dataTransactionService;


    public JSONObject updatePatient(JSONObject input) throws IHubException {
        JSONObject response;
        try {
            response = updatePatientHandler.doExecute(input);
        } catch (IHubException e) {
            log.error("Error in processing the update patient ECP request {} ", e.getMessage());
            JSONObject error=new JSONObject();
            error.put("Flow","ECP");
            error.put("error",e.getMessage());
            dataTransactionService.logData(error, UPDATE_PATIENT.getKey(), FAILED.getKey(),
                    "ECP Update Patient Failed");
            throw e;
        }
        dataTransactionService.logData(response, UPDATE_PATIENT.getKey(), SUCCESS.getKey(),
                "ECP Update Patient Successful");
        log.info("ECP Update Patient Successful");
        return response;
    }

    public BaseResponse prepareSuccessResponseObject(String response) {
        BaseResponse responseObj = new BaseResponse();
        responseObj.setResponseType("Success-Response");//epm-response  ,
        responseObj.setMethod("API");
        responseObj.setResponseCode("200");
        responseObj.setData(response);
        responseObj.setSuccess(true);
        responseObj.setMessage("ECP Update Successful");
        return responseObj;
    }

    public BaseResponse prepareErrorResponseObject(String error, String code) {
        BaseResponse responseObj = new BaseResponse();
        responseObj.setResponseType("Error-Response");//epm-response  ,
        responseObj.setMethod("API");
        responseObj.setResponseCode(code);
        responseObj.setData(error);
        responseObj.setSuccess(false);
        responseObj.setMessage("ECP Update Failed");
        return responseObj;
    }

}