package com.pes.integration.ecp.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.ecp.service.ProcessPatientService;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.service.IHubDataServiceDelegator;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import static com.pes.integration.constant.DocASAPConstants.Key.DA_APPOINTMENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.EXTN_APPT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.ecp.constant.ECPEngineConstants.ECP_CONFIG;
import static com.pes.integration.ecp.constant.ECPEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.*;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.getValueOrDefault;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.slf4j.MDC.put;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@RestController("ECPUpdatePatientController")
public class ECPUpdatePatientController {
    @Autowired
    DataCacheManager cacheManager;
    @Autowired
    ProcessPatientService processPatientService;
    @Autowired
    IHubDataServiceDelegator iHubDataServiceDelegator;
    @Autowired
    RedisService redisService;
    @Autowired
    DataTransactionService dataTransactionService;
    @Value("${spring.profiles.active}")
    String activeProfileName;


    @PostMapping(value = "/updatePatientEcp", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
     public ResponseEntity<Object> updatePatient(@RequestBody String requestBody) throws JsonProcessingException, IHubException {
        JSONObject openAppointments = null;
        String ecpConfigKey;
        JSONObject response;
        JSONObject requestObject = new JSONObject(requestBody);
        log.info("ECP Update Patient Request Received");
        JSONObject dataObject = requestObject.getJSONObject(DATA);
        JSONArray appointmentSyncArray = dataObject.getJSONArray(APPOINTMENT_SYNC);
        JSONObject appointmentObject = appointmentSyncArray.getJSONObject(0);
        putMDCValues(appointmentObject);
        dataTransactionService.logData(requestObject, UPDATE_PATIENT.getKey(), IN_PROGRESS.getKey(),
                "ECP Update Patient Request Received");
        String deploymentId = getValue(appointmentObject, DEPLOYMENT_ID).toString();
        if (!activeProfileName.equals("prod")){
            ecpConfigKey = deploymentId+"_"+EPM_NAME_PREFIX+"_"+activeProfileName;
        }else{
            ecpConfigKey = deploymentId+"_"+EPM_NAME_PREFIX;
        }

        String ecpConfig = redisService.get(ecpConfigKey);
        try {
            if (isNull(ecpConfig)) {
                ecpConfig = iHubDataServiceDelegator.getIHubDataConfig(deploymentId, ECP_CONFIG);
                redisService.save(ecpConfigKey, ecpConfig);
            }
            response = processPatientService.updatePatient(requestObject);
        }catch(Exception e){
            log.info("Error while processing ECP request with message {}",e.getMessage());
            String code="500";
            if(e.getMessage().toString().contains("\"status\":400")){
                code ="400";
            }
            return ResponseEntity.status(HttpStatus.OK).body(processPatientService.prepareErrorResponseObject(e.getMessage(),code));
        }
        log.info("Sending ECP Update Patient Response");
        return ResponseEntity.status(HttpStatus.OK).body(processPatientService.prepareSuccessResponseObject(response.toString()));
    }

    public void putMDCValues(JSONObject appointmentObject) {
        put(MESSAGE_CONTROL_ID, appointmentObject.optString(MESSAGE_CONTROL_ID));
        put(DEPLOYMENT_ID, appointmentObject.optString(DEPLOYMENT_ID));
        put(MESSAGE_TYPE, appointmentObject.optString(MESSAGE_TYPE));
        put("DAPatientId", getValueOrDefault(appointmentObject, DA_PATIENT_ID, EMPTY).toString());
        put("ExternalPatientId", getValueOrDefault(appointmentObject, EXT_PATIENT_ID, EMPTY).toString());
        put("DAApptId", getValueOrDefault(appointmentObject, DA_APPOINTMENT_ID, EMPTY).toString());
        put("ExternalApptId", getValueOrDefault(appointmentObject, EXTN_APPT_ID, EMPTY).toString());
    }
}
