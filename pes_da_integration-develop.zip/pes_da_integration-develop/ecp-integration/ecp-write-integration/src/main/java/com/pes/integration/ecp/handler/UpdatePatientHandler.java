package com.pes.integration.ecp.handler;

import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.constant.ValidationConstants;
import com.pes.integration.ecp.api.ApiName;
import com.pes.integration.ecp.api.ECPApiCaller;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.utils.NullChecker;
import io.micrometer.observation.annotation.Observed;
import io.opentelemetry.api.trace.StatusCode;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.IN_PROGRESS;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;

@Slf4j
@Service(value = "UpdatePatient")
public class UpdatePatientHandler{

    @Autowired
    ECPApiCaller ecpApiCaller;

    @Autowired
    protected DataTransactionService dataTransactionService;

    @Observed(name = "integration.UpdatePatient.doExecute", contextualName = "integration")
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        JSONObject responseObject;
        try {
            validateExternalPatientId(inputObject);
            JSONObject apptSync=inputObject.getJSONObject(UtilitiesConstants.JsonConstants.DATA).getJSONArray(APPOINTMENT_SYNC)
                            .getJSONObject(0);
            String deploymentId = getValue(apptSync, DEPLOYMENT_ID).toString();
            dataTransactionService.logData(new JSONObject(), UPDATE_PATIENT.getKey(),
                    IN_PROGRESS.getKey(), "Processing ECP Request");
            log.info("Processing ECP Request");
            responseObject = ecpApiCaller.callECP(deploymentId, ApiName.UPDATE_PATIENT.getKey(), inputObject,
                    UPDATE_PATIENT.getKey());

        } catch (Exception e1) {
            throw e1;
        }
        log.info("ECP Response has generated");
        return responseObject;
    }

    public void validateExternalPatientId(JSONObject inputObject) throws IHubException {
        JSONObject patient = (JSONObject) inputObject.optJSONObject("data").optJSONArray("appointment_sync")
                .optJSONObject(0).getJSONObject("DemographicData")
                .getJSONArray("PatientInformation").get(0);
        validateRequiredField(patient, ValidationConstants.EXTERNAL_PATIENT_ID);
    }

    private void validateRequiredField(JSONObject data, String key) throws IHubException {
        if (!data.has(key) || (data.has(key) && (JSONObject.NULL.equals( data.get(key)) || NullChecker.isEmpty((String) data.get(key))))) {
            throw new IHubException(DATA_VALIDATION_ERROR.getErrorCode(), "{\"status\":400, \"message\": \"ExternalPatientId should not be empty\"}");
        }
    }
}
