package com.pes.integration.ecp.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.ecp.service.ProcessPatientService;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.service.IHubDataServiceDelegator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.ecp.constant.ECPEngineConstants.EPM_NAME_PREFIX;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.OK;

@ExtendWith(MockitoExtension.class)
public class ECPUpdatePatientControllerTest {

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private ProcessPatientService processPatientService;

    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;

    @Mock
    private RedisService redisService;

    @Mock
    private DataTransactionService dataTransactionService;

    @InjectMocks
    private ECPUpdatePatientController ecpUpdatePatientController;

    private String requestBody;

    @BeforeEach
    void setUp() {
        requestBody = "{ \"data\": { \"appointment_sync\": [ { \"deployment_id\": \"123\" } ] } }";
    }

    @Test
    void updatePatientReturnsOkWhenSuccessful() throws JsonProcessingException, IHubException {
        when(redisService.get(anyString())).thenReturn("ecpConfig");
        when(processPatientService.updatePatient(any(JSONObject.class))).thenReturn(new JSONObject());
        ReflectionTestUtils.setField(ecpUpdatePatientController, "activeProfileName", "staging");

        ResponseEntity<Object> response = ecpUpdatePatientController.updatePatient(requestBody);

        assertEquals(OK, response.getStatusCode());
    }

    @Test
    void updatePatientReturnsInternalServerErrorWhenExceptionOccurs() throws JsonProcessingException, IHubException {
        when(redisService.get(anyString())).thenReturn(null);
        when(iHubDataServiceDelegator.getIHubDataConfig(anyString(), anyString())).thenThrow(new RuntimeException("Error"));
        ReflectionTestUtils.setField(ecpUpdatePatientController, "activeProfileName", "staging");

        ResponseEntity<Object> response = ecpUpdatePatientController.updatePatient(requestBody);

        assertEquals(OK, response.getStatusCode());
    }

    @Test
    void updatePatientCachesConfigWhenNotInCache() throws JsonProcessingException, IHubException {
        when(redisService.get(anyString())).thenReturn(null);
        when(iHubDataServiceDelegator.getIHubDataConfig(anyString(), anyString())).thenReturn("ecpConfig");
        when(processPatientService.updatePatient(any(JSONObject.class))).thenReturn(new JSONObject());
        ReflectionTestUtils.setField(ecpUpdatePatientController, "activeProfileName", "staging");

        ecpUpdatePatientController.updatePatient(requestBody);

        verify(redisService).save(anyString(), eq("ecpConfig"));
    }

    @Test
    void updatePatientDoesNotCacheConfigWhenAlreadyInCache() throws JsonProcessingException, IHubException {
        when(redisService.get(anyString())).thenReturn("ecpConfig");
        when(processPatientService.updatePatient(any(JSONObject.class))).thenReturn(new JSONObject());
        ReflectionTestUtils.setField(ecpUpdatePatientController, "activeProfileName", "staging");

        ecpUpdatePatientController.updatePatient(requestBody);

        verify(redisService, never()).save(anyString(), anyString());
    }

    @Test
    void updatePatientHandlesExceptionAndReturnsErrorResponse() throws JsonProcessingException, IHubException {
        when(redisService.get(anyString())).thenReturn(null);
        when(iHubDataServiceDelegator.getIHubDataConfig(anyString(), anyString()))
                .thenThrow(new RuntimeException("{\"status\":400, \"message\":\"Bad Request\"}"));
        ReflectionTestUtils.setField(ecpUpdatePatientController, "activeProfileName", "staging");

        ResponseEntity<Object> response = ecpUpdatePatientController.updatePatient(requestBody);

        assertEquals(OK, response.getStatusCode());
        verify(processPatientService).prepareErrorResponseObject(contains("\"status\":400"), eq("400"));
    }

    @Test
    void putMDCValuesSetsCorrectValues() {
        JSONObject appointmentObject = new JSONObject();
        JSONObject schedulingData = new JSONObject();
        JSONArray scheduleArray = new JSONArray();
        JSONObject scheduleObject = new JSONObject();
        appointmentObject.put("message_control_id", "123");
        appointmentObject.put("deployment_id", "456");
        appointmentObject.put("message_type", "type");
        appointmentObject.put("DAPatientId", "789");
        appointmentObject.put("ExternalPatientId", "101112");
        scheduleObject.put("DAApptId", "131415");
        scheduleArray.put(scheduleObject);
        schedulingData.put("Schedule", scheduleArray);
        appointmentObject.put("SchedulingData", schedulingData);
//        appointmentObject.put("SchedulingData.Schedule[0].DAApptId", "131415");
        appointmentObject.put("externalApptId", "161718");

        ecpUpdatePatientController.putMDCValues(appointmentObject);

        assertEquals("123", MDC.get("message_control_id"));
        assertEquals("456", MDC.get("deployment_id"));
        assertEquals("type", MDC.get("message_type"));
        assertEquals("789", MDC.get("DAPatientId"));
        assertEquals("101112", MDC.get("ExternalPatientId"));
        assertEquals("131415", MDC.get("DAApptId"));
        assertEquals("161718", MDC.get("ExternalApptId"));
    }

    @Test
    void putMDCValuesHandlesMissingOptionalValues() {
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("message_control_id", "123");
        appointmentObject.put("deployment_id", "456");
        appointmentObject.put("message_type", "type");

        ecpUpdatePatientController.putMDCValues(appointmentObject);

        assertEquals("123", MDC.get("message_control_id"));
        assertEquals("456", MDC.get("deployment_id"));
        assertEquals("type", MDC.get("message_type"));
        assertEquals("", MDC.get("DAPatientId"));
        assertEquals("", MDC.get("ExternalPatientId"));
        assertEquals("", MDC.get("DAApptId"));
        assertEquals("", MDC.get("ExternalApptId"));
    }

    @Test
    void updatePatientConstructsEcpConfigKeyForProdProfile() throws JsonProcessingException, IHubException {
        // Arrange
        String deploymentId = "123";
        String activeProfile = "prod";
        String expectedEcpConfigKey = deploymentId + "_" + EPM_NAME_PREFIX;
        ReflectionTestUtils.setField(ecpUpdatePatientController, "activeProfileName", activeProfile);

        JSONObject requestObject = new JSONObject(requestBody);
        JSONObject dataObject = requestObject.getJSONObject(DATA);
        JSONArray appointmentSyncArray = dataObject.getJSONArray(APPOINTMENT_SYNC);
        JSONObject appointmentObject = appointmentSyncArray.getJSONObject(0);
        appointmentObject.put(DEPLOYMENT_ID, deploymentId);

        when(redisService.get(anyString())).thenReturn(null);
        when(iHubDataServiceDelegator.getIHubDataConfig(anyString(), anyString())).thenReturn("ecpConfig");
        when(processPatientService.updatePatient(any(JSONObject.class))).thenReturn(new JSONObject());

        // Act
        ecpUpdatePatientController.updatePatient(requestBody);

        // Assert
        verify(redisService).get(eq(expectedEcpConfigKey));
    }
}