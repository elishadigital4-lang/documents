package com.pes.integration.ecp.handler;

import com.pes.integration.ecp.api.ECPApiCaller;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static com.pes.integration.TestUtils.TestUtils.getData;
import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.IN_PROGRESS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UpdatePatientHandlerTest {

    @Mock
    private ECPApiCaller ecpApiCaller;

    @Mock
    private DataTransactionService dataTransactionService;

    @InjectMocks
    private UpdatePatientHandler updatePatientHandler;

    private JSONObject inputObject;

    @BeforeEach
    void setUp() {
        inputObject = getData("getPatientDemographics.json");
    }

    @Test
    void doExecuteReturnsResponseObjectWhenSuccessful() throws IHubException {
        JSONObject expectedResponse = new JSONObject("{ \"response\": \"success\" }");
        when(ecpApiCaller.callECP(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        JSONObject response = updatePatientHandler.doExecute(inputObject);

        assertEquals(expectedResponse, response);
    }

    @Test
    void doExecuteThrowsExceptionWhenECPApiCallerFails() throws IHubException {
        when(ecpApiCaller.callECP(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("ECP API call failed"));

        assertThrows(RuntimeException.class, () -> updatePatientHandler.doExecute(inputObject));
    }

    @Test
    void doExecuteLogsDataWhenCalled() throws IHubException {
        JSONObject expectedResponse = new JSONObject("{ \"response\": \"success\" }");

        when(ecpApiCaller.callECP(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        updatePatientHandler.doExecute(inputObject);
        assertNotNull(dataTransactionService);
        verify(dataTransactionService).logData(any(JSONObject.class), eq(UPDATE_PATIENT.getKey()), eq(IN_PROGRESS.getKey()), eq("Processing ECP Request"));
    }

    @Test
    void doExecuteHandlesMissingDeploymentIdGracefully() {
        JSONObject inputObjectWithoutDeploymentId = new JSONObject("{ \"data\": { \"appointment_sync\": [ { } ] } }");

        assertThrows(Exception.class, () -> updatePatientHandler.doExecute(inputObjectWithoutDeploymentId));
    }

    @Test
    void validateRequiredFieldThrowsExceptionWhenFieldIsMissingOrEmpty() throws Exception {
        // Arrange
        UpdatePatientHandler updatePatientHandler = new UpdatePatientHandler();
        JSONObject data = new JSONObject();
        data.put("someKey", "someValue"); // Missing the required key

        // Access the private method using Reflection
        Method validateRequiredFieldMethod = UpdatePatientHandler.class.getDeclaredMethod("validateRequiredField", JSONObject.class, String.class);
        validateRequiredFieldMethod.setAccessible(true);

        // Act & Assert
        Throwable thrown = assertThrows(InvocationTargetException.class, () -> {
            validateRequiredFieldMethod.invoke(updatePatientHandler, data, "missingKey");
        });

        assertTrue(thrown.getCause() instanceof IHubException);
        IHubException actualException = (IHubException) thrown.getCause();
        assertEquals("{\"status\":400, \"message\": \"ExternalPatientId should not be empty\"}", actualException.getMessage());
    }
}