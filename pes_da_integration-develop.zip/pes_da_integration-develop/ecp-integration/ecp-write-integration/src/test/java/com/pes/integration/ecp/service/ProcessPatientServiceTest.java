package com.pes.integration.ecp.service;

import com.pes.integration.ecp.dto.BaseResponse;
import com.pes.integration.ecp.handler.UpdatePatientHandler;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Qualifier;

import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.FAILED;
import static com.pes.integration.enums.FlowStatus.SUCCESS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class ProcessPatientServiceTest {
    @Mock
    protected DataTransactionService dataTransactionService;
    @Mock
    @Qualifier("UpdatePatient")
    UpdatePatientHandler updatePatientHandler;
    @InjectMocks
    private ProcessPatientService processPatientService;

    @Test
    void updatePatientLogsDataWhenCalled() throws IHubException {
        JSONObject input = new JSONObject("{ \"data\": { \"appointment_sync\": [ { \"deployment_id\": \"123\" } ] } }");
        JSONObject expectedResponse = new JSONObject("{ \"response\": \"success\" }");

        when(updatePatientHandler.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        processPatientService.updatePatient(input);

//        verify(dataTransactionService).logData(eq(input), eq(UPDATE_PATIENT.getKey()), eq(CREATED.getKey()), eq("iHub Update Patient Request Message"));
        verify(dataTransactionService).logData(eq(expectedResponse), eq(UPDATE_PATIENT.getKey()), eq(SUCCESS.getKey()), eq("ECP Update Patient Successful"));
    }

//    @Test
//    void updatePatientLogsDataWhenCalled() throws IHubException {
//        JSONObject expectedResponse = new JSONObject("{ \"response\": \"success\" }");
//
//        when(updatePatientHandler.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);
//
//        processPatientService.updatePatient(input);
//
//        verify(dataTransactionService).logData(eq(expectedResponse), eq(UPDATE_PATIENT.getKey()), eq(SUCCESS.getKey()), eq("ECP Update Patient Successful"));
//    }

    @Test
    void updatePatientReturnsResponseWhenSuccessful() throws IHubException {
        JSONObject input = new JSONObject("{ \"data\": { \"appointment_sync\": [ { \"deployment_id\": \"123\" } ] } }");
        JSONObject expectedResponse = new JSONObject("{ \"response\": \"success\" }");

        when(updatePatientHandler.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        JSONObject response = processPatientService.updatePatient(input);

        assertEquals(expectedResponse, response);
    }

    @Test
    void updatePatientThrowsExceptionWhenHandlerFails() throws IHubException {
        JSONObject input = new JSONObject("{ \"data\": { \"appointment_sync\": [ { \"deployment_id\": \"123\" } ] } }");

        when(updatePatientHandler.doExecute(any(JSONObject.class))).thenThrow(new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, "Handler error", "Error in processing the update patient ECP request"));

        assertThrows(IHubException.class, () -> processPatientService.updatePatient(input));

        verify(dataTransactionService).logData(any(JSONObject.class), eq(UPDATE_PATIENT.getKey()), eq(FAILED.getKey()), eq("ECP Update Patient Failed"));
    }


    @Test
    void updatePatientLogsFailureWhenExceptionOccurs() throws IHubException {
        JSONObject input = new JSONObject("{ \"data\": { \"appointment_sync\": [ { \"deployment_id\": \"123\" } ] } }");

        when(updatePatientHandler.doExecute(any(JSONObject.class))).thenThrow(new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, "Handler error", "Error while processing update patient ECP request"));
        try {
            processPatientService.updatePatient(input);
        } catch (IHubException e) {
            // Expected exception
        }

        verify(dataTransactionService).logData(any(JSONObject.class), eq(UPDATE_PATIENT.getKey()), eq(FAILED.getKey()), eq("ECP Update Patient Failed"));
    }


    @Test
    void prepareSuccessResponseObjectReturnsCorrectResponse() {
        String response = "Success response";
        BaseResponse baseResponse = processPatientService.prepareSuccessResponseObject(response);

        assertTrue(baseResponse.isSuccess());
        assertEquals("200", baseResponse.getResponseCode());
        assertEquals("ECP Update Successful", baseResponse.getMessage());
        assertEquals(response, baseResponse.getData());
    }

    @Test
    void prepareErrorResponseObjectReturnsCorrectResponse() {
        String error = "Error response";
        String code = "500";
        BaseResponse baseResponse = processPatientService.prepareErrorResponseObject(error, code);

        assertFalse(baseResponse.isSuccess());
        assertEquals(code, baseResponse.getResponseCode());
        assertEquals("ECP Update Failed", baseResponse.getMessage());
        assertEquals(error, baseResponse.getData());
    }

    @Test
    void prepareSuccessResponseObjectReturnsSuccessResponse() {
        String response = "Success response";
        BaseResponse baseResponse = processPatientService.prepareSuccessResponseObject(response);

        assertTrue(baseResponse.isSuccess());
        assertEquals("200", baseResponse.getResponseCode());
        assertEquals("ECP Update Successful", baseResponse.getMessage());
        assertEquals(response, baseResponse.getData());
    }

    @Test
    void prepareErrorResponseObjectReturnsErrorResponse() {
        String error = "Error response";
        String code = "500";
        BaseResponse baseResponse = processPatientService.prepareErrorResponseObject(error, code);

        assertFalse(baseResponse.isSuccess());
        assertEquals(code, baseResponse.getResponseCode());
        assertEquals("ECP Update Failed", baseResponse.getMessage());
        assertEquals(error, baseResponse.getData());
    }

    @Test
    void prepareSuccessResponseObjectHandlesEmptyResponse() {
        String response = "";
        BaseResponse baseResponse = processPatientService.prepareSuccessResponseObject(response);

        assertTrue(baseResponse.isSuccess());
        assertEquals("200", baseResponse.getResponseCode());
        assertEquals("ECP Update Successful", baseResponse.getMessage());
        assertEquals(response, baseResponse.getData());
    }

    @Test
    void prepareErrorResponseObjectHandlesEmptyError() {
        String error = "";
        String code = "500";
        BaseResponse baseResponse = processPatientService.prepareErrorResponseObject(error, code);

        assertFalse(baseResponse.isSuccess());
        assertEquals(code, baseResponse.getResponseCode());
        assertEquals("ECP Update Failed", baseResponse.getMessage());
        assertEquals(error, baseResponse.getData());
    }

    @Test
    void prepareErrorResponseObjectHandlesNullError() {
        String error = null;
        String code = "500";
        BaseResponse baseResponse = processPatientService.prepareErrorResponseObject(error, code);

        assertFalse(baseResponse.isSuccess());
        assertEquals(code, baseResponse.getResponseCode());
        assertEquals("ECP Update Failed", baseResponse.getMessage());
        assertNull(baseResponse.getData());
    }
}
