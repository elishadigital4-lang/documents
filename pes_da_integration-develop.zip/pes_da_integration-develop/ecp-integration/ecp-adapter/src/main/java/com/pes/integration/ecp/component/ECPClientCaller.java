package com.pes.integration.ecp.component;

import com.pes.integration.ecp.dto.Token;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

import static com.pes.integration.ecp.constant.ECPConstants.*;
import static com.pes.integration.ecp.constant.ECPEngineConstants.END_POINT;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.MetricsUtil.metricClientErrorCount;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.BodyInserters.fromFormData;

@Slf4j
@Component
public class ECPClientCaller {

    @Autowired
    WebClient webClient;

    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;


    public Token generateToken(String url, HttpHeaders headers, MultiValueMap<String, String> formValues) {
        return webClient.post()
                .uri(url)
                .accept(APPLICATION_JSON)
                .headers(h -> h.addAll(headers))
                .body(fromFormData(formValues))
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error("Error status code while calling ecp token api is Status code:: {} and errorBody:: {}", clientResponse.statusCode(), errorBody);
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(), errorBody));
                        }))
                .bodyToMono(Token.class)
                .doOnError(ex ->{
                    log.error("Error while calling ecp token api with Error message:: {} ", ex.getMessage());})
                .doOnSuccess(response -> log.info("Successfully fetched token for ecp"))
                .block();
    }

    public String getData(String httpMethod, String url, String body, String token) {
        return webClient.method(HttpMethod.valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .headers(header -> header.setBearerAuth(token))
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> {
                    // Extract the response body
                    return clientResponse.bodyToMono(String.class)
                            .switchIfEmpty(Mono.just("")).map(errorBody -> errorBody == null ? "" : errorBody)
                            .flatMap(errorBody -> {
                                if (errorBody == null || errorBody.trim().isEmpty()) {
                                    // Construct JSON response with statusCode and statusMessage
                                    String jsonResponse = String.format("{\"statusCode\": \"%s\", \"statusMessage\": \"\"}",
                                            clientResponse.statusCode().value());
                                    log.error("Error body is empty. Sending JSON response: {}", jsonResponse);
                                    return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(), jsonResponse));
                                } else {
                                    log.error("Error body: {}", errorBody);
                                    metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                                    return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(), clientResponse.statusCode(), errorBody));
                                }
                            });
                })
                .bodyToMono(String.class)
                .doOnError(ex -> log.error("Error while calling ecp api with  Error message:: {} ", ex.getMessage()))
                .doOnSuccess(response -> log.info("Successfully fetched data for ecp Api for url {} ", sanitizeForLog(url)))
                .block();
    }
}