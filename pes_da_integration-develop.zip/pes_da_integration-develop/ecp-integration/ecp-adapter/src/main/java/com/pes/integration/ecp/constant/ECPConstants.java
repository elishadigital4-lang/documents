package com.pes.integration.ecp.constant;

public class ECPConstants {

    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DATE_TIME_FORMAT_AM_PM = "MM/dd/yyyy hh:mm:ss a";
    public static final String TIME_FORMAT = "HH:mm:ss";
    public static final String TIME_FORMAT_REALTIME = "MM/dd/yyyy hh:mma";
    public static final String TIME_FORMAT_AM_PM = "hh:mm a";
    public static final String DATE_TIME_FORMAT_WITHOUT_AM_PM = "MM/dd/yyyy HH:mm:ss";
    public static final String DOB_DATE_FORMAT = "MM/dd/yyyy";
    public static final String APPT_INPUT_DATE = "yyyymmddHHmm";
    public static final String APPT_INPUT_TIME = "HHmm";
    public static final String DATE_TIME_FORMAT_CHANGED_APP = "YYYY-MM-dd HH:mm:ss";
    public static final String ECP_DOB_DATE_FORMAT = "YYYY-MM-dd";

    public static final String USR_ID = "ecp_token_usrid";
    public static final String USR_PSWD = "ecp_token_pswrd";
    public static final String CLIENT_ID = "ecp_client_id";
    public static final String CLIENT_SECRET = "ecp_client_secret";
    public static final String SCOPE = "ecp_token_scope";
    public static final String GRANT_TYPE = "ecp_grant_type";
    public static final String TOKEN_END_POINT = "ecp_token_url";
    public static final String TOKEN_URL = "ecp_token_url";
    public static final String ECP_URL = "ecp_update_url";
    public static final String BASE_URL = "https://api.ecp.com";


    public static final String NEXT = "next";
    public static final String ID = "Id";
    public static final String TIME = "Time";
    public static final String START_TIME = "startTime";

    public static final String DEFAULT_CANCEL_REASON = "defcanreason";
    public static final String APPT_REASON = "ApptReason";
    public static final String ALLOW_MULTIPLE_PATIENT = "allow_mul_pat";
    public static final String ALLOW_DUPLICATE_PATIENT = "allow_dup_pat";


    // appointment status codes

    public static final String TIME_ZONE = "timezone";
    public static final Object ONE = "1";
    public static final String GRANT_TYPE_STR = "grant_type";
    public static final String CLIENT_CREDENTIALS = "client_credentials";
    public static final String SCOPE_STR = "scope";
    public static final String CLIENT_ID_STR = "client_id";
    public static final String CLIENT_SECRET_STR = "client_secret";
    public static final String USR_ID_STR = "username";
    public static final String USR_PSWD_STR = "password";
    public static final String MALE = "male";
    public static final String FEMALE = "female";
    public static final String GENDER_M = "M";
    public static final String GENDER_F = "F";

    public static final String LOCATION_ENTITY = "location";

    public static final String PROVIDER_ENTITY = "provider";
    public static final String PROVIDER_OR_LOCATION = "is_prov_filter";
    public static final String NOOFPROVIDERPERAPIALL = "prov_loc_batch_size";
    public static final String ECP_STARTDATE = "start_date";
    public static final String ECP_ENDDATE = "end_date";
    public static final String ECP_PROVIDERIDS = "provider_ids";
    public static final String GETOPENAPPOINTMENTSBYPROVIDER = "open_appointments_prov";
    public static final String GETOPENAPPOINTMENTSBYLOCATION = "open_appointments_loc";
    public static final String ECP_LOCATIONIDS = "location_ids";
    public static final String ECP_REQUEST_MAPPING = "ecp_req_map";
    public static final String ECP_RESPONSE_MAPPING = "ecp_res_map";
    public static final String ECP_REQUEST_CONFIG = "ecp_req_conf";


    private ECPConstants() {
    }

}

