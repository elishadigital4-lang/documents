package com.pes.integration.ecp.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BaseResponse {
    private boolean success;
    private String responseCode;
    private String responseType;
    private String message;
    private String method;
    private String data;
}