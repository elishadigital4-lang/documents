package com.pes.integration.ecp.api;

import static java.util.Arrays.stream;

public enum ApiName {
    UPDATE_PATIENT("update_patient");

    String key;

    ApiName(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public ApiName getEnum(String apiName) {
        return stream(values()).filter(api -> api.getKey().equals(apiName)).findFirst().orElse(null);
    }
}
