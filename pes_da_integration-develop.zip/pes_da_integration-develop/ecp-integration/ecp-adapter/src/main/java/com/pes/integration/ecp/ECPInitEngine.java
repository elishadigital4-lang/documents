package com.pes.integration.ecp;

import com.pes.integration.service.RefreshBaseInitEngine;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.ecp.constant.ECPConstants.*;
import static com.pes.integration.ecp.constant.ECPEngineConstants.*;

@Slf4j
@Component
public class ECPInitEngine implements RefreshBaseInitEngine {

    /**
     * This method is used to initialize the ECP Engine.
     */
    @PostConstruct
    public void init() {
        // not used at the moment
    }
}