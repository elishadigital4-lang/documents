package com.pes.integration.ecp.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.ecp.component.ECPClientCaller;
import com.pes.integration.ecp.dto.Token;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import static com.pes.integration.constant.DocASAPConstants.Key.DEPLOYMENT_ID;
import static com.pes.integration.constant.EngineConstants.METHOD;
import static com.pes.integration.ecp.constant.ECPConstants.*;
import static com.pes.integration.ecp.constant.ECPEngineConstants.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_REQUEST;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;


@Slf4j
@Service
public class ECPApiCaller extends BaseApiCaller {

    private static final String ECP_TOKEN = "ecp_token_";
    @Autowired
    ECPClientCaller ecpClientCaller;

    @Autowired
    DataCacheManager cacheManager;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    RedisService redisService;
    @Value("${spring.profiles.active}")
    String activeProfileName;

    private String deploymentId;
    private String tokenUrl;

    private String grantType;

    private String clientId;

    private String clientSecret;

    private String scope;


    private String contextUrl;

    public void initializeObject(String deploymentId) throws IHubException {
        this.deploymentId = deploymentId;

        String ecpConfigKey;
        if (!activeProfileName.equals("prod")){
            ecpConfigKey = deploymentId+"_"+EPM_NAME_PREFIX+"_"+activeProfileName;
        }else{
            ecpConfigKey = deploymentId+"_"+EPM_NAME_PREFIX;
        }
        String configs = (String) cacheManager.getRedisCacheData(ecpConfigKey);

        JSONObject storedConfigRedis =  new JSONObject(configs);

        requestConfig = (JSONObject) storedConfigRedis.getJSONObject(ECP_CONFIG).get(REQUEST_CONFIG_KEY_NAME);//add update_patient
        requestMapping = (JSONObject) storedConfigRedis.getJSONObject(ECP_CONFIG).get(REQUEST_MAPPING_KEY_NAME);
        responseMapping = (JSONObject) storedConfigRedis.getJSONObject(ECP_CONFIG).get(RESPONSE_MAPPING_KEY_NAME);

        clientId = (String) storedConfigRedis.getJSONObject(ECP_CONFIG).get(CLIENT_ID);
        clientSecret = (String) storedConfigRedis.getJSONObject(ECP_CONFIG).get(CLIENT_SECRET);
        scope = (String) storedConfigRedis.getJSONObject(ECP_CONFIG).get(SCOPE);
        grantType = (String) storedConfigRedis.getJSONObject(ECP_CONFIG).get(GRANT_TYPE);
        tokenUrl = (String) storedConfigRedis.getJSONObject(ECP_CONFIG).get(TOKEN_URL);
        contextUrl = (String) storedConfigRedis.getJSONObject(ECP_CONFIG).get(ECP_URL);
    }

    @Override
    protected Object callApi(JSONObject apiConfig, JSONObject requestObject) throws IHubException {
        log.info("Call Client API.");
        requestObject.remove(DEPLOYMENT_ID);
        String method = "POST";
        Object responseObject = null;
        try {
            String response = ecpClientCaller.getData(method, contextUrl, requestObject.toString(), getToken(deploymentId));
            if(!isEmpty(response)){
                log.info("Received valid response");
                Object json = new JSONTokener(response).nextValue();
                if (json instanceof JSONArray) {
                    responseObject = new JSONArray(json.toString());
                } else {
                    responseObject = new JSONObject(json.toString());
                }
            } else {
                log.info("Received empty/null response");
            }
        } catch (Exception e) {
            String errorMessage = "Error occurred while calling client api - " + contextUrl + " with error message " + e.getMessage();
            log.error(sanitizeForLog(errorMessage));
            throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE,errorMessage,"Error while processing update patient ECP request");
        }
        return responseObject;
    }

    @Override
    public void getMappingConfig(String deploymentId) throws IHubException {
        initializeObject(deploymentId);
    }

    @Override
    protected JSONObject customizeResponseMapping(JSONObject apiResponseMapping, String apiName, Object inputObject) {
        return null;
    }

    private String getToken(String deploymentId) throws IHubException {
        String token;
        if (!activeProfileName.equals("prod")){
            token = redisService.get(ECP_TOKEN +deploymentId+"_"+activeProfileName);
        }else{
            token = redisService.get(ECP_TOKEN +deploymentId);
        }
        if (StringUtils.isEmpty(token)) {
            return generateToken();
        }
        return token;
    }

    /*
     * Generate the token and update redis with ttl
     */
    protected String generateToken(){
        HttpHeaders headers = getHttpHeaders();
        Token token = ecpClientCaller.generateToken(tokenUrl, headers, formValues());
        if (!activeProfileName.equals("prod")){
            redisService.saveWithTtl(ECP_TOKEN +deploymentId+"_"+activeProfileName, token.getAccessToken(), parseInt(token.getExpiresIn()));
        }else{
            redisService.saveWithTtl(ECP_TOKEN +deploymentId, token.getAccessToken(), parseInt(token.getExpiresIn()));
        }
        return token.getAccessToken();
    }

    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        return headers;
    }

    private MultiValueMap<String, String> formValues() {
        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        formValues.add("grant_type", grantType);
        formValues.add("client_id", clientId);
        formValues.add("client_secret", clientSecret);
        formValues.add("scope", scope);
        return formValues;
    }
}