package com.pes.integration.ecp.constant;

public class ECPEngineConstants {
    public static final String EPM_NAME_PREFIX = "ECP";
    public static final String ECP_CONFIG = "ecpprop";
    public static final String BLANK = "";
    public static final String RETRY_COUNT = "retrycount";
    public static final String URL = "url";
    public static final String METHOD = "method";
    public static final String CLASS = "@class";
    public static final String NAME = "Name";
    public static final String REQUEST_MAPPING_KEY_NAME = "ecp_req_map";

    public static final String RESPONSE_MAPPING_KEY_NAME = "ecp_res_map";
    public static final String REQUEST_CONFIG_KEY_NAME = "ecp_req_conf";
    public static final String RESPONSE_CODES_MAPPING_KEY_NAME = "ecp_res_codes";
    public static final String END_POINT = "ecp_base_url";
    public static final String EPM_TYPE = "ecp";
    public static final String EPM_CONFIG_GROUPS = "RunBaselineSync,Epic Properties,Filter Service Config";

    public static final String COLUMN_ID = "SchedulingData.Provider[0].ColumnId";
    public static final String APPT_EPISODE_ID = "SchedulingData.Provider[0].EpisodeId";
    public static final String EPISODE_ID = "Episodes[0].EpisodeId";
    public static final String VIEW= "temp.view";
    public static final String HIPPA_RELATIONSHIP = "DemographicData.PatientInformation[0].hipaarelationship";
    public static final String CHART = "DemographicData.PatientInformation[0].chart";
    public static final String OTHER_PHONE_TYPE = "DemographicData.PatientInformation[0].OtheryPhoneType";
    public static final String FNAME = "DemographicData.PatientInformation[0].PatientFirstName";
    public static final String LNAME = "DemographicData.PatientInformation[0].PatientLastName";
    public static final String INACTIVE = "DemographicData.PatientInformation[0].Inactive";
    public static final String DECEASED = "DemographicData.PatientInformation[0].Deceased";
    public static final String PROV_COLUMN_ID = "ColumnId";
    public static final String REASON_TYPE_VAL = "2";
    public static final String COLUMNS = "Columns";
    public static final String IS_HOLD_ONLY ="is_hold_only";
    public static final String BS_SLOT_INTERVAL = "slot_interval";
    public static final String IGNORE_APPT_NAME_MATCH = "ignore_match";
    public static final String HOLD_REASON_MAP = "hold_reason_map";
    public static final String EXCLUDE_STATUS_CODE = "ex_status_code";
    public static final String IS_HOLD_WITH_GEN ="is_hold_with_gen";
    public static final String IS_BLOCKED = "is_blocked";
    public static final String SLOT_ID = "SchedulingData.Schedule[0].SlotId";
    public static final String APPT_TEMPLATE_ID = "SchedulingData.Schedule[0].TemplateId";
    public static final String RUN_REALTIME_BY_FILTER = "realt_by_fil";
    public static final String DEFAULT_CANCEL_REASON = "defcanreason";

    private ECPEngineConstants() {
    }
}
