package com.pes.integration.ecp.api;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;


@ExtendWith(MockitoExtension.class)
public class ApiNameTest {

    @Test
    void getKeyReturnsCorrectKey() {
        ApiName apiName = ApiName.UPDATE_PATIENT;
        assertEquals("update_patient", apiName.getKey());
    }

    @Test
    void getEnumReturnsCorrectEnumForValidKey() {
        ApiName apiName = ApiName.UPDATE_PATIENT.getEnum("update_patient");
        assertEquals(ApiName.UPDATE_PATIENT, apiName);
    }

    @Test
    void getEnumReturnsNullForInvalidKey() {
        ApiName apiName = ApiName.UPDATE_PATIENT.getEnum("invalid_key");
        assertNull(apiName);
    }
}
