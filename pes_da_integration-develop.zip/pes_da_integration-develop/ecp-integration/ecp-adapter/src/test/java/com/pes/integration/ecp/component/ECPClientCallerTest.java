package com.pes.integration.ecp.component;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.ecp.api.ECPApiCaller;
import com.pes.integration.ecp.component.ECPClientCaller;
import com.pes.integration.ecp.dto.Token;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.utils.MetricsUtil;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.function.Function;

import static com.pes.integration.constant.UtilitiesConstants.GET;
import static com.pes.integration.ecp.constant.ECPConstants.*;
import static com.pes.integration.ecp.constant.ECPEngineConstants.END_POINT;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;
import static org.springframework.http.MediaType.APPLICATION_JSON;


@ExtendWith(MockitoExtension.class)
public class ECPClientCallerTest {
    @InjectMocks
    private ECPClientCaller ecpClientCaller;

    @Mock
    WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    WebClient.RequestHeadersSpec requestHeadersSpec;
    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    WebClient.RequestHeadersSpec requestHeadersSpec1;

    private WebClient webClient;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    WebClient.ResponseSpec responseSpec;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        webClient = mock(WebClient.class);
        ecpClientCaller.webClient = webClient;
    }

    @Test
    void generateTokenReturnsValidToken() {
        String url = "http://example.com/token";
        HttpHeaders headers = new HttpHeaders();
        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        Token expectedToken = new Token();
        expectedToken.setExpiresIn("3600");
        expectedToken.setAccessToken("token");


        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.just(expectedToken));

        Token result = ecpClientCaller.generateToken(url, headers,formValues);

        assertEquals(expectedToken, result);
    }

    @Test
    void generateTokenHandlesErrorResponse() {

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
            String errorBody = "Invalid request";


            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.error(new RuntimeException(errorBody)));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> ecpClientCaller.generateToken(url, headers,formValues));

            Assertions.assertEquals(errorBody, exception.getMessage());
        }
    }

    @Test
    void getDataReturnsResponseWhenSuccessful() {
        String response = "{ \"key\": \"value\" }";
        when(webClient.method(HttpMethod.GET)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("http://example.com")).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just(response));

        String result = ecpClientCaller.getData("GET", "http://example.com", "body", "token");

        assertEquals(response, result);
    }

    @Test
    void getDataThrowsExceptionOnNotFound() {
        when(webClient.method(HttpMethod.GET)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("http://example.com")).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE,"errorMessage","Error while processing update patient ECP request")));

        assertThrows(Exception.class, () -> ecpClientCaller.getData("GET", "http://example.com", "body", "token"));
    }

    @Test
    void getDataThrowsExceptionOnServerError() {
        when(webClient.method(HttpMethod.GET)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("http://example.com")).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE,"errorMessage","Error while processing update patient ECP request")));

        assertThrows(Exception.class, () -> ecpClientCaller.getData("GET", "http://example.com", "body", "token"));
    }

    @Test
    void generateTokenHandlesEmptyFormValues() {
        String url = "http://example.com/token";
        HttpHeaders headers = new HttpHeaders();
        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        Token expectedToken = new Token();
        expectedToken.setExpiresIn("3600");
        expectedToken.setAccessToken("token");

        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.just(expectedToken));

        Token result = ecpClientCaller.generateToken(url, headers, formValues);

        assertEquals(expectedToken, result);
    }

    @Test
    void getDataHandlesClientError() {
        when(webClient.method(HttpMethod.GET)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("http://example.com")).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE,"Client Error","Error while processing update patient ECP request")));
        assertThrows(Exception.class, () -> ecpClientCaller.getData("GET", "http://example.com", "body", "token"));
    }

    @Test
    void getData_throwsIHubExceptionOnClientError() {
        HttpHeaders headers = new HttpHeaders();
        String httpMethod = GET;
        String url = "http://example.com";
        headers.add("Authorization", "Bearer token");
        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenAnswer(reqMethod -> requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenAnswer(reqBody ->requestHeadersSpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(eq(String.class))).thenReturn(Mono.error(new IHubException(new IHubErrorCode("400"), "Bad Request")));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            try {
                ecpClientCaller.getData(httpMethod, url, "{}", "token");
            } catch (Exception e) {
                assertTrue(e.getMessage().contains("Bad Request"));
            }
        }

    }

    @Test
    void getData_handlesEmptyErrorBodyViaOnStatus() {
        // Arrange
        String url = "http://example.com";
        String httpMethod = "GET";
        String body = "{}";
        String token = "token";

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        ClientResponse clientResponse = mock(ClientResponse.class);
        when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(""));
        when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);

        ArgumentCaptor<java.util.function.Function<ClientResponse, Mono<? extends Throwable>>> captor = ArgumentCaptor.forClass(java.util.function.Function.class);
        when(responseSpec.onStatus(any(), captor.capture())).thenReturn(responseSpec);

        when(responseSpec.bodyToMono(String.class)).then(invocation -> {
            if (!captor.getAllValues().isEmpty()) {
                Mono<? extends Throwable> errorMono = captor.getValue().apply(clientResponse);
                throw errorMono.block();
            }
            return Mono.just("");
        });

        // Act & Assert
        Exception ex = assertThrows(Exception.class, () -> ecpClientCaller.getData(httpMethod, url, body, token));
        Throwable cause = ex.getCause();
        if (cause instanceof IHubException) {
            assertTrue(cause.getMessage().contains("\"statusCode\": \"400\""));
        } else if (ex instanceof IHubException) {
            assertTrue(ex.getMessage().contains("\"statusCode\": \"400\""));
        } else {
            fail("Expected IHubException but got: " + ex.getClass());
        }
    }
    @Test
    void getData_handlesNonEmptyErrorBodyViaOnStatus() {
        String url = "http://example.com";
        String httpMethod = "GET";
        String body = "{}";
        String token = "token";
        String errorBody = "Some error occurred";

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        ClientResponse clientResponse = mock(ClientResponse.class);
        when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
        when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);

        ArgumentCaptor<java.util.function.Function<ClientResponse, Mono<? extends Throwable>>> captor = ArgumentCaptor.forClass(java.util.function.Function.class);
        when(responseSpec.onStatus(any(), captor.capture())).thenReturn(responseSpec);

        try (MockedStatic<com.pes.integration.utils.MetricsUtil> metricsUtilMock = mockStatic(com.pes.integration.utils.MetricsUtil.class)) {
            metricsUtilMock.when(() -> com.pes.integration.utils.MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            when(responseSpec.bodyToMono(String.class)).then(invocation -> {
                if (!captor.getAllValues().isEmpty()) {
                    Mono<? extends Throwable> errorMono = captor.getValue().apply(clientResponse);
                    throw errorMono.block();
                }
                return Mono.just(errorBody);
            });

            Exception ex = assertThrows(Exception.class, () -> ecpClientCaller.getData(httpMethod, url, body, token));
            Throwable cause = ex.getCause();
            if (cause instanceof IHubException) {
                assertTrue(cause.getMessage().contains(errorBody));
            } else if (ex instanceof IHubException) {
                assertTrue(ex.getMessage().contains(errorBody));
            } else {
                fail("Expected IHubException but got: " + ex.getClass());
            }
            metricsUtilMock.verify(() -> com.pes.integration.utils.MetricsUtil.metricClientErrorCount(isNull(), isNull(), eq(errorBody), eq("500")));
        }
    }
}
