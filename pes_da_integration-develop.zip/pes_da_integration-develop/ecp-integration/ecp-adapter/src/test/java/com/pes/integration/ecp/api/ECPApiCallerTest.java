package com.pes.integration.ecp.api;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.ecp.api.ECPApiCaller;
import com.pes.integration.ecp.component.ECPClientCaller;
import com.pes.integration.ecp.dto.Token;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;


@ExtendWith(MockitoExtension.class)
public class ECPApiCallerTest {
    @Mock
    ECPClientCaller ecpClientCaller;
    @Mock
    DataCacheManager cacheManager;
    @Mock
    RedisService redisService;
    @InjectMocks
    private ECPApiCaller ecpApiCaller;
    @Mock
    WebClient webClient;

    @Test
    void initializeObjectSetsCorrectValues() throws IHubException {
        String deploymentId = "123";
        String configs = "{ \"ecpprop\": { \"ecp_req_conf\": {}, \"ecp_req_map\": {}, \"ecp_res_map\": {}, \"ecp_client_id\": \"clientId\", \"ecp_client_secret\": \"clientSecret\", \"ecp_token_scope\": \"scope\", \"ecp_grant_type\": \"grantType\", \"ecp_token_url\": \"tokenUrl\", \"ecp_update_url\": \"contextUrl\", \"ecp_oauth_api_token\": \"oauthApiToken\" } }";
        when(cacheManager.getRedisCacheData(anyString())).thenReturn(configs);
        ReflectionTestUtils.setField(ecpApiCaller, "activeProfileName", "staging");
        ecpApiCaller.initializeObject(deploymentId);

        assertEquals("clientId", "clientId");
        assertEquals("clientSecret", "clientSecret");
        assertEquals("scope", "scope");
        assertEquals("grantType", "grantType");
        assertEquals("tokenUrl", "tokenUrl");
        assertEquals("contextUrl", "contextUrl");
        assertEquals("oauthApiToken", "oauthApiToken");
    }

    @Test
    void callApiReturnsJSONObjectWhenResponseIsJSONObject() throws IHubException {
        JSONObject apiConfig = new JSONObject();
        JSONObject requestObject = new JSONObject();
        Token token=new Token();
        token.setAccessToken("abc");
        token.setExpiresIn("3600");
        String response = "{ \"key\": \"value\" }";
        ReflectionTestUtils.setField(ecpApiCaller, "contextUrl", "https://test.uhc.com/data");
        when(redisService.get(anyString())).thenReturn("abc");
        when(ecpClientCaller.getData(anyString(),anyString(),anyString(),anyString())).thenReturn(response);
        ReflectionTestUtils.setField(ecpApiCaller, "activeProfileName", "staging");

        Object result = ecpApiCaller.callApi(apiConfig, requestObject);

        assertTrue(result instanceof JSONObject);
        assertEquals("value", ((JSONObject) result).getString("key"));
    }

    @Test
    void callApiReturnsJSONArrayWhenResponseIsJSONArray() throws IHubException {
        JSONObject apiConfig = new JSONObject();
        JSONObject requestObject = new JSONObject();
        String response = "[ { \"key\": \"value\" } ]";
        ReflectionTestUtils.setField(ecpApiCaller, "activeProfileName", "staging");
        ReflectionTestUtils.setField(ecpApiCaller, "contextUrl", "https://test.uhc.com/data");
        when(ecpClientCaller.getData(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        when(redisService.get(anyString())).thenReturn("abc");
        Object result = ecpApiCaller.callApi(apiConfig, requestObject);

        assertTrue(result instanceof JSONArray);
        assertEquals("value", ((JSONArray) result).getJSONObject(0).getString("key"));
    }

    @Test
    void callApiThrowsExceptionWhenClientCallFails() throws IHubException {
        JSONObject apiConfig = new JSONObject();
        JSONObject requestObject = new JSONObject();
        when(redisService.get(anyString())).thenReturn("abc");
        ReflectionTestUtils.setField(ecpApiCaller, "activeProfileName", "staging");
        ReflectionTestUtils.setField(ecpApiCaller, "contextUrl", "https://test.uhc.com/data");
        when(ecpClientCaller.getData(anyString(), anyString(), anyString(), anyString())).thenThrow(new RuntimeException("Client error"));

        assertThrows(IHubException.class, () -> ecpApiCaller.callApi(apiConfig, requestObject));
    }

//    @Test
//    void getTokenReturnsTokenFromRedisWhenAvailable() throws IHubException {
//        when(redisService.get(anyString())).thenReturn("cachedToken");
//        String token = ecpApiCaller.getToken("123");
//        assertEquals("cachedToken", token);
//    }
//
//    @Test
//    void getTokenGeneratesNewTokenWhenNotInRedis() throws IHubException {
//        when(redisService.get(anyString())).thenReturn(null);
//        Token token = new Token();
//        token.setAccessToken("newToken");
//        token.setExpiresIn("3600");
//        when(ecpClientCaller.generateToken(anyString(), any(HttpHeaders.class), any(MultiValueMap.class))).thenReturn(token);
//
//        String result = ecpApiCaller.getToken("123");
//
//        assertEquals("newToken", result);
//        verify(redisService).saveWithTtl(anyString(), eq("newToken"), eq(3600));
//    }

    @Test
    void generateTokenSavesTokenInRedis() {
        Token token = new Token();
        token.setAccessToken("newToken");
        token.setExpiresIn("3600");
        ReflectionTestUtils.setField(ecpApiCaller, "tokenUrl", "https://test.uhc.com/token");
        doReturn(token).when(ecpClientCaller).generateToken(anyString(),any(),any());
        ReflectionTestUtils.setField(ecpApiCaller, "activeProfileName", "staging");
        String result = ecpApiCaller.generateToken();

        assertEquals("newToken", result);
        verify(redisService).saveWithTtl(anyString(), eq("newToken"), eq(3600));
    }
}
