package com.pes.integration.ecp.constant;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ECPEngineConstantsTest {

    @Test
    void epmNamePrefix_hasCorrectValue() {
        assertEquals("ECP", ECPEngineConstants.EPM_NAME_PREFIX);
    }

    @Test
    void ecpConfig_hasCorrectValue() {
        assertEquals("ecpprop", ECPEngineConstants.ECP_CONFIG);
    }

    @Test
    void blankConstant_hasCorrectValue() {
        assertEquals("", ECPEngineConstants.BLANK);
    }

    @Test
    void retryCount_hasCorrectValue() {
        assertEquals("retrycount", ECPEngineConstants.RETRY_COUNT);
    }

    @Test
    void urlConstant_hasCorrectValue() {
        assertEquals("url", ECPEngineConstants.URL);
    }

    @Test
    void methodConstant_hasCorrectValue() {
        assertEquals("method", ECPEngineConstants.METHOD);
    }

    @Test
    void classConstant_hasCorrectValue() {
        assertEquals("@class", ECPEngineConstants.CLASS);
    }

    @Test
    void nameConstant_hasCorrectValue() {
        assertEquals("Name", ECPEngineConstants.NAME);
    }

    @Test
    void requestMappingKeyName_hasCorrectValue() {
        assertEquals("ecp_req_map", ECPEngineConstants.REQUEST_MAPPING_KEY_NAME);
    }

    @Test
    void responseMappingKeyName_hasCorrectValue() {
        assertEquals("ecp_res_map", ECPEngineConstants.RESPONSE_MAPPING_KEY_NAME);
    }

    @Test
    void requestConfigKeyName_hasCorrectValue() {
        assertEquals("ecp_req_conf", ECPEngineConstants.REQUEST_CONFIG_KEY_NAME);
    }

    @Test
    void responseCodesMappingKeyName_hasCorrectValue() {
        assertEquals("ecp_res_codes", ECPEngineConstants.RESPONSE_CODES_MAPPING_KEY_NAME);
    }

    @Test
    void endPoint_hasCorrectValue() {
        assertEquals("ecp_base_url", ECPEngineConstants.END_POINT);
    }

    @Test
    void epmType_hasCorrectValue() {
        assertEquals("ecp", ECPEngineConstants.EPM_TYPE);
    }

    @Test
    void epmConfigGroups_hasCorrectValue() {
        assertEquals("RunBaselineSync,Epic Properties,Filter Service Config", ECPEngineConstants.EPM_CONFIG_GROUPS);
    }

    @Test
    void columnId_hasCorrectValue() {
        assertEquals("SchedulingData.Provider[0].ColumnId", ECPEngineConstants.COLUMN_ID);
    }

    @Test
    void apptEpisodeId_hasCorrectValue() {
        assertEquals("SchedulingData.Provider[0].EpisodeId", ECPEngineConstants.APPT_EPISODE_ID);
    }

    @Test
    void episodeId_hasCorrectValue() {
        assertEquals("Episodes[0].EpisodeId", ECPEngineConstants.EPISODE_ID);
    }

    @Test
    void viewConstant_hasCorrectValue() {
        assertEquals("temp.view", ECPEngineConstants.VIEW);
    }

    @Test
    void hippaRelationship_hasCorrectValue() {
        assertEquals("DemographicData.PatientInformation[0].hipaarelationship", ECPEngineConstants.HIPPA_RELATIONSHIP);
    }

    @Test
    void chartConstant_hasCorrectValue() {
        assertEquals("DemographicData.PatientInformation[0].chart", ECPEngineConstants.CHART);
    }

    @Test
    void otherPhoneType_hasCorrectValue() {
        assertEquals("DemographicData.PatientInformation[0].OtheryPhoneType", ECPEngineConstants.OTHER_PHONE_TYPE);
    }

    @Test
    void fNameConstant_hasCorrectValue() {
        assertEquals("DemographicData.PatientInformation[0].PatientFirstName", ECPEngineConstants.FNAME);
    }

    @Test
    void lNameConstant_hasCorrectValue() {
        assertEquals("DemographicData.PatientInformation[0].PatientLastName", ECPEngineConstants.LNAME);
    }

    @Test
    void inactiveConstant_hasCorrectValue() {
        assertEquals("DemographicData.PatientInformation[0].Inactive", ECPEngineConstants.INACTIVE);
    }

    @Test
    void deceasedConstant_hasCorrectValue() {
        assertEquals("DemographicData.PatientInformation[0].Deceased", ECPEngineConstants.DECEASED);
    }

    @Test
    void provColumnId_hasCorrectValue() {
        assertEquals("ColumnId", ECPEngineConstants.PROV_COLUMN_ID);
    }

    @Test
    void reasonTypeVal_hasCorrectValue() {
        assertEquals("2", ECPEngineConstants.REASON_TYPE_VAL);
    }

    @Test
    void columnsConstant_hasCorrectValue() {
        assertEquals("Columns", ECPEngineConstants.COLUMNS);
    }

    @Test
    void isHoldOnly_hasCorrectValue() {
        assertEquals("is_hold_only", ECPEngineConstants.IS_HOLD_ONLY);
    }

    @Test
    void bsSlotInterval_hasCorrectValue() {
        assertEquals("slot_interval", ECPEngineConstants.BS_SLOT_INTERVAL);
    }

    @Test
    void ignoreApptNameMatch_hasCorrectValue() {
        assertEquals("ignore_match", ECPEngineConstants.IGNORE_APPT_NAME_MATCH);
    }

    @Test
    void holdReasonMap_hasCorrectValue() {
        assertEquals("hold_reason_map", ECPEngineConstants.HOLD_REASON_MAP);
    }

    @Test
    void excludeStatusCode_hasCorrectValue() {
        assertEquals("ex_status_code", ECPEngineConstants.EXCLUDE_STATUS_CODE);
    }

    @Test
    void isHoldWithGen_hasCorrectValue() {
        assertEquals("is_hold_with_gen", ECPEngineConstants.IS_HOLD_WITH_GEN);
    }

    @Test
    void isBlocked_hasCorrectValue() {
        assertEquals("is_blocked", ECPEngineConstants.IS_BLOCKED);
    }

    @Test
    void slotId_hasCorrectValue() {
        assertEquals("SchedulingData.Schedule[0].SlotId", ECPEngineConstants.SLOT_ID);
    }

    @Test
    void apptTemplateId_hasCorrectValue() {
        assertEquals("SchedulingData.Schedule[0].TemplateId", ECPEngineConstants.APPT_TEMPLATE_ID);
    }

    @Test
    void runRealtimeByFilter_hasCorrectValue() {
        assertEquals("realt_by_fil", ECPEngineConstants.RUN_REALTIME_BY_FILTER);
    }

    @Test
    void defaultCancelReason_hasCorrectValue() {
        assertEquals("defcanreason", ECPEngineConstants.DEFAULT_CANCEL_REASON);
    }
}