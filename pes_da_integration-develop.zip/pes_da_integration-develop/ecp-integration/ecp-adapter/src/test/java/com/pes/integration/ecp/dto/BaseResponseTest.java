package com.pes.integration.ecp.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BaseResponseTest {

    @Test
    void successResponse_hasCorrectValues() {
        BaseResponse response = new BaseResponse();
        response.setSuccess(true);
        response.setResponseCode("200");
        response.setResponseType("OK");
        response.setMessage("Request successful");
        response.setMethod("GET");
        response.setData("Some data");

        assertTrue(response.isSuccess());
        assertEquals("200", response.getResponseCode());
        assertEquals("OK", response.getResponseType());
        assertEquals("Request successful", response.getMessage());
        assertEquals("GET", response.getMethod());
        assertEquals("Some data", response.getData());
    }

    @Test
    void failureResponse_hasCorrectValues() {
        BaseResponse response = new BaseResponse();
        response.setSuccess(false);
        response.setResponseCode("500");
        response.setResponseType("ERROR");
        response.setMessage("Internal server error");
        response.setMethod("POST");
        response.setData(null);

        assertFalse(response.isSuccess());
        assertEquals("500", response.getResponseCode());
        assertEquals("ERROR", response.getResponseType());
        assertEquals("Internal server error", response.getMessage());
        assertEquals("POST", response.getMethod());
        assertNull(response.getData());
    }

    @Test
    void emptyResponse_hasDefaultValues() {
        BaseResponse response = new BaseResponse();

        assertFalse(response.isSuccess());
        assertNull(response.getResponseCode());
        assertNull(response.getResponseType());
        assertNull(response.getMessage());
        assertNull(response.getMethod());
        assertNull(response.getData());
    }
}