package com.pes.integration.ecp.constant;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ECPConstantsTest {

    @Test
    void dateFormatConstants_haveCorrectValues() {
        assertEquals("MM/dd/yyyy", ECPConstants.DATE_FORMAT);
        assertEquals("yyyy-MM-dd'T'HH:mm:ss", ECPConstants.DATE_TIME_FORMAT);
        assertEquals("MM/dd/yyyy hh:mm:ss a", ECPConstants.DATE_TIME_FORMAT_AM_PM);
        assertEquals("HH:mm:ss", ECPConstants.TIME_FORMAT);
        assertEquals("MM/dd/yyyy hh:mma", ECPConstants.TIME_FORMAT_REALTIME);
        assertEquals("hh:mm a", ECPConstants.TIME_FORMAT_AM_PM);
        assertEquals("MM/dd/yyyy HH:mm:ss", ECPConstants.DATE_TIME_FORMAT_WITHOUT_AM_PM);
        assertEquals("MM/dd/yyyy", ECPConstants.DOB_DATE_FORMAT);
        assertEquals("yyyymmddHHmm", ECPConstants.APPT_INPUT_DATE);
        assertEquals("HHmm", ECPConstants.APPT_INPUT_TIME);
        assertEquals("YYYY-MM-dd HH:mm:ss", ECPConstants.DATE_TIME_FORMAT_CHANGED_APP);
        assertEquals("YYYY-MM-dd", ECPConstants.ECP_DOB_DATE_FORMAT);
    }

    @Test
    void tokenConstants_haveCorrectValues() {
        assertEquals("ecp_token_usrid", ECPConstants.USR_ID);
        assertEquals("ecp_token_pswrd", ECPConstants.USR_PSWD);
        assertEquals("ecp_client_id", ECPConstants.CLIENT_ID);
        assertEquals("ecp_client_secret", ECPConstants.CLIENT_SECRET);
        assertEquals("ecp_token_scope", ECPConstants.SCOPE);
        assertEquals("ecp_grant_type", ECPConstants.GRANT_TYPE);
        assertEquals("ecp_token_url", ECPConstants.TOKEN_END_POINT);
        assertEquals("ecp_token_url", ECPConstants.TOKEN_URL);
        assertEquals("https://api.ecp.com", ECPConstants.BASE_URL);
    }

    @Test
    void appointmentStatusConstants_haveCorrectValues() {
        assertEquals("next", ECPConstants.NEXT);
        assertEquals("Id", ECPConstants.ID);
        assertEquals("Time", ECPConstants.TIME);
        assertEquals("startTime", ECPConstants.START_TIME);
        assertEquals("defcanreason", ECPConstants.DEFAULT_CANCEL_REASON);
        assertEquals("ApptReason", ECPConstants.APPT_REASON);
        assertEquals("allow_mul_pat", ECPConstants.ALLOW_MULTIPLE_PATIENT);
        assertEquals("allow_dup_pat", ECPConstants.ALLOW_DUPLICATE_PATIENT);
    }

    @Test
    void genderConstants_haveCorrectValues() {
        assertEquals("male", ECPConstants.MALE);
        assertEquals("female", ECPConstants.FEMALE);
        assertEquals("M", ECPConstants.GENDER_M);
        assertEquals("F", ECPConstants.GENDER_F);
    }

    @Test
    void entityConstants_haveCorrectValues() {
        assertEquals("location", ECPConstants.LOCATION_ENTITY);
        assertEquals("provider", ECPConstants.PROVIDER_ENTITY);
        assertEquals("is_prov_filter", ECPConstants.PROVIDER_OR_LOCATION);
        assertEquals("prov_loc_batch_size", ECPConstants.NOOFPROVIDERPERAPIALL);
    }

    @Test
    void ecpRequestConstants_haveCorrectValues() {
        assertEquals("start_date", ECPConstants.ECP_STARTDATE);
        assertEquals("end_date", ECPConstants.ECP_ENDDATE);
        assertEquals("provider_ids", ECPConstants.ECP_PROVIDERIDS);
        assertEquals("open_appointments_prov", ECPConstants.GETOPENAPPOINTMENTSBYPROVIDER);
        assertEquals("open_appointments_loc", ECPConstants.GETOPENAPPOINTMENTSBYLOCATION);
        assertEquals("location_ids", ECPConstants.ECP_LOCATIONIDS);
        assertEquals("ecp_req_map", ECPConstants.ECP_REQUEST_MAPPING);
        assertEquals("ecp_res_map", ECPConstants.ECP_RESPONSE_MAPPING);
        assertEquals("ecp_req_conf", ECPConstants.ECP_REQUEST_CONFIG);
    }
}