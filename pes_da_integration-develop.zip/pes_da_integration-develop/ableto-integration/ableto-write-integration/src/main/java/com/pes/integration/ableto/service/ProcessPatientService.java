package com.pes.integration.ableto.service;

import com.pes.integration.ableto.handler.NewPatientHandlerService;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.service.PatientFlowHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.*;
@Service
@Slf4j
public class ProcessPatientService extends PatientFlowHandler {
    @Autowired
    NewPatientHandlerService newPatientHandlerService;
    @Autowired
    DataTransactionService dataTransactionService;
    @Override
    public JSONObject createPatient(JSONObject input) throws IHubException {
        dataTransactionService.logData(input, CREATE_PATIENT.getKey(), CREATED.getKey(),
                "iHub Create Patient Request Message");
        JSONObject response = new JSONObject();
        try {
            response = newPatientHandlerService.doExecute(
                    input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC)
                            .getJSONObject(0));
        } catch (IHubException e) {
            log.error("Error in processing the create patient request {} ", e.getMessage());
            dataTransactionService.logData(input, CREATE_PATIENT.getKey(), FAILED.getKey(),
                    e.getMessage());
            throw e;
        }
        dataTransactionService.logData(input, CREATE_PATIENT.getKey(), SUCCESS.getKey(),
                "iHub Create Patient Successful");
        return response;
    }

    @Override
    public JSONObject updatePatient(JSONObject input) throws IHubException {
        return null;
    }

    @Override
    public JSONObject searchPatient(JSONObject input) throws IHubException {
        return null;
    }

    @Override
    public JSONObject getPatient(JSONObject input) throws IHubException {
        return null;
    }
}
