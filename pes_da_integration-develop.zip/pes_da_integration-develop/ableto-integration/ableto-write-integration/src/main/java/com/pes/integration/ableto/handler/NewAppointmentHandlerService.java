package com.pes.integration.ableto.handler;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.api.ApiName;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.handlers.AbstractNewAppointmentHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.ableto.constant.AbleToConstants.DATE_TIME_FORMAT;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;

@Slf4j
@Service(value = "NewAppt")
public class NewAppointmentHandlerService extends AbstractNewAppointmentHandler {
    @Autowired
    AbleToApiCaller ableToApiCaller;

    @Override
    protected JSONObject createNewAppointment(Object inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = (String) getValue(inputObject, DocASAPConstants.Key.DEPLOYMENT_ID);
        try {
            String apptDate = (String) getValue(inputObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START);
            if (!isEmpty(apptDate)) {
                String ableToFormatDate = convertDateFormat(apptDate, DocASAPConstants.DATE_TIME_FORMAT,
                        DATE_TIME_FORMAT);
                setValue(inputObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START, ableToFormatDate);
            }
            outputObject = ableToApiCaller.call(deploymentId, ApiName.NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
            if (!isEmpty(outputObject) && outputObject.has("temp")) {
                JSONObject temp = (JSONObject) outputObject.get("temp");
                if (!isEmpty(temp.get("error_message"))) {
                    throw new IHubException(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
                            temp.toString());
                }
            }
            String apptId = (String) getValue(outputObject, DocASAPConstants.Key.APPOINTMENT_ID);
            setValue(inputObject, DocASAPConstants.Key.APPOINTMENT_TIMING_START, apptDate);
            // if apptId=null indicates some issue with Realtime Write
            if (apptId == null) {
                log.info("Appointment ID: " + sanitizeForLog(apptId) + ", Error: "
                        + getValue(outputObject, "temp.error_message") + ", DeploymentId: " + sanitizeForLog(deploymentId));
            } else {
                log.info("Appointment ID: " + sanitizeForLog(apptId) + ", DeploymentId: " + sanitizeForLog(deploymentId));
            }
        } catch (IHubException ihubExc) {
            log.error("IHUB_EXCEPTION:: while setting/getting json keys. AbleTo- NewAppt Flow. DeploymentId:"
                    + sanitizeForLog(deploymentId) + " " + ihubExc.getMessage());
            throw new IHubException(ihubExc, UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
                    ihubExc.getMessage());
        } catch (Exception exc) {
            log.error("EXCEPTION:: AbleTo- NewAppt Flow. DeploymentId:" + sanitizeForLog(deploymentId) + " " + exc.getMessage());
            throw new IHubException(exc, UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
                    exc.getMessage());
        }
        return outputObject;
    }
}
