package com.pes.integration.ableto.handler;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.api.ApiName;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.handlers.AbstractCancelAppointmentsHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.ableto.constant.AbleToEngineConstants.*;
import static com.pes.integration.enums.Flow.CANCEL_APPOINTMENT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.NullChecker.isEmpty;

@Slf4j
@Service(value = "CancelAppt")
public class CancelAppointmentsHandlerService extends AbstractCancelAppointmentsHandler {
    @Autowired
    AbleToApiCaller ableToApiCaller;
    @Override
    public JSONObject cancelAppointment(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = String.valueOf(getValue(inputObject, DocASAPConstants.Key.DEPLOYMENT_ID));
            try {
                outputObject = ableToApiCaller.call(deploymentId, ApiName.CANCEL_APPOINTMENT.getKey(), inputObject, CANCEL_APPOINTMENT.getKey());
            } catch (Exception exc) {
                log.error("EXCEPTION:: AbleTo - While cancelling appointment.  deploymentId:"+deploymentId+" "+exc.getMessage());
                throw new IHubException(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), exc.getMessage());
            }
            return outputObject;
        }

        public void getCancelReason(String deploymentId, JSONObject inputObject) throws IHubException {
            try {
                String cancelReason = (String) dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX,deploymentId, ABLETO_CONFIG,
                        DEFAULT_CANCEL_REASON, false);
                setValue(inputObject, DocASAPConstants.Key.EVENT_REASON_ID, cancelReason);
            } catch (IHubException bee) {
                log.error(bee.getMessage());
                throw bee;
            } catch (Exception e) {
                log.error(e.getMessage());
                throw new IHubException(UtilityErrors.ERROR_LOADING_CONFIG.getErrorCode(), "getCancelReason");
            }
        }

}
