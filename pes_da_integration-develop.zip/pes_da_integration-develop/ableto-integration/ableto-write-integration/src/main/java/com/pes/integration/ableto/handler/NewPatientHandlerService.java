package com.pes.integration.ableto.handler;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.api.ApiName;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.handlers.AbstractNewPatientHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import static com.pes.integration.ableto.constant.AbleToConstants.*;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.*;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.NUMBER;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.PHONE_TYPE;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.SCHEDULING_DATA;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;

@Service(value = "NewPatient")
@Slf4j
public class NewPatientHandlerService extends AbstractNewPatientHandler {
    @Autowired
    AbleToApiCaller abletoApiCaller;
    @Autowired
    DataCacheManager cacheManager;

    @Override
    public JSONObject createNewPatient(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = String.valueOf(getValue(inputObject, DEPLOYMENT_ID));
        try {
            String lan = (String) getValue(inputObject, DocASAPConstants.Key.LANGUAGE_PREFERENCE);
            if (!isEmpty(lan)) {
                lan = getLanguage(deploymentId, lan);
                setValue(inputObject, DocASAPConstants.Key.LANGUAGE_PREFERENCE, lan.toLowerCase());
            }else {
                lan="english";
                setValue(inputObject, DocASAPConstants.Key.LANGUAGE_PREFERENCE, lan.toLowerCase());
            }
            setGender(inputObject);
            handleEpmPhoneNoEmail(HOME_PHONE_TYPE_VALUE, CELL_PHONE_TYPE_VALUE,
                    WORK_PHONE_TYPE_VALUE, inputObject);
            populateSource(inputObject, deploymentId);
            setValue(inputObject, TEMP_TEAM, getTeam(deploymentId));
            setValue(inputObject, INS_NAME, getInsName(deploymentId));
            outputObject = abletoApiCaller.call(deploymentId, ApiName.NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey());
            if (!isEmpty(outputObject)) {
                String patientId = (String) getValue(outputObject, PATIENT_ID);
                // if patientId=null indicates some issue with Realtime Write
                if (patientId == null) {
                    log.info("Error: "
                            + getValue(outputObject, "temp.error_message") + ", DeploymentId: " + deploymentId);
                } else {
                    log.info("Patient ID: " + patientId + ", DeploymentId: " + deploymentId);
                }
                copyKey(DEMOGRAPHIC_DATA, inputObject, outputObject);
                setValue(outputObject, PATIENT_ID, patientId);
                copyKey(SCHEDULING_DATA, inputObject, outputObject);
                copyKey(INSURANCE_INFORMATION, inputObject, outputObject);
            }
        } catch (IHubException ihubExc) {
            log.error("IHUB_EXCEPTION:: while setting/getting json keys. AbleTo- NewPatient Flow. DeploymentId:"
                    + deploymentId + " " + ihubExc.getMessage());
            throw ihubExc;
        } catch (Exception exc) {
            log.error("EXCEPTION:: AbleTo- NewPatient Flow. DeploymentId:" + deploymentId + " " + exc.getMessage());
            throw new IHubException(exc, UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
                    exc.getMessage());
        }
        return outputObject;
    }

    private String getLanguage(String deploymentId, String lan) throws IHubException {
        //fetching language preference from ihubdb config
        boolean isLang= Boolean.parseBoolean(dataCacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, "language_pref"));
        log.info("Language preference is set to: " + sanitizeForLog(String.valueOf(isLang)) + ", for deploymentId: " + sanitizeForLog(deploymentId));
        JSONObject languageMap;
        // If language preference is true, fetch the language map from ihubdb config
        if (isLang) {
            try{
            languageMap=new JSONObject(dataCacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, "language_map"));
            }catch (Exception e){
                log.error("Error while fetching language map from cache for deploymentId: " + deploymentId, e);
                languageMap = new JSONObject();
            }
            //If language map does not contain the language we got from payload, then whatever lan we received, we will use it as it is
            if (languageMap.has(lan.toLowerCase())) {
                lan = languageMap.getString(lan.toLowerCase());
            } else {
                log.info("Language preference is set to true, but language map does not contain the language: " + sanitizeForLog(lan) + ", for deploymentId: " + sanitizeForLog(deploymentId));
            }
        }
        return lan;
    }

    private void populateSource(JSONObject inputObject, String deploymentId) {
        String channel = (String) getValue(inputObject, DocASAPConstants.Key.CHANNEL);
        Object sourceMap = getSourceMap(deploymentId);
        try {
            if (!isEmpty(channel) && !isEmpty(sourceMap)) {
                JSONObject source = new JSONObject();
                source = formatRequest(sourceMap, source);
                Set<String> keys = source.keySet();
                for (String key : keys) {
                    String[] channels = key.split("\\^");
                    List<String> channelList = Stream.of(channels).toList();
                    if (channelList.contains(channel)) {
                        String value = (String) source.get(key);
                        setValue(inputObject, TEMP_SOURCE, value);
                        break;
                    }
                }
            }
        } catch (IHubException e) {
            log.error(e.getMessage());
        }
    }

    private JSONObject formatRequest(Object sourceMap, JSONObject source) {
        try {
            source = new JSONObject(sourceMap.toString());
        } catch (JSONException e) {
            log.error(e.getMessage());
        }
        return source;
    }

    private String getTeam(String deploymentId) {
        try {
            return String.valueOf(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
                    ABLETO_CONFIG, REFERRER_TEAM, false));
        } catch (Exception e) {
            log.info(e.getMessage());
            return null;
        }
    }

    private String getInsName(String deploymentId) {
        try {
            return String.valueOf(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
                    ABLETO_CONFIG, PAYOR_NAME, false));
        } catch (Exception e) {
            log.info(e.getMessage());
            return null;
        }
    }

    private Object getSourceMap(String deploymentId) {
        try {
            return cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
                    ABLETO_CONFIG, REFERRER_SOURCE, false);
        } catch (Exception e) {
            log.info(e.getMessage());
            return null;
        }
    }

    public void handleEpmPhoneNoEmail(String homeType, String cellType, String workType, JSONObject inputObject) throws IHubException {
        Object homePhoneNumber = getValue(inputObject, DocASAPConstants.Key.HOME_PHONE);
        Object workPhoneNumber = getValue(inputObject, DocASAPConstants.Key.WORK_PHONE);
        Object mobilePhoneNumber = getValue(inputObject, DocASAPConstants.Key.MOBILE_PHONE);
        JSONArray phoneArray = new JSONArray();
        if (homePhoneNumber != null) {
            JSONObject homeJson = new JSONObject();
            if (homePhoneNumber.toString().length() == 7) {
                String areaCode = getValue(inputObject, DocASAPConstants.Key.HOME_PHONE_AREA_CODE).toString();
                homePhoneNumber = areaCode + homePhoneNumber;
            }
            setValue(homeJson, NUMBER, homePhoneNumber);
            setValue(homeJson, PHONE_TYPE, homeType);
            phoneArray.put(homeJson);
        }
        if (workPhoneNumber != null) {
            JSONObject workJson = new JSONObject();
            if (workPhoneNumber.toString().length() == 7) {
                String areaCode = getValue(inputObject, DocASAPConstants.Key.WORK_PHONE_AREA_CODE).toString();
                workPhoneNumber = areaCode + workPhoneNumber;
            }
            setValue(workJson, NUMBER, workPhoneNumber);
            setValue(workJson, PHONE_TYPE, workType);
            phoneArray.put(workJson);
        }
        if (mobilePhoneNumber != null) {
            JSONObject mobileJson = new JSONObject();
            if (mobilePhoneNumber.toString().length() == 7) {
                String areaCode = getValue(inputObject, DocASAPConstants.Key.MOBILE_PHONE_AREA_CODE).toString();
                mobilePhoneNumber = areaCode + mobilePhoneNumber;
            }
            setValue(mobileJson, NUMBER, mobilePhoneNumber);
            setValue(mobileJson, PHONE_TYPE, cellType);
            phoneArray.put(mobileJson);
        }
        JSONObject patientInformation = (JSONObject) getValue(inputObject,
                "DemographicData.PatientInformation[0]");
        patientInformation.put("Phone", phoneArray);
    }

    @Override
    public JSONObject getPatientDemographics(JSONObject inputObject) throws IHubException {
        JSONObject demographicObject = new JSONObject();
        copyKey(DEPLOYMENT_ID, inputObject, demographicObject);
        copyKey(DEMOGRAPHIC_DATA, inputObject, demographicObject);
        setValue(demographicObject, "DemographicData.PatientInformation[0].Phone", null);
        copyKey(SCHEDULING_DATA, inputObject, demographicObject);
        return demographicObject;
    }

    private void setGender(JSONObject inputObject) {
        String gender = (String) getValue(inputObject, DocASAPConstants.Key.GENDER);
        if (gender.equalsIgnoreCase(GENDER_M))
            gender = MALE;
        else if (gender.equalsIgnoreCase(GENDER_F))
            gender = FEMALE;
        try {
            setValue(inputObject, DocASAPConstants.Key.GENDER, gender);
        } catch (IHubException e) {
            log.error(e.getMessage());
        }
    }

    @Override
    public JSONObject getPatientInsuranceInfo(JSONObject inputObject) {
        return null;
    }
}
