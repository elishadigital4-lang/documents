package com.pes.integration.ableto.handler;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.api.ApiName;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NewAppointmentHandlerServiceTest {

    @Mock
    private AbleToApiCaller ableToApiCaller;

    @InjectMocks
    private NewAppointmentHandlerService newAppointmentHandlerService;

    private static final Logger log = LoggerFactory.getLogger(NewAppointmentHandlerService.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateNewAppointment_Success() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        JSONObject expectedResponse = new JSONObject();
        expectedResponse.put(DocASAPConstants.Key.APPOINTMENT_ID, "456");

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        JSONObject response = newAppointmentHandlerService.createNewAppointment(inputObject);

        verify(ableToApiCaller, times(1)).call("123", ApiName.NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
        assertEquals(expectedResponse, response);
    }

    @Test
    void testCreateNewAppointment_IHubException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        IHubException exception = new IHubException(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "Error");
        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(exception);

        IHubException thrown = assertThrows(IHubException.class, () -> {
            newAppointmentHandlerService.createNewAppointment(inputObject);
        });

        assertEquals(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), thrown.getErrorCode());
        assertEquals("Error", thrown.getMessage());
    }

    @Test
    void testCreateNewAppointment_Exception() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("Error"));

        IHubException thrown = assertThrows(IHubException.class, () -> {
            newAppointmentHandlerService.createNewAppointment(inputObject);
        });

        assertEquals(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), thrown.getErrorCode());
        assertEquals("Error", thrown.getMessage());
    }

    @Test
    void testCreateNewAppointment_TempError() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        JSONObject temp = new JSONObject();
        temp.put("error_message", "Temp error");

        JSONObject expectedResponse = new JSONObject();
        expectedResponse.put("temp", temp);

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        IHubException thrown = assertThrows(IHubException.class, () -> {
            newAppointmentHandlerService.createNewAppointment(inputObject);
        });

        assertEquals(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), thrown.getErrorCode());
        assertTrue(thrown.getMessage().contains("Temp error"));
    }

    @Test
    void testCreateNewAppointment_NullApptId() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        JSONObject expectedResponse = new JSONObject();

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        JSONObject response = newAppointmentHandlerService.createNewAppointment(inputObject);

        verify(ableToApiCaller, times(1)).call("123", ApiName.NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
        assertEquals(expectedResponse, response);
    }

    @Test
    void testCreateNewAppointment_EmptyResponse() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(new JSONObject());

        JSONObject response = newAppointmentHandlerService.createNewAppointment(inputObject);

        verify(ableToApiCaller, times(1)).call("123", ApiName.NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
        assertTrue(response.isEmpty());
    }

    @Test
    void testCreateNewAppointment_Successs() throws Exception {
        JSONObject input = new JSONObject();
        input.put(DocASAPConstants.Key.DEPLOYMENT_ID, "depId");
        input.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        JSONObject expectedResponse = new JSONObject();
        expectedResponse.put(DocASAPConstants.Key.APPOINTMENT_ID, "apptId");

        try (
                MockedStatic<JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
                MockedStatic<com.pes.integration.utils.DateUtils> dateUtils = mockStatic(com.pes.integration.utils.DateUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullChecker = mockStatic(com.pes.integration.utils.NullChecker.class);
                MockedStatic<com.pes.integration.utils.LogUtil> logUtil = mockStatic(com.pes.integration.utils.LogUtil.class)
        ) {
            jsonUtils.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID)))
                    .thenReturn("depId");
            jsonUtils.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_TIMING_START)))
                    .thenReturn("2023-10-10T10:00:00Z");
            nullChecker.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);
            dateUtils.when(() -> com.pes.integration.utils.DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenReturn("2023-10-10T10:00:00Z");
            jsonUtils.when(() -> com.pes.integration.jsonmapper.JsonUtils.setValue(any(), anyString(), any())).thenAnswer(invocation -> null);
            logUtil.when(() -> com.pes.integration.utils.LogUtil.sanitizeForLog(any())).thenReturn("sanitized");

            when(ableToApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(expectedResponse);
            jsonUtils.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(eq(expectedResponse), eq(DocASAPConstants.Key.APPOINTMENT_ID)))
                    .thenReturn("apptId");

            JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(newAppointmentHandlerService, "createNewAppointment", input);

            assertEquals(expectedResponse, result);
        }
    }

    @Test
    void testCreateNewAppointment_TempErrors() throws Exception {
        JSONObject input = new JSONObject();
        input.put(DocASAPConstants.Key.DEPLOYMENT_ID, "depId");
        input.put(DocASAPConstants.Key.APPOINTMENT_TIMING_START, "2023-10-10T10:00:00Z");

        JSONObject temp = new JSONObject();
        temp.put("error_message", "Temp error");
        JSONObject response = new JSONObject();
        response.put("temp", temp);

        try (
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
                MockedStatic<com.pes.integration.utils.DateUtils> dateUtils = mockStatic(com.pes.integration.utils.DateUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullChecker = mockStatic(com.pes.integration.utils.NullChecker.class);
                MockedStatic<com.pes.integration.utils.LogUtil> logUtil = mockStatic(com.pes.integration.utils.LogUtil.class)
        ) {
            jsonUtils.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID)))
                    .thenReturn("depId");
            jsonUtils.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_TIMING_START)))
                    .thenReturn("2023-10-10T10:00:00Z");
            nullChecker.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);
            dateUtils.when(() -> com.pes.integration.utils.DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenReturn("2023-10-10T10:00:00Z");
            jsonUtils.when(() -> com.pes.integration.jsonmapper.JsonUtils.setValue(any(), anyString(), any())).thenAnswer(invocation -> null);
            logUtil.when(() -> com.pes.integration.utils.LogUtil.sanitizeForLog(any())).thenReturn("sanitized");

            when(ableToApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(response);

            Exception ex = assertThrows(Exception.class, () ->
                    ReflectionTestUtils.invokeMethod(newAppointmentHandlerService, "createNewAppointment", input)
            );
        }
    }
}