package com.pes.integration.ableto.service;

import com.pes.integration.ableto.handler.CancelAppointmentsHandlerService;
import com.pes.integration.ableto.handler.NewAppointmentHandlerService;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.CANCEL_APPOINTMENT;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.enums.FlowStatus.CREATED;
import static com.pes.integration.enums.FlowStatus.FAILED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProcessAppointmentServiceTest {

    @Mock
    private DataTransactionService dataTransactionService;

    @Mock
    private CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    @Mock
    private NewAppointmentHandlerService newAppointmentHandlerService;

    @InjectMocks
    private ProcessAppointmentService processAppointmentService;

    private static final Logger log = LoggerFactory.getLogger(ProcessAppointmentService.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateAppointment_Success() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put(APPOINTMENT_SYNC, appointmentSync);
        input.put(DATA, data);

        JSONObject expectedResponse = new JSONObject();
        when(newAppointmentHandlerService.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        JSONObject response = processAppointmentService.createAppointment(input);

        verify(dataTransactionService, times(1)).logData(input, CREATE_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Create Appointment Request Message");
        verify(newAppointmentHandlerService, times(1)).doExecute(appointment);
        assertEquals(expectedResponse, response);
    }

    @Test
    void testCreateAppointment_IHubException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put(APPOINTMENT_SYNC, appointmentSync);
        input.put(DATA, data);


        IHubException exception = new IHubException(new Exception("Error"), null, "Error");
        when(newAppointmentHandlerService.doExecute(any(JSONObject.class))).thenThrow(exception);

        IHubException thrown = assertThrows(IHubException.class, () -> {
            processAppointmentService.createAppointment(input);
        });

        verify(dataTransactionService, times(1)).logData(input, CREATE_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Create Appointment Request Message");
        verify(dataTransactionService, times(1)).logData(input, CREATE_APPOINTMENT.getKey(), FAILED.getKey(), exception.getMessage());
        verify(newAppointmentHandlerService, times(1)).doExecute(appointment);
        assertEquals(exception, thrown);
    }

    @Test
    void testCancelAppointment_Success() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put(APPOINTMENT_SYNC, appointmentSync);
        input.put(DATA, data);

        JSONObject expectedResponse = new JSONObject();
        when(cancelAppointmentsHandlerService.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        JSONObject response = processAppointmentService.cancelAppointment(input);

        verify(dataTransactionService, times(1)).logData(input, CANCEL_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Cancel Appointment Request Message");
        verify(cancelAppointmentsHandlerService, times(1)).doExecute(appointment);
        assertEquals(expectedResponse, response);
    }

    @Test
    void testCancelAppointment_IHubException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put(APPOINTMENT_SYNC, appointmentSync);
        input.put(DATA, data);

        IHubException exception = new IHubException(new Exception("Error"), null, "Error");
        when(cancelAppointmentsHandlerService.doExecute(any(JSONObject.class))).thenThrow(exception);

        IHubException thrown = assertThrows(IHubException.class, () -> {
            processAppointmentService.cancelAppointment(input);
        });

        verify(dataTransactionService, times(1)).logData(input, CANCEL_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Cancel Appointment Request Message");
        verify(dataTransactionService, times(1)).logData(input, CANCEL_APPOINTMENT.getKey(), FAILED.getKey(), exception.getMessage());
        verify(cancelAppointmentsHandlerService, times(1)).doExecute(appointment);
        assertEquals(exception, thrown);
    }
}