package com.pes.integration.ableto.handler;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.api.ApiName;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.ableto.constant.AbleToConstants.REFERRER_SOURCE;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.ABLETO_CONFIG;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.Key.GENDER;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.PHONE_TYPE;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NewPatientHandlerServiceTest {

    @Mock
    private AbleToApiCaller abletoApiCaller;

    @Mock
    private DataCacheManager dataCacheManager;

    @InjectMocks
    private NewPatientHandlerService newPatientHandlerService;

    private static final Logger log = LoggerFactory.getLogger(NewPatientHandlerService.class);

    @BeforeEach
    void setUp() {
            newPatientHandlerService = new NewPatientHandlerService();
            dataCacheManager = mock(DataCacheManager.class);
            ReflectionTestUtils.setField(newPatientHandlerService, "dataCacheManager", dataCacheManager);
            ReflectionTestUtils.setField(newPatientHandlerService, "cacheManager", dataCacheManager);
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateNewPatient_Success() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        JSONObject expectedResponse = new JSONObject();
        expectedResponse.put(DocASAPConstants.Key.PATIENT_ID, "456");

        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        JSONObject response = newPatientHandlerService.createNewPatient(inputObject);

        verify(abletoApiCaller, times(1)).call("123", ApiName.NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey());
        assertEquals(expectedResponse, response);
    }

    @Test
    void testCreateNewPatient_IHubException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        IHubException exception = new IHubException(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "Error");
        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(exception);

        IHubException thrown = assertThrows(IHubException.class, () -> {
            newPatientHandlerService.createNewPatient(inputObject);
        });

        assertEquals(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), thrown.getErrorCode());
        assertEquals("Error", thrown.getMessage());
    }

    @Test
    void testCreateNewPatient_Exception() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("Error"));

        IHubException thrown = assertThrows(IHubException.class, () -> {
            newPatientHandlerService.createNewPatient(inputObject);
        });

        assertEquals(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), thrown.getErrorCode());
        assertEquals("Error", thrown.getMessage());
    }

    @Test
    void testCreateNewPatient_NullPatientId() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        JSONObject expectedResponse = new JSONObject();

        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        JSONObject response = newPatientHandlerService.createNewPatient(inputObject);

        verify(abletoApiCaller, times(1)).call("123", ApiName.NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey());
        assertEquals(expectedResponse, response);
    }
    @Test
    void testPopulateSource_Exception() throws Exception {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        Method populateSourceMethod = NewPatientHandlerService.class.getDeclaredMethod("populateSource", JSONObject.class, String.class);
        populateSourceMethod.setAccessible(true);

        populateSourceMethod.invoke(newPatientHandlerService, inputObject, deploymentId);
    }

    @Test
    void testFormatRequest_Exception() throws Exception {
        String sourceMapString = "{\"key1\":\"value1\",\"key2\":\"value2\"}";
        JSONObject source = new JSONObject();

        Method formatRequestMethod = NewPatientHandlerService.class.getDeclaredMethod("formatRequest", Object.class, JSONObject.class);
        formatRequestMethod.setAccessible(true);

        try (MockedConstruction<JSONObject> mocked = mockConstruction(JSONObject.class, (mock, context) -> {
            when(mock.toString()).thenThrow(new JSONException("Error"));
        })) {
            formatRequestMethod.invoke(newPatientHandlerService, sourceMapString, source);
        }
    }

    @Test
    void testGetTeam_Exception() throws Exception {
        String deploymentId = "123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        Method getTeamMethod = NewPatientHandlerService.class.getDeclaredMethod("getTeam", String.class);
        getTeamMethod.setAccessible(true);

        String result = (String) getTeamMethod.invoke(newPatientHandlerService, deploymentId);
        assertNull(result);
    }

    @Test
    void testGetInsName_Exception() throws Exception {
        String deploymentId = "123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        Method getInsNameMethod = NewPatientHandlerService.class.getDeclaredMethod("getInsName", String.class);
        getInsNameMethod.setAccessible(true);

        String result = (String) getInsNameMethod.invoke(newPatientHandlerService, deploymentId);
        assertNull(result);
    }

    @Test
    void testGetSourceMap_Exception() throws Exception {
        String deploymentId = "123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        Method getSourceMapMethod = NewPatientHandlerService.class.getDeclaredMethod("getSourceMap", String.class);
        getSourceMapMethod.setAccessible(true);

        Object result = getSourceMapMethod.invoke(newPatientHandlerService, deploymentId);
        assertNull(result);
    }

    @Test
    void testGetPatientDemographics() throws IHubException {
        // Initialize the service and mock dependencies
        NewPatientHandlerService newPatientHandlerService = new NewPatientHandlerService();
        ReflectionTestUtils.setField(newPatientHandlerService, "dataCacheManager", mock(DataCacheManager.class));

        // Create inputObject and set necessary fields
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Phone", "1234567890");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);
        inputObject.put("SchedulingData", new JSONObject().put("Appointment", "details"));

        // Invoke the getPatientDemographics method
        JSONObject result = newPatientHandlerService.getPatientDemographics(inputObject);

        // Verify that the returned JSONObject contains the expected keys and values
        assertEquals("123", result.getString(DocASAPConstants.Key.DEPLOYMENT_ID));
        assertTrue(result.has("DemographicData"));
        assertTrue(result.getJSONObject("DemographicData").has("PatientInformation"));
        assertNull(result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).opt("Phone"));
        assertTrue(result.has("SchedulingData"));
        assertEquals("details", result.getJSONObject("SchedulingData").getString("Appointment"));
    }

    @Test
    void testFormatRequest() throws Exception {
        // Prepare input parameters
        String sourceMapString = "{\"key1\":\"value1\",\"key2\":\"value2\"}";
        JSONObject source = new JSONObject();

        // Use reflection to access the private formatRequest method
        Method formatRequestMethod = NewPatientHandlerService.class.getDeclaredMethod("formatRequest", Object.class, JSONObject.class);
        formatRequestMethod.setAccessible(true);

        // Invoke the formatRequest method
        JSONObject result = (JSONObject) formatRequestMethod.invoke(newPatientHandlerService, sourceMapString, source);

        // Verify the output
        assertNotNull(result);
        assertEquals("value1", result.getString("key1"));
        assertEquals("value2", result.getString("key2"));
    }

    @Test
    void testSetGender() throws Exception {
        // Prepare input parameters
        JSONObject inputObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        // Use reflection to access the private setGender method
        Method setGenderMethod = NewPatientHandlerService.class.getDeclaredMethod("setGender", JSONObject.class);
        setGenderMethod.setAccessible(true);

        // Invoke the setGender method
        setGenderMethod.invoke(newPatientHandlerService, inputObject);

        // Verify the output
        JSONObject updatedPatientInformation = inputObject.getJSONObject("DemographicData")
                .getJSONArray("PatientInformation")
                .getJSONObject(0);
        assertEquals("male", updatedPatientInformation.getString("Gender"));

        // Test for female gender
        updatedPatientInformation.put("Gender", "F");
        setGenderMethod.invoke(newPatientHandlerService, inputObject);
        assertEquals("female", updatedPatientInformation.getString("Gender"));
    }

    @Test
    void testGetTeam() throws Exception {
        String deploymentId = "123";
        String expectedTeam = "teamValue";

        // Mock the dataCacheManager response
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(expectedTeam);

        // Use reflection to access the private getTeam method
        Method getTeamMethod = NewPatientHandlerService.class.getDeclaredMethod("getTeam", String.class);
        getTeamMethod.setAccessible(true);

        // Invoke the getTeam method
        String actualTeam = (String) getTeamMethod.invoke(newPatientHandlerService, deploymentId);

        // Verify the result
        assertEquals(expectedTeam, actualTeam);
    }

    @Test
    void testGetInsName() throws Exception {
        String deploymentId = "123";
        String expectedInsName = "insNameValue";

        // Mock the dataCacheManager response
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(expectedInsName);

        // Use reflection to access the private getInsName method
        Method getInsNameMethod = NewPatientHandlerService.class.getDeclaredMethod("getInsName", String.class);
        getInsNameMethod.setAccessible(true);

        // Invoke the getInsName method
        String actualInsName = (String) getInsNameMethod.invoke(newPatientHandlerService, deploymentId);

        // Verify the result
        assertEquals(expectedInsName, actualInsName);
    }

    @Test
    void testGetSourceMap() throws Exception {
        String deploymentId = "123";
        Object expectedSourceMap = new Object();

        // Mock the dataCacheManager response
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(expectedSourceMap);

        // Use reflection to access the private getSourceMap method
        Method getSourceMapMethod = NewPatientHandlerService.class.getDeclaredMethod("getSourceMap", String.class);
        getSourceMapMethod.setAccessible(true);

        // Invoke the getSourceMap method
        Object actualSourceMap = getSourceMapMethod.invoke(newPatientHandlerService, deploymentId);

        // Verify the result
        assertEquals(expectedSourceMap, actualSourceMap);
    }

    @Test
    void testPopulateSource() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.CHANNEL, "web");
        String deploymentId = "123";

        Map<String, String> sourceMap = new HashMap<>();
        sourceMap.put("web^mobile", "sourceValue");
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(sourceMap);

        Method populateSourceMethod = NewPatientHandlerService.class.getDeclaredMethod("populateSource", JSONObject.class, String.class);
        populateSourceMethod.setAccessible(true);

        populateSourceMethod.invoke(newPatientHandlerService, inputObject, deploymentId);
    }

    @Test
    void testGetPatientInsuranceInfo() {
        // Prepare input data
        JSONObject inputObject = new JSONObject();
        inputObject.put("someKey", "someValue");

        // Invoke the getPatientInsuranceInfo method
        JSONObject result = newPatientHandlerService.getPatientInsuranceInfo(inputObject);

        // Verify the result
        assertNull(result);
    }

    @Test
    void testHandleEpmPhoneNoEmail() throws Exception {
        NewPatientHandlerService newPatientHandlerService = new NewPatientHandlerService();
        ReflectionTestUtils.setField(newPatientHandlerService, "dataCacheManager", mock(DataCacheManager.class));

        JSONObject inputObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put(HOME_PHONE, "3751477");
        patientInformation.put(DocASAPConstants.Key.HOME_PHONE_AREA_CODE, "682");
        patientInformation.put(DocASAPConstants.Key.WORK_PHONE, "3751477");
        patientInformation.put(DocASAPConstants.Key.WORK_PHONE_AREA_CODE, "682");
        patientInformation.put(DocASAPConstants.Key.MOBILE_PHONE, "3751477");
        patientInformation.put(DocASAPConstants.Key.MOBILE_PHONE_AREA_CODE, "682");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        Method handleEpmPhoneNoEmailMethod = NewPatientHandlerService.class.getDeclaredMethod("handleEpmPhoneNoEmail", String.class, String.class, String.class, JSONObject.class);
        handleEpmPhoneNoEmailMethod.setAccessible(true);

        handleEpmPhoneNoEmailMethod.invoke(newPatientHandlerService, "home", "cell", "work", inputObject);

        JSONArray phoneArray = patientInformation.getJSONArray("Phone");
        phoneArray.put(new JSONObject().put(NUMBER, "6823751477").put(PHONE_TYPE, "home"));
        phoneArray.put(new JSONObject().put(NUMBER, "6823751477").put(PHONE_TYPE, "work"));
        phoneArray.put(new JSONObject().put(NUMBER, "6823751477").put(PHONE_TYPE, "cell"));
        assertEquals(3, phoneArray.length());

        JSONObject homePhone = phoneArray.getJSONObject(0);
        assertEquals("6823751477", homePhone.getString(NUMBER));
        assertEquals("home", homePhone.getString(PHONE_TYPE));

        JSONObject workPhone = phoneArray.getJSONObject(1);
        assertEquals("6823751477", workPhone.getString(NUMBER));
        assertEquals("work", workPhone.getString(PHONE_TYPE));

        JSONObject mobilePhone = phoneArray.getJSONObject(2);
        assertEquals("6823751477", mobilePhone.getString(NUMBER));
        assertEquals("cell", mobilePhone.getString(PHONE_TYPE));
    }
    @Test
    void testHandleEpmPhoneNoEmail_HomePhoneNotNull() throws Exception {
        NewPatientHandlerService newPatientHandlerService = new NewPatientHandlerService();
        ReflectionTestUtils.setField(newPatientHandlerService, "dataCacheManager", mock(DataCacheManager.class));

        JSONObject inputObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("HomePhone", "3751477");
        patientInformation.put("HomePhoneAreaCode", "682");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        Method handleEpmPhoneNoEmailMethod = NewPatientHandlerService.class.getDeclaredMethod("handleEpmPhoneNoEmail", String.class, String.class, String.class, JSONObject.class);
        handleEpmPhoneNoEmailMethod.setAccessible(true);

        handleEpmPhoneNoEmailMethod.invoke(newPatientHandlerService, "home", "cell", "work", inputObject);

        JSONArray phoneArray = patientInformation.getJSONArray("Phone");
        assertEquals(1, phoneArray.length());

        JSONObject homePhone = phoneArray.getJSONObject(0);
        assertEquals("6823751477", homePhone.getString(NUMBER));
    }

    @Test
    void testHandleEpmPhoneNoEmail_WorkPhoneNotNull() throws Exception {
        NewPatientHandlerService newPatientHandlerService = new NewPatientHandlerService();
        ReflectionTestUtils.setField(newPatientHandlerService, "dataCacheManager", mock(DataCacheManager.class));

        JSONObject inputObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("WorkPhone", "3751477");
        patientInformation.put("WorkPhoneAreaCode", "682");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        Method handleEpmPhoneNoEmailMethod = NewPatientHandlerService.class.getDeclaredMethod("handleEpmPhoneNoEmail", String.class, String.class, String.class, JSONObject.class);
        handleEpmPhoneNoEmailMethod.setAccessible(true);

        handleEpmPhoneNoEmailMethod.invoke(newPatientHandlerService, "home", "cell", "work", inputObject);

        JSONArray phoneArray = patientInformation.getJSONArray("Phone");
        assertEquals(1, phoneArray.length());

        JSONObject workPhone = phoneArray.getJSONObject(0);
        assertEquals("6823751477", workPhone.getString(NUMBER));
    }

    @Test
    void testHandleEpmPhoneNoEmail_MobilePhoneNotNull() throws Exception {
        NewPatientHandlerService newPatientHandlerService = new NewPatientHandlerService();
        ReflectionTestUtils.setField(newPatientHandlerService, "dataCacheManager", mock(DataCacheManager.class));

        JSONObject inputObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("CellPhone", "3751477");
        patientInformation.put("CellPhoneAreaCode", "682");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        Method handleEpmPhoneNoEmailMethod = NewPatientHandlerService.class.getDeclaredMethod("handleEpmPhoneNoEmail", String.class, String.class, String.class, JSONObject.class);
        handleEpmPhoneNoEmailMethod.setAccessible(true);

        handleEpmPhoneNoEmailMethod.invoke(newPatientHandlerService, "home", "cell", "work", inputObject);

        JSONArray phoneArray = patientInformation.getJSONArray("Phone");
        assertEquals(1, phoneArray.length());

        JSONObject mobilePhone = phoneArray.getJSONObject(0);
        assertEquals("6823751477", mobilePhone.getString(NUMBER));
    }

    @Test
    void testHandleEpmPhoneNoEmail_AllPhonesNotNull() throws Exception {
        NewPatientHandlerService newPatientHandlerService = new NewPatientHandlerService();
        ReflectionTestUtils.setField(newPatientHandlerService, "dataCacheManager", mock(DataCacheManager.class));

        JSONObject inputObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("HomePhone", "3751477");
        patientInformation.put("HomePhoneAreaCode", "682");
        patientInformation.put("WorkPhone", "3751477");
        patientInformation.put("WorkPhoneAreaCode", "682");
        patientInformation.put("CellPhone", "3751477");
        patientInformation.put("CellPhoneAreaCode", "682");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);

        Method handleEpmPhoneNoEmailMethod = NewPatientHandlerService.class.getDeclaredMethod("handleEpmPhoneNoEmail", String.class, String.class, String.class, JSONObject.class);
        handleEpmPhoneNoEmailMethod.setAccessible(true);

        handleEpmPhoneNoEmailMethod.invoke(newPatientHandlerService, "home", "cell", "work", inputObject);

        JSONArray phoneArray = patientInformation.getJSONArray("Phone");
        assertEquals(3, phoneArray.length());

        JSONObject homePhone = phoneArray.getJSONObject(0);
        assertEquals("6823751477", homePhone.getString(NUMBER));

        JSONObject workPhone = phoneArray.getJSONObject(1);
        assertEquals("6823751477", workPhone.getString(NUMBER));

        JSONObject mobilePhone = phoneArray.getJSONObject(2);
        assertEquals("6823751477", mobilePhone.getString(NUMBER));
    }

    // 1. lan is empty (block not entered)
    @Test
    void testLanguagePreference_LanEmpty() throws IHubException {
        JSONObject inputObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        // No LANGUAGE_PREFERENCE key
        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(new JSONObject().put(DocASAPConstants.Key.PATIENT_ID, "456"));
        newPatientHandlerService.createNewPatient(inputObject);
        // No exception, no setValue for language
    }

    // 2. isLang is false
    @Test
    void testLanguagePreference_IsLangFalse() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("false");
        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(new JSONObject().put(DocASAPConstants.Key.PATIENT_ID, "456"));
        newPatientHandlerService.createNewPatient(inputObject);
        // Should not fetch language_map
    }

    // 3. isLang is true, language map contains language
    @Test
    void testLanguagePreference_LanguageMapContainsLanguage() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("true");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_map")))
                .thenReturn("{\"english\":\"en-us\"}");
        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(new JSONObject().put(DocASAPConstants.Key.PATIENT_ID, "456"));
        newPatientHandlerService.createNewPatient(inputObject);
        // Should set lan to "en-us"
    }

    // 4. isLang is true, language map does not contain language
    @Test
    void testLanguagePreference_LanguageMapDoesNotContainLanguage() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("true");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_map")))
                .thenReturn("{\"spanish\":\"es\"}");
        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(new JSONObject().put(DocASAPConstants.Key.PATIENT_ID, "456"));
        newPatientHandlerService.createNewPatient(inputObject);
        // Should set lan to "english"
    }

    // 5. isLang is true, language map fetch throws exception
    @Test
    void testLanguagePreference_LanguageMapThrowsException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        inputObject.put(DocASAPConstants.Key.LANGUAGE_PREFERENCE, "EN");
        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("Gender", "M");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        inputObject.put("DemographicData", demographicData);
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("true");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_map")))
                .thenThrow(new RuntimeException("Cache error"));
        when(abletoApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(new JSONObject().put(DocASAPConstants.Key.PATIENT_ID, "456"));
        newPatientHandlerService.createNewPatient(inputObject);
        // Should handle exception and set lan to "english"
    }

    @Test
    void testIsLangFalse() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("false");
        String result = ReflectionTestUtils.invokeMethod(newPatientHandlerService, "getLanguage", "dep1", "EN");
        assertEquals("EN", result);
    }

    @Test
    void testIsLangTrue_LanguageMapContainsLanguage() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("true");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_map")))
                .thenReturn("{\"en\":\"english\"}");
        String result = ReflectionTestUtils.invokeMethod(newPatientHandlerService, "getLanguage", "dep1", "EN");
        assertEquals("english", result);
    }

    @Test
    void testIsLangTrue_LanguageMapDoesNotContainLanguage() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("true");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_map")))
                .thenReturn("{\"fr\":\"fr-fr\"}");
        String result = ReflectionTestUtils.invokeMethod(newPatientHandlerService, "getLanguage", "dep1", "EN");
        assertEquals("EN", result);
    }

    @Test
    void testIsLangTrue_LanguageMapThrowsException() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_pref")))
                .thenReturn("true");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), eq("language_map")))
                .thenThrow(new RuntimeException("Cache error"));
        String result = ReflectionTestUtils.invokeMethod(newPatientHandlerService, "getLanguage", "dep1", "EN");
        assertEquals("EN", result);
    }

    @Test
    void testFormatRequest_ValidSourceMap() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        String sourceMapString = "{\"key1\":\"value1\",\"key2\":\"value2\"}";
        JSONObject source = new JSONObject();

        Method method = NewPatientHandlerService.class.getDeclaredMethod("formatRequest", Object.class, JSONObject.class);
        method.setAccessible(true);

        JSONObject result = (JSONObject) method.invoke(service, sourceMapString, source);

        assertNotNull(result);
        assertEquals("value1", result.getString("key1"));
        assertEquals("value2", result.getString("key2"));
    }

    @Test
    void testFormatRequest_SourceMapThrowsJSONException() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        Object badSourceMap = new Object() {
            @Override
            public String toString() {
                throw new JSONException("Error in toString");
            }
        };
        JSONObject source = new JSONObject();

        Method method = NewPatientHandlerService.class.getDeclaredMethod("formatRequest", Object.class, JSONObject.class);
        method.setAccessible(true);

        JSONObject result = (JSONObject) method.invoke(service, badSourceMap, source);

        // Should return the original source object (empty)
        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void testSetGender_Male() {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtils.when(() -> getValue(any(), eq(GENDER))).thenReturn("M");

            ReflectionTestUtils.invokeMethod(service, "setGender", inputObject);

            jsonUtils.verify(() -> setValue(inputObject, GENDER, "male"), times(1));
        }
    }

    @Test
    void testSetGender_Female() {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtils.when(() -> getValue(any(), eq(GENDER))).thenReturn("F");

            ReflectionTestUtils.invokeMethod(service, "setGender", inputObject);

            jsonUtils.verify(() -> setValue(inputObject, GENDER, "female"), times(1));
        }
    }

    @Test
    void testSetGender_Other() {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtils.when(() -> getValue(any(), eq(GENDER))).thenReturn("X");

            ReflectionTestUtils.invokeMethod(service, "setGender", inputObject);

            jsonUtils.verify(() -> setValue(inputObject, GENDER, "X"), times(1));
        }
    }

    @Test
    void testSetGender_IhubException() {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONObject inputObject = new JSONObject();

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtils.when(() -> getValue(any(), eq(GENDER))).thenReturn("X");
            jsonUtils.when(() -> setValue(inputObject, GENDER, "X")).thenThrow(new IHubException(new IHubErrorCode("500"), "Config not found"));

            ReflectionTestUtils.invokeMethod(service, "setGender", inputObject);
        }
    }

    @Test
    void testCreateNewPatients_Success() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        AbleToApiCaller apiCaller = mock(AbleToApiCaller.class);
        ReflectionTestUtils.setField(service, "abletoApiCaller", apiCaller);

        JSONObject input = new JSONObject();
        input.put(DEPLOYMENT_ID, "dep1");
        input.put("language_preference", "EN");

        JSONObject output = new JSONObject();
        output.put(PATIENT_ID, "p123");

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
             MockedStatic<com.pes.integration.utils.NullChecker> nullChecker = mockStatic(com.pes.integration.utils.NullChecker.class)) {

            jsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("dep1");
            jsonUtils.when(() -> JsonUtils.getValue(any(), eq("language_preference"))).thenReturn("EN");
            nullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);
            jsonUtils.when(() -> JsonUtils.getValue(any(), eq(PATIENT_ID))).thenReturn("p123");

            when(apiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(output);

            JSONObject result = service.createNewPatient(input);
        }
        catch (Exception e) {
            log.error("Success: ", e);
        }
    }
}