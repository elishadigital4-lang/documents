package com.pes.integration.ableto.consumer;

import com.pes.integration.service.AsyncConsumerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;

import static org.mockito.Mockito.*;

class AbleToAsyncConsumerTest {

    @Mock
    private AsyncConsumerService asyncConsumerService;

    @InjectMocks
    private AbleToAsyncConsumer ableToAsyncConsumer;

    @Value("${kafka.sync.data.topic}")
    private String syncDataTopic = "testSyncDataTopic";

    private static final Logger log = LoggerFactory.getLogger(AbleToAsyncConsumer.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Manually set the syncDataTopic value
        ableToAsyncConsumer.syncDataTopic = syncDataTopic;
    }

    @Test
    void testConsumeAsyncMessage() {
        String payload = "testPayload";

        ableToAsyncConsumer.consumeAsyncMessage(payload);

        verify(asyncConsumerService, times(1)).processAsyncMessage(syncDataTopic, payload);
        // Verify log message if necessary
    }

    @Test
    void testListen() {
        String topic = "testTopic.d2e";
        String message = "testMessage";
        String expectedTopic = "testTopic.e2d";

        ableToAsyncConsumer.listen(topic, message);

        verify(asyncConsumerService, times(1)).processAsyncMessage(expectedTopic, message);
        // Verify log message if necessary
    }
}