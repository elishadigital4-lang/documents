package com.pes.integration.ableto.handler;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.api.ApiName;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.pes.integration.ableto.constant.AbleToEngineConstants.*;
import static com.pes.integration.enums.Flow.CANCEL_APPOINTMENT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CancelAppointmentsHandlerServiceTest {

    @Mock
    private AbleToApiCaller ableToApiCaller;

    @Mock
    private DataCacheManager dataCacheManager;

    @InjectMocks
    private CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    private static final Logger log = LoggerFactory.getLogger(CancelAppointmentsHandlerService.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCancelAppointment_Success() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        JSONObject expectedResponse = new JSONObject();
        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        JSONObject response = cancelAppointmentsHandlerService.cancelAppointment(inputObject);

        verify(ableToApiCaller, times(1)).call("123", ApiName.CANCEL_APPOINTMENT.getKey(), inputObject, CANCEL_APPOINTMENT.getKey());
        assertEquals(expectedResponse, response);
    }

    @Test
    void testCancelAppointment_Exception() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "123");
        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("Error"));

        IHubException thrown = assertThrows(IHubException.class, () -> {
            cancelAppointmentsHandlerService.cancelAppointment(inputObject);
        });

        assertEquals(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), thrown.getErrorCode());
        assertEquals("Error", thrown.getMessage());
    }

    @Test
    void testGetCancelReason_Success() throws IHubException {
        String deploymentId = "123";
        JSONObject inputObject = new JSONObject();
        inputObject.put("SchedulingData", new JSONObject().put("Schedule", new JSONArray().put(new JSONObject().put("EventReasonId", "123"))));

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("reason");

        cancelAppointmentsHandlerService.getCancelReason(deploymentId, inputObject);

        verify(dataCacheManager, times(1)).getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, DEFAULT_CANCEL_REASON, false);
        assertEquals("reason", inputObject.getJSONObject("SchedulingData").getJSONArray("Schedule").getJSONObject(0).getString("EventReasonId"));
    }

    @Test
    void testGetCancelReason_IHubException() throws IHubException {
        String deploymentId = "123";
        JSONObject inputObject = new JSONObject();
        IHubException exception = new IHubException(new Exception("Error"), null, "Error");
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenThrow(exception);

        IHubException thrown = assertThrows(IHubException.class, () -> {
            cancelAppointmentsHandlerService.getCancelReason(deploymentId, inputObject);
        });

        assertEquals("Error", thrown.getMessage());
    }

    @Test
    void testGetCancelReason_Exception() throws IHubException {
        String deploymentId = "123";
        JSONObject inputObject = new JSONObject();
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenThrow(new RuntimeException("Error"));

        IHubException thrown = assertThrows(IHubException.class, () -> {
            cancelAppointmentsHandlerService.getCancelReason(deploymentId, inputObject);
        });

        assertEquals(UtilityErrors.ERROR_LOADING_CONFIG.getErrorCode(), thrown.getErrorCode());
        assertEquals("getCancelReason", thrown.getMessage());
    }
}