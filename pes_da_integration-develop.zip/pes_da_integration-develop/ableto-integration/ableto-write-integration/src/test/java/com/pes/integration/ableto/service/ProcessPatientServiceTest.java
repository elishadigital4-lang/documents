package com.pes.integration.ableto.service;

import com.pes.integration.ableto.handler.NewPatientHandlerService;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProcessPatientServiceTest {

    @Mock
    private DataTransactionService dataTransactionService;

    @Mock
    private NewPatientHandlerService newPatientHandlerService;

    @InjectMocks
    private ProcessPatientService processPatientService;

    private static final Logger log = LoggerFactory.getLogger(ProcessPatientService.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreatePatient_Success() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put(APPOINTMENT_SYNC, appointmentSync);
        input.put(DATA, data);

        JSONObject expectedResponse = new JSONObject();
        when(newPatientHandlerService.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        JSONObject response = processPatientService.createPatient(input);

        verify(dataTransactionService, times(1)).logData(input, CREATE_PATIENT.getKey(), CREATED.getKey(), "iHub Create Patient Request Message");
        verify(newPatientHandlerService, times(1)).doExecute(appointment);
        verify(dataTransactionService, times(1)).logData(input, CREATE_PATIENT.getKey(), SUCCESS.getKey(), "iHub Create Patient Successful");
        assertEquals(expectedResponse, response);
    }

    @Test
    void testCreatePatient_IHubException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put(APPOINTMENT_SYNC, appointmentSync);
        input.put(DATA, data);

        IHubException exception = new IHubException(new Exception("Error"), null, "Error");
        when(newPatientHandlerService.doExecute(any(JSONObject.class))).thenThrow(exception);

        IHubException thrown = assertThrows(IHubException.class, () -> {
            processPatientService.createPatient(input);
        });

        verify(dataTransactionService, times(1)).logData(input, CREATE_PATIENT.getKey(), CREATED.getKey(), "iHub Create Patient Request Message");
        verify(dataTransactionService, times(1)).logData(input, CREATE_PATIENT.getKey(), FAILED.getKey(), exception.getMessage());
        verify(newPatientHandlerService, times(1)).doExecute(appointment);
        assertEquals(exception, thrown);
    }

    @Test
    void testUpdatePatient() throws IHubException {
        assertNull(processPatientService.updatePatient(new JSONObject()));
    }

    @Test
    void testSearchPatient() throws IHubException {
        assertNull(processPatientService.searchPatient(new JSONObject()));
    }

    @Test
    void testGetPatient() throws IHubException {
        assertNull(processPatientService.getPatient(new JSONObject()));
    }
}