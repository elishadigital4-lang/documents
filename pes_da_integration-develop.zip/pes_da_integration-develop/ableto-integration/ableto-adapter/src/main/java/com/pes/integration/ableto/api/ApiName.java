package com.pes.integration.ableto.api;

import static java.util.Arrays.stream;

public enum ApiName {
    NEW_PATIENT("new_patient"),
    GET_PATIENT_DEMOGRAPHICS("get_patient_demographics"),
    GET_PATIENT_INSURANCE("get_patient_insurance"),

    CANCEL_APPOINTMENT("cancel_appointment"),
    NEW_APPOINTMENT("new_appointment"),

    GET_LOCATIONS("get_locations"),
    GET_PROVIDERS("get_providers"),
    CHANGED_APPOINTMENTS("changed_appointments"),
    GET_PATIENTS("patient_lookup"),
    GET_APPOINTMENT("get_appointment"),
    SET_PATIENT_INSURANCE("set_patient_insurance"),
    GET_APPOINTMENT_TYPES("get_appointment_types"),
    MOVE_APPOINTMENT("move_appointment"),
    RESCHEDULE_APPOINTMENT("reschedule_appointment");

    String key;

    ApiName(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public ApiName getEnum(String apiName) {
        return stream(values()).filter(api -> api.getKey().equals(apiName)).findFirst().orElse(null);
    }
}
