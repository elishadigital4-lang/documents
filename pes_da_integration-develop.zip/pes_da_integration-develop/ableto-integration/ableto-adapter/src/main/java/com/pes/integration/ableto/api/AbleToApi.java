package com.pes.integration.ableto.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AbleToApi {
    String clientId;
    String clientSecret;
    String audience;
    String grantType;
    String endPoint;
    String tokenUrl;
}
