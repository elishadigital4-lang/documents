package com.pes.integration.ableto.factory;

import com.pes.integration.enums.HandlerType;
import com.pes.integration.factory.BaseHandlerFactory;
import com.pes.integration.handlers.BaseHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
@Slf4j
@Service
@RequiredArgsConstructor
public class AbleToHandlerFactory extends BaseHandlerFactory {
    private final Map<String, BaseHandler> handlerMap = new HashMap<>();

    @Override
    public BaseHandler create(HandlerType handlerType, Object inputObject, Object outputObject) {
        return handlerMap.get(handlerType.getKey());
    }
}
