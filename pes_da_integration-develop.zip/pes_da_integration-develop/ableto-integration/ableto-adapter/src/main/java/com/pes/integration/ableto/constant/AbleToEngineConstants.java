package com.pes.integration.ableto.constant;

/**
 * @author neetoo
 * 
 */
public class AbleToEngineConstants {
	public static final String EPM_NAME_PREFIX = "at";
	public static final String ABLETO_CONFIG = "abletoprop";
	public static final String BLANK = "";
	public static final String RETRY_COUNT = "retrycount";
	public static final String URL = "url";
	public static final String METHOD = "method";
	public static final String CLASS = "@class";
	public static final String NAME = "Name";
	public static final String REQUEST_MAPPING_KEY_NAME = "at_req_map";

	public static final String RESPONSE_MAPPING_KEY_NAME = "at_res_map";
	public static final String REQUEST_CONFIG_KEY_NAME = "at_req_conf";
	public static final String RESPONSE_CODES_MAPPING_KEY_NAME = "at_res_codes";
	public static final String END_POINT = "at_base_url";
	public static final String EPM_TYPE = "ableto";
	public static final String EPM_CONFIG_GROUPS = "RunBaselineSync,AbleTo Properties,Filter Service Config";
	public static final String NUMBER = "Number";
	public static final String PHONE_TYPE = "Type";
	public static final String SYSTEM = "System";

	public static final String FNAME = "DemographicData.PatientInformation[0].PatientFirstName";
	public static final String LNAME = "DemographicData.PatientInformation[0].PatientLastName";
	public static final String COLUMNS = "Columns";
	public static final String RUN_REALTIME_BY_FILTER = "realt_by_fil";
	public static final String DEFAULT_CANCEL_REASON = "defcanreason";

	private AbleToEngineConstants() {
	}
}
