package com.pes.integration.ableto.api;

import com.pes.integration.ableto.component.AbleToClientCaller;
import com.pes.integration.ableto.dto.Token;
import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;

import static com.pes.integration.ableto.constant.AbleToConstants.*;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getMapFromJson;
import static java.lang.System.currentTimeMillis;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;

@Service
@Slf4j
public class AbleToApiCaller extends BaseApiCaller {

    private static Map<String, AbleToApi> ableToApiMap = new HashMap<>();

    @Autowired
    DataCacheManager cacheManager;
    @Autowired
    AbleToClientCaller ableToClientCaller;
    @Autowired
    RedisService redisService;


    @Override
    protected Object callApi(JSONObject apiConfig, JSONObject requestObject) throws IHubException {
        AbleToApi ableToApi = getAbleToApi(requestObject.getString(DEPLOYMENT_ID));
        requestObject.remove(DEPLOYMENT_ID);
        String url = apiConfig.getString(URL);
        String method = apiConfig.getString(METHOD);
        Object responseObject = null;
        Object response = null;
        try {
            Map<String, String> parameters;
            parameters = getMapFromJson(requestObject);
            url =  buildUrl(ableToApi.getEndPoint(), url, parameters);
            long startTime = currentTimeMillis();// Record the start time
            if(method.equals("GET")){
                responseObject = ableToClientCaller.getData(url, getToken(ableToApi));
            }else{
                responseObject = ableToClientCaller.getData(method, url, requestObject.toString(), getToken(ableToApi));
            }
            double executionTimeSeconds = (currentTimeMillis() - startTime) / 1000.0;
            String formattedExecutionTime = String.format("%.2f", executionTimeSeconds);
            log.info("Execution Time For AbleTo_Client_Caller Get_Data: {} seconds", formattedExecutionTime);
            response = new JSONTokener(responseObject.toString()).nextValue();
            if(response instanceof JSONArray){
                response = new JSONArray(responseObject.toString()).getJSONObject(0);
            } else {
                response = new JSONObject(responseObject.toString());

            }
        } catch (Exception e) {
            log.error("Error occurred while calling client api - {} with error message {}", escapeJava(url), e.getCause().getMessage());
            throw new IHubException(e, StatusCodes.EPM_INTERNAL_ERROR, e.getCause().getMessage(), "");
        }
        return response;
    }

    private AbleToApi getAbleToApi(String deploymentId) throws IHubException {
        AbleToApi epicApi = ableToApiMap.getOrDefault(deploymentId, null);
        if (Objects.isNull(epicApi)) {
            return apiCaller(deploymentId);
        }
        return epicApi;
    }

    public AbleToApi apiCaller(String deploymentId) throws IHubException {
        String clientId = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, CLIENT_ID);
        String clientSecret = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, CLIENT_SECRET);
        String audience = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, AUDIENCE);
        String grantType = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, GRANT_TYPE);
        String endPoint = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, END_POINT);
        String tokenUrl = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ABLETO_CONFIG, TOKEN_URL);
        AbleToApi ableToApi = new AbleToApi(clientId, clientSecret, audience, grantType, endPoint, tokenUrl);
        ableToApiMap.put(deploymentId, ableToApi);
        return ableToApi;
    }

    private String getNewUrl(StringTokenizer tokenizer,Map<String, String> parameters){
        String newUrl = "";
        while (tokenizer.hasMoreTokens()) {
            String urlPart = tokenizer.nextToken();
            if(urlPart.startsWith(":")){
                urlPart =  parameters.get(urlPart);
                if(urlPart!=null){
                    parameters.remove(urlPart);
                }
            }
            newUrl+="/"+urlPart;
        }
        return newUrl;
    }

    private String buildUrl(String endPoint, String url, Map<String, String> parameters) {
        StringTokenizer tokenizer = new StringTokenizer(url, "/");
        String newUrl= getNewUrl(tokenizer,parameters);
        if(newUrl.contains("?")){
            int index = newUrl.indexOf('?');
            String baseUrl =  newUrl.substring(0,index);
            Object[] keyArray = parameters.keySet().toArray();
            StringBuilder sb = new StringBuilder();
            for(int i = 0; i < keyArray.length; i++){
                String key = keyArray[i].toString();
                if(url.contains(key)){
                    if(i==0){
                        sb.append(String.format("&%s=%s", key, parameters.get(key)));
                    }else sb.append(String.format("?%s=%s", key, parameters.get(key)));
                }
            }
            newUrl = baseUrl+ sb;
        }
        return String.format("%s%s", endPoint, newUrl);
    }

    @Override
    protected void getMappingConfig(String deploymentId){
        /*
         * not needed for this implementation
         */
    }

    @Override
    protected JSONObject customizeResponseMapping(JSONObject apiResponseMapping, String apiName, Object inputObject) {
        return null;
    }

    private MultiValueMap<String, String> formValues(AbleToApi ableToApi) {
        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        formValues.add("grant_type", ableToApi.getGrantType());
        formValues.add("client_id", ableToApi.getClientId());
        formValues.add("client_secret", ableToApi.getClientSecret());
        formValues.add("audience", ableToApi.getAudience());
        return formValues;
    }

    private String getToken(AbleToApi ableToApi) {
        String token = redisService.get("ableto_token");
        if (StringUtils.isEmpty(token)) {
            return generateToken(ableToApi);
        }
        return token;
    }

    /*
     * Generate the token and update redis with ttl
     */
    private String generateToken(AbleToApi ableToApi) {
        String endPoint = ableToApi.getEndPoint();
        String tokenUrl = ableToApi.getTokenUrl();
        String tokenUri = endPoint.concat(tokenUrl);
        Token token = ableToClientCaller.generateToken(tokenUri, getHttpHeaders(), formValues(ableToApi));
        redisService.saveWithTtl("ableto_token", token.getAccessToken(),
                token.getExpiresIn());
        return token.getAccessToken();
    }

    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.add("AuthType", "Bearer");
        return headers;
    }
}