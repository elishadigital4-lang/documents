package com.pes.integration.ableto.constant;

public class AbleToConstants {
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final String DATE_TIME_FORMAT_AM_PM = "MM/dd/yyyy hh:mm:ss a";
	public static final String TIME_FORMAT = "HH:mm:ss";
	public static final String DATE_TIME_FORMAT_WITHOUT_AM_PM = "MM/dd/yyyy HH:mm:ss";
	public static final String DOB_DATE_FORMAT = "MM/dd/yyyy";
	public static final String ABLETO_DOB_DATE_FORMAT = "YYYY-MM-dd";
	public static final String PATIENTID = "patientId";
	public static final String PRACTITIONERID = "practitionerId";
	public static final String PRACTITIONER = "practitioner";
	public static final String PROVIDERID = "providerId";
	public static final String REASONID = "reasonId";
	public static final String LOCATIONID = "locationId";
	public static final String ISCENTER = "is_center";
	public static final String DURATIONUNIT = "durationUnit";
	public static final String MINUTES = "minutes";
	public static final String DURATION = "duration";
	public static final String AVAILABLETIMESLOTSRESPONSE = "availableTimeslotsResponse";
	public static final String START = "start";
	public static final String AVAILABLETIMESLOTS = "available-time-slots";
	public static final String USR_ID = "at_token_usrid";
	public static final String USR_PSWD = "at_token_pswrd";
	public static final String CLIENT_ID = "at_client_id";
	public static final String CLIENT_SECRET = "at_client_secret";
	public static final String SCOPE = "at_token_scope";
	public static final String GRANT_TYPE = "at_grant_type";
	public static final String TOKEN_END_POINT = "at_token_url";
	public static final String TOKEN_URL = "at_token_url";
	public static final String AUDIENCE = "at_audience";
	public static final String CLIENT_ID_STR = "client_id";
	public static final String CLIENT_SECRET_STR = "client_secret";

	public static final String HOME_PHONE_TYPE_VALUE = "home";
	public static final String WORK_PHONE_TYPE_VALUE = "work";
	public static final String CELL_PHONE_TYPE_VALUE = "cell";

	public static final String TIME_ZONE = "timezone";
	public static final String GRANT_TYPE_STR = "grant_type";
	public static final String MALE = "male";
	public static final String FEMALE = "female";
	public static final String GENDER_M = "M";
	public static final String GENDER_F = "F";
	public static final String REFERRER_SOURCE = "referrer_source_map";
	public static final String REFERRER_TEAM = "referrer_team";
	public static final String TEMP_SOURCE =  "temp.source";
	public static final String TEMP_TEAM =  "temp.team";
	public static final String PAYOR_NAME =  "payor_name";
	public static final String INS_NAME =  "DemographicData.InsuranceInformation[0].InsName";
	public static final String APPOINTMENT_STATUS_FOR_ABLETO = "SchedulingData.Schedule[0].status_id";
	public static final String AUDIENCE_STR = "audience";

	public static final String PHONES = "DemographicData.PatientInformation[0].Phones";

	private AbleToConstants() {
	}

}
