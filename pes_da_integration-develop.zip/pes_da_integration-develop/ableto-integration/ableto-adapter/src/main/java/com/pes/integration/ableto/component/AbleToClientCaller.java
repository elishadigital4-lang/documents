package com.pes.integration.ableto.component;

import com.pes.integration.ableto.dto.Token;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;


import static com.pes.integration.utils.MetricsUtil.metricClientErrorCount;
import static com.pes.integration.utils.MetricsUtil.metricClientRequestCount;
import static com.pes.integration.utils.MetricsUtil.metricClientSuccessCount;
import static org.springframework.http.HttpMethod.valueOf;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.BodyInserters.fromFormData;

@Component
@Slf4j
public class AbleToClientCaller {
    @Autowired
    WebClient webClient;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;

    public static final List<String> IGNORABLE_ERRORS = Arrays.asList("Field was required and is missing or invalid", "Cancel Initial Consulation Failed", "Treatment already booked");

    @Observed(name = "integration.generateToken", contextualName = "integration")
    public Token generateToken(String url, HttpHeaders headers, MultiValueMap<String, String> formValues) {
        metricClientRequestCount(engineName, appDescription, "Token - "+ url);
        return webClient.post()
                .uri(url)
                .headers(h -> h.addAll(headers))
                .body(fromFormData(formValues))
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    "Error status code while calling AbleTo token api is Status code:: {} and errorBody:: {}"
                                    , clientResponse.statusCode(), errorBody);
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,""));
                        }))
                .bodyToMono(Token.class)
                .doOnSuccess(response -> {
                            metricClientSuccessCount(engineName, appDescription, "Token - "+ url);
                    log.info("Successfully fetched token for AbleTo ");
                }
                ).block();
    }

    @Observed(name = "integration.getAbleToApiData", contextualName = "integration")
    public String getData(String httpMethod, String url, String body, String token) {
        ConnectionProvider provider = ConnectionProvider.builder("fixed")
                .maxConnections(500)
                .maxIdleTime(Duration.ofSeconds(20))
                .maxLifeTime(Duration.ofSeconds(60))
                .pendingAcquireTimeout(Duration.ofSeconds(60))
                .evictInBackground(Duration.ofSeconds(120)).build();
        HttpClient httpClient = HttpClient.create(provider);
        httpClient.warmup().block();
        var reactorClientHttpConnector = new ReactorClientHttpConnector(httpClient);
        this.webClient = WebClient.builder()
                .clientConnector(reactorClientHttpConnector)
                .build();
        metricClientRequestCount(engineName, appDescription, httpMethod+" - "+ url);
        return webClient.method(valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .headers(header ->
                        header.setBearerAuth(token))
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    "Error status code while calling AbleTo api is Status code:: {} and errorBody:: {}",
                                    clientResponse.statusCode(), errorBody);
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(
                                    new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,""));
                        }))
                .bodyToMono(String.class)
                .doOnSuccess(response ->{
                        metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                        log.info("Successfully fetched data for AbleTo Api ");
                }
                ).block();
    }
    public String getData(String url,String token) {
        metricClientRequestCount(engineName, appDescription, "Get Method - "+ url);
        return webClient.get()
                .uri(url)
                .headers(header ->
                        header.setBearerAuth(token))
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            log.error(
                                    "Error status code while calling AbleTo api is Status code:: {} and errorBody:: {}",
                                    clientResponse.statusCode(), errorBody);
                            return Mono.error(
                                    new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,""));
                        }))
                .bodyToMono(String.class)
                .doOnSuccess(response -> {
                            metricClientSuccessCount(engineName, appDescription, "Get Method - "+ url);
                    log.info("Successfully fetched data for AbleTo Api ");
                }
                ).block();
    }
}
