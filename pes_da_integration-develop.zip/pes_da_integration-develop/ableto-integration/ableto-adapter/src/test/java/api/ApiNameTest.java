package api;

import com.pes.integration.ableto.api.ApiName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ApiNameTest {
    @Test
    public void testGetKey() {
        assertEquals("patient_lookup", ApiName.GET_PATIENTS.getKey());
        assertEquals("new_patient", ApiName.NEW_PATIENT.getKey());
        assertEquals("get_patient_demographics", ApiName.GET_PATIENT_DEMOGRAPHICS.getKey());
        assertEquals("get_patient_insurance", ApiName.GET_PATIENT_INSURANCE.getKey());
        assertEquals("new_appointment", ApiName.NEW_APPOINTMENT.getKey());
        assertEquals("cancel_appointment", ApiName.CANCEL_APPOINTMENT.getKey());
        assertEquals("reschedule_appointment", ApiName.RESCHEDULE_APPOINTMENT.getKey());
        assertEquals("get_locations", ApiName.GET_LOCATIONS.getKey());
        assertEquals("get_providers", ApiName.GET_PROVIDERS.getKey());
        assertEquals("changed_appointments", ApiName.CHANGED_APPOINTMENTS.getKey());
        assertEquals("get_appointment", ApiName.GET_APPOINTMENT.getKey());
        assertEquals("set_patient_insurance", ApiName.SET_PATIENT_INSURANCE.getKey());
        assertEquals("get_appointment_types", ApiName.GET_APPOINTMENT_TYPES.getKey());
        assertEquals("move_appointment", ApiName.MOVE_APPOINTMENT.getKey());
    }

    @Test
    public void testGetEnum() {
        assertEquals(ApiName.GET_PATIENTS, ApiName.GET_PATIENTS.getEnum("patient_lookup"));
        assertEquals(ApiName.NEW_PATIENT, ApiName.NEW_PATIENT.getEnum("new_patient"));
        assertEquals(ApiName.GET_PATIENT_DEMOGRAPHICS, ApiName.GET_PATIENT_DEMOGRAPHICS.getEnum("get_patient_demographics"));
        assertEquals(ApiName.GET_PATIENT_INSURANCE, ApiName.GET_PATIENT_INSURANCE.getEnum("get_patient_insurance"));
        assertEquals(ApiName.NEW_APPOINTMENT, ApiName.NEW_APPOINTMENT.getEnum("new_appointment"));
        assertEquals(ApiName.CANCEL_APPOINTMENT, ApiName.CANCEL_APPOINTMENT.getEnum("cancel_appointment"));
        assertEquals(ApiName.RESCHEDULE_APPOINTMENT, ApiName.RESCHEDULE_APPOINTMENT.getEnum("reschedule_appointment"));
        assertEquals(ApiName.GET_LOCATIONS, ApiName.GET_LOCATIONS.getEnum("get_locations"));
        assertEquals(ApiName.GET_PROVIDERS, ApiName.GET_PROVIDERS.getEnum("get_providers"));
        assertEquals(ApiName.CHANGED_APPOINTMENTS, ApiName.CHANGED_APPOINTMENTS.getEnum("changed_appointments"));
        assertEquals(ApiName.GET_APPOINTMENT, ApiName.GET_APPOINTMENT.getEnum("get_appointment"));
        assertEquals(ApiName.SET_PATIENT_INSURANCE, ApiName.SET_PATIENT_INSURANCE.getEnum("set_patient_insurance"));
        assertEquals(ApiName.GET_APPOINTMENT_TYPES, ApiName.GET_APPOINTMENT_TYPES.getEnum("get_appointment_types"));
        assertEquals(ApiName.MOVE_APPOINTMENT, ApiName.MOVE_APPOINTMENT.getEnum("move_appointment"));
    }

    @Test
    public void testConstructor() {
        ApiName apiName = ApiName.GET_PATIENTS;
        assertEquals("patient_lookup", apiName.getKey());
    }

}
