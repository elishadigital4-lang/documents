package api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.ableto.api.AbleToApi;
import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.component.AbleToClientCaller;
import com.pes.integration.ableto.dto.Token;
import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import static com.pes.integration.ableto.constant.AbleToEngineConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;

@ExtendWith(MockitoExtension.class)
public class AbleToApiCallerTest {
    @InjectMocks
    private AbleToApiCaller ableToApiCaller;
    @Mock
    AbleToClientCaller ableToClientCaller;

    @Mock
    DataCacheManager cacheManager;

    @Mock
    ObjectMapper mapper;

    @Mock
    RedisService redisService;
    @Mock
    WebClient webClient;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec<?> requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetMappingConfig() throws Exception {
        String deploymentId = "74415^0001";

        JSONObject requestConfigMock = new JSONObject();
        requestConfigMock.put("key", "value");
        lenient().when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ABLETO_CONFIG), eq(REQUEST_CONFIG_KEY_NAME), eq(false)))
                .thenReturn(requestConfigMock);

        JSONObject requestMappingMock = new JSONObject();
        requestMappingMock.put("key", "value");
        lenient().when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ABLETO_CONFIG), eq(REQUEST_MAPPING_KEY_NAME), eq(false)))
                .thenReturn(requestMappingMock);

        JSONObject responseMappingMock = new JSONObject();
        responseMappingMock.put("key", "value");
        lenient().when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ABLETO_CONFIG), eq(RESPONSE_MAPPING_KEY_NAME), eq(false)))
                .thenReturn(responseMappingMock);

        Method method = AbleToApiCaller.class.getDeclaredMethod("getMappingConfig", String.class);
        method.setAccessible(true);
        method.invoke(ableToApiCaller, deploymentId);

        Field requestConfigField = BaseApiCaller.class.getDeclaredField("requestConfig");
        requestConfigField.setAccessible(true);
        JSONObject requestConfig = (JSONObject) requestConfigField.get(ableToApiCaller);
        assertNull(requestConfig);
//        assertEquals("value", requestConfig.getString("key"));

        Field requestMappingField = BaseApiCaller.class.getDeclaredField("requestMapping");
        requestMappingField.setAccessible(true);
        JSONObject requestMapping = (JSONObject) requestMappingField.get(ableToApiCaller);
        assertNull(requestMapping);
//        assertEquals("value", requestMapping.getString("key"));

        Field responseMappingField = BaseApiCaller.class.getDeclaredField("responseMapping");
        responseMappingField.setAccessible(true);
        JSONObject responseMapping = (JSONObject) responseMappingField.get(ableToApiCaller);
        assertNull(responseMapping);
//        assertEquals("value", responseMapping.getString("key"));
    }

    @Test
    void testCustomizeResponseMapping() throws Exception {
        JSONObject apiResponseMapping = new JSONObject();
        String apiName = "testApi";
        Object inputObject = new Object();

        Method method = AbleToApiCaller.class.getDeclaredMethod("customizeResponseMapping", JSONObject.class, String.class, Object.class);
        method.setAccessible(true);
        JSONObject result = (JSONObject) method.invoke(ableToApiCaller, apiResponseMapping, apiName, inputObject);

        assertNull(result);
    }
    @Test
    void testCallApiException() throws Exception {
        Token mockToken = new Token();
        mockToken.setAccessToken("mockAccessToken");
        mockToken.setExpiresIn(3600);
        mockToken.setTokenType("Bearer");
        mockToken.setScope("scope");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.add("AuthType", "Bearer");
        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        formValues.add("grant_type", null);
        formValues.add("client_id", null);
        formValues.add("client_secret", null);
        formValues.add("audience", null);

        JSONObject apiConfig = new JSONObject();
        apiConfig.put("method", "GET");
        apiConfig.put("url", "http://example.com");
        JSONObject requestObject = new JSONObject();
        requestObject.put("deployment_id", "70192^0001");
        lenient().doReturn(mockToken).when(ableToClientCaller).generateToken(eq("http://mocked-endpoint.com/tokenurl/protocols/oauth2/profiles/smart-v1/token")
                , eq(headers), eq(formValues));

        Method method = AbleToApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        lenient().when(ableToClientCaller.getData(anyString(), anyString())).thenThrow(new RuntimeException("Test Exception"));
        assertThrows(Exception.class, () -> method.invoke(ableToApiCaller, apiConfig, requestObject));
    }

    @Test
    void testCallApiException_postCall() throws Exception {
        Token mockToken = new Token();
        mockToken.setAccessToken("mockAccessToken");
        mockToken.setExpiresIn(3600);
        mockToken.setTokenType("Bearer");
        mockToken.setScope("scope");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.add("AuthType", "Bearer");
        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        formValues.add("grant_type", null);
        formValues.add("client_id", null);
        formValues.add("client_secret", null);
        formValues.add("audience", null);

        JSONObject apiConfig = new JSONObject();
        apiConfig.put("method", "POST");
        apiConfig.put("url", "http://example.com");
        JSONObject requestObject = new JSONObject();
        requestObject.put("deployment_id", "70192^0001");
        lenient().doReturn(mockToken).when(ableToClientCaller).generateToken(eq("http://mocked-endpoint.com/tokenurl/protocols/oauth2/profiles/smart-v1/token")
                , eq(headers), eq(formValues));

        Method method = AbleToApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        lenient().when(ableToClientCaller.getData(anyString(), anyString(),anyString(),anyString())).thenThrow(new RuntimeException("Test Exception"));
        assertThrows(Exception.class, () -> method.invoke(ableToApiCaller, apiConfig, requestObject));
    }

    @Test
    void testGetNewUrl() throws Exception {
        String url = ":http://example/key.com?";
        StringTokenizer tokenizer = new StringTokenizer(url, "/");
        Map<String, String> parameters = new HashMap<>();
        parameters.put(":http:", "value");
        parameters.put("key2", "value2");
        Method method = AbleToApiCaller.class.getDeclaredMethod("getNewUrl", StringTokenizer.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, tokenizer, parameters);

        assertNotNull(result);
        assertTrue(result.equals("/value/example/key.com?"));
    }
    @Test
    void testGetNewUrlNoColon() throws Exception {
        String url = "http//example/key.com?";
        StringTokenizer tokenizer = new StringTokenizer(url, "/");
        Map<String, String> parameters = new HashMap<>();
        parameters.put("http", "value");
        parameters.put("key2", "value2");
        Method method = AbleToApiCaller.class.getDeclaredMethod("getNewUrl", StringTokenizer.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, tokenizer, parameters);

        assertNotNull(result);
        assertTrue(result.equals("/http/example/key.com?"));
    }
    @Test
    void testGetNewUrlNullUrlPart() throws Exception {
        String url = ":http://example/key.com?";
        StringTokenizer tokenizer = new StringTokenizer(url, "/");
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key", "value");
        Method method = AbleToApiCaller.class.getDeclaredMethod("getNewUrl", StringTokenizer.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, tokenizer, parameters);

        assertNotNull(result);
        assertTrue(result.equals("/null/example/key.com?"));
    }
    @Test
    void testBuildUrl() throws Exception {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key", "value");
        parameters.put("key2", "value2");
        Method method = AbleToApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, "http://example", "/key.com", parameters);

        assertNotNull(result);
        assertTrue(result.contains("http://example/key.com"));
    }
    @Test
    void getTokenReturnsTokenFromRedis() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        when(redisService.get("ableto_token")).thenReturn("mockToken");
        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "endPoint", "tokenUrl");
        Method method = AbleToApiCaller.class.getDeclaredMethod("getToken", AbleToApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, ableToApi);
        assertNotNull(result);
        assertEquals("mockToken", result);
    }
    @Test
    void generateTokenSuccessfully() throws Exception {
        Token mockToken = new Token();
        mockToken.setAccessToken("mockAccessToken");
        mockToken.setExpiresIn(3600);
        mockToken.setTokenType("Bearer");
        mockToken.setScope("scope");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.add("AuthType", "Bearer");

        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        formValues.add("grant_type", "grantType");
        formValues.add("client_id", "clientId");
        formValues.add("client_secret", "clientSecret");
        formValues.add("audience", "audience");

        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "http://mocked-endpoint.com", "/tokenurl/profiles/smart-v1/token");

        doReturn(mockToken).when(ableToClientCaller).generateToken(eq("http://mocked-endpoint.com/tokenurl/profiles/smart-v1/token"), eq(headers), eq(formValues));

        Method method = AbleToApiCaller.class.getDeclaredMethod("generateToken", AbleToApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, ableToApi);

        assertNotNull(result);
        assertEquals("mockAccessToken", result);
    }

    @Test
    void generateTokenNullToken() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.add("AuthType", "Bearer");

        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        formValues.add("grant_type", "grantType");
        formValues.add("client_id", "clientId");
        formValues.add("client_secret", "clientSecret");
        formValues.add("audience", "audience");

        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "http://mocked-endpoint.com", "/tokenurl/profiles/smart-v1/token");

        doReturn(null).when(ableToClientCaller).generateToken(eq("http://mocked-endpoint.com/tokenurl/profiles/smart-v1/token"), eq(headers), eq(formValues));

        Method method = AbleToApiCaller.class.getDeclaredMethod("generateToken", AbleToApi.class);
        method.setAccessible(true);
        assertThrows(InvocationTargetException.class, () -> method.invoke(ableToApiCaller, ableToApi));
    }

    @Test
    void generateTokenException() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.add("AuthType", "Bearer");

        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        formValues.add("grant_type", "grantType");
        formValues.add("client_id", "clientId");
        formValues.add("client_secret", "clientSecret");
        formValues.add("audience", "audience");

        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "http://mocked-endpoint.com", "/tokenurl/profiles/smart-v1/token");

        doThrow(new RuntimeException("Test Exception")).when(ableToClientCaller).generateToken(eq("http://mocked-endpoint.com/tokenurl/profiles/smart-v1/token"), eq(headers), eq(formValues));

        Method method = AbleToApiCaller.class.getDeclaredMethod("generateToken", AbleToApi.class);
        method.setAccessible(true);
        assertThrows(InvocationTargetException.class, () -> method.invoke(ableToApiCaller, ableToApi));
    }
    private void setField(Object targetObject, String fieldName, Object fieldValue) throws Exception {
        Field field = targetObject.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(targetObject, fieldValue);
    }

    @Test
    void testGetHttpHeaders() throws Exception {
        Method method = AbleToApiCaller.class.getDeclaredMethod("getHttpHeaders");
        method.setAccessible(true);
        HttpHeaders result = (HttpHeaders) method.invoke(ableToApiCaller);

        assertNotNull(result);
        assertEquals("application/x-www-form-urlencoded", result.getContentType().toString());
    }
    @Test
    void buildUrlWithQueryParameters() throws Exception {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key", "value");
        parameters.put("key2", "value2");
        Method method = AbleToApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, "http://example", "/key.com?param1=val1", parameters);

        assertNotNull(result);
        assertTrue(result.contains("http://example/key.com?key=value"));
    }

    @Test
    void buildUrlWithoutQueryParameters() throws Exception {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key", "value");
        parameters.put("key2", "value2");
        Method method = AbleToApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, "http://example", "/key.com", parameters);

        assertNotNull(result);
        assertTrue(result.contains("http://example/key.com"));
    }

    @Test
    void buildUrlWithNullUrlPart() throws Exception {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key", "value");
        Method method = AbleToApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(ableToApiCaller, "http://example", ":http://key.com?", parameters);

        assertNotNull(result);
        assertTrue(result.contains("http://example/null/key.com&key=value"));
    }

    @Test
    void testCallApi_GET_Success() throws Exception {
        // Mock AbleToApi
        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "http://endpoint", "/token");
        // Mock getAbleToApi via reflection
        Method getAbleToApiMethod = AbleToApiCaller.class.getDeclaredMethod("getAbleToApi", String.class);
        getAbleToApiMethod.setAccessible(true);

        // Mock token
        doReturn("mockToken").when(redisService).get(anyString());

        // Mock AbleToClientCaller GET response
        JSONObject mockResponse = new JSONObject();
        mockResponse.put("result", "success");
        doReturn(mockResponse.toString()).when(ableToClientCaller).getData(anyString(), anyString());

        // Prepare input
        JSONObject apiConfig = new JSONObject();
        apiConfig.put("method", "GET");
        apiConfig.put("url", "/test");
        JSONObject requestObject = new JSONObject();
        requestObject.put("deployment_id", "depId");
        requestObject.put("param1", "value1");

        // Call private method
        Method callApiMethod = AbleToApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        callApiMethod.setAccessible(true);
        Object result = callApiMethod.invoke(ableToApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertTrue(result instanceof JSONObject);
        assertEquals("success", ((JSONObject) result).getString("result"));
    }

    @Test
    void testCallApi_POST_Success() throws Exception {
        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "http://endpoint", "/token");
        doReturn("mockToken").when(redisService).get(anyString());

        JSONObject mockResponse = new JSONObject();
        mockResponse.put("result", "posted");
        doReturn(mockResponse.toString()).when(ableToClientCaller).getData(anyString(), anyString(), anyString(), anyString());

        JSONObject apiConfig = new JSONObject();
        apiConfig.put("method", "POST");
        apiConfig.put("url", "/test");
        JSONObject requestObject = new JSONObject();
        requestObject.put("deployment_id", "depId");
        requestObject.put("param1", "value1");

        Method callApiMethod = AbleToApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        callApiMethod.setAccessible(true);
        Object result = callApiMethod.invoke(ableToApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertTrue(result instanceof JSONObject);
        assertEquals("posted", ((JSONObject) result).getString("result"));
    }

    @Test
    void testCallApi_ThrowsException() throws Exception {
        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "http://endpoint", "/token");
        doReturn("mockToken").when(redisService).get(anyString());

        doThrow(new RuntimeException("Test Exception")).when(ableToClientCaller).getData(anyString(), anyString());

        JSONObject apiConfig = new JSONObject();
        apiConfig.put("method", "GET");
        apiConfig.put("url", "/test");
        JSONObject requestObject = new JSONObject();
        requestObject.put("deployment_id", "depId");
        requestObject.put("param1", "value1");

        Method callApiMethod = AbleToApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        callApiMethod.setAccessible(true);

        assertThrows(Exception.class, () -> callApiMethod.invoke(ableToApiCaller, apiConfig, requestObject));
    }

}
