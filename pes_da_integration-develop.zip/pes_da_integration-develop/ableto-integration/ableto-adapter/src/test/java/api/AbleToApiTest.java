package api;

import com.pes.integration.ableto.api.AbleToApi;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class AbleToApiTest {

    @Test
    void testNoArgsConstructor() {
        AbleToApi ableToApi = new AbleToApi();
        assertNull(ableToApi.getClientId());
        assertNull(ableToApi.getClientSecret());
        assertNull(ableToApi.getAudience());
        assertNull(ableToApi.getGrantType());
        assertNull(ableToApi.getEndPoint());
        assertNull(ableToApi.getTokenUrl());
    }

    @Test
    void testAllArgsConstructor() {
        AbleToApi ableToApi = new AbleToApi("clientId", "clientSecret", "audience", "grantType", "endPoint", "tokenUrl");
        assertEquals("clientId", ableToApi.getClientId());
        assertEquals("clientSecret", ableToApi.getClientSecret());
        assertEquals("audience", ableToApi.getAudience());
        assertEquals("grantType", ableToApi.getGrantType());
        assertEquals("endPoint", ableToApi.getEndPoint());
        assertEquals("tokenUrl", ableToApi.getTokenUrl());
    }

    @Test
    void testSettersAndGetters() {
        AbleToApi ableToApi = new AbleToApi();
        ableToApi.setClientId("clientId");
        ableToApi.setClientSecret("clientSecret");
        ableToApi.setAudience("audience");
        ableToApi.setGrantType("grantType");
        ableToApi.setEndPoint("endPoint");
        ableToApi.setTokenUrl("tokenUrl");

        assertEquals("clientId", ableToApi.getClientId());
        assertEquals("clientSecret", ableToApi.getClientSecret());
        assertEquals("audience", ableToApi.getAudience());
        assertEquals("grantType", ableToApi.getGrantType());
        assertEquals("endPoint", ableToApi.getEndPoint());
        assertEquals("tokenUrl", ableToApi.getTokenUrl());
    }
}