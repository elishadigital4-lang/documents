import com.pes.integration.ableto.AbleToInitEngine;
import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.exceptions.IHubException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.*;

public class AbleToInitEngineTest {

    @Mock
    private BaseInitEngine baseInitEngine;

    @InjectMocks
    private AbleToInitEngine ableToInitEngine;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testInit() throws IHubException {
        doNothing().when(baseInitEngine).initializeConfig(EPM_NAME_PREFIX, false);

        ableToInitEngine.init();

        verify(baseInitEngine).initializeConfig(EPM_NAME_PREFIX, false);
    }
}
