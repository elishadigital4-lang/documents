package component;
import com.pes.integration.ableto.component.AbleToClientCaller;
import com.pes.integration.ableto.dto.Token;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.reactive.ClientHttpResponse;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.lang.reflect.Field;
import java.util.function.Function;

import static com.pes.integration.constant.UtilitiesConstants.GET;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AbleToClientCallerTest {

    private WebClient webClient;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    WebClient.RequestHeadersSpec requestHeadersSpec1;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private ClientHttpResponse clientHttpResponse;

    @InjectMocks
    private AbleToClientCaller ableToClientCaller;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        webClient = mock(WebClient.class);
        setField(ableToClientCaller, "webClient", webClient);
    }

    private void setField(Object targetObject, String fieldName, Object fieldValue) throws Exception {
        Field field = targetObject.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(targetObject, fieldValue);
    }

    @Test
    void generateTokenReturnsValidToken() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            Token expectedToken = new Token();
            expectedToken.setExpiresIn(3600);
            expectedToken.setAccessToken("token");
            MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
            formValues.add("grant_type", null);
            formValues.add("client_id", null);
            formValues.add("client_secret", null);
            formValues.add("audience", null);


            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.just(expectedToken));

            Token result = ableToClientCaller.generateToken(url, headers, formValues);

            assertEquals(expectedToken, result);
        }
    }

    @Test
    void generateTokenHandlesErrorResponse() {

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            String errorBody = "Invalid request";
            MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
            formValues.add("grant_type", null);
            formValues.add("client_id", null);
            formValues.add("client_secret", null);
            formValues.add("audience", null);


            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.error(new RuntimeException(errorBody)));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> ableToClientCaller.generateToken(url, headers, formValues));

            Assertions.assertEquals(errorBody, exception.getMessage());
        }
    }

    @Test
    void testGenerateToken_Error() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            String errorBody = "400 Bad Request";
            MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
            formValues.add("grant_type", null);
            formValues.add("client_id", null);
            formValues.add("client_secret", null);
            formValues.add("audience", null);

            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.error(new WebClientResponseException(400,
                    "Bad Request", null, null, null)));

            Exception exception = assertThrows(RuntimeException.class, () -> ableToClientCaller.generateToken(url, headers, formValues));

            Assertions.assertEquals(errorBody, exception.getMessage());
        }
    }

//   @Test
//void getDataReturnsValidResponse() {
//    try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
//        mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
//                .thenAnswer(invocation -> null);
//        String httpMethod = "POST";
//        String url = "http://example.com/data";
//        String body = "requestBody";
//        String token = "validToken";
//        ClientResponse clientResponse = mock(ClientResponse.class);
//        Mono<ClientResponse> clientResponseMono = Mono.just(clientResponse);
//
//        // Ensure non-null arguments are passed to metricClientSuccessCount
//        mockedStatic.when(() -> MetricsUtil.metricClientSuccessCount(anyString(), anyString(), anyString()))
//                .thenAnswer(invocation -> null);
//
//        when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
//        when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just("Success Response"));
//
//        String result = ableToClientCaller.getData(httpMethod, url, body, token);
//        assertEquals("Success Response", result);
//    }
//}
    @Test
    void getData_throwsIHubExceptionOnClientError() {
        HttpHeaders headers = new HttpHeaders();
        String httpMethod = GET;
        String url = "http://example.com";
        headers.add("Authorization", "Bearer token");
        lenient().when(webClient.method(HttpMethod.valueOf(httpMethod))).thenAnswer(reqMethod -> requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        lenient().when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        lenient().when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        lenient().when(requestBodySpec.body(any(), eq(String.class))).thenAnswer(reqBody ->requestHeadersSpec);
        lenient().when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        lenient().when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        lenient().when(responseSpec.bodyToMono(eq(String.class))).thenReturn(Mono.error(new IHubException(new IHubErrorCode("400"), "Bad Request")));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            assertThrows(Exception.class, () ->
                    ableToClientCaller.getData(httpMethod, url, "{}", "token")
            );
        }

    }
    @Test
    void testGetData_SuccessfulResponse() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
        lenient().when(webClient.get()).thenReturn(requestHeadersUriSpec);
        lenient().when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.headers(any())).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        lenient().when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        lenient().when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("Success Response"));
        String result = ableToClientCaller.getData("http://example.com", "token");
        assertEquals("Success Response",result);
        }
    }

    @Test
    void testGetData_ErrorResponse() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            lenient().when(webClient.get()).thenReturn(requestHeadersUriSpec);
            lenient().when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersSpec);
            lenient().when(requestHeadersSpec.headers(any())).thenReturn(requestHeadersSpec);
            lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            lenient().when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            lenient().when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.empty());
            String result = ableToClientCaller.getData("http://example.com", "token");
            assertNull(result);
        }
    }

    @Test
    void testGetData_ClientErrorStatusCode() {
        lenient().when(webClient.get()).thenReturn(requestHeadersUriSpec);
        lenient().when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.headers(any())).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        lenient().when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        lenient().when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(new IHubErrorCode("400"), "Error")));
        assertThrows(Exception.class, () ->
                ableToClientCaller.getData("http://example.com", "token")
        );
    }
    @Test
    void testGetData_ServerErrorStatusCode() {
        lenient().when(webClient.get()).thenReturn(requestHeadersUriSpec);
        lenient().when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.headers(any())).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        lenient().when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        lenient().when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(new IHubErrorCode("500"),"Server error")));
        assertThrows(Exception.class, () ->
                ableToClientCaller.getData("http://example.com", "token")
        );
    }
    @Test
    void getDataExceptionOnErrorStatus() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer token");
        String url = "http://example.com";
        String httpMethod = GET;
        String errorBody = "Error occurred";

        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        lenient().when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        lenient().when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        lenient().when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<Throwable>> errorFunction = invocation.getArgument(1);
            ClientResponse clientResponse = mock(ClientResponse.class);
            lenient().when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
            lenient().when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
            return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(),
                    errorBody));
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Exception exception = assertThrows(Exception.class, () -> {
                ableToClientCaller.getData(url, "token");
            });
        }
    }

    @Test
    void generateToken_onStatusError_shouldLogErrorAndCallRecordErrorMetrics() throws Exception {
        String url = "http://example.com/token";
        HttpHeaders headers = new HttpHeaders();
        MultiValueMap<String, String> formValues = new LinkedMultiValueMap<>();
        String deploymentId = "depId";

        try (MockedStatic<MDC> mdcMockedStatic = mockStatic(MDC.class);
             MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            mdcMockedStatic.when(() -> MDC.get(anyString())).thenReturn(deploymentId);

            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            String errorBody = "server_error";
            // Simulate onStatus error
            when(responseSpec.onStatus(any(), any())).then(invocation -> {
                java.util.function.Predicate<HttpStatus> predicate = invocation.getArgument(0);
                java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
                if (predicate.test(HttpStatus.INTERNAL_SERVER_ERROR)) {
                    ClientResponse clientResponse = mock(ClientResponse.class);
                    when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
                    when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
                    Mono<? extends Throwable> errorMono = function.apply(clientResponse);
                    throw errorMono.block();
                }
                return responseSpec;
            });

            assertThrows(IHubException.class, () -> {
                try {
                    ableToClientCaller.generateToken(url, headers, formValues);
                } catch (Exception e) {
                    // Unwrap if wrapped by reactor
                    Throwable cause = e.getCause();
                    if (cause instanceof IHubException) {
                        throw (IHubException) cause;
                    }
                    throw e;
                }
            });
        }
    }

    @Test
    void testGetData_onStatusError_logsErrorAndThrowsIHubException() {
        String url = "http://example.com/resource?param=value";
        String token = "testToken";
        String deploymentId = "deploymentId";
        String errorBody = "error body";
        ClientResponse mockClientResponse = mock(ClientResponse.class);

        try (MockedStatic<MDC> mdcMockedStatic = mockStatic(MDC.class)) {
            mdcMockedStatic.when(() -> MDC.get(anyString())).thenReturn(deploymentId);

            when(webClient.get()).thenReturn(requestHeadersUriSpec);
            when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.headers(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

            when(responseSpec.onStatus(any(), any())).then(invocation -> {
                java.util.function.Predicate<HttpStatusCode> predicate = invocation.getArgument(0);
                java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
                if (predicate.test(HttpStatus.BAD_REQUEST)) {
                    when(mockClientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
                    when(mockClientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
                    Mono<? extends Throwable> errorMono = function.apply(mockClientResponse);
                    throw errorMono.block();
                }
                return responseSpec;
            });

            try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
                metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCountWithDeploymentId(anyString(), anyString(), anyString(), anyString()))
                        .thenAnswer(invocation -> null);
                assertThrows(IHubException.class, () -> {
                    try {
                        ableToClientCaller.getData(url, token);
                    } catch (Exception e) {
                        Throwable cause = e.getCause();
                        if (cause instanceof IHubException) {
                            throw (IHubException) cause;
                        }
                        throw e;
                    }
                });
            }
        }
    }
}
