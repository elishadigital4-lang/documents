package com.pes.integration.ableto.consumer;

import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;

import static org.mockito.Mockito.*;

class SendSyncDataConsumerTest {

    @Mock
    private SyncDataConsumerService syncDataConsumerService;

    @InjectMocks
    private SendSyncDataConsumer sendSyncDataConsumer;

    private static final Logger log = LoggerFactory.getLogger(SendSyncDataConsumer.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testConsumeSendSyncDataMessage() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String payload = "testPayload";

            sendSyncDataConsumer.consumeSendSyncDataMessage(payload);

            verify(syncDataConsumerService, times(1)).processSendSyncData(payload);
            // Verify log message if necessary
        }
    }

    @Test
    void testListen() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String topic = "testTopic";
            String message = "testMessage";

            sendSyncDataConsumer.listen(topic, message);

            verify(syncDataConsumerService, times(1)).processSendSyncData(message);
            // Verify log message if necessary
        }
    }
}