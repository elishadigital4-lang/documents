package com.pes.integration.ableto.task;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.exceptions.EpmApiCallerException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static com.pes.integration.ableto.constant.AbleToConstants.*;
import static com.pes.integration.constant.EpmConstant.DATE_KEY;
import static com.pes.integration.constant.EpmConstant.START_TIME;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RealTimeOpenSlotsTaskTest {

    @Mock
    private AbleToApiCaller ableToApiCaller;

    @Mock
    private JSONObject inputParam;

    @InjectMocks
    private RealTimeOpenSlotsTask realTimeOpenSlotsTask;

    private String epmPrefix = "EPM_NAME_PREFIX";
    private String deploymentId = "74654^0001";
    private String engineName="ableto";

    private String appDescription="AbleTo Availability Integration";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        realTimeOpenSlotsTask = new RealTimeOpenSlotsTask(ableToApiCaller, inputParam, deploymentId,engineName,appDescription);
    }

    @Test
    void testGet_Success() throws Exception {
        // Mock the response from ableToApiCaller
        JSONObject responseObject = new JSONObject();
        responseObject.put(AVAILABLETIMESLOTSRESPONSE, new JSONArray());
        responseObject.put(PRACTITIONER, new JSONObject());

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(responseObject);

        // Invoke the method
        JSONArray result = realTimeOpenSlotsTask.get();

        // Assert the result
        assertNotNull(result);
    }

    @Test
    void testGet_EpmApiCallerException() throws Exception {
        // Mock the response from ableToApiCaller to throw an exception
        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new EpmApiCallerException("Error"));

        // Assert that the method throws an exception
        assertThrows(EpmApiCallerException.class, () -> {
            realTimeOpenSlotsTask.get();
        });
    }

    @Test
    void testGet_EmptyResponse() throws Exception {
        // Mock the response from ableToApiCaller
        JSONObject responseObject = new JSONObject();

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(responseObject);

        // Invoke the method
        JSONArray result = realTimeOpenSlotsTask.get();

        // Assert the result
        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void testGet_ResponseWithoutRequiredFields() throws Exception {
        // Mock the response from ableToApiCaller
        JSONObject responseObject = new JSONObject();
        responseObject.put(AVAILABLETIMESLOTSRESPONSE, new JSONArray());

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(responseObject);

        // Invoke the method
        JSONArray result = realTimeOpenSlotsTask.get();

        // Assert the result
        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void testExtractSlots() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException{
        // Mock input parameters
        when(inputParam.optString(DURATION)).thenReturn("60");
        when(inputParam.optString(LOCATIONID)).thenReturn("telehealth");
        when(inputParam.optString(REASONID)).thenReturn("123");
        when(inputParam.optString(PRACTITIONERID)).thenReturn("77738126-ee36-4d3f-93dd-bde8ae2ea5b9");

        // Create appointmentSlot
        JSONObject appointmentSlot = new JSONObject();
        appointmentSlot.put("start", "2024-09-23T18:00:00.000Z");
        appointmentSlot.put("end", "2024-09-23T19:00:00.000Z");

        // Create appointmentObject
        JSONArray appointmentObject = new JSONArray();
        appointmentObject.put(appointmentSlot);

        // Expected output
        JSONObject expectedAppt = new JSONObject();
        expectedAppt.put(DATE_KEY, "2024-09-23T00:00:00");
        expectedAppt.put(DURATION, "60");
        expectedAppt.put(ISCENTER, 0);
        expectedAppt.put(REASONID, "123");
        expectedAppt.put(LOCATIONID, "telehealth");
        expectedAppt.put(PROVIDERID, "77738126-ee36-4d3f-93dd-bde8ae2ea5b9");
        expectedAppt.put(START_TIME, "1800");
        expectedAppt.put(DURATIONUNIT, "minutes");

        JSONArray expectedOpenAppointmentsArray = new JSONArray();
        expectedOpenAppointmentsArray.put(expectedAppt);

        // Use reflection to call the private method
        Method method = RealTimeOpenSlotsTask.class.getDeclaredMethod("extractSlots", JSONArray.class);
        method.setAccessible(true);
        JSONArray result = (JSONArray) method.invoke(realTimeOpenSlotsTask, appointmentObject);

        // Assert the result
        assertEquals(expectedOpenAppointmentsArray.toString(), result.toString());
    }

    @Test
    void testExtractSlots_ParseException() throws NoSuchMethodException{
        // Mock input parameters
        when(inputParam.optString(DURATION)).thenReturn("60");
        when(inputParam.optString(LOCATIONID)).thenReturn("telehealth");
        when(inputParam.optString(REASONID)).thenReturn("123");
        when(inputParam.optString(PRACTITIONERID)).thenReturn("77738126-ee36-4d3f-93dd-bde8ae2ea5b9");

        // Create appointmentSlot with invalid date format to trigger ParseException
        JSONObject appointmentSlot = new JSONObject();
        appointmentSlot.put("start", "invalid-date-format");
        appointmentSlot.put("end", "2024-09-23T19:00:00.000Z");

        // Create appointmentObject
        JSONArray appointmentObject = new JSONArray();
        appointmentObject.put(appointmentSlot);

        // Use reflection to call the private method
        Method method = RealTimeOpenSlotsTask.class.getDeclaredMethod("extractSlots", JSONArray.class);
        method.setAccessible(true);

        // Assert that the method throws an exception
        assertThrows(InvocationTargetException.class, () -> {
            method.invoke(realTimeOpenSlotsTask, appointmentObject);
        });
    }
}