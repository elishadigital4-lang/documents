package com.pes.integration.ableto.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import static com.pes.integration.ableto.constant.AbleToConstants.*;
import static com.pes.integration.constant.EpmConstant.ENDDATE;
import static com.pes.integration.constant.EpmConstant.STARTDATE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OpenAppointmentServiceImplTest {

    @Mock
    private AbleToApiCaller ableToApiCaller;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private OpenAppointmentServiceImpl openAppointmentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFetchOpenAppointments_ObjectMapperNotNull() throws Exception {
        // Create a test RealTimeRequest object
        RealTimeRequest request = new RealTimeRequest();
        request.setDeploymentId("74654^0001");
        request.setEntityId(List.of("123", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9"));

        // Mock the behavior of dataCacheManager and objectMapper
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("configValue");
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(mock(ObjectWriter.class));
        when(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(any())).thenReturn("[{\"providerId\":\"77738126-ee36-4d3f-93dd-bde8ae2ea5b9\",\"reasonId\":\"123\"}]");

        // Mock the responseObject from ableToApiCaller
        JSONObject responseObject = new JSONObject();
        JSONObject practitioner = new JSONObject();
        practitioner.put("gender", "F");
        practitioner.put("givenName", "First222326");
        practitioner.put("familyName", "Last222326");
        responseObject.put("practitioner", practitioner);

        JSONArray availableTimeslotsResponse = new JSONArray();
        JSONObject timeslot1 = new JSONObject();
        timeslot1.put("start", "2024-09-23T18:00:00.000Z");
        timeslot1.put("end", "2024-09-23T19:00:00.000Z");
        availableTimeslotsResponse.put(timeslot1);

        JSONObject timeslot2 = new JSONObject();
        timeslot2.put("start", "2024-09-24T12:00:00.000Z");
        timeslot2.put("end", "2024-09-24T13:00:00.000Z");
        availableTimeslotsResponse.put(timeslot2);

        responseObject.put("availableTimeslotsResponse", availableTimeslotsResponse);

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(responseObject);

        // Use reflection to access the private method
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", AbleToApiCaller.class, RealTimeRequest.class, String.class);
        method.setAccessible(true);

        // Invoke the private method
        JSONArray result = (JSONArray) method.invoke(openAppointmentService, ableToApiCaller, request, "EPM_NAME_PREFIX");

        // Assert the result
        assertNotNull(result);
        assertEquals(2, result.length());
    }

    @Test
    void testFetchOpenAppointments_Exception() throws IHubException, NoSuchMethodException {
        // Create a test RealTimeRequest object
        RealTimeRequest request = new RealTimeRequest();
        request.setDeploymentId("74654^0001");
        request.setEntityId(List.of("123", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9"));

        // Mock the behavior of dataCacheManager
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("configValue");

        // Use reflection to access the private method
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", AbleToApiCaller.class, RealTimeRequest.class, String.class);
        method.setAccessible(true);

        // Assert that the method throws an exception
        assertThrows(InvocationTargetException.class, () -> {
            method.invoke(openAppointmentService, ableToApiCaller, request, "EPM_NAME_PREFIX");
        });
    }

    @Test
    void testFetchOpenAppointments_JsonProcessingException() throws Exception {
        // Create a test RealTimeRequest object
        RealTimeRequest request = new RealTimeRequest();
        request.setDeploymentId("74654^0001");
        request.setEntityId(List.of("123", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9"));

        // Mock the behavior of dataCacheManager and objectMapper
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("configValue");
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(mock(ObjectWriter.class));
        when(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(any())).thenThrow(new JsonProcessingException("Error") {});

        // Use reflection to access the private method
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", AbleToApiCaller.class, RealTimeRequest.class, String.class);
        method.setAccessible(true);

        // Assert that the method throws an exception
        assertThrows(InvocationTargetException.class, () -> {
            method.invoke(openAppointmentService, ableToApiCaller, request, "EPM_NAME_PREFIX");
        });
    }

    @Test
    void testGetInputObject_Success() throws Exception {
        // Create a test RealTimeRequest object
        RealTimeRequest request = new RealTimeRequest();
        request.setStartDate("2024-08-25");
        request.setEndDate("2024-08-30");

        // Create a test providerReasonObj
        JSONObject providerReasonObj = new JSONObject();
        providerReasonObj.put("providerId", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9");
        providerReasonObj.put("reasonId", "123");

        // Mock the behavior of dataCacheManager
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("configValue");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        // Use reflection to access the private method
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("getInputObject", JSONObject.class, RealTimeRequest.class, String.class, String.class);
        method.setAccessible(true);

        // Invoke the private method
        JSONObject result = (JSONObject) method.invoke(openAppointmentService, providerReasonObj, request, "74654^0001", "EPM_NAME_PREFIX");

        // Assert the result
        assertNotNull(result);
        assertEquals("2024-08-25", result.getString(STARTDATE));
        assertEquals("2024-08-30", result.getString(ENDDATE));
        assertEquals("configValue", result.getString(DURATION));
        assertEquals("configValue", result.getString(LOCATIONID));
        assertEquals("77738126-ee36-4d3f-93dd-bde8ae2ea5b9", result.getString(PRACTITIONERID));
        assertEquals("123", result.getString(REASONID));
    }

    @Test
    void testGetRealTimeAvailability_Success() throws Exception {
        RealTimeRequest request = new RealTimeRequest();
        request.setEndDate("2024-08-30");
        request.setEntityType("provider/reason");
        request.setDeploymentId("74654^0001");
        request.setEntityId(List.of("123", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9"));
        request.setMessageControlId("msg-test");
        request.setStartDate("2024-08-25");
        request.setFlow("RealTime");

        // Mock the behavior of dataCacheManager and objectMapper
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("configValue");
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(mock(ObjectWriter.class));
        when(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(any())).thenReturn("[{\"providerId\":\"77738126-ee36-4d3f-93dd-bde8ae2ea5b9\",\"reasonId\":\"123\"}]");

        // Mock the responseObject from ableToApiCaller
        JSONObject responseObject = new JSONObject();
        JSONObject practitioner = new JSONObject();
        practitioner.put("gender", "F");
        practitioner.put("givenName", "First222326");
        practitioner.put("familyName", "Last222326");
        responseObject.put("practitioner", practitioner);

        JSONArray availableTimeslotsResponse = new JSONArray();
        JSONObject timeslot1 = new JSONObject();
        timeslot1.put("start", "2024-09-23T18:00:00.000Z");
        timeslot1.put("end", "2024-09-23T19:00:00.000Z");
        availableTimeslotsResponse.put(timeslot1);

        JSONObject timeslot2 = new JSONObject();
        timeslot2.put("start", "2024-09-24T12:00:00.000Z");
        timeslot2.put("end", "2024-09-24T13:00:00.000Z");
        availableTimeslotsResponse.put(timeslot2);

        responseObject.put("availableTimeslotsResponse", availableTimeslotsResponse);

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(responseObject);

        JSONObject result = openAppointmentService.getRealTimeAvailability(request);

        assertNotNull(result);
    }

    @Test
    void testGetAvailability() throws Exception {
        AvailabilityRequest request = new AvailabilityRequest();
        Map<String, JSONArray> providerLocationMap = Map.of();
        String epmPrefix = "EPM_NAME_PREFIX";

        JSONArray result = openAppointmentService.getAvailability(request, providerLocationMap, epmPrefix);

        assertNull(result);
    }

    @Test
    void testFetchOpenAppointments_EmptyEntityId() throws Exception {
        // Create a test RealTimeRequest object with empty entityId
        RealTimeRequest request = new RealTimeRequest();
        request.setDeploymentId("74654^0001");
        request.setEntityId(List.of());

        // Mock the behavior of dataCacheManager and objectMapper
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("configValue");
        ObjectWriter mockObjectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(mockObjectWriter);
        when(mockObjectWriter.writeValueAsString(any())).thenReturn("[{\"providerId\":\"77738126-ee36-4d3f-93dd-bde8ae2ea5b9\",\"reasonId\":\"123\"}]");

        // Mock the responseObject from ableToApiCaller
        JSONObject responseObject = new JSONObject();
        JSONObject practitioner = new JSONObject();
        practitioner.put("gender", "F");
        practitioner.put("givenName", "First222326");
        practitioner.put("familyName", "Last222326");
        responseObject.put("practitioner", practitioner);

        JSONArray availableTimeslotsResponse = new JSONArray();
        JSONObject timeslot1 = new JSONObject();
        timeslot1.put("start", "2024-09-23T18:00:00.000Z");
        timeslot1.put("end", "2024-09-23T19:00:00.000Z");
        availableTimeslotsResponse.put(timeslot1);

        JSONObject timeslot2 = new JSONObject();
        timeslot2.put("start", "2024-09-24T12:00:00.000Z");
        timeslot2.put("end", "2024-09-24T13:00:00.000Z");
        availableTimeslotsResponse.put(timeslot2);

        responseObject.put("availableTimeslotsResponse", availableTimeslotsResponse);

        when(ableToApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(responseObject);

        // Use reflection to access the private method
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", AbleToApiCaller.class, RealTimeRequest.class, String.class);
        method.setAccessible(true);

        // Invoke the private method
        JSONArray result = (JSONArray) method.invoke(openAppointmentService, ableToApiCaller, request, "EPM_NAME_PREFIX");

        // Assert the result
        assertNotNull(result);
        assertEquals(2, result.length());
    }

    @Test
    void testGetInputObject_EmptyReasonId() throws Exception {
        // Create a test RealTimeRequest object
        RealTimeRequest request = new RealTimeRequest();
        request.setStartDate("2024-08-25");
        request.setEndDate("2024-08-30");

        // Create a test providerReasonObj with empty reasonId
        JSONObject providerReasonObj = new JSONObject();
        providerReasonObj.put("providerId", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9");
        providerReasonObj.put("reasonId", "");

        // Mock the behavior of dataCacheManager
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("configValue");
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        // Use reflection to access the private method
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("getInputObject", JSONObject.class, RealTimeRequest.class, String.class, String.class);
        method.setAccessible(true);

        // Invoke the private method
        JSONObject result = (JSONObject) method.invoke(openAppointmentService, providerReasonObj, request, "74654^0001", "EPM_NAME_PREFIX");

        // Assert the result
        assertNotNull(result);
        assertEquals("2024-08-25", result.getString(STARTDATE));
        assertEquals("2024-08-30", result.getString(ENDDATE));
        assertEquals("configValue", result.getString(DURATION));
        assertEquals("configValue", result.getString(LOCATIONID));
        assertEquals("77738126-ee36-4d3f-93dd-bde8ae2ea5b9", result.getString(PRACTITIONERID));
        assertEquals("configValue", result.getString(REASONID));
    }
}