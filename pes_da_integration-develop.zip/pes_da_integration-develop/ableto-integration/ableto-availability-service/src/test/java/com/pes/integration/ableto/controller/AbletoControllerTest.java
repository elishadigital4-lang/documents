package com.pes.integration.ableto.controller;

import com.pes.integration.ableto.service.OpenAppointmentServiceImpl;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.IHubDataApiException;
import com.pes.integration.utils.MetricsUtil;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.OK;

class AbletoControllerTest {

    @Mock
    private OpenAppointmentServiceImpl openAppointmentService;

    @InjectMocks
    private AbletoController abletoController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetRealTimeData_Success() throws Exception {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricRealTimeRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            RealTimeRequest request = new RealTimeRequest();
            request.setEndDate("2024-08-30");
            request.setEntityType("provider/reason");
            request.setDeploymentId("74654^0001");
            request.setEntityId(List.of("123", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9"));
            request.setMessageControlId("msg-test");
            request.setStartDate("2024-08-25");
            request.setFlow("RealTime");

            JSONObject mockResponse = new JSONObject();
            mockResponse.put("key", "value");

            when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class))).thenReturn(mockResponse);

            ResponseEntity<Object> response = abletoController.getRealTimeData(request);

            assertEquals(OK, response.getStatusCode());
            assertEquals(mockResponse.toString(), response.getBody());
        }
    }
    @Test
    void testGetRealTimeData_Exception() throws Exception {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricRealTimeRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            RealTimeRequest request = new RealTimeRequest();
            request.setEndDate("2024-08-30");
            request.setEntityType("provider/reason");
            request.setDeploymentId("74654^0001");
            request.setEntityId(List.of("123", "77738126-ee36-4d3f-93dd-bde8ae2ea5b9"));
            request.setMessageControlId("msg-test");
            request.setStartDate("2024-08-25");
            request.setFlow("RealTime");

            doThrow(new IHubDataApiException("Error")).when(openAppointmentService).getRealTimeAvailability(any(RealTimeRequest.class));

            try {
                abletoController.getRealTimeData(request);
            } catch (IHubDataApiException e) {
                assertEquals("Error", e.getMessage());
            }
        }
    }
}