package com.pes.integration.ableto.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.ableto.component.AbleToClientCaller;
import com.pes.integration.ableto.task.RealTimeOpenSlotsTask;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.AppointmentService;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

import static com.pes.integration.ableto.constant.AbleToConstants.*;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeErrorCount;
import static java.util.Objects.nonNull;
import static com.pes.integration.utils.NullChecker.isEmpty;

import static com.pes.integration.constant.EpmConstant.OPEN_APPOINTMENT;
import static com.pes.integration.constant.EpmConstant.STARTDATE;
import static com.pes.integration.constant.EpmConstant.ENDDATE;
import static com.pes.integration.ableto.constant.AbleToEngineConstants.*;

@Service
@Qualifier(OPEN_APPOINTMENT)
@Slf4j
public class OpenAppointmentServiceImpl extends AppointmentService {
    @Autowired
    private AbleToApiCaller ableToApiCaller;
    @Autowired
    private AbleToClientCaller ableToClientCaller;
    @Autowired
    DataCacheManager dataCacheManager;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;

    private String deploymentId;

    private JSONArray fetchOpenAppointments(AbleToApiCaller ableToApiCaller, RealTimeRequest realTimeRequest, String epmPrefix) {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray providerList = new JSONArray();
        deploymentId = realTimeRequest.getDeploymentId();
        if (nonNull(realTimeRequest.getEntityId())) {
            List<Object> list = (List<Object>) realTimeRequest.getEntityId();
            try {
                JSONArray providerReasonList =
                        new JSONArray(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(list));
                providerReasonList.forEach(
                        provider -> {
                            JSONObject inputParam;
                            try {
                                inputParam = getInputObject(new JSONObject(provider.toString()), realTimeRequest, deploymentId, EPM_NAME_PREFIX);
                            } catch (IHubException e) {
                                metricRealTimeErrorCount(engineName, appDescription, "Error in loading provider " +e.getMessage());
                                throw new RuntimeException(e);
                            }
                            openAppointmentsArray.putAll(
                                    new RealTimeOpenSlotsTask(ableToApiCaller, inputParam, deploymentId,engineName,appDescription).get());
                        });
            } catch (JSONException | JsonProcessingException e) {
                log.error("error in getting provider/reason list from request {} ", e.getMessage());
                metricRealTimeErrorCount(engineName, appDescription, "error in getting provider/reason list from request " +e.getMessage());
                throw new EpmApiCallerException(
                        "error in getting provider/reason list from request " + e.getMessage());
            }
        }
        return openAppointmentsArray;
    }

    private JSONObject getInputObject(
            JSONObject providerReasonObj, RealTimeRequest realTimeRequest, String deploymentId, String epmPrefix) throws IHubException {
        String startDate = realTimeRequest.getStartDate();
        String endDate = realTimeRequest.getEndDate();
        JSONObject inputParameter = new JSONObject();
        inputParameter.put(STARTDATE, startDate);
        inputParameter.put(ENDDATE, endDate);
        inputParameter.put(PATIENTID, " ");
        inputParameter.put(DURATION,  dataCacheManager.getStoredComponentConfig(epmPrefix,ABLETO_CONFIG, DURATION,false));
        inputParameter.put(LOCATIONID, dataCacheManager.getStoredComponentConfig(epmPrefix,ABLETO_CONFIG, LOCATIONID,false));
        inputParameter.put(PRACTITIONERID, providerReasonObj.opt("providerId"));
        if (isEmpty(providerReasonObj.optString("reasonId"))) {
            inputParameter.put(REASONID, dataCacheManager.getConfiguration(epmPrefix,deploymentId,ABLETO_CONFIG,REASONID));
        } else inputParameter.put(REASONID, providerReasonObj.optString("reasonId"));
        return inputParameter;
    }

    @Override
    public JSONArray getAvailability(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap, String epmPrefix) throws JsonProcessingException, IHubException {
        return null;
    }

    @Override
    public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
        return getOpenAppointmentObject(
                fetchOpenAppointments(ableToApiCaller, realTimeRequest, EPM_NAME_PREFIX),
                realTimeRequest);
    }
}