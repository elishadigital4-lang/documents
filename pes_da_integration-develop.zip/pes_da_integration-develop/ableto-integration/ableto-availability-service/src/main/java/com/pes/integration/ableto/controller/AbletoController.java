package com.pes.integration.ableto.controller;

import com.pes.integration.ableto.service.OpenAppointmentServiceImpl;
import com.pes.integration.dto.EngineAppInfo;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.IHubDataApiException;
import com.pes.integration.service.AvailabilityOperations;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.core.JsonProcessingException;

import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.utils.MetricsUtil.*;
import static org.springframework.http.HttpStatus.OK;

@RestController
@Slf4j
public class AbletoController implements AvailabilityOperations {

    @Autowired
    private OpenAppointmentServiceImpl openAppointmentService;

    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;


    @Override
    public ResponseEntity<Object> getRealTimeData(RealTimeRequest realTimeRequest) throws JsonProcessingException {
        JSONObject openAppointments = null;
        try {
            metricRealTimeRequestCount(engineName, appDescription,OPEN_APPOINTMENT);
            AvailabilityOperations.validateInput(realTimeRequest, new EngineAppInfo(engineName, appDescription));
            openAppointments = openAppointmentService.getRealTimeAvailability(realTimeRequest);
            metricRealTimeSuccessCount(engineName, appDescription, OPEN_APPOINTMENT);
        } catch (IHubDataApiException e) {
            log.error(e.getMessage());
            metricRealTimeErrorCount(engineName, appDescription, e.getMessage());
            throw e;
        }
        return new ResponseEntity<>(openAppointments.toString(), OK);
    }

}