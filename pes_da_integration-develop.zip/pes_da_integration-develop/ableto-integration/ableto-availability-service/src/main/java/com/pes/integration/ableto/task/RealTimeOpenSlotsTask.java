package com.pes.integration.ableto.task;

import com.pes.integration.ableto.api.AbleToApiCaller;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.ParseException;
import java.util.function.Supplier;

import static com.pes.integration.ableto.constant.AbleToConstants.PRACTITIONERID;
import static com.pes.integration.ableto.constant.AbleToConstants.REASONID;
import static com.pes.integration.ableto.constant.AbleToConstants.LOCATIONID;
import static com.pes.integration.ableto.constant.AbleToConstants.ISCENTER;
import static com.pes.integration.ableto.constant.AbleToConstants.AVAILABLETIMESLOTS;
import static com.pes.integration.ableto.constant.AbleToConstants.AVAILABLETIMESLOTSRESPONSE;
import static com.pes.integration.ableto.constant.AbleToConstants.PRACTITIONER;
import static com.pes.integration.ableto.constant.AbleToConstants.PROVIDERID;
import static com.pes.integration.ableto.constant.AbleToConstants.DURATIONUNIT;
import static com.pes.integration.ableto.constant.AbleToConstants.MINUTES;
import static com.pes.integration.ableto.constant.AbleToConstants.DURATION;
import static com.pes.integration.ableto.constant.AbleToConstants.START;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeErrorCount;
import static java.lang.String.format;

import static org.apache.commons.text.StringEscapeUtils.escapeJava;

@Slf4j
public class RealTimeOpenSlotsTask implements Supplier<JSONArray> {

    private static final String ERROR_PROCESSING_DATA = "Error in processing the data for appointment slot, Details:- Start Date : %s, End date: %s, ProviderId ID: %s with status %s ";

    @Autowired
    private AbleToApiCaller ableToApiCaller;
    private JSONObject inputParam;
    private String deploymentId;


    private String engineName;

    private String appDescription;

    public RealTimeOpenSlotsTask(
            AbleToApiCaller ableToApiCaller, JSONObject inputParam, String deploymentId, String engineName, String appDescription) {
        this.ableToApiCaller = ableToApiCaller;
        this.inputParam = inputParam;
        this.deploymentId = deploymentId;
        this.engineName = engineName;
        this.appDescription = appDescription;
    }

    @Override
    public JSONArray get() {
        JSONArray openAppointmentsArray = new JSONArray();
        try {
            JSONObject responseObject = ableToApiCaller.call(deploymentId,AVAILABLETIMESLOTS, inputParam,"RealTime");
            if (!responseObject.isEmpty()
                    && responseObject.has(AVAILABLETIMESLOTSRESPONSE)
                    && responseObject.has(PRACTITIONER)) {

                openAppointmentsArray.putAll(
                        extractSlots(responseObject.optJSONArray(AVAILABLETIMESLOTSRESPONSE)));
            }
        } catch (EpmApiCallerException ee) {
            String exceptionDetails =
                    format(
                            ERROR_PROCESSING_DATA,
                            inputParam.optString(STARTDATE),
                            inputParam.optString(ENDDATE),
                            inputParam.optString(PRACTITIONERID),
                            ee.getMessage());
            log.error(escapeJava(exceptionDetails));
            metricRealTimeErrorCount(engineName, appDescription, exceptionDetails);
            throw new EpmApiCallerException(exceptionDetails);
        } catch (IHubException e) {
            metricRealTimeErrorCount(engineName, appDescription, e.getMessage());
            throw new EpmApiCallerException(e.getMessage());
        }
        return openAppointmentsArray;
    }

    private JSONArray extractSlots(JSONArray appointmentObject) {
        JSONArray openAppointmentsArray = new JSONArray();
        appointmentObject.forEach(
                appointmentSlot -> {
                    JSONObject appt = new JSONObject();
                    String startDateTime = (((JSONObject) appointmentSlot).optString(START));
                    try {
                        appt.put(
                                START_TIME,
                                convertDateFormat(
                                        startDateTime.substring(11, 19).trim(),
                                        TIME_FORMAT_HH_MM_SS,
                                        DOCASAP_TIME_FORMAT));
                    } catch (ParseException e) {
                        throw new EpmApiCallerException(e.getMessage());
                    }
                    try {
                        appt.put(
                                DATE_KEY,
                                convertDateFormat(
                                        startDateTime.substring(0, 10), DATE_FORMAT, DATE_TIME_FORMAT));
                    } catch (ParseException e) {
                        throw new EpmApiCallerException(e.getMessage());
                    }
                    appt.put(DURATIONUNIT, MINUTES);
                    appt.put(DURATION,inputParam.optString(DURATION));
                    appt.put(LOCATIONID,inputParam.optString(LOCATIONID));
                    appt.put(REASONID, inputParam.optString(REASONID));
                    appt.put(PROVIDERID, inputParam.optString(PRACTITIONERID));
                    appt.put(ISCENTER, 0);
                    openAppointmentsArray.put(appt);
                });
        return openAppointmentsArray;
    }
}