package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import static com.pes.integration.athena.api.ApiName.GET_PATIENTS;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.PAT_MATCHING_USE_DEPT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

class MatchPatientHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private HandlerUtils handlerUtils;

    @InjectMocks
    private MatchPatientHandler matchPatientHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getPatients() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(APPT_LOCATION_ID))).thenReturn("testLocationId");
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject outputObject = new JSONObject();
            JSONObject tempObject = new JSONObject();
            tempObject.put("appointment_status", "x");
            outputObject.put("temp", tempObject);

            when(athenaApiCaller.call(eq(GET_PATIENTS.getKey()),
                    any(JSONObject.class), anyString())).thenReturn(outputObject);
            doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
            doReturn("true").when(cacheManager)
                    .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(PAT_MATCHING_USE_DEPT), eq(false));

            JSONObject result = matchPatientHandler.getPatients(inputObject);

            assertNotNull(result);
            assertEquals("x", result.getJSONObject("temp").getString("appointment_status"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }

    @Test
    void getPatients_IHubException() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(APPT_LOCATION_ID))).thenReturn("testLocationId");
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject outputObject = new JSONObject();
            JSONObject tempObject = new JSONObject();
            tempObject.put("appointment_status", "x");
            outputObject.put("temp", tempObject);

            when(athenaApiCaller.call(eq(GET_PATIENTS.getKey()),
                    any(JSONObject.class), anyString())).thenThrow(new IHubException(new IHubErrorCode("33"),"Error Message"));
            doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
            doReturn("true").when(cacheManager)
                    .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(PAT_MATCHING_USE_DEPT), eq(false));

            JSONObject result = matchPatientHandler.getPatients(inputObject);
            System.out.println(result);
            assertNotNull(result);
            assertEquals("Error Message", result.getString("Error"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }

    @Test
    void getPatients_RuntimeException() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(APPT_LOCATION_ID))).thenReturn("testLocationId");
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject outputObject = new JSONObject();
            JSONObject tempObject = new JSONObject();
            tempObject.put("appointment_status", "x");
            outputObject.put("temp", tempObject);

            when(athenaApiCaller.call(eq(GET_PATIENTS.getKey()),
                    any(JSONObject.class), anyString())).thenReturn(outputObject);
            doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
            doReturn(new RuntimeException("test error")).when(cacheManager)
                    .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(PAT_MATCHING_USE_DEPT), eq(false));

            JSONObject result = matchPatientHandler.getPatients(inputObject);

            assertNotNull(result);
            assertEquals("x", result.getJSONObject("temp").getString("appointment_status"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }


    @Test
    void getPatientDemographicsDetails() {

        JSONArray patientsArray = new JSONArray();
        JSONArray jsonArray = matchPatientHandler.getPatientDemographicsDetails(patientsArray);
        Assertions.assertEquals(patientsArray,jsonArray);

    }

    @Test
    void isSingleMatch() throws IHubException {
        Assertions.assertFalse(matchPatientHandler.isSingleMatch());
    }
}