package com.pes.integration.athena.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.handler.CancelAppointmentsHandlerService;
import com.pes.integration.athena.handler.NewAppointmentHandlerService;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class ProcessAppointmentsServiceTest {

    @Mock
    private DataTransactionService dataTransactionService;

    @Mock
    private CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    @Mock
    private NewAppointmentHandlerService newAppointmentHandlerService;

    @InjectMocks
    private ProcessAppointmentsService processAppointmentsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createAppointmentWithValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));
        JSONObject response = new JSONObject();

        when(newAppointmentHandlerService.doExecute(any())).thenReturn(response);

        JSONObject result = processAppointmentsService.createAppointment(input);

        assertNotNull(result);
        verify(dataTransactionService, times(1)).logData(input, "CREATE_APPOINTMENT", "CREATED", "iHub Create Appointment Request Message");
        verify(newAppointmentHandlerService, times(1)).doExecute(appointmentSync);
    }

    @Test
    void createAppointmentWithException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        when(newAppointmentHandlerService.doExecute(appointmentSync)).thenThrow(new IHubException(new IHubErrorCode("222"), "Error"));

        assertThrows(IHubException.class, () -> {
            processAppointmentsService.createAppointment(input);
        });

        verify(dataTransactionService, times(1)).logData(input, "CREATE_APPOINTMENT", "CREATED", "iHub Create Appointment Request Message");
        verify(dataTransactionService, times(1)).logData(input, "CREATE_APPOINTMENT", "FAILED", "Error");
    }

    @Test
    void cancelAppointmentWithValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));
        JSONObject response = new JSONObject();

        when(cancelAppointmentsHandlerService.doExecute(appointmentSync)).thenReturn(response);

        JSONObject result = processAppointmentsService.cancelAppointment(input);

        assertNotNull(result);
        verify(dataTransactionService, times(1)).logData(input, "CANCEL_APPOINTMENT", "CREATED", "iHub Cancel Appointment Request Message");
        verify(cancelAppointmentsHandlerService, times(1)).doExecute(appointmentSync);
    }

    @Test
    void cancelAppointmentWithException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        when(cancelAppointmentsHandlerService.doExecute(appointmentSync)).thenThrow(new IHubException(new IHubErrorCode("555"), "Error"));

        assertThrows(IHubException.class, () -> {
            processAppointmentsService.cancelAppointment(input);
        });

        verify(dataTransactionService, times(1)).logData(input, "CANCEL_APPOINTMENT", "CREATED", "iHub Cancel Appointment Request Message");
        verify(dataTransactionService, times(1)).logData(input, "CANCEL_APPOINTMENT", "FAILED", "Error");
    }
}