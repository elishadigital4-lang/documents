package com.pes.integration.athena.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.handler.GetPatientHandler;
import com.pes.integration.athena.handler.NewPatientHandlerService;
import com.pes.integration.athena.handler.UpdatePatientHandler;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

class ProcessPatientServiceTest {

    @Mock
    private NewPatientHandlerService newPatientHandlerService;

    @Mock
    private GetPatientHandler getPatientHandler;

    @Mock
    private UpdatePatientHandler updatePatientHandler;

    @Mock
    private DataTransactionService dataTransactionService;

    @InjectMocks
    private ProcessPatientService processPatientService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        Mockito.reset(newPatientHandlerService, getPatientHandler, updatePatientHandler, dataTransactionService);
    }

    @Test
    void createPatientWithValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));
        JSONObject response = new JSONObject();

        when(newPatientHandlerService.doExecute(appointmentSync)).thenReturn(response);

        JSONObject result = processPatientService.createPatient(input);

        assertNotNull(result);
        verify(dataTransactionService, times(1)).logData(input, "CREATE_PATIENT", "CREATED", "iHub Create Patient Request Message");
        verify(newPatientHandlerService, times(1)).doExecute(appointmentSync);
    }

    @Test
    void createPatientWithException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        when(newPatientHandlerService.doExecute(appointmentSync)).thenThrow(new IHubException(new IHubErrorCode("22"),"Error"));

        assertThrows(IHubException.class, () -> {
            processPatientService.createPatient(input);
        });

        verify(dataTransactionService, times(1)).logData(input, "CREATE_PATIENT", "CREATED", "iHub Create Patient Request Message");
        verify(dataTransactionService, times(1)).logData(input, "CREATE_PATIENT", "FAILED", "Error");
    }

    @Test
    void updatePatientWithValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));
        JSONObject response = new JSONObject();

        when(updatePatientHandler.doExecute(appointmentSync)).thenReturn(response);

        JSONObject result = processPatientService.updatePatient(input);

        assertNotNull(result);
        verify(dataTransactionService, times(1)).logData(input, "UPDATE_PATIENT", "CREATED", "iHub Update Patient Request Message");
        verify(updatePatientHandler, times(1)).doExecute(appointmentSync);
    }

    @Test
    void updatePatientWithException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        when(updatePatientHandler.doExecute(appointmentSync)).thenThrow(new IHubException(new IHubErrorCode("22"),"Error"));

        assertThrows(IHubException.class, () -> {
            processPatientService.updatePatient(input);
        });

        verify(dataTransactionService, times(1)).logData(input, "UPDATE_PATIENT", "CREATED", "iHub Update Patient Request Message");
        verify(dataTransactionService, times(1)).logData(input, "UPDATE_PATIENT", "FAILED", "Error");
    }

    @Test
    void searchPatientWithValidInput() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));
        JSONObject response = new JSONObject();
        JSONObject responseJson = new JSONObject();

        when(getPatientHandler.doExecute(appointmentSync)).thenReturn(response);

        JSONObject result = processPatientService.searchPatient(input);

        assertNotNull(result);
        verify(dataTransactionService, times(1)).logData(input, "SEARCH_PATIENT", "CREATED", "iHub Search Patient Request Message");
        verify(getPatientHandler, times(1)).doExecute(appointmentSync);
    }

    @Test
    void searchPatientWithException() throws IHubException {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        when(getPatientHandler.doExecute(appointmentSync)).thenThrow(new IHubException(new IHubErrorCode("22"),"Error"));

        assertThrows(IHubException.class, () -> {
            processPatientService.searchPatient(input);
        });

        verify(dataTransactionService, times(1)).logData(input, "SEARCH_PATIENT", "CREATED", "iHub Search Patient Request Message");
        verify(dataTransactionService, times(1)).logData(input, "SEARCH_PATIENT", "FAILED", "Error");
    }

    @Test
    void getPatientShouldReturnNull() throws IHubException {
        JSONObject input = new JSONObject();

        JSONObject result = processPatientService.getPatient(input);

        assertNull(result, "Expected getPatient to return null");
    }

    @Test
    void testSearchPatient_successWithTemp() throws Exception {
        ProcessPatientService service = new ProcessPatientService();
        service.getPatientHandler = mock(GetPatientHandler.class);
        service.dataTransactionService = mock(DataTransactionService.class);

        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        JSONObject response = new JSONObject();
        JSONObject tempObj = new JSONObject();
        response.put("temp", tempObj);

        when(service.getPatientHandler.doExecute(appointmentSync)).thenReturn(response);

        JSONObject result = service.searchPatient(input);

        verify(service.dataTransactionService, times(1))
                .logData(input, "SEARCH_PATIENT", "CREATED", "iHub Search Patient Request Message");
        assertTrue(result.has("data"));
    }

    @Test
    void testSearchPatient_successWithoutTemp() throws Exception {
        ProcessPatientService service = new ProcessPatientService();
        service.getPatientHandler = mock(GetPatientHandler.class);
        service.dataTransactionService = mock(DataTransactionService.class);

        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        JSONObject response = new JSONObject();
        when(service.getPatientHandler.doExecute(appointmentSync)).thenReturn(response);

        JSONObject result = service.searchPatient(input);

        verify(service.dataTransactionService, times(1))
                .logData(input, "SEARCH_PATIENT", "CREATED", "iHub Search Patient Request Message");
        assertTrue(result.has("data"));
        assertFalse(result.has("error"));
    }

    @Test
    void testSearchPatient_withException() throws Exception {
        ProcessPatientService service = new ProcessPatientService();
        service.getPatientHandler = mock(GetPatientHandler.class);
        service.dataTransactionService = mock(DataTransactionService.class);

        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject appointmentSync = new JSONObject();
        input.put("data", data);
        data.put("appointment_sync", new JSONArray().put(appointmentSync));

        when(service.getPatientHandler.doExecute(appointmentSync))
                .thenThrow(new com.pes.integration.exceptions.IHubException(null, "Error"));

        assertThrows(com.pes.integration.exceptions.IHubException.class, () -> {
            service.searchPatient(input);
        });

        verify(service.dataTransactionService, times(1))
                .logData(input, "SEARCH_PATIENT", "CREATED", "iHub Search Patient Request Message");
        verify(service.dataTransactionService, times(1))
                .logData(input, "SEARCH_PATIENT", "FAILED", "Error");
    }
}