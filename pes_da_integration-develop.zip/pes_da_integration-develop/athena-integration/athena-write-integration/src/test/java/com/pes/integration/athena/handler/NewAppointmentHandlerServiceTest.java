package com.pes.integration.athena.handler;

import static com.pes.integration.athena.api.ApiName.NEW_APPOINTMENT;
import static com.pes.integration.athena.constant.AthenaConstants.NOT_REGISTERED_MSG;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.CUSTOM_FIELD_UPDATED_COUNT;
import static com.pes.integration.constant.DocASAPConstants.TempKey.ERROR_MESSAGE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.ManageFlagsUtility;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;

@ExtendWith(MockitoExtension.class)
class NewAppointmentHandlerServiceTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private PatientNotificationHandler patientNotificationHandler;

    @Mock
    private PatientInsuranceHandler patientInsuranceHandler;

    @Mock
    private ManageFlagsUtility manageFlagsUtility;

    @InjectMocks
    private NewAppointmentHandlerService newAppointmentHandlerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createNewAppointmentWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.GUARANTOR_DOB))).thenReturn("1990-01-01");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DocASAPConstants.DOCASAP_DATE_FORMAT), eq(BaseEPMConstants.EPM_DATE_FORMAT))).thenReturn("19900101");

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(ERROR_MESSAGE))).thenReturn(NOT_REGISTERED_MSG);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_LOCATION_ID))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_RELATIONSHIP))).thenReturn("father");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.ADR_SAME_AS_PATIENT))).thenReturn(1);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("DemographicData.PatientInformation[0]"))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DA_APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_CHECKIN))).thenReturn("testAppointmentCheckin");
                JSONArray customField = new JSONArray();
                customField.put(new JSONObject().put(AthenaEngineConstants.CUSTOM_FIELD_ID, "testCustomFieldId"));
                customField.put(new JSONObject().put(AthenaEngineConstants.OPTION_ID, "optionId"));
//                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.CUSTOM_FIELDS))).thenReturn(customField);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.CUSTOM_FIELD_ID))).thenReturn("testCustomFieldId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.OPTION_ID))).thenReturn("testOptionId");

                JSONObject inputObject = new JSONObject();
                inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
                inputObject.put(DocASAPConstants.Key.PATIENT_ID, "testPatientId");

                JSONObject outputObject = new JSONObject();
                outputObject.put("APPOINTMENT_ID", "testAppointmentId");
                JSONObject demographicData = new JSONObject();
                demographicData.put("InsuranceInformation", new JSONObject());
                demographicData.put(ApiName.GET_PATIENT_INSURANCE.getKey(), "testInsuranceData");
                demographicData.put(DocASAPConstants.Key.APPT_LOCATION_ID, "testLocationId");
                demographicData.put(DocASAPConstants.Key.DA_PATIENT_ID, "testPatientId");
                demographicData.put(DocASAPConstants.Key.INSURANCE_INFORMATION, "testInsuranceInformation");
                outputObject.put(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA, demographicData);

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA))).thenReturn(demographicData);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(CUSTOM_FIELD_UPDATED_COUNT))).thenReturn("0");
                when(athenaApiCaller.call(eq(NEW_APPOINTMENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.ADD_CUSTOM_FIELDS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
                when(patientInsuranceHandler.doExecute(any())).thenReturn(new JSONObject());
                when(manageFlagsUtility.containsErrorMessage(any())).thenReturn(true);
                when(manageFlagsUtility.getConfiguration(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG),
                        eq(GUARANTOR_RELATIONS))).thenReturn("father:mother");

                JSONObject result = newAppointmentHandlerService.createNewAppointment(inputObject);
                System.out.println(result);
                assertNotNull(result);
                assertEquals("testPatientId", result.getString("DemographicData.PatientInformation[0].ExternalPatientId"));
                assertEquals("testDeploymentId", result.getString("deployment_id"));
                verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
                verify(athenaApiCaller, times(5)).call(anyString(), any(JSONObject.class), anyString());
            }
        }
    }


    @Test
    void createNewAppointmentWithValidInput_CUSTOM_FIELD_ERROR() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.GUARANTOR_DOB))).thenReturn("1990-01-01");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DocASAPConstants.DOCASAP_DATE_FORMAT), eq(BaseEPMConstants.EPM_DATE_FORMAT))).thenReturn("19900101");

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(ERROR_MESSAGE))).thenReturn(NOT_REGISTERED_MSG);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_LOCATION_ID))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_RELATIONSHIP))).thenReturn("father");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.ADR_SAME_AS_PATIENT))).thenReturn(1);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("DemographicData.PatientInformation[0]"))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DA_APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_CHECKIN))).thenReturn("testAppointmentCheckin");
                JSONArray customField = new JSONArray();
                customField.put(new JSONObject().put(AthenaEngineConstants.CUSTOM_FIELD_ID, "testCustomFieldId"));
                customField.put(new JSONObject().put(AthenaEngineConstants.OPTION_ID, "optionId"));
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.CUSTOM_FIELDS))).thenReturn(customField);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.CUSTOM_FIELD_ID))).thenReturn("testCustomFieldId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.OPTION_ID))).thenReturn("testOptionId");

                JSONObject inputObject = new JSONObject();
                inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
                inputObject.put(DocASAPConstants.Key.PATIENT_ID, "testPatientId");

                JSONObject outputObject = new JSONObject();
                outputObject.put("APPOINTMENT_ID", "testAppointmentId");
                JSONObject demographicData = new JSONObject();
                demographicData.put("InsuranceInformation", new JSONObject());
                demographicData.put(ApiName.GET_PATIENT_INSURANCE.getKey(), "testInsuranceData");
                demographicData.put(DocASAPConstants.Key.APPT_LOCATION_ID, "testLocationId");
                demographicData.put(DocASAPConstants.Key.DA_PATIENT_ID, "testPatientId");
                demographicData.put(DocASAPConstants.Key.INSURANCE_INFORMATION, "testInsuranceInformation");
                outputObject.put(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA, demographicData);

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA))).thenReturn(demographicData);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(CUSTOM_FIELD_UPDATED_COUNT))).thenReturn("0");
                when(athenaApiCaller.call(eq(NEW_APPOINTMENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.ADD_CUSTOM_FIELDS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
                when(patientInsuranceHandler.doExecute(any())).thenReturn(new JSONObject());
                when(manageFlagsUtility.containsErrorMessage(any())).thenReturn(true);
                when(manageFlagsUtility.getConfiguration(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG),
                        eq(GUARANTOR_RELATIONS))).thenReturn("father:mother");

                JSONObject result = newAppointmentHandlerService.createNewAppointment(inputObject);
                System.out.println(result);
                assertNotNull(result);
                verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
                verify(athenaApiCaller, times(6)).call(anyString(), any(JSONObject.class), anyString());
            }
        }
    }

    @Test
    void createNewAppointmentWithValidInput_CONSENT_UPDATE_ERROR() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.GUARANTOR_DOB))).thenReturn("1990-01-01");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DocASAPConstants.DOCASAP_DATE_FORMAT), eq(BaseEPMConstants.EPM_DATE_FORMAT))).thenReturn("19900101");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DocASAPConstants.DATE_TIME_FORMAT), eq( BaseEPMConstants.DATE_TIME_FORMAT))).thenReturn("200101012345");

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(ERROR_MESSAGE))).thenReturn(NOT_REGISTERED_MSG);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_LOCATION_ID))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_RELATIONSHIP))).thenReturn("father");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.ADR_SAME_AS_PATIENT))).thenReturn(1);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("DemographicData.PatientInformation[0]"))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DA_APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_CHECKIN))).thenReturn("1");
                JSONArray customField = new JSONArray();
                customField.put(new JSONObject().put(AthenaEngineConstants.CUSTOM_FIELD_ID, "testCustomFieldId"));
                customField.put(new JSONObject().put(AthenaEngineConstants.OPTION_ID, "optionId"));
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(PATIENT_CONSENT))).thenReturn("testCustomFieldId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(PRIVACY_POLICY_CONSENT))).thenReturn("policy");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(ASSIGNMENT_BENEFITS_CONSENT))).thenReturn("benefits");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(RELEASE_BILLING_INFORMATION_CONSENT))).thenReturn("billing");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(CALL_CONSENT))).thenReturn("call");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(TEXT_CONSENT))).thenReturn("text");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(CONTACT_CONSENT))).thenReturn("contact");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.CUSTOM_FIELD_ID))).thenReturn("testCustomFieldId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.OPTION_ID))).thenReturn("testOptionId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(PATIENT_CONSENT_TIMESTAMP))).thenReturn("200101012345");

                JSONObject inputObject = new JSONObject();
                inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
                inputObject.put(DocASAPConstants.Key.PATIENT_ID, "testPatientId");

                JSONObject outputObject = new JSONObject();
                outputObject.put("APPOINTMENT_ID", "testAppointmentId");
                JSONObject demographicData = new JSONObject();
                demographicData.put("InsuranceInformation", new JSONObject());
                demographicData.put(ApiName.GET_PATIENT_INSURANCE.getKey(), "testInsuranceData");
                demographicData.put(DocASAPConstants.Key.APPT_LOCATION_ID, "testLocationId");
                demographicData.put(DocASAPConstants.Key.DA_PATIENT_ID, "testPatientId");
                demographicData.put(DocASAPConstants.Key.INSURANCE_INFORMATION, "testInsuranceInformation");
                outputObject.put(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA, demographicData);

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA))).thenReturn(demographicData);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(CUSTOM_FIELD_UPDATED_COUNT))).thenReturn("0");
                when(athenaApiCaller.call(eq(NEW_APPOINTMENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.ADD_CUSTOM_FIELDS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                when(athenaApiCaller.call(eq(ApiName.VERIFY_PATIENT_PRIVACY_INFORMATION.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
                when(patientInsuranceHandler.doExecute(any())).thenReturn(new JSONObject());
                when(manageFlagsUtility.containsErrorMessage(any())).thenReturn(true);
                when(manageFlagsUtility.getConfiguration(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG),
                        eq(GUARANTOR_RELATIONS))).thenReturn("father:mother");

                assertThrows(IHubException.class, () -> {
                    newAppointmentHandlerService.createNewAppointment(inputObject);
                });
                verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
                verify(athenaApiCaller, times(8)).call(anyString(), any(JSONObject.class), anyString());
            }
        }
    }

    @Test
    void createNewAppointmentWithValidInput_APPT_CHECKIN_ERROR() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.GUARANTOR_DOB))).thenReturn("1990-01-01");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DocASAPConstants.DOCASAP_DATE_FORMAT), eq(BaseEPMConstants.EPM_DATE_FORMAT))).thenReturn("19900101");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DocASAPConstants.DATE_TIME_FORMAT), eq( BaseEPMConstants.DATE_TIME_FORMAT))).thenReturn("200101012345");

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(ERROR_MESSAGE))).thenReturn(NOT_REGISTERED_MSG);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPT_LOCATION_ID))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn("testLocationId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_RELATIONSHIP))).thenReturn("father");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.ADR_SAME_AS_PATIENT))).thenReturn(1);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("DemographicData.PatientInformation[0]"))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DA_APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID))).thenReturn("testAppointmentId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_CHECKIN))).thenReturn("1");
                JSONArray customField = new JSONArray();
                customField.put(new JSONObject().put(AthenaEngineConstants.CUSTOM_FIELD_ID, "testCustomFieldId"));
                customField.put(new JSONObject().put(AthenaEngineConstants.OPTION_ID, "optionId"));
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.CUSTOM_FIELD_ID))).thenReturn("testCustomFieldId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(AthenaEngineConstants.OPTION_ID))).thenReturn("testOptionId");
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(PATIENT_CONSENT_TIMESTAMP))).thenReturn("200101012345");

                JSONObject inputObject = new JSONObject();
                inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
                inputObject.put(DocASAPConstants.Key.PATIENT_ID, "testPatientId");

                JSONObject outputObject = new JSONObject();
                outputObject.put("APPOINTMENT_ID", "testAppointmentId");
                JSONObject demographicData = new JSONObject();
                demographicData.put("InsuranceInformation", new JSONObject());
                demographicData.put(ApiName.GET_PATIENT_INSURANCE.getKey(), "testInsuranceData");
                demographicData.put(DocASAPConstants.Key.APPT_LOCATION_ID, "testLocationId");
                demographicData.put(DocASAPConstants.Key.DA_PATIENT_ID, "testPatientId");
                demographicData.put(DocASAPConstants.Key.INSURANCE_INFORMATION, "testInsuranceInformation");
                outputObject.put(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA, demographicData);

                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA))).thenReturn(demographicData);
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn(new JSONObject());
                mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(CUSTOM_FIELD_UPDATED_COUNT))).thenReturn("0");
                when(athenaApiCaller.call(eq(NEW_APPOINTMENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_INSURANCE.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.ADD_CUSTOM_FIELDS.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);

                when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                lenient().when(athenaApiCaller.call(eq(ApiName.VERIFY_PATIENT_PRIVACY_INFORMATION.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                when(athenaApiCaller.call(eq(ApiName.UPDATE_APPOINTMENT_CHECKIN.getKey()), any(JSONObject.class),
                        eq(CREATE_APPOINTMENT.getKey()))).thenReturn(outputObject);
                doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
                when(patientInsuranceHandler.doExecute(any())).thenReturn(new JSONObject());
                when(manageFlagsUtility.containsErrorMessage(any())).thenReturn(true);
                when(manageFlagsUtility.getConfiguration(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG),
                        eq(GUARANTOR_RELATIONS))).thenReturn("father:mother");

                JSONObject result = newAppointmentHandlerService.createNewAppointment(inputObject);
                System.out.println(result);
                assertNotNull(result);
                verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
                verify(athenaApiCaller, times(6)).call(anyString(), any(JSONObject.class), anyString());
            }
        }
    }

    @Test
    void testSetDob_withValidDob() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        inputObject.put("dob", "1990-01-01");

        try (MockedStatic<DateUtils> mockedDateUtils = mockStatic(DateUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = mockStatic(NullChecker.class);
             MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {

            mockedNullChecker.when(() -> NullChecker.isEmpty("1990-01-01")).thenReturn(false);
            mockedDateUtils.when(() -> DateUtils.convertDateFormat("1990-01-01",
                            DocASAPConstants.DOCASAP_DATE_FORMAT, BaseEPMConstants.EPM_DATE_FORMAT))
                    .thenReturn("19900101");

            // Mock getValue and setValue
            mockedJsonUtils.when(() -> JsonUtils.getValue(inputObject, "dob")).thenReturn("1990-01-01");
            mockedJsonUtils.when(() -> JsonUtils.setValue(inputObject, "dob", "19900101")).then(invocation -> {
                inputObject.put("dob", "19900101");
                return null;
            });

            Method setDobMethod = NewAppointmentHandlerService.class.getDeclaredMethod("setDob", Object.class);
            setDobMethod.setAccessible(true);
            setDobMethod.invoke(service, inputObject);

            assertEquals("1990-01-01", inputObject.getString("dob"));
        }
    }

    @Test
    void testSetDob_withException() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        inputObject.put("dob", "invalid-date");

        try (MockedStatic<DateUtils> mockedDateUtils = mockStatic(DateUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = mockStatic(NullChecker.class);
             MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {

            mockedNullChecker.when(() -> NullChecker.isEmpty("invalid-date")).thenReturn(false);
            mockedDateUtils.when(() -> DateUtils.convertDateFormat(anyString(),
                    anyString(), anyString())).thenThrow(new RuntimeException("Parse error"));
            mockedJsonUtils.when(() -> JsonUtils.getValue(inputObject, DocASAPConstants.Key.DOB)).thenThrow(new RuntimeException("Parse error"));

            Method setDobMethod = NewAppointmentHandlerService.class.getDeclaredMethod("setDob", Object.class);
            setDobMethod.setAccessible(true);

            // Should not throw, just log error
            assertDoesNotThrow(() -> setDobMethod.invoke(service, inputObject));
        }
    }


    @Test
    void testUpdateGuarantorInformation_withValidGuarantor() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deployment_id", "depId");
        inputObject.put("guarantor_information", new JSONObject());
        inputObject.put("guarantor_relationship", "father");
        inputObject.put("adr_same_as_patient", 1);
        inputObject.put("guarantor_dob", "1990-01-01");
        inputObject.put("DemographicData.PatientInformation[0]", new JSONObject());

        JSONObject outputObject = new JSONObject();
        outputObject.put("someKey", "someValue");

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> mockedDateUtils = mockStatic(DateUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = mockStatic(NullChecker.class)) {

            mockedNullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);
            mockedDateUtils.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenReturn("19900101");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("depId");
            JSONObject jsonObject = new JSONObject("{\n" +
                    "  \"endDate\": \"2025-09-30\",\n" +
                    "  \"entityType\": \"location/provider/reason\",\n" +
                    "  \"deploymentId\": \"747303^0001\",\n" +
                    "  \"messageControlId\": \"7896542345632\",\n" +
                    "  \"startDate\": \"2025-09-11\",\n" +
                    "  \"flow\": \"RealTime\"\n" +
                    "}");

            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn(jsonObject);
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_RELATIONSHIP))).thenThrow(new RuntimeException("Not found"));

            lenient().when(manageFlagsUtility.getConfiguration(anyString(), anyString(), anyString(), anyString()))
                    .thenReturn("father:Father,mother:Mother");
            lenient().when(athenaApiCaller.call(anyString(), any(), anyString())).thenReturn(outputObject);
            lenient().when(manageFlagsUtility.containsErrorMessage(any())).thenReturn(false);

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "updateGuarantorInformation", Object.class, String.class);
            method.setAccessible(true);
            method.invoke(newAppointmentHandlerService, inputObject, "patientId");

            assertTrue(true);
        }
    }

    @Test
    void testUpdateGuarantorInformation_withEmptyGuarantor_returnsEarly() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deployment_id", "depId");
        inputObject.put("guarantor_information", new JSONObject());
        inputObject.put("guarantor_relationship", "father");
        inputObject.put("adr_same_as_patient", 1);
        inputObject.put("guarantor_dob", "1990-01-01");
        inputObject.put("DemographicData.PatientInformation[0]", new JSONObject());

        JSONObject outputObject = new JSONObject();
        outputObject.put("someKey", "someValue");

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> mockedDateUtils = mockStatic(DateUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = mockStatic(NullChecker.class)) {

            mockedNullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);
            mockedDateUtils.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenReturn("19900101");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("depId");
            JSONObject jsonObject = new JSONObject("{\n" +
                    "  \"endDate\": \"2025-09-30\",\n" +
                    "  \"entityType\": \"location/provider/reason\",\n" +
                    "  \"deploymentId\": \"747303^0001\",\n" +
                    "  \"messageControlId\": \"7896542345632\",\n" +
                    "  \"startDate\": \"2025-09-11\",\n" +
                    "  \"flow\": \"RealTime\"\n" +
                    "}");

            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn(jsonObject);
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_RELATIONSHIP))).thenReturn("unknownRelation");

            when(manageFlagsUtility.getConfiguration(eq(AthenaEngineConstants.EPM_NAME_PREFIX), eq("depId"), eq(ATHENA_CONFIG), eq(GUARANTOR_RELATIONS)))
                    .thenThrow(new IHubException(null, "Config error", null));
            lenient().when(athenaApiCaller.call(anyString(), any(), anyString())).thenReturn(outputObject);
            lenient().when(manageFlagsUtility.containsErrorMessage(any())).thenReturn(false);

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "updateGuarantorInformation", Object.class, String.class);
            method.setAccessible(true);
            method.invoke(newAppointmentHandlerService, inputObject, "patientId");

            assertTrue(true);
        }
    }

    @Test
    void testUpdateGuarantorInformation_withException() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put("deployment_id", "depId");
        inputObject.put("guarantor_information", new JSONObject());
        inputObject.put("guarantor_relationship", "father");
        inputObject.put("adr_same_as_patient", 1);
        inputObject.put("guarantor_dob", "1990-01-01");
        inputObject.put("DemographicData.PatientInformation[0]", new JSONObject());

        JSONObject outputObject = new JSONObject();
        outputObject.put("someKey", "someValue");

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class);
             MockedStatic<DateUtils> mockedDateUtils = mockStatic(DateUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = mockStatic(NullChecker.class)) {

            mockedNullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("depId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(ADR_SAME_AS_PATIENT))).thenReturn(123);
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GUARANTOR_DOB))).thenReturn("1990-01-01");
            mockedDateUtils.when(() -> DateUtils.convertDateFormat(eq("1990-01-01"), eq(DocASAPConstants.DOCASAP_DATE_FORMAT), eq(BaseEPMConstants.EPM_DATE_FORMAT)))
                    .thenThrow(new ParseException("Parse error", 0));

            JSONObject jsonObject = new JSONObject("{\n" +
                    "  \"endDate\": \"2025-09-30\",\n" +
                    "  \"entityType\": \"location/provider/reason\",\n" +
                    "  \"deploymentId\": \"747303^0001\",\n" +
                    "  \"messageControlId\": \"7896542345632\",\n" +
                    "  \"startDate\": \"2025-09-11\",\n" +
                    "  \"flow\": \"RealTime\"\n" +
                    "}");

            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_INFORMATION))).thenReturn(jsonObject);
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(GURANTOR_RELATIONSHIP))).thenReturn("unknown");

            when(manageFlagsUtility.getConfiguration(anyString(), anyString(), anyString(), anyString()))
                    .thenReturn("father:Father,mother:Mother");
            lenient().when(athenaApiCaller.call(anyString(), any(), anyString())).thenReturn(outputObject);
            lenient().when(manageFlagsUtility.containsErrorMessage(any())).thenReturn(false);

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "updateGuarantorInformation", Object.class, String.class);
            method.setAccessible(true);
            method.invoke(newAppointmentHandlerService, inputObject, "patientId");

            assertTrue(true);
        }
    }

    @Test
    void testUpdatePatientData_withException() throws Exception {
        NewAppointmentHandlerService service = Mockito.spy(new NewAppointmentHandlerService());
        AthenaApiCaller athenaApiCaller = mock(AthenaApiCaller.class);
        java.lang.reflect.Field field = NewAppointmentHandlerService.class.getDeclaredField("athenaApiCaller");
        field.setAccessible(true);
        field.set(service, athenaApiCaller);

        JSONObject inputObject = new JSONObject();
        inputObject.put("address", "test address");
        JSONObject responseObject = new JSONObject();
        String errorMsg = AthenaConstants.NOT_REGISTERED_MSG;

        try (MockedStatic<NullChecker> nullCheckerMock = mockStatic(NullChecker.class);
             MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class)) {

            nullCheckerMock.when(() -> NullChecker.isEmpty(errorMsg)).thenReturn(false);
            jsonUtilsMock.when(() -> JsonUtils.getValue(inputObject, DocASAPConstants.Key.APPT_LOCATION_ID)).thenReturn("locId");

            doThrow(new IHubException(null, "error")).when(athenaApiCaller)
                    .call(anyString(), any(JSONObject.class), anyString());

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "updatePatientData", Object.class, Object.class, JSONObject.class, String.class);
            method.setAccessible(true);

            // Should not throw, just log error
            method.invoke(service, inputObject, "patientId", responseObject, errorMsg);
        }
    }


    @Test
    void testRegisterPatient_getValueThrowsException() throws Exception {
        NewAppointmentHandlerService service = Mockito.spy(new NewAppointmentHandlerService());
        AthenaApiCaller athenaApiCaller = mock(AthenaApiCaller.class);

        java.lang.reflect.Field field = NewAppointmentHandlerService.class.getDeclaredField("athenaApiCaller");
        field.setAccessible(true);
        field.set(service, athenaApiCaller);

        JSONObject inputObject = new JSONObject();
        JSONObject responseObject = new JSONObject();

        when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq("CREATE_APPOINTMENT")))
                .thenReturn(responseObject);

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class);
        MockedStatic<NullChecker> mockedNullChecker = mockStatic(NullChecker.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(responseObject, ERROR_MESSAGE))
                    .thenThrow(new RuntimeException("error"));

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "registerPatient", Object.class, Object.class);
            method.setAccessible(true);
            method.invoke(service, inputObject, "externalPatientId");

            verify(athenaApiCaller, times(1)).call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq("CREATE_APPOINTMENT"));
        }
    }


    @Test
    void testHandleInsurance_withException() throws Exception {
        NewAppointmentHandlerService service = Mockito.spy(new NewAppointmentHandlerService());

        PatientInsuranceHandler patientInsuranceHandler = mock(PatientInsuranceHandler.class);
        ManageFlagsUtility manageFlagsUtility = mock(ManageFlagsUtility.class);

        java.lang.reflect.Field insuranceField = NewAppointmentHandlerService.class.getDeclaredField("patientInsuranceHandler");
        insuranceField.setAccessible(true);
        insuranceField.set(service, patientInsuranceHandler);

        java.lang.reflect.Field flagsField = NewAppointmentHandlerService.class.getDeclaredField("manageFlagsUtility");
        flagsField.setAccessible(true);
        flagsField.set(service, manageFlagsUtility);

        JSONObject inputObject = new JSONObject();
        inputObject.put("deployment_id", "depId");

        when(patientInsuranceHandler.doExecute(any(JSONObject.class))).thenThrow(new IHubException(null, "error"));

        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(inputObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID)).thenReturn("depId");
            mockedJsonUtils.when(() -> JsonUtils.copyKey(eq(DocASAPConstants.Key.APPT_LOCATION_ID), anyString(), anyString())).thenThrow(new IHubException(null, "error"));

                try (MockedStatic<com.pes.integration.utils.LogUtil> logUtilMock = mockStatic(com.pes.integration.utils.LogUtil.class)) {
                    logUtilMock.when(() -> com.pes.integration.utils.LogUtil.sanitizeForLog(anyString())).thenReturn("sanitized");

                    Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                            "handleInsurance", Object.class, Object.class);
                    method.setAccessible(true);

                    // Should not throw, just log error
                    assertDoesNotThrow(() -> method.invoke(service, inputObject, "patientId"));
                }
            }
        }

    @Test
    void testUpdatePrivacyConsentTimestamps_withParseException() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        inputObject.put("consent_timestamp", "invalid-date");

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = Mockito.mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
             MockedStatic<com.pes.integration.utils.DateUtils> dateUtilsMock = Mockito.mockStatic(com.pes.integration.utils.DateUtils.class)) {

            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(eq(inputObject), eq(PATIENT_CONSENT_TIMESTAMP)))
                    .thenReturn("invalid-date");
            dateUtilsMock.when(() -> com.pes.integration.utils.DateUtils.convertDateFormat(eq("invalid-date"),
                    eq(DocASAPConstants.DATE_TIME_FORMAT), eq(BaseEPMConstants.DATE_TIME_FORMAT))).thenThrow(new ParseException("error", 0));

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "updatePrivacyConsentTimestamps", Object.class);
            method.setAccessible(true);

            Exception exception = assertThrows(InvocationTargetException.class, () -> method.invoke(service, inputObject));
            assertTrue(true);
        }
    }
}