package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import static com.pes.integration.athena.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.athena.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

class GetPatientInsurancesHandlerTest {
    @InjectMocks
    private GetPatientInsurancesHandler getPatientInsurancesHandler;

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private HandlerUtils handlerUtils;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecute() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject outputObject = new JSONObject();
            JSONObject tempObject = new JSONObject();
            tempObject.put("appointment_status", "x");
            outputObject.put("temp", tempObject);

            when(athenaApiCaller.call(eq(GET_PATIENT_INSURANCE.getKey()),
                    any(JSONObject.class), eq(""))).thenReturn(outputObject);
            doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
            doReturn("22").when(cacheManager)
                    .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(DEFAULT_CANCEL_REASON), eq(false));

            JSONObject result = getPatientInsurancesHandler.doExecute(inputObject);

            assertNotNull(result);
            assertEquals("x", result.getJSONObject("temp").getString("appointment_status"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }
}