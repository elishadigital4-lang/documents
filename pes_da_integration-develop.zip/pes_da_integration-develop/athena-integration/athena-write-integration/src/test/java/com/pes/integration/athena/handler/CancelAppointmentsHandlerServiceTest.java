package com.pes.integration.athena.handler;

import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.EVENT_REASON_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.StatusCodes.INVALID_FORMAT;
import static com.pes.integration.enums.StatusCodes.NO_APPOINTMENT_FOUND;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

class CancelAppointmentsHandlerServiceTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private HandlerUtils handlerUtils;

    @InjectMocks
    private CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void cancelAppointmentWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject outputObject = new JSONObject();
            JSONObject tempObject = new JSONObject();
            tempObject.put("appointment_status", "x");
            outputObject.put("temp", tempObject);

            when(athenaApiCaller.call(eq(ApiName.CANCEL_APPOINTMENT.getKey()),
                    any(JSONObject.class), eq(Flow.CANCEL_APPOINTMENT.getKey()))).thenReturn(outputObject);
            doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
            doReturn("22").when(cacheManager)
                    .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(DEFAULT_CANCEL_REASON), eq(false));

            JSONObject result = cancelAppointmentsHandlerService.cancelAppointment(inputObject);

            assertNotNull(result);
            assertEquals("x", result.getJSONObject("temp").getString("appointment_status"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }

    @Test
    void cancelAppointmentWithValidInput_appointment_status_false() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject outputObject = new JSONObject();
            JSONObject tempObject = new JSONObject();
            outputObject.put("temp", tempObject);

            when(athenaApiCaller.call(eq(ApiName.CANCEL_APPOINTMENT.getKey()),
                    any(JSONObject.class), eq(Flow.CANCEL_APPOINTMENT.getKey()))).thenReturn(outputObject);
            doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
            doReturn("22").when(cacheManager)
                    .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(DEFAULT_CANCEL_REASON), eq(false));

            JSONObject result = cancelAppointmentsHandlerService.cancelAppointment(inputObject);
            System.out.println(result);
            assertNotNull(result);
            assertTrue(result.has("temp"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }

    @Test
    void cancelAppointmentWithException() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenThrow(new IHubException(new IHubErrorCode("2"), "My Error Message"));

            IHubException hubException = assertThrows(IHubException.class, () -> {
                cancelAppointmentsHandlerService.cancelAppointment(inputObject);
            });

            assertEquals(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), hubException.getErrorCode());
            assertEquals("My Error Message", hubException.getMessage());
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }

    @Test
    void cancelAppointmentWithException_NO_APPOINTMENT_FOUND() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("already canceled"));

            IHubException hubException = assertThrows(IHubException.class, () -> {
                cancelAppointmentsHandlerService.cancelAppointment(inputObject);
            });

            assertEquals(NO_APPOINTMENT_FOUND.getKey(), hubException.getErrorCode().getCode());
            assertEquals("APPOINTMENT IS ALREADY CANCELED", hubException.getMessage());
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }
    @Test
    void cancelAppointmentWithException_INVALID_FORMAT() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("Patient ID"));

            IHubException hubException = assertThrows(IHubException.class, () -> {
                cancelAppointmentsHandlerService.cancelAppointment(inputObject);
            });

            assertEquals(INVALID_FORMAT.getKey(), hubException.getErrorCode().getCode());
            assertEquals("PATIENT ID IS INVALID", hubException.getMessage());
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }
    }

    @Test
    void cancelAppointmentWithEmptyOutput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject outputObject = new JSONObject();

            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);
            doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
            doReturn("33").when(cacheManager).getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean());

            JSONObject result = cancelAppointmentsHandlerService.cancelAppointment(inputObject);

            assertNotNull(result);
            assertFalse(result.has("temp"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }

    }

    @Test
    void getCancelReasonWithValidInput() throws IHubException {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";
        String cancelReason = "22";

        when(cacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), eq(false)))
                .thenReturn(cancelReason);

        cancelAppointmentsHandlerService.getCancelReason(inputObject, deploymentId);
        System.out.println(inputObject.toString());
        assertEquals(22, inputObject.getJSONObject("SchedulingData").getJSONArray("Schedule").getJSONObject(0).getInt("EventReasonId"));
    }

    @Test
    void getCancelReasonWithEmptyCancelReason() throws IHubException {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        when(cacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), eq(false)))
                .thenReturn("");

        cancelAppointmentsHandlerService.getCancelReason(inputObject, deploymentId);

        assertFalse(inputObject.has("EVENT_REASON_ID"));
    }

    @Test
    void getCancelReasonWithIHubException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        when(cacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), eq(false)))
                .thenThrow(new IHubException(new IHubErrorCode("22"), "Error"));

        assertThrows(IHubException.class, () -> {
            cancelAppointmentsHandlerService.getCancelReason(inputObject, deploymentId);
        });
    }

    @Test
    void getCancelReasonWithGeneralException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        when(cacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), eq(false)))
                .thenThrow(new RuntimeException("Error"));

        assertThrows(IHubException.class, () -> {
            cancelAppointmentsHandlerService.getCancelReason(inputObject, deploymentId);
        });
    }
}