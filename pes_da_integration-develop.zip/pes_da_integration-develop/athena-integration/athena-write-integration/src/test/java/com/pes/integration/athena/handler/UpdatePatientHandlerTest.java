package com.pes.integration.athena.handler;

import static com.pes.integration.athena.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.athena.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.athena.constant.AthenaConstants.DATE_FORMAT;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.PhoneNumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;

class UpdatePatientHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private DataCacheManager dataCacheManager;
    @Mock
    DataTransactionService dataTransactionService;
    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private PatientNotificationPreferences patientNotificationPreferences;

    @Mock
    private PatientInsuranceHandler patientInsuranceHandler;

    @InjectMocks
    private UpdatePatientHandler updatePatientHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSetEmail_Exception() throws Exception {
        Method method = UpdatePatientHandler.class.getDeclaredMethod("setEmail", JSONObject.class, String.class);
        method.setAccessible(true);

        // Create a JSONObject that throws an exception when put is called
        JSONObject responseObject = new JSONObject() {
            @Override
            public JSONObject put(String key, Object value) {
                throw new RuntimeException("Forced exception");
            }
        };

        // Should not throw, just log error
        method.invoke(updatePatientHandler, responseObject, "test@example.com");
    }

    @Test
    void testDoExecuteWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DATE_FORMAT),
                            eq(DOCASAP_DATE_FORMAT))).thenReturn("20230101");
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberFromFlag(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("TestPatientId");
                    mockedJsonUtils.when(() -> getValue(any(), eq(PATIENT_ID))).thenReturn("TestPatientId");
                    mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(EMAIL))).thenReturn("test@email.com");
                    mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(EMAIL_EXISTS))).thenReturn("false");

                    JSONObject inputObject = new JSONObject();
                    inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
                    inputObject.put(EMAIL, "test@example.com");

                    JSONObject updatePatientOutput = new JSONObject();
                    updatePatientOutput.put(PATIENT_ID, "testPatientId");

                    JSONObject demographicsData = new JSONObject();
                    demographicsData.put(PATIENT_ID, "testPatientId");

                    JSONObject responseObject = new JSONObject();
                    responseObject.put(PATIENT_ID, "testPatientId");

                    JSONObject policyHolderInformation = new JSONObject();
                    policyHolderInformation.put(POLICYHOLDER_INFORMATION, "policyHolderInformation");
                    mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(POLICYHOLDER_INFORMATION))).thenReturn(policyHolderInformation);

                    when(patientNotificationPreferences.arePatientNotificationPreferencesPresent(any(JSONObject.class)))
                            .thenReturn(true);
                    when(patientNotificationPreferences.getPatientNotificationPreferences(any(JSONObject.class)))
                            .thenReturn(new JSONObject());

                    doNothing().when(dataTransactionService).logData(any(), any(), any(), any());
                    when(athenaApiCaller.call(eq(ApiName.UPDATE_PATIENT.getKey()), any(JSONObject.class), eq(UPDATE_PATIENT.getKey())))
                            .thenReturn(updatePatientOutput);
                    when(athenaApiCaller.call(eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq(UPDATE_PATIENT.getKey())))
                            .thenReturn(demographicsData);
                    when(athenaApiCaller.call(eq(GET_PATIENT_INSURANCE.getKey()), any(JSONObject.class), eq(UPDATE_PATIENT.getKey())))
                            .thenReturn(new JSONObject());

                    when(dataCacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                            eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                            .thenReturn("false");

                    JSONObject result = updatePatientHandler.doExecute(inputObject);

                    assertNotNull(result);
                    verify(athenaApiCaller, times(2)).call(eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq(UPDATE_PATIENT.getKey()));
                    verify(patientInsuranceHandler, times(1)).doExecute(any(JSONObject.class));
                }
            }
        }
    }

    @Test
    void testFindNextDocasapObject() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject epmObject = new JSONObject();
        epmObject.put("key", new JSONArray().put(new JSONObject().put("subKey", "subValue")));

        JSONObject updateObject = new JSONObject();
        String key = "key";
        JSONArray nextDocasapObject = new JSONArray().put(new JSONObject().put("subKey", "subValue"));

        Method method = getMethod("findNextDocasapObject", JSONObject.class, JSONObject.class, String.class, Object.class);
        method.invoke(updatePatientHandler, epmObject, updateObject, key, nextDocasapObject);
        System.out.println(updateObject);
        assertTrue(updateObject.has("key"));
    }

    @Test
    void testDoExecuteWithValidInput_IHubException() {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenThrow(new RuntimeException("error"));
            Assertions.assertThrows(RuntimeException.class, () -> updatePatientHandler.doExecute(new JSONObject()));
        }
    }

    @Test
    void testUpdateNotificationStatus() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(NOTIFICATION_STATUS))).thenReturn(DAEON);

            JSONObject inputObject = new JSONObject();
            inputObject.put(NOTIFICATION_STATUS, DAEON);
            inputObject.put("EMAIL", "test@example.com");

            JSONObject updateObject = new JSONObject();

            Method method = getMethod("updateNotificationStatus", String.class, Object.class, JSONObject.class);
            Object notificationStatus = method.invoke(updatePatientHandler, "test@example.com", updateObject, inputObject);

            assertEquals(DAEON, notificationStatus);
        }
    }

    @Test
    void testUpdateNotificationStatus_DATON() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(NOTIFICATION_STATUS))).thenReturn(DATON);

            JSONObject inputObject = new JSONObject();
            inputObject.put(NOTIFICATION_STATUS, DATON);
            inputObject.put("EMAIL", "test@example.com");

            JSONObject updateObject = new JSONObject();

            Method method = getMethod("updateNotificationStatus", String.class, Object.class, JSONObject.class);
            Object notificationStatus = method.invoke(updatePatientHandler, "test@example.com", updateObject, inputObject);

            assertEquals(DATON, notificationStatus);
        }
    }

    @Test
    void testUpdateNotificationStatus_DAOFF() throws Exception {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> getValue(any(JSONObject.class), eq(NOTIFICATION_STATUS))).thenReturn(DAOFF);

            JSONObject inputObject = new JSONObject();
            inputObject.put(NOTIFICATION_STATUS, DAOFF);
            inputObject.put("EMAIL", "test@example.com");

            JSONObject updateObject = new JSONObject();

            Method method = getMethod("updateNotificationStatus", String.class, Object.class, JSONObject.class);
            Object notificationStatus = method.invoke(updatePatientHandler, "test@example.com", updateObject, inputObject);

            assertEquals(DAOFF, notificationStatus);
        }
    }

    private static Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = UpdatePatientHandler.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

    @Test
    void testUpdateGetPatientObject() throws Exception {
        // Arrange
        JSONObject updateObject = new JSONObject();
        String key = "testKey";
        JSONObject nextDocasapObject = new JSONObject();
        nextDocasapObject.put("nestedKey", "nestedValue");
        JSONObject nextEpmObject = new JSONObject();
        nextEpmObject.put("nestedKey", "nestedValue");
        JSONObject nextUpdateObject = null;

        // Use reflection to access the private method
        Method method = UpdatePatientHandler.class.getDeclaredMethod(
                "updateGetPatientObject", JSONObject.class, String.class, Object.class, Object.class, Object.class
        );
        method.setAccessible(true);

        // Act
        method.invoke(updatePatientHandler, updateObject, key, nextDocasapObject, nextEpmObject, nextUpdateObject);

        // Debugging: Print the updateObject to verify its structure
        System.out.println("updateObject after method invocation: " + updateObject.toString());

        // Assert
        assertTrue(updateObject.has(key), "Key '" + key + "' not found in updateObject");
        JSONObject resultObject = updateObject.getJSONObject(key);
        assertNotNull(resultObject, "Result object is null for key: " + key);
        assertEquals("nestedValue", resultObject.optString("nestedKey", "nestedValue"), "Unexpected value for 'nestedKey'");
    }

    @Test
    void testSetPolicyHolderInfo_setValueThrowsException() throws Exception {
        UpdatePatientHandler handler = new UpdatePatientHandler();
        JSONObject policyholderInputObject = new JSONObject();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";
        JSONObject policyholderInformation = new JSONObject();

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
             MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = mockStatic(com.pes.integration.utils.NullChecker.class)) {

            jsonUtilsMock.when(() -> getValue(eq(inputObject), eq(POLICYHOLDER_INFORMATION)))
                    .thenReturn(policyholderInformation);
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(policyholderInformation)).thenReturn(false);
            jsonUtilsMock.when(() -> setValue(eq(policyholderInputObject), eq(POLICYHOLDER_INFORMATION), eq(policyholderInformation)))
                    .thenThrow(new IHubException(null, "err"));

            Method method = UpdatePatientHandler.class.getDeclaredMethod(
                    "setPolicyHolderInfo", JSONObject.class, JSONObject.class, String.class);
            method.setAccessible(true);

            // Should not throw, just log error
            method.invoke(handler, policyholderInputObject, inputObject, deploymentId);
        }
    }

    @Test
    void testRemoveGuarantorInformation_setValueThrowsException() throws Exception {
        UpdatePatientHandler handler = new UpdatePatientHandler();
        JSONObject updatePatientInputObject = new JSONObject();
        String deploymentId = "depId";

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtilsMock.when(() -> setValue(eq(updatePatientInputObject), eq(GURANTOR_INFORMATION_ARR), isNull()))
                    .thenThrow(new com.pes.integration.exceptions.IHubException(null, "err"));

            Method method = UpdatePatientHandler.class.getDeclaredMethod(
                    "removeGuarantorInformation", JSONObject.class, String.class);
            method.setAccessible(true);

            // Should not throw, just log error
            method.invoke(handler, updatePatientInputObject, deploymentId);

            jsonUtilsMock.verify(() -> setValue(eq(updatePatientInputObject), eq(GURANTOR_INFORMATION_ARR), isNull()), times(1));
        }
    }

    @Test
    void testGetUpdatePatientObject_withException() throws Exception {
        UpdatePatientHandler handler = new UpdatePatientHandler();

        // docasapObject contains a key with a value that will cause an exception in findNextDocasapObject
        JSONObject docasapObject = new JSONObject();
        docasapObject.put("key1", "value1");

        JSONObject epmObject = new JSONObject();
        epmObject.put("key1", "epmValue1");

        JSONObject updateObject = new JSONObject();

        // Use reflection to invoke the method
        Method method = UpdatePatientHandler.class.getDeclaredMethod(
                "getUpdatePatientObject", JSONObject.class, JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        // To simulate an exception, spy the handler and throw from findNextDocasapObject
        UpdatePatientHandler spyHandler = Mockito.spy(handler);

        assertThrows(Exception.class, () ->  method.invoke(spyHandler, null, epmObject, updateObject));

    }

    @Test
    void testSetPatientNotification_preferencesPresent() throws Exception {
        UpdatePatientHandler handler = new UpdatePatientHandler();
        JSONObject responseObject = new JSONObject();
        JSONObject inputObject = new JSONObject();

        // Mock patientNotificationPreferences
        UpdatePatientHandler spyHandler = Mockito.spy(handler);
        spyHandler.patientNotificationPreferences = mock(PatientNotificationPreferences.class);

        when(spyHandler.patientNotificationPreferences.arePatientNotificationPreferencesPresent(inputObject)).thenReturn(true);

        Method method = UpdatePatientHandler.class.getDeclaredMethod(
                "setPatientNotification", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        method.invoke(spyHandler, responseObject, inputObject);

        verify(spyHandler.patientNotificationPreferences, times(1)).setPatientNotificationPreferences(responseObject);
    }

    @Test
    void testSetPatientNotification_preferencesNotPresent() throws Exception {
        UpdatePatientHandler handler = new UpdatePatientHandler();
        JSONObject responseObject = new JSONObject();
        JSONObject inputObject = new JSONObject();

        JSONObject demographicInfo = new JSONObject();
        demographicInfo.put(EMAILNOTIFICATIONSTATUS, "on");
        demographicInfo.put(TEXTNOTIFICATIONSTATUS, "on");
        demographicInfo.put(VOICENOTIFICATIONSTATUS, "on");
        responseObject.put(DEMOGRAPHIC_PATIENT_INFO, demographicInfo);

        UpdatePatientHandler spyHandler = Mockito.spy(handler);
        spyHandler.patientNotificationPreferences = mock(PatientNotificationPreferences.class);

        when(spyHandler.patientNotificationPreferences.arePatientNotificationPreferencesPresent(inputObject)).thenReturn(false);

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtilsMock.when(() -> getValue(responseObject, DEMOGRAPHIC_PATIENT_INFO)).thenReturn(demographicInfo);

            Method method = UpdatePatientHandler.class.getDeclaredMethod(
                    "setPatientNotification", JSONObject.class, JSONObject.class);
            method.setAccessible(true);

            method.invoke(spyHandler, responseObject, inputObject);

            // Assert that notification statuses are removed
            assertFalse(demographicInfo.has(EMAILNOTIFICATIONSTATUS));
            assertFalse(demographicInfo.has(TEXTNOTIFICATIONSTATUS));
            assertFalse(demographicInfo.has(VOICENOTIFICATIONSTATUS));
        }
    }


    @Test
    void testSetDob_invalidDob_throwsIHubException() throws Exception {
        UpdatePatientHandler handler = new UpdatePatientHandler();
        JSONObject responseObject = new JSONObject();

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
             MockedStatic<com.pes.integration.utils.DateUtils> dateUtilsMock = mockStatic(com.pes.integration.utils.DateUtils.class);
             MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = mockStatic(com.pes.integration.utils.NullChecker.class);
             MockedStatic<com.pes.integration.utils.LogUtil> logUtilMock = mockStatic(com.pes.integration.utils.LogUtil.class)) {

            jsonUtilsMock.when(() -> getValue(responseObject, DOB)).thenReturn("invalid-date");
            nullCheckerMock.when(() -> isEmpty("invalid-date")).thenReturn(false);
            dateUtilsMock.when(() -> convertDateFormat("invalid-date", DATE_FORMAT, DOCASAP_DATE_FORMAT))
                    .thenThrow(new ParseException("Invalid date", 0));
            logUtilMock.when(() -> sanitizeForLog("invalid-date")).thenReturn("invalid-date");

            Method method = UpdatePatientHandler.class.getDeclaredMethod("setDob", Object.class);
            method.setAccessible(true);

            Exception exception = assertThrows(
                    java.lang.reflect.InvocationTargetException.class,
                    () -> method.invoke(handler, responseObject)
            );
            assertTrue(exception.getCause() instanceof com.pes.integration.exceptions.IHubException);
            assertTrue(exception.getCause().getMessage().contains("DOB was invalid or null."));
        }
    }
}