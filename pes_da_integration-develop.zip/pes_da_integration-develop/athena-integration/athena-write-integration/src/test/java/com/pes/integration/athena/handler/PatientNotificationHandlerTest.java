package com.pes.integration.athena.handler;

import static com.pes.integration.constant.DocASAPConstants.Key.ERROR_DETAIL;
import static com.pes.integration.constant.DocASAPConstants.Key.PATIENT_ID;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

class PatientNotificationHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private PatientNotificationPreferences patientNotificationPreferences;

    @InjectMocks
    private PatientNotificationHandler patientNotificationHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void executeWithValidInputAndPreferencesPresent() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("TestPatientId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("PATIENT_ID", "testPatientId");

            JSONObject updatePatientObject = new JSONObject(inputObject.toString());
            JSONObject outputObject = new JSONObject();
            outputObject.put("status", "success");

            when(patientNotificationPreferences.arePatientNotificationPreferencesPresent(any(JSONObject.class))).thenReturn(true);
            when(patientNotificationPreferences.getPatientNotificationPreferences(any(JSONObject.class))).thenReturn(updatePatientObject);
            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);

            JSONObject result = patientNotificationHandler.doExecute(inputObject);

            assertNotNull(result);
            assertEquals("success", result.getString("status"));
            verify(patientNotificationPreferences, times(1)).arePatientNotificationPreferencesPresent(any());
            verify(patientNotificationPreferences, times(1)).getPatientNotificationPreferences(any());
            verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
        }

    }

    @Test
    void executeWithValidInputAndPreferencesNotPresent() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("PATIENT_ID", "testPatientId");

        JSONObject updatePatientObject = new JSONObject(inputObject.toString());

        when(patientNotificationPreferences.arePatientNotificationPreferencesPresent(updatePatientObject)).thenReturn(false);

        JSONObject result = patientNotificationHandler.doExecute(inputObject);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(patientNotificationPreferences, times(1)).arePatientNotificationPreferencesPresent(any());
        verify(patientNotificationPreferences, times(0)).getPatientNotificationPreferences(any());
        verify(athenaApiCaller, times(0)).call(anyString(), any(JSONObject.class), anyString());
    }

    @Test
    void executeWithIHubException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("PATIENT_ID", "testPatientId");

        JSONObject updatePatientObject = new JSONObject(inputObject.toString());

        when(patientNotificationPreferences.arePatientNotificationPreferencesPresent(any())).thenReturn(true);
        when(patientNotificationPreferences.getPatientNotificationPreferences(any())).thenReturn(updatePatientObject);
        when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenThrow(new IHubException(new IHubErrorCode("22"), "Error"));

        JSONObject result = patientNotificationHandler.doExecute(inputObject);
        System.out.println(result);
        assertNotNull(result);
        assertEquals("Error", result.getString(ERROR_DETAIL));
        verify(patientNotificationPreferences, times(1)).arePatientNotificationPreferencesPresent(any());
        verify(patientNotificationPreferences, times(1)).getPatientNotificationPreferences(any());
        verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
    }

    @Test
    void executeWithGeneralException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("PATIENT_ID", "testPatientId");

        JSONObject updatePatientObject = new JSONObject(inputObject.toString());

        when(patientNotificationPreferences.arePatientNotificationPreferencesPresent(any())).thenReturn(true);
        when(patientNotificationPreferences.getPatientNotificationPreferences(any())).thenReturn(updatePatientObject);
        when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenThrow(new RuntimeException("Error"));

        JSONObject result = patientNotificationHandler.doExecute(inputObject);

        assertNotNull(result);
    }
}