package com.pes.integration.athena.consumer;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.service.AsyncConsumerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class AthenaAsyncConsumerTest {

    @Mock
    private AsyncConsumerService asyncConsumerService;

    @InjectMocks
    private AthenaAsyncConsumer athenaAsyncConsumer;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void consumeAsyncMessageWithValidPayload() {
        String payload = "{\"key\":\"value\"}";
        String syncDataTopic = "syncDataTopic";

        athenaAsyncConsumer.syncDataTopic = syncDataTopic;
        athenaAsyncConsumer.consumeAsyncMessage(payload);

        verify(asyncConsumerService, times(1)).processAsyncMessage(syncDataTopic, payload);
    }

    @Test
    void consumeAsyncMessageWithNullPayload() {
        String syncDataTopic = "syncDataTopic";

        athenaAsyncConsumer.syncDataTopic = syncDataTopic;
        athenaAsyncConsumer.consumeAsyncMessage(null);

        verify(asyncConsumerService, times(1)).processAsyncMessage(syncDataTopic, null);
    }

    @Test
    void listenWithValidMessage() {
        String topic = "d2eTopic";
        String message = "{\"key\":\"value\"}";
        String expectedTopic = "e2dTopic";

        athenaAsyncConsumer.listen(topic, message);

        verify(asyncConsumerService, times(1)).processAsyncMessage(expectedTopic, message);
    }

    @Test
    void listenWithEmptyMessage() {
        String topic = "d2eTopic";
        String message = "";
        String expectedTopic = "e2dTopic";

        athenaAsyncConsumer.listen(topic, message);

        verify(asyncConsumerService, times(1)).processAsyncMessage(expectedTopic, message);
    }
}