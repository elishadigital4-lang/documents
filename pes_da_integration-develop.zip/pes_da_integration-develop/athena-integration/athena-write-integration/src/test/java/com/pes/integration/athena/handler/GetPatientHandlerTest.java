package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.text.ParseException;

import static com.pes.integration.athena.api.ApiName.GET_PATIENTS;
import static com.pes.integration.athena.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.DOB;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.SEARCH_PATIENT;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

class GetPatientHandlerTest {
    @InjectMocks
    private GetPatientHandler getPatientHandler;

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private HandlerUtils handlerUtils;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecute() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testPatientId");
                jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DOCASAP_DATE_FORMAT), eq(EPM_DATE_FORMAT))).thenReturn("19900101");

                JSONObject inputObject = new JSONObject();
                inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

                JSONObject outputObject = new JSONObject();
                JSONObject tempObject = new JSONObject();
                tempObject.put("appointment_status", "x");
                outputObject.put("temp", tempObject);

                when(athenaApiCaller.call(eq(GET_PATIENTS.getKey()),
                        any(JSONObject.class), eq(SEARCH_PATIENT.getKey()))).thenReturn(outputObject);
                doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
                doReturn("22").when(cacheManager)
                        .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(DEFAULT_CANCEL_REASON), eq(false));

                JSONObject result = getPatientHandler.doExecute(inputObject);

                assertNotNull(result);
                assertEquals("x", result.getJSONObject("temp").getString("appointment_status"));
                verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
                verify(athenaApiCaller, times(1)).call(anyString(), any(JSONObject.class), anyString());
            }
        }
    }

    @Test
    void doExecute_IHubException() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testPatientId");
                jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-XXX-01");
                dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DOCASAP_DATE_FORMAT), eq(EPM_DATE_FORMAT))).thenThrow(new ParseException("parse exception",3));

                JSONObject inputObject = new JSONObject();
                inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

                JSONObject outputObject = new JSONObject();
                JSONObject tempObject = new JSONObject();
                tempObject.put("appointment_status", "x");
                outputObject.put("temp", tempObject);

                when(athenaApiCaller.call(eq(GET_PATIENTS.getKey()),
                        any(JSONObject.class), eq(SEARCH_PATIENT.getKey()))).thenReturn(outputObject);
                doNothing().when(handlerUtils).addPracticeId(anyString(), any(JSONObject.class));
                doReturn("22").when(cacheManager)
                        .getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(), eq(ATHENA_CONFIG), eq(DEFAULT_CANCEL_REASON), eq(false));

                IHubException hubException = assertThrows(IHubException.class, () -> getPatientHandler.doExecute(inputObject));

                assertTrue(hubException.getMessage().contains("DOB was invalid or null"));
                assertEquals(DATA_VALIDATION_ERROR.getErrorCode(),hubException.getErrorCode());
            }
        }
    }
}