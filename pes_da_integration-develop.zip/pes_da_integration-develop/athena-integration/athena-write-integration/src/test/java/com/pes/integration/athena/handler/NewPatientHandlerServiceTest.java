package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static com.pes.integration.athena.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.athena.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_PATIENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.ERROR_CODE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.StatusCodes.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NewPatientHandlerServiceTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;
    @Mock
    private DataTransactionService dataTransactionService;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private MatchPatientHandler matchPatientHandler;

    @Mock
    private PatientNotificationHandler patientNotificationHandler;

    @Mock
    private PatientNotificationPreferences patientNotificationPreferences;

    @Mock
    private PatientInsuranceHandler patientInsuranceHandler;

    @InjectMocks
    private NewPatientHandlerService newPatientHandlerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getPatMatchingLayerPriConfStr_shouldLogError_whenExceptionThrown() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        // Inject mock via reflection
        var field = NewPatientHandlerService.class.getDeclaredField("cacheManager");
        field.setAccessible(true);
        field.set(service, mockCacheManager);

        when(mockCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenThrow(new RuntimeException("Priority config error"));

        Method method = NewPatientHandlerService.class
                .getDeclaredMethod("getPatMatchingLayerPriConfStr", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(service, "testDeploymentId");
        assertNull(result); // Should return null
    }

    @Test
    void getPatMatchingAlgoConfigStr_shouldLogError_whenExceptionThrown() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        // Inject mock via reflection
        var field = NewPatientHandlerService.class.getDeclaredField("cacheManager");
        field.setAccessible(true);
        field.set(service, mockCacheManager);

        when(mockCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenThrow(new RuntimeException("Config error"));

        Method method = NewPatientHandlerService.class
                .getDeclaredMethod("getPatMatchingAlgoConfigStr", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(service, "testDeploymentId");
        assertEquals("", result); // Should return EMPTY string
    }

    @Test
    void createNewPatientWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("TestPatientId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject matchPatientResponse = new JSONObject();
            matchPatientResponse.put("APPOINTMENT_PATIENT_ID", JSONObject.NULL);
            when(matchPatientHandler.processMatchPatient(any(JSONObject.class), any(JSONObject.class)))
                    .thenReturn(matchPatientResponse);

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_ID", "testPatientId");
            when(athenaApiCaller.call(eq("new_patient"), any(JSONObject.class), eq("create_patient")))
                    .thenReturn(apiResponse);
            doNothing().when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                    .thenReturn(apiResponse);
            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_TEXT), eq(false)))
                    .thenReturn(apiResponse);


            assertDoesNotThrow(() -> newPatientHandlerService.createNewPatient(inputObject));


        }
    }

    @Test
    void createNewPatientWithValidInput_error() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_PATIENT_ID))).thenReturn("TestPatientId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(ERROR_CODE))).thenReturn(MULTIPLE_PATIENT.getKey());

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject matchPatientResponse = new JSONObject();
            matchPatientResponse.put("APPOINTMENT_PATIENT_ID", JSONObject.NULL);
            when(matchPatientHandler.processMatchPatient(any(JSONObject.class), any(JSONObject.class)))
                    .thenReturn(matchPatientResponse);

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_ID", "testPatientId");
            when(athenaApiCaller.call(eq("new_patient"), any(JSONObject.class), eq("create_patient")))
                    .thenReturn(apiResponse);
            doNothing().when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                    .thenReturn(apiResponse);
            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_TEXT), eq(false)))
                    .thenReturn(apiResponse);


            assertDoesNotThrow(() -> newPatientHandlerService.createNewPatient(inputObject));


        }
    }

    @Test
    void createNewPatientWithValidInput_2() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_PATIENT_ID))).thenReturn("TestPatientId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(ERROR_CODE))).thenReturn("errorCode");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject matchPatientResponse = new JSONObject();
            matchPatientResponse.put("APPOINTMENT_PATIENT_ID", JSONObject.NULL);
            when(matchPatientHandler.processMatchPatient(any(JSONObject.class), any(JSONObject.class)))
                    .thenReturn(matchPatientResponse);

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_ID", "testPatientId");
            when(athenaApiCaller.call(eq("new_patient"), any(JSONObject.class), eq("create_patient")))
                    .thenReturn(apiResponse);
            doNothing().when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                    .thenReturn(apiResponse);
            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_TEXT), eq(false)))
                    .thenReturn(apiResponse);


            assertDoesNotThrow(() -> newPatientHandlerService.createNewPatient(inputObject));


        }
    }

    @Test
    void createNewPatientWithValidInput_hubException() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("TestPatientId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject matchPatientResponse = new JSONObject();
            matchPatientResponse.put("APPOINTMENT_PATIENT_ID", JSONObject.NULL);
            when(matchPatientHandler.processMatchPatient(any(JSONObject.class), any(JSONObject.class)))
                    .thenReturn(matchPatientResponse);
            doThrow(new RuntimeException("My Error Message")).when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_ID", "testPatientId");
            when(athenaApiCaller.call(eq("new_patient"), any(JSONObject.class), eq("create_patient")))
                    .thenReturn(apiResponse);

            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                    .thenReturn(apiResponse);
            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_TEXT), eq(false)))
                    .thenReturn(apiResponse);

            IHubException hubException = assertThrows(IHubException.class, () -> newPatientHandlerService.createNewPatient(inputObject));
            Assertions.assertEquals(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), hubException.getErrorCode());
            Assertions.assertEquals("My Error Message", hubException.getMessage());


        }
    }

    @Test
    void createNewPatientWithValidInput_hubException_NO_LAST_NAME_FOUND() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("TestPatientId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject matchPatientResponse = new JSONObject();
            matchPatientResponse.put("APPOINTMENT_PATIENT_ID", JSONObject.NULL);
            when(matchPatientHandler.processMatchPatient(any(JSONObject.class), any(JSONObject.class)))
                    .thenReturn(matchPatientResponse);
            doThrow(new RuntimeException("My Error Message lastname")).when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_ID", "testPatientId");
            when(athenaApiCaller.call(eq("new_patient"), any(JSONObject.class), eq("create_patient")))
                    .thenReturn(apiResponse);

            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                    .thenReturn(apiResponse);
            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_TEXT), eq(false)))
                    .thenReturn(apiResponse);

            IHubException hubException = assertThrows(IHubException.class, () -> newPatientHandlerService.createNewPatient(inputObject));
            Assertions.assertEquals(NO_LAST_NAME_FOUND.getKey(), hubException.getErrorCode().getCode());
            Assertions.assertEquals("NO LAST NAME FOUND", hubException.getMessage());


        }
    }
    @Test
    void createNewPatientWithValidInput_hubException_NO_FIRST_NAME_FOUND() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("TestPatientId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject matchPatientResponse = new JSONObject();
            matchPatientResponse.put("APPOINTMENT_PATIENT_ID", JSONObject.NULL);
            when(matchPatientHandler.processMatchPatient(any(JSONObject.class), any(JSONObject.class)))
                    .thenReturn(matchPatientResponse);
            doThrow(new RuntimeException("My Error Message firstname")).when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_ID", "testPatientId");
            when(athenaApiCaller.call(eq("new_patient"), any(JSONObject.class), eq("create_patient")))
                    .thenReturn(apiResponse);

            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                    .thenReturn(apiResponse);
            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_TEXT), eq(false)))
                    .thenReturn(apiResponse);

            IHubException hubException = assertThrows(IHubException.class, () -> newPatientHandlerService.createNewPatient(inputObject));
            Assertions.assertEquals(NO_FIRST_NAME_FOUND.getKey(), hubException.getErrorCode().getCode());
            Assertions.assertEquals("NO FIRST NAME FOUND", hubException.getMessage());


        }
    }

    @Test
    void createNewPatientWithValidInput_hubException_INVALID_FORMAT() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("TestPatientId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");

            JSONObject matchPatientResponse = new JSONObject();
            matchPatientResponse.put("APPOINTMENT_PATIENT_ID", JSONObject.NULL);
            when(matchPatientHandler.processMatchPatient(any(JSONObject.class), any(JSONObject.class)))
                    .thenReturn(matchPatientResponse);
            doThrow(new RuntimeException("My Error Message HOMEPHONE")).when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_ID", "testPatientId");
            when(athenaApiCaller.call(eq("new_patient"), any(JSONObject.class), eq("create_patient")))
                    .thenReturn(apiResponse);

            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_EMAIL), eq(false)))
                    .thenReturn(apiResponse);
            when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), anyString(),
                    eq(ATHENA_CONFIG), eq(CONSENT_TO_TEXT), eq(false)))
                    .thenReturn(apiResponse);

            IHubException hubException = assertThrows(IHubException.class, () -> newPatientHandlerService.createNewPatient(inputObject));
            Assertions.assertEquals(INVALID_FORMAT.getKey(), hubException.getErrorCode().getCode());
            Assertions.assertEquals("HOMEPHONE IS INVALID", hubException.getMessage());


        }
    }

    @Test
    void handleInsuranceWithValidInput() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
        inputObject.put(DEMOGRAPHIC_DATA, new JSONObject().put("InsuranceInformation", new JSONObject()));
        inputObject.put("APPT_LOCATION_ID", "testLocationId");
        inputObject.put("PATIENT_ID", "testPatientId");
        inputObject.put("DA_PATIENT_ID", "testDaPatientId");

        doReturn(new JSONObject()).when(patientInsuranceHandler).doExecute(any(JSONObject.class));
        getMethod("handleInsurance", JSONObject.class, Object.class)
                .invoke(newPatientHandlerService, inputObject, "testPatientId");

        verify(patientInsuranceHandler, times(1)).doExecute(any(JSONObject.class));
    }

    @Test
    void handleInsuranceWithException() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
        inputObject.put(DEMOGRAPHIC_DATA, new JSONObject().put("InsuranceInformation", new JSONObject()));
        inputObject.put("APPT_LOCATION_ID", "testLocationId");
        inputObject.put("PATIENT_ID", "testPatientId");
        inputObject.put("DA_PATIENT_ID", "testDaPatientId");

        doThrow(new IHubException(new IHubErrorCode("22"), "Error")).when(patientInsuranceHandler).doExecute(any(JSONObject.class));
        doNothing().when(dataTransactionService).logData(any(JSONObject.class), anyString(), anyString(), anyString());

        getMethod("handleInsurance", JSONObject.class, Object.class)
                .invoke(newPatientHandlerService, inputObject, "testPatientId");

        verify(patientInsuranceHandler, times(1)).doExecute(any(JSONObject.class));
        verify(dataTransactionService, times(1)).logData(any(JSONObject.class), eq("CREATE_PATIENT"), eq("FAILED"), contains("Error in adding insurance to patient"));
    }

    @Test
    void getPatientDemographicsWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            JSONObject inputObject = new JSONObject();
            inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_DEMOGRAPHICS", new JSONObject());
            when(athenaApiCaller.call(eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq(CREATE_PATIENT.getKey())))
                    .thenReturn(apiResponse);

            JSONObject result = newPatientHandlerService.getPatientDemographics(inputObject);

            assertNotNull(result);
            assertTrue(result.has("PATIENT_DEMOGRAPHICS"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(eq(GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq(CREATE_PATIENT.getKey()));
        }
    }

    @Test
    void getPatientInsuranceWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            JSONObject inputObject = new JSONObject();
            inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

            JSONObject apiResponse = new JSONObject();
            apiResponse.put("PATIENT_DEMOGRAPHICS", new JSONObject());
            when(athenaApiCaller.call(eq(GET_PATIENT_INSURANCE.getKey()), any(JSONObject.class), eq(CREATE_PATIENT.getKey())))
                    .thenReturn(apiResponse);

            JSONObject result = newPatientHandlerService.getPatientInsuranceInfo(inputObject);

            assertNotNull(result);
            assertTrue(result.has("PATIENT_DEMOGRAPHICS"));
            verify(handlerUtils, times(1)).addPracticeId(anyString(), any(JSONObject.class));
            verify(athenaApiCaller, times(1)).call(eq(GET_PATIENT_INSURANCE.getKey()), any(JSONObject.class), eq(CREATE_PATIENT.getKey()));
        }
    }

    private static Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = NewPatientHandlerService.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }
}