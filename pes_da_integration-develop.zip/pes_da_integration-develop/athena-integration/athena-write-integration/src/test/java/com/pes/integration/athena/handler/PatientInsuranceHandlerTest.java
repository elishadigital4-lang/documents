package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.config.data.ManageFlagsUtility;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.PhoneNumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.INSURANCE_PH_DOB;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PatientInsuranceHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private ManageFlagsUtility manageFlagsUtility;

    @Mock
    private GetPatientInsurancesHandler getPatientInsurancesHandler;
    @Mock
    private DataCacheManager dataCacheManager;

    @InjectMocks
    private PatientInsuranceHandler patientInsuranceHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addInsurancesAtTop_outputSequenceNumberLessThanOrEqualToSequenceNumber() throws Exception {
        PatientInsuranceHandler handler = new PatientInsuranceHandler();
        JSONArray inputInsurances = new JSONArray();
        JSONObject inputInsurance = new JSONObject().put("SEQUENCE_NUMBER", "2").put("INSURANCE_PAYOR_ID", "payor1");
        inputInsurances.put(inputInsurance);

        JSONArray outputInsurances = new JSONArray();
        JSONObject outputInsurance = new JSONObject().put("SEQUENCE_NUMBER", "1").put("INSURANCE_PAYOR_ID", "payor2");
        outputInsurances.put(outputInsurance);


        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        outputInsuranceMap.put("payor2", outputInsurance);
        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor2");
        Method method = PatientInsuranceHandler.class.getDeclaredMethod("addInsurancesAtTop", JSONObject.class, JSONObject.class, JSONArray.class, JSONArray.class, HashMap.class, HashSet.class);
        method.setAccessible(true);

        // Should not throw, and should cover the outputSequenceNumber <= sequenceNumber branch
        Assertions.assertDoesNotThrow(() -> method.invoke(handler, inputObject, outputObject, inputInsurances, outputInsurances, outputInsuranceMap, addedPlanIds));
    }

    @Test
    void addInsurancesAtTop_ExceptionLogging() throws Exception {
        // Prepare input and output objects that will cause an exception in outputInsurancesArray.getJSONObject(outputIndex)
        PatientInsuranceHandler handler = new PatientInsuranceHandler();
        JSONArray inputInsurances = new JSONArray();
        inputInsurances.put(new JSONObject().put("SEQUENCE_NUMBER", "1"));

        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();


        Method method = PatientInsuranceHandler.class.getDeclaredMethod("addInsurancesAtTop", JSONObject.class, JSONObject.class, JSONArray.class, JSONArray.class, HashMap.class, HashSet.class);
        method.setAccessible(true);

        // Should not throw, but will log the error
        Assertions.assertDoesNotThrow(() -> method.invoke(handler, inputObject, outputObject, inputInsurances, new JSONArray(), new HashMap<>(), new HashSet<>()));
    }

    @Test
    void getInsuranceLogic_Exception() throws Exception {
        // Arrange
        String deploymentId = "testDeploymentId";
        PatientInsuranceHandler handler = new PatientInsuranceHandler();
        DataCacheManager mockDataCacheManager = mock(DataCacheManager.class);

        // Use reflection to inject the mock
        Field field = null;
        try {
            field = PatientInsuranceHandler.class.getDeclaredField("dataCacheManager");
        } catch (NoSuchFieldException e) {
            // Try superclass if not found in current class
            field = PatientInsuranceHandler.class.getSuperclass().getDeclaredField("dataCacheManager");
        }
        field.setAccessible(true);
        field.set(handler, mockDataCacheManager);

        when(mockDataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Simulated exception"));

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getInsuranceLogic", String.class);
        method.setAccessible(true);

        // Act
        Object result = method.invoke(handler, deploymentId);

        // Assert
        assertNull(result);
    }

    @Test
    void doExecuteWithValidInputAndAddInsurancesAtBottom() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("TestPatientId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.SEQUENCE_NUMBER))).thenReturn("1");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
            inputObject.put("INSURANCE_INFORMATION", new JSONArray());
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.INSURANCE_INFORMATION))).thenReturn(new JSONArray().put(inputObject));

            JSONObject outputObject = new JSONObject();
            outputObject.put("INSURANCE_INFORMATION", new JSONArray());

            when(getPatientInsurancesHandler.doExecute(any(JSONObject.class))).thenReturn(outputObject);
            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(new JSONObject());
            when(manageFlagsUtility.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("father:mother");
            when(dataCacheManager.getStoredProvidersConfig(
                    eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(),
                    eq(AthenaEngineConstants.ATHENA_CONFIG), eq(AthenaEngineConstants.INSURANCE_LOGIC), eq(false)
            )).thenReturn("add_to_bottom");

            JSONObject result = patientInsuranceHandler.doExecute(inputObject);

            assertNotNull(result);
            assertTrue(result.has("INSURANCE_INFORMATION"));
            verify(getPatientInsurancesHandler, times(1)).doExecute(inputObject);
        }
    }

    @Test
    void doExecuteWithValidInputAndAddInsurancesAtTop() throws IHubException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("TestPatientId");
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.SEQUENCE_NUMBER))).thenReturn("1");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
            inputObject.put("INSURANCE_INFORMATION", new JSONArray());
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.INSURANCE_INFORMATION))).thenReturn(new JSONArray().put(inputObject));

            JSONObject outputObject = new JSONObject();
            outputObject.put("INSURANCE_INFORMATION", new JSONArray());

            when(getPatientInsurancesHandler.doExecute(any(JSONObject.class))).thenReturn(outputObject);
            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(new JSONObject());
            when(manageFlagsUtility.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("father:mother");
            when(dataCacheManager.getStoredProvidersConfig(
                    eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(),
                    eq(AthenaEngineConstants.ATHENA_CONFIG), eq(AthenaEngineConstants.INSURANCE_LOGIC), eq(false)
            )).thenReturn("add_to_top");

            JSONObject result = patientInsuranceHandler.doExecute(inputObject);

            assertNotNull(result);
            assertTrue(result.has("INSURANCE_INFORMATION"));
            verify(getPatientInsurancesHandler, times(1)).doExecute(inputObject);
        }
    }

    @Test
    void addInsurancesAtBottomWithValidInput() throws IHubException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
        JSONArray inputInsurances = new JSONArray();
        inputInsurances.put(new JSONObject().put("INSURANCE_PAYOR_ID", "payor1"));
        inputObject.put("INSURANCE_INFORMATION", inputInsurances);

        JSONObject outputObject = new JSONObject();
        JSONArray outputInsurances = new JSONArray();
        outputObject.put("INSURANCE_INFORMATION", outputInsurances);
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        outputInsuranceMap.put("payor1", new JSONObject());
        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor1");

        Method method = getMethod("addInsurancesAtBottom", JSONObject.class, JSONObject.class, JSONArray.class, HashMap.class, HashSet.class);

        // Invoke the private method
        Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, outputObject, inputInsurances, outputInsuranceMap, addedPlanIds));

    }

    @Test
    void addInsurancesAtTopWithValidInput() throws IHubException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
        JSONArray inputInsurances = new JSONArray();
        inputInsurances.put(new JSONObject().put("INSURANCE_PAYOR_ID", "payor1"));
        inputObject.put("INSURANCE_INFORMATION", inputInsurances);

        JSONObject outputObject = new JSONObject();
        JSONArray outputInsurances = new JSONArray();
        outputObject.put("INSURANCE_INFORMATION", outputInsurances);
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        outputInsuranceMap.put("payor1", new JSONObject());
        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor1");

        Method method = getMethod("addInsurancesAtTop", JSONObject.class, JSONObject.class, JSONArray.class, JSONArray.class, HashMap.class, HashSet.class);

        // Invoke the private method
        Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, outputObject, inputInsurances, outputInsurances, outputInsuranceMap, addedPlanIds));

    }

    @Test
    void addInsurancesAtBottomWithValidInput_outputInsuranceMap() throws IHubException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.INSURANCE_PAYOR_ID))).thenReturn("1");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
            JSONArray inputInsurances = new JSONArray();
            inputInsurances.put(new JSONObject().put("INSURANCE_PAYOR_ID", "payor1"));
            inputObject.put("INSURANCE_INFORMATION", inputInsurances);

            JSONObject outputObject = new JSONObject();
            JSONArray outputInsurances = new JSONArray();
            outputObject.put("INSURANCE_INFORMATION", outputInsurances);

            HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
            outputInsuranceMap.put("1", new JSONObject());
            HashSet<String> planIds = new HashSet<>();
            planIds.add("1");
            Method method = getMethod("addInsurancesAtBottom", JSONObject.class, JSONObject.class, JSONArray.class, HashMap.class, HashSet.class);

            // Invoke the private method
            Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, outputObject, inputInsurances, outputInsuranceMap, planIds));
        }
    }

    @Test
    void setInputInsuranceObjectWithValidInput() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String insuredFName = "John";
        String insuredLName = "Doe";
        String insuredGender = "Male";
        Object locationId = "123";
        int index = 0;

        JSONArray inputInsurancesArray = new JSONArray();
        JSONObject insuranceObject = new JSONObject();
        inputInsurancesArray.put(insuranceObject);
        Method method = getMethod("setInputInsuranceObject", String.class, String.class, String.class, Object.class, int.class, JSONArray.class);

        method.invoke(patientInsuranceHandler, insuredFName, insuredLName, insuredGender, locationId, index, inputInsurancesArray);

    }

    @Test
    void checkAndAddInsuranceWithValidInput() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.INSURANCE_PAYOR_ID))).thenReturn("1");

            JSONObject inputObject = new JSONObject();
            inputObject.put("PATIENT_ID", "testPatientId");

            JSONObject outputObject = new JSONObject();
            JSONObject insuranceObject = new JSONObject();
            insuranceObject.put("INSURANCE_PAYOR_ID", "payor1");
            HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
            outputInsuranceMap.put("1", new JSONObject());
            HashSet<String> addedPlanIds = new HashSet<>();
            addedPlanIds.add("1");

//        doNothing().when(athenaApiCaller).call(anyString(), any(JSONObject.class), anyString());

            getMethod("checkAndAddInsurance", JSONObject.class, JSONObject.class, JSONObject.class, String.class, HashMap.class, HashSet.class)
                    .invoke(patientInsuranceHandler, inputObject, outputObject, insuranceObject, "1", outputInsuranceMap, addedPlanIds);

        }
    }

    @Test
    void checkAndAddInsurance_Exception() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.INSURANCE_PAYOR_ID))).thenThrow(new RuntimeException("Error"));

            JSONObject inputObject = new JSONObject();
            inputObject.put("PATIENT_ID", "testPatientId");

            JSONObject outputObject = new JSONObject();
            JSONObject insuranceObject = new JSONObject();
            insuranceObject.put("INSURANCE_PAYOR_ID", "payor1");
            HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
            outputInsuranceMap.put("1", new JSONObject());
            HashSet<String> addedPlanIds = new HashSet<>();
            addedPlanIds.add("1");


//        doNothing().when(athenaApiCaller).call(anyString(), any(JSONObject.class), anyString());

            getMethod("checkAndAddInsurance", JSONObject.class, JSONObject.class, JSONObject.class, String.class, HashMap.class, HashSet.class)
                    .invoke(patientInsuranceHandler, inputObject, outputObject, insuranceObject, "1", outputInsuranceMap, addedPlanIds);


            mockedJsonUtils.verify(() -> JsonUtils.setValue(any(JSONObject.class), eq(DocASAPConstants.Key.ADDITIONAL_INFO), eq("One or more Insurances could not be updated")));
        }
    }


    @Test
    void addSingleInsuranceWithValidInput() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("PATIENT_ID", "testPatientId");
        inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
        inputObject.put("PRACTICE_ID", "testPracticeId");

        JSONObject insuranceObject = new JSONObject();
        insuranceObject.put("INSURANCE_PAYOR_ID", "payor1");

        JSONObject outputObject = new JSONObject();

        JSONObject apiResponse = new JSONObject();
        when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(apiResponse);

        getMethod("addSingleInsurance", JSONObject.class, JSONObject.class, JSONObject.class)
                .invoke(patientInsuranceHandler, inputObject, outputObject, insuranceObject);

        verify(athenaApiCaller, times(1)).call(eq("set_patient_insurance"), any(), eq(""));
        assertFalse(outputObject.has("ERROR_MESSAGE"));
    }

    @Test
    void addSingleInsuranceWithValidInput_ErrorMessage() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.TempKey.ERROR_MESSAGE))).thenReturn("Error");

            JSONObject inputObject = new JSONObject();
            inputObject.put("PATIENT_ID", "testPatientId");
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
            inputObject.put("PRACTICE_ID", "testPracticeId");

            JSONObject insuranceObject = new JSONObject();
            insuranceObject.put("INSURANCE_PAYOR_ID", "payor1");

            JSONObject outputObject = new JSONObject();

            JSONObject apiResponse = new JSONObject();
            when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(apiResponse);

            InvocationTargetException exception = assertThrows(InvocationTargetException.class, () -> {
                Method method = getMethod("addSingleInsurance", JSONObject.class, JSONObject.class, JSONObject.class);
                method
                        .invoke(patientInsuranceHandler, inputObject, outputObject, insuranceObject);
            });

            Assertions.assertEquals("Error while adding insurance: Error", exception.getCause().getMessage());

        }
    }

    @Test
    void deleteSingleInsuranceWithValidInput() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("PATIENT_ID", "testPatientId");
        inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
        inputObject.put("PRACTICE_ID", "testPracticeId");

        String sequenceNumber = "1";

        doReturn(new JSONObject()).when(athenaApiCaller).call(anyString(), any(JSONObject.class), anyString());

        Method method = getMethod("deleteSingleInsurance", JSONObject.class, String.class);
        method.invoke(patientInsuranceHandler, inputObject, sequenceNumber);

        verify(athenaApiCaller, times(1)).call(eq("delete_patient_insurance"), any(JSONObject.class), eq(""));
    }

    @Test
    void addRelationshipToInsuredIdWithValidInput() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.POLICYHOLDER_INFORMATION))).thenReturn(new JSONObject().put("INSURED_ID", "testInsuredId"));
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.POLICYHOLDER_RELATIONSHIP))).thenReturn("testRelationship");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", "testDeploymentId");
            inputObject.put("POLICYHOLDER_RELATIONSHIP", "self");

            JSONObject policyholderInformation = new JSONObject();
            policyholderInformation.put("someKey", "someValue");
            inputObject.put("POLICYHOLDER_INFORMATION", policyholderInformation);

            JSONObject insuranceObject = new JSONObject();

            when(manageFlagsUtility.getConfiguration(anyString(), anyString(), anyString(), anyString()))
                    .thenReturn("self:1,spouse:2");

            Method method = getMethod("addRelationshipToInsuredId", JSONObject.class, JSONObject.class);
            Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, insuranceObject));

        }
    }

    @Test
    void setPolicyholderRelationshipWithValidInput() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject insuranceObject = new JSONObject();
        JSONObject policyholderInformation = new JSONObject();
        String policyholderRelationship = "self";
        String deploymentId = "testDeploymentId";

        when(manageFlagsUtility.getConfiguration(anyString(), anyString(), anyString(), anyString()))
                .thenReturn("self:1,spouse:2");

        Method method = getMethod("setPolicyholderRelationship", JSONObject.class, JSONObject.class, String.class, String.class);
        Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, insuranceObject, policyholderInformation, policyholderRelationship, deploymentId));

    }

    @Test
    void setPolicyholderRelationship_Exception() throws IHubException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONObject insuranceObject = new JSONObject();
        JSONObject policyholderInformation = new JSONObject();
        String policyholderRelationship = "self";
        String deploymentId = "testDeploymentId";

        when(manageFlagsUtility.getConfiguration(anyString(), anyString(), anyString(), anyString()))
                .thenThrow(new IHubException(new IHubErrorCode("22"), "Error"));

        Method method = getMethod("setPolicyholderRelationship", JSONObject.class, JSONObject.class, String.class, String.class);
        Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, insuranceObject, policyholderInformation, policyholderRelationship, deploymentId));

    }

    @Test
    void setPatientInsuranceWithValidInput() throws Exception {


        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> mockedHandlerUtils = mockStatic(DateUtils.class)) {
                try (MockedStatic<PhoneNumberUtils> mockedPhoneNumberUtils = mockStatic(PhoneNumberUtils.class)) {
                    mockedHandlerUtils.when(() -> DateUtils.convertDateFormat(any(), eq(DocASAPConstants.DOCASAP_DATE_FORMAT),
                            eq(EPM_DATE_FORMAT))).thenReturn("20230101");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(INSURANCE_PH_DOB))).thenReturn("2023-01-01");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq("temp.error_code"))).thenReturn(null);
                    mockedJsonUtils.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID))).thenReturn("testPatientId");
                    mockedPhoneNumberUtils.when(() -> PhoneNumberUtils.handlePhoneNumberD2E(any())).thenAnswer(invocation -> invocation.getArgument(0));

                    JSONObject inputObject = new JSONObject();

                    JSONObject insuranceObject = new JSONObject();


                    Method method = getMethod("setPatientInsurance", JSONObject.class, JSONObject.class);
                    Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, insuranceObject));

                }
            }
        }
    }

    private static Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = PatientInsuranceHandler.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

    // Test case for the printError method using Reflection API
    @Test
    void testPrintError() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        // Arrange
        String deploymentId = "testDeploymentId";
        Exception exception = new Exception("Test Exception");

        // Use reflection to access the private method
        Method printErrorMethod = PatientInsuranceHandler.class.getDeclaredMethod("printError", String.class, Exception.class);
        printErrorMethod.setAccessible(true);

        // Act & Assert
        Assertions.assertDoesNotThrow(() -> {
            printErrorMethod.invoke(patientInsuranceHandler, deploymentId, exception);
        });
    }

    // Add to src/test/java/com/pes/integration/athena/handler/PatientInsuranceHandlerTest.java

    @org.junit.jupiter.api.Test
    void getSequenceNumberSafe_ReturnsSequenceNumber_WhenValid() throws Exception {
        JSONArray array = new JSONArray();
        JSONObject obj = new JSONObject();
        obj.put("SequenceNumber", "5");
        array.put(obj);

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getSequenceNumberSafe", JSONArray.class, int.class, int.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, array, 0, 5);
        Assertions.assertEquals(5, result);
    }

    @org.junit.jupiter.api.Test
    void getSequenceNumberSafe_ReturnsDefault_WhenIndexOutOfBounds() throws Exception {
        JSONArray array = new JSONArray();
        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getSequenceNumberSafe", JSONArray.class, int.class, int.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, array, 1, 42);
        Assertions.assertEquals(42, result);
    }

    @org.junit.jupiter.api.Test
    void getSequenceNumberSafe_ReturnsDefault_WhenSequenceNumberIsNotANumber() throws Exception {
        JSONArray array = new JSONArray();
        JSONObject obj = new JSONObject();
        obj.put("SequenceNumber", "notANumber");
        array.put(obj);

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getSequenceNumberSafe", JSONArray.class, int.class, int.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, array, 0, 77);
        Assertions.assertEquals(77, result);
    }

    @org.junit.jupiter.api.Test
    void getSequenceNumberSafe_ReturnsDefault_WhenSequenceNumberIsNull() throws Exception {
        JSONArray array = new JSONArray();
        JSONObject obj = new JSONObject();
        obj.put("SOME_OTHER_KEY", "value");
        array.put(obj);

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getSequenceNumberSafe", JSONArray.class, int.class, int.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, array, 0, 88);
        Assertions.assertEquals(88, result);
    }

    @org.junit.jupiter.api.Test
    void getNextValidOutputIndex_ReturnsFirstNonAddedIndex_WhenSomePayorIdsAreAlreadyAdded() throws Exception {
        JSONArray outputInsurancesArray = new JSONArray();
        JSONObject obj1 = new JSONObject();
        obj1.put("InsPayorId", "payor1");
        JSONObject obj2 = new JSONObject();
        obj2.put("InsPayorId", "payor2");
        JSONObject obj3 = new JSONObject();
        obj3.put("InsPayorId", "payor3");
        outputInsurancesArray.put(obj1);
        outputInsurancesArray.put(obj2);
        outputInsurancesArray.put(obj3);

        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor1");
        addedPlanIds.add("payor2");

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getNextValidOutputIndex", JSONArray.class, int.class, HashSet.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, outputInsurancesArray, 2, addedPlanIds);
        Assertions.assertEquals(2, result);
    }

    @org.junit.jupiter.api.Test
    void getNextValidOutputIndex_ReturnsInputIndex_WhenNoPayorIdsAreAdded() throws Exception {
        JSONArray outputInsurancesArray = new JSONArray();
        JSONObject obj1 = new JSONObject();
        obj1.put("InsPayorId", "payor1");
        outputInsurancesArray.put(obj1);

        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getNextValidOutputIndex", JSONArray.class, int.class, HashSet.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, outputInsurancesArray, 0, addedPlanIds);
        Assertions.assertEquals(0, result);
    }

    @org.junit.jupiter.api.Test
    void getNextValidOutputIndex_ReturnsArrayLength_WhenAllPayorIdsAreAdded() throws Exception {
        JSONArray outputInsurancesArray = new JSONArray();
        JSONObject obj1 = new JSONObject();
        obj1.put("InsPayorId", "payor1");
        JSONObject obj2 = new JSONObject();
        obj2.put("InsPayorId", "payor2");
        outputInsurancesArray.put(obj1);
        outputInsurancesArray.put(obj2);

        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor1");
        addedPlanIds.add("payor2");

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getNextValidOutputIndex", JSONArray.class, int.class, HashSet.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, outputInsurancesArray, 2, addedPlanIds);
        Assertions.assertEquals(2, result);
    }

    @org.junit.jupiter.api.Test
    void getNextValidOutputIndex_ReturnsInputIndex_WhenArrayIsEmpty() throws Exception {
        JSONArray outputInsurancesArray = new JSONArray();
        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getNextValidOutputIndex", JSONArray.class, int.class, HashSet.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, outputInsurancesArray, 0, addedPlanIds);
        Assertions.assertEquals(0, result);
    }

    @org.junit.jupiter.api.Test
    void getNextValidOutputIndex_HandlesExceptionAndReturnsInputIndex() throws Exception {
        JSONArray outputInsurancesArray = new JSONArray();
        outputInsurancesArray.put("notAJSONObject");
        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("getNextValidOutputIndex", JSONArray.class, int.class, HashSet.class);
        method.setAccessible(true);

        int result = (int) method.invoke(patientInsuranceHandler, outputInsurancesArray, 0, addedPlanIds);
        Assertions.assertEquals(0, result);
    }

    // Add to src/test/java/com/pes/integration/athena/handler/PatientInsuranceHandlerTest.java

    @org.junit.jupiter.api.Test
    void addInsurancesAtTop_HappyPath_AddsInputInsuranceWhenInputSequenceNumberLessThanOrEqualToSequenceNumber() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONArray inputInsurancesArray = new JSONArray();
        JSONObject inputInsurance = new JSONObject().put("SequenceNumber", "1").put("InsPayorId", "payor1");
        inputInsurancesArray.put(inputInsurance);
        JSONArray outputInsurancesArray = new JSONArray();
        JSONObject outputInsurance = new JSONObject().put("SequenceNumber", "2").put("InsPayorId", "payor2");
        outputInsurancesArray.put(outputInsurance);
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        outputInsuranceMap.put("2", outputInsurance);
        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("addInsurancesAtTop", JSONObject.class, JSONObject.class, JSONArray.class, JSONArray.class, HashMap.class, HashSet.class);
        method.setAccessible(true);

        Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, outputObject, inputInsurancesArray, outputInsurancesArray, outputInsuranceMap, addedPlanIds));
    }

    @org.junit.jupiter.api.Test
    void addInsurancesAtTop_AddsOutputInsuranceWhenOutputSequenceNumberLessThanOrEqualToSequenceNumber() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONArray inputInsurancesArray = new JSONArray();
        JSONObject inputInsurance = new JSONObject().put("SequenceNumber", "3").put("InsPayorId", "payor1");
        inputInsurancesArray.put(inputInsurance);
        JSONArray outputInsurancesArray = new JSONArray();
        JSONObject outputInsurance = new JSONObject().put("SequenceNumber", "1").put("InsPayorId", "payor2");
        outputInsurancesArray.put(outputInsurance);
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        outputInsuranceMap.put("1", outputInsurance);
        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("addInsurancesAtTop", JSONObject.class, JSONObject.class, JSONArray.class, JSONArray.class, HashMap.class, HashSet.class);
        method.setAccessible(true);

        Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, outputObject, inputInsurancesArray, outputInsurancesArray, outputInsuranceMap, addedPlanIds));
    }

    @org.junit.jupiter.api.Test
    void addInsurancesAtTop_AddsInputInsuranceWhenNeitherSequenceNumberIsInfinity() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONArray inputInsurancesArray = new JSONArray();
        JSONObject inputInsurance = new JSONObject().put("SequenceNumber", "5").put("InsPayorId", "payor1");
        inputInsurancesArray.put(inputInsurance);
        JSONArray outputInsurancesArray = new JSONArray();
        JSONObject outputInsurance = new JSONObject().put("SequenceNumber", "6").put("InsPayorId", "payor2");
        outputInsurancesArray.put(outputInsurance);
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        outputInsuranceMap.put("6", outputInsurance);
        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod("addInsurancesAtTop", JSONObject.class, JSONObject.class, JSONArray.class, JSONArray.class, HashMap.class, HashSet.class);
        method.setAccessible(true);

        Assertions.assertDoesNotThrow(() -> method.invoke(patientInsuranceHandler, inputObject, outputObject, inputInsurancesArray, outputInsurancesArray, outputInsuranceMap, addedPlanIds));
    }
    @org.junit.jupiter.api.Test
    void tryAddInsuranceAtAvailablePlace_AddsInsuranceWhenNoOutputInsuranceExists() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONObject inputInsuranceObject = new JSONObject().put("InsPayorId", "payor1");
        String payorId = "payor1";
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod(
                "tryAddInsuranceAtAvailablePlace",
                JSONObject.class, JSONObject.class, JSONObject.class, String.class,
                HashMap.class, HashSet.class, int.class, int.class, int.class
        );
        method.setAccessible(true);

        Assertions.assertTrue((Boolean) method.invoke(
                patientInsuranceHandler, inputObject, outputObject, inputInsuranceObject, payorId,
                outputInsuranceMap, addedPlanIds, 0, 1, 1
        ));
    }

    @org.junit.jupiter.api.Test
    void tryAddInsuranceAtAvailablePlace_SkipsAlreadyAddedInsurance() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONObject inputInsuranceObject = new JSONObject().put("InsPayorId", "payor1");
        String payorId = "payor1";
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        JSONObject outputInsuranceObject = new JSONObject().put("InsPayorId", "payor2");
        outputInsuranceMap.put("1", outputInsuranceObject);
        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor1");

        Method method = PatientInsuranceHandler.class.getDeclaredMethod(
                "tryAddInsuranceAtAvailablePlace",
                JSONObject.class, JSONObject.class, JSONObject.class, String.class,
                HashMap.class, HashSet.class, int.class, int.class, int.class
        );
        method.setAccessible(true);

       Assertions.assertFalse((Boolean) method.invoke(
                patientInsuranceHandler, inputObject, outputObject, inputInsuranceObject, payorId,
                outputInsuranceMap, addedPlanIds, 0, 1, 1
        ));
    }

    @org.junit.jupiter.api.Test
    void tryAddInsuranceAtAvailablePlace_AddsOutputPayorIdToAddedPlanIdsWhenNotAlreadyAdded() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONObject inputInsuranceObject = new JSONObject().put("InsPayorId", "payor1");
        String payorId = "payor1";
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        JSONObject outputInsuranceObject = new JSONObject().put("InsPayorId", "payor2");
        outputInsuranceMap.put("1", outputInsuranceObject);
        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor2");
        Method method = PatientInsuranceHandler.class.getDeclaredMethod(
                "tryAddInsuranceAtAvailablePlace",
                JSONObject.class, JSONObject.class, JSONObject.class, String.class,
                HashMap.class, HashSet.class, int.class, int.class, int.class
        );
        method.setAccessible(true);

        Assertions.assertFalse((Boolean) method.invoke(
                patientInsuranceHandler, inputObject, outputObject, inputInsuranceObject, payorId,
                outputInsuranceMap, addedPlanIds, 1, 1, 1
        ));
        Assertions.assertTrue(addedPlanIds.contains("payor2"));
    }

    @org.junit.jupiter.api.Test
    void tryAddInsuranceAtAvailablePlace_ReturnsFalseWhenNoAvailablePlace() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONObject inputInsuranceObject = new JSONObject().put("InsPayorId", "payor1");
        String payorId = "payor1";
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        HashSet<String> addedPlanIds = new HashSet<>();

        Method method = PatientInsuranceHandler.class.getDeclaredMethod(
                "tryAddInsuranceAtAvailablePlace",
                JSONObject.class, JSONObject.class, JSONObject.class, String.class,
                HashMap.class, HashSet.class, int.class, int.class, int.class
        );
        method.setAccessible(true);

        Assertions.assertFalse((Boolean) method.invoke(
                patientInsuranceHandler, inputObject, outputObject, inputInsuranceObject, payorId,
                outputInsuranceMap, addedPlanIds, 1, 1, 1
        ));
    }

    @org.junit.jupiter.api.Test
    void tryAddInsuranceAtAvailablePlace_AddsInsuranceWhenOutputPayorIdAlreadyAddedAndPayorIdNotYetAdded() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONObject inputInsuranceObject = new JSONObject().put("InsPayorId", "payor1");
        String payorId = "payor1";
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        JSONObject outputInsuranceObject = new JSONObject().put("InsPayorId", "payor2");
        outputInsuranceMap.put("1", outputInsuranceObject);
        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor2");

        Method method = PatientInsuranceHandler.class.getDeclaredMethod(
                "tryAddInsuranceAtAvailablePlace",
                JSONObject.class, JSONObject.class, JSONObject.class, String.class,
                HashMap.class, HashSet.class, int.class, int.class, int.class
        );
        method.setAccessible(true);

        Assertions.assertTrue((Boolean) method.invoke(
                patientInsuranceHandler, inputObject, outputObject, inputInsuranceObject, payorId,
                outputInsuranceMap, addedPlanIds, 0, 1, 1
        ));
    }

    @org.junit.jupiter.api.Test
    void tryAddInsuranceAtAvailablePlace_SkipsAddingInsuranceWhenOutputPayorIdAlreadyAddedAndPayorIdAlreadyAdded() throws Exception {
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        JSONObject inputInsuranceObject = new JSONObject().put("InsPayorId", "payor1");
        String payorId = "payor1";
        HashMap<String, JSONObject> outputInsuranceMap = new HashMap<>();
        JSONObject outputInsuranceObject = new JSONObject().put("InsPayorId", "payor1");
        outputInsuranceMap.put("1", outputInsuranceObject);
        HashSet<String> addedPlanIds = new HashSet<>();
        addedPlanIds.add("payor1");

        Method method = PatientInsuranceHandler.class.getDeclaredMethod(
                "tryAddInsuranceAtAvailablePlace",
                JSONObject.class, JSONObject.class, JSONObject.class, String.class,
                HashMap.class, HashSet.class, int.class, int.class, int.class
        );
        method.setAccessible(true);

        Assertions.assertTrue((Boolean) method.invoke(
                patientInsuranceHandler, inputObject, outputObject, inputInsuranceObject, payorId,
                outputInsuranceMap, addedPlanIds, 0, 1, 1
        ));
    }
}