package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.ManageFlagsUtility;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.handlers.AbstractNewAppointmentHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import static com.pes.integration.athena.api.ApiName.NEW_APPOINTMENT;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.PATIENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.SLOT_ID_PATH;
import static com.pes.integration.constant.DocASAPConstants.TempKey.*;
import static com.pes.integration.constant.UtilitiesConstants.FALSE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.enums.StatusCodes.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static java.util.Objects.isNull;

@Slf4j
@Service(value = "NewAppt")
public class NewAppointmentHandlerService extends AbstractNewAppointmentHandler {

  @Value("${epm.engine.component_id}")
  String componentId;

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Autowired
  PatientNotificationHandler patientNotificationHandler;

  @Autowired
  PatientInsuranceHandler patientInsuranceHandler;

  @Autowired
  ManageFlagsUtility manageFlagsUtility;

  /**
   * creates a new Appointment based on the EPM engine to be defined in the EPM engine. * * @throws
   * IHubException
   *
   * @param inputObject this is input object
   * @throws IHubException throws iHub exception
   */
  @Override
  @Observed(name = "integration.createNewAppointment", contextualName = "integration")
  protected JSONObject createNewAppointment(Object inputObject) throws IHubException {
    try {
      JSONObject outputObject = new JSONObject();
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      outputObject = newAppointment(deploymentId, inputObject, outputObject);
      String externalAppointmentId = (String) getValue(outputObject, Key.APPOINTMENT_ID);
      log.info("externalAppointmentId {} for the deployment id {} ", externalAppointmentId, deploymentId);
      copyKey(Key.APPOINTMENT_ID, externalAppointmentId, inputObject);
      String appointmentCheckIn = String.valueOf(getValue(inputObject, Key.APPOINTMENT_CHECKIN));
      updatePatientNotificationPreferences(inputObject, externalAppointmentId);

      if (!NullChecker.isEmpty(externalAppointmentId) && isCustomFieldsPresent(inputObject)) {
        log.info("isCustomFieldsPresent : " + true);
        JSONObject customFieldsOutput = updateCustomFields(inputObject, externalAppointmentId);
        boolean errorStatus = checkAndSetErrorMessageOutputObject(customFieldsOutput,
                StatusCodes.CUSTOM_FIELD_ERROR);
        if (errorStatus) {
          return outputObject;
          // TODO  handle error scenario
        }
      }
      if (!NullChecker.isEmpty(externalAppointmentId) && isPrivacyConsentPresent(inputObject)) {
        log.info("isPrivacyConsentPresent : " + true);
        JSONObject privacyOutput = updatePatientPrivacyConsent(inputObject);
        boolean errorStatus = checkAndSetErrorMessageOutputObject(privacyOutput,
                StatusCodes.CONSENT_UPDATE_ERROR);
        if (errorStatus) {
          return outputObject;
        }
      }
      if (!NullChecker.isEmpty(externalAppointmentId) && isContactConsentPresent(inputObject)) {
        log.info("isContactConsentPresent : " + true);
        JSONObject consentOutput = updatePatientContactConsent(inputObject);
        boolean errorStatus = checkAndSetErrorMessageOutputObject(consentOutput,
                StatusCodes.CONSENT_UPDATE_ERROR);
        if (errorStatus) {
          return outputObject;
        }
      }
      if (!NullChecker.isEmpty(externalAppointmentId) && "1".equals(appointmentCheckIn)) {
        log.info("appointmentCheckIn : " + appointmentCheckIn);
        JSONObject checkInOutput = updateAppointmentCheckIn(inputObject, externalAppointmentId);
        boolean errorStatus = checkAndSetErrorMessageOutputObject(checkInOutput,
                StatusCodes.APPT_CHECKIN_ERROR);
        if (errorStatus) {
          return outputObject;
        }
      }
    }
    catch(Exception e) {
      log.error("Error {} ", e.getMessage());
      String statusCode = null;
      String message = null;
      throw new IHubException(e, ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
              e.getMessage());
    }
    return new JSONObject(inputObject.toString());
  }

  private JSONObject newAppointment(String deploymentId, Object inputObject, JSONObject outputObject) throws IHubException {
    log.info("createAppointment for the deployment id {} ", deploymentId);
    handlerUtils.addPracticeId(deploymentId, inputObject);
    JsonUtils.setValue(inputObject, IGNORE_SCHEDULABLE_PERMISSION,
            AthenaConstants.SHOULD_IGNORE_SCHEDULABLE_PERMISSION);
    Object externalPatientId = JsonUtils.getValue(inputObject, Key.PATIENT_ID);
    doRegisterPatient(inputObject, externalPatientId);
    doRegisterInsurance(inputObject, outputObject, externalPatientId);
    updateGuarantorInformation(inputObject, (String) externalPatientId);
    return athenaApiCaller.call(NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
  }

  @Observed(name = "integration.updatePatientNotificationPreferences", contextualName = "integration")
  private void updatePatientNotificationPreferences(Object inputObject,
      String externalAppointmentId) throws IHubException {
    JSONObject requestObject = new JSONObject(inputObject.toString());
    if (!NullChecker.isEmpty(externalAppointmentId)) {
      patientNotificationHandler.doExecute(requestObject);
    }
  }

  @Observed(name = "integration.doRegisterInsurance", contextualName = "integration")
  private void doRegisterInsurance(Object inputObject, JSONObject outputObject,
      Object externalPatientId) {
    try {
      registerInsurance(inputObject, outputObject, externalPatientId);
    } catch (IHubException e) {
      // do nothing
    }
  }

  @Observed(name = "integration.doRegisterPatient", contextualName = "integration")
  private void doRegisterPatient(Object inputObject, Object externalPatientId) {
    try {
      registerPatient(inputObject, externalPatientId);
    } catch (IHubException e) {
      // do nothing
    }
  }

  private boolean checkAndSetErrorMessageOutputObject(Object outputObject,
                                                      StatusCodes errorStatusCode)
          throws IHubException {
    boolean areErrorFieldsPresent = getValue(outputObject, TempKey.ERROR) != null
            || getValue(outputObject, ERROR_DETAIL) != null;
    if (StatusCodes.CUSTOM_FIELD_ERROR.equals(errorStatusCode)) {
      String updatedCount = String.valueOf(getValue(outputObject, CUSTOM_FIELD_UPDATED_COUNT));
      if ("0".equals(updatedCount)) {
        areErrorFieldsPresent = true;
      }
    }
    if (areErrorFieldsPresent) {
      setValue(outputObject, Key.ERROR_MESSAGE, AthenaEngineConstants.API_ERROR_MSG);
      setValue(outputObject, Key.ERROR_CODE, errorStatusCode.getKey());
      return true;
    }
    return false;
  }

  private JSONObject updateAppointmentCheckIn(Object inputObject, String externalApptId)
          throws IHubException {
    JSONObject updateAppointmentCheckInInputObject = new JSONObject();
    copyKey(TempKey.PRACTICE_ID, inputObject, updateAppointmentCheckInInputObject);
    setValue(updateAppointmentCheckInInputObject, Key.EXTN_APPT_ID, externalApptId);
    return athenaApiCaller.call(ApiName.UPDATE_APPOINTMENT_CHECKIN.getKey(),
            updateAppointmentCheckInInputObject, CREATE_APPOINTMENT.getKey());
  }

  @Observed(name = "integration.updateCustomFields", contextualName = "integration")
  private JSONObject updateCustomFields(Object inputObject, String externalApptId)
          throws IHubException {
    JSONArray customFields = (JSONArray) getValue(inputObject, AthenaEngineConstants.CUSTOM_FIELDS);
    String custFields = prepareUpdateCustomFieldsJson(customFields);
    JSONObject customFieldsInputObject = new JSONObject();
    setValue(customFieldsInputObject, Key.EXTN_APPT_ID, externalApptId);
    copyKey(TempKey.PRACTICE_ID, inputObject, customFieldsInputObject);
    String appointmentId = (String) getValue(inputObject, SLOT_ID_PATH);
    setValue(customFieldsInputObject, "temp.appointmentid", appointmentId);
    setValue(customFieldsInputObject, Key.CUSTOM_FIELDS, custFields);
    return athenaApiCaller.call(ApiName.ADD_CUSTOM_FIELDS.getKey(), customFieldsInputObject, CREATE_APPOINTMENT.getKey());
  }

  private String prepareUpdateCustomFieldsJson(JSONArray customFields) throws IHubException {
    JSONArray custFields = new JSONArray();
    for (Object customField : customFields) {
      String customFieldId = (String) getValue(customField, AthenaEngineConstants.CUSTOM_FIELD_ID);
      String optionId = (String) getValue(customField, AthenaEngineConstants.OPTION_ID);
      JSONObject custField = new JSONObject();
      setValue(custField, AthenaEngineConstants.CUSTOM_FIELD_ID_EPM, customFieldId);
      setValue(custField, AthenaEngineConstants.OPTION_ID_EPM, optionId);
      custFields.put(custField);
    }
    return custFields.toString();
  }

  private boolean isCustomFieldsPresent(Object inputObject) {
    return getValue(inputObject, AthenaEngineConstants.CUSTOM_FIELDS) != null;
  }

  @Observed(name = "integration.updatePatientContactConsent", contextualName = "integration")
  private JSONObject updatePatientContactConsent(Object inputObject) throws IHubException {
    JSONObject updateConsentInputObject;
    updateConsentInputObject = prepareUpdateContactConsentInputJson(inputObject);
    copyKey(TempKey.PRACTICE_ID, inputObject, updateConsentInputObject);
    copyKey(PATIENT_ID, inputObject, updateConsentInputObject);
    copyKey(DEPLOYMENT_ID, inputObject, updateConsentInputObject);
    return athenaApiCaller.call(ApiName.UPDATE_PATIENT.getKey(), updateConsentInputObject, CREATE_APPOINTMENT.getKey());
  }

  private JSONObject prepareUpdateContactConsentInputJson(Object inputObject) throws IHubException {
    JSONObject jsonObject = new JSONObject();
    String callConsent = (String) getValue(inputObject, AthenaEngineConstants.CALL_CONSENT);
    if (!NullChecker.isEmpty(callConsent)) {
      String value = getAthenaBooleanValue(callConsent);
      setValue(jsonObject, Key.CONSENT_TO_CALL, value);
    }
    String textConsent = (String) getValue(inputObject, AthenaEngineConstants.TEXT_CONSENT);
    if (!NullChecker.isEmpty(textConsent)) {
      String value = getAthenaBooleanValue(textConsent);
      setValue(jsonObject, Key.CONSENT_TO_TEXT, value);
    }
    String contactConsent = (String) getValue(inputObject, AthenaEngineConstants.CONTACT_CONSENT);
    if (!NullChecker.isEmpty(contactConsent)) {
      String value = getAthenaBooleanValue(contactConsent);
      setValue(jsonObject, Key.CONSENT_TO_CALL, value);
      setValue(jsonObject, Key.CONSENT_TO_TEXT, value);
    }
    return jsonObject;
  }

  private boolean isContactConsentPresent(Object inputObject) {
    return getValue(inputObject, AthenaEngineConstants.CALL_CONSENT) != null
            || getValue(inputObject, AthenaEngineConstants.TEXT_CONSENT) != null
            || getValue(inputObject, AthenaEngineConstants.CONTACT_CONSENT) != null;
  }

  @Observed(name = "integration.updatePatientPrivacyConsent", contextualName = "integration")
  private JSONObject updatePatientPrivacyConsent(Object inputObject) throws IHubException {
    updatePrivacyConsentTimestamps(inputObject);
    updatePrivacyConsentValues(inputObject);
    String firstName = (String) getValue(inputObject, Key.FIRST_NAME);
    String lastName = (String) getValue(inputObject, Key.LAST_NAME);
    updatePrivacyConsentSignatory(inputObject, firstName, lastName);
    JSONObject responseObject = athenaApiCaller.call(
            ApiName.VERIFY_PATIENT_PRIVACY_INFORMATION.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
    setValue(inputObject, Key.FIRST_NAME, firstName);
    return responseObject;
  }

  private void updatePrivacyConsentSignatory(Object inputObject, String firstName, String lastName)
          throws IHubException {
    String fullName = String.join(" ", firstName, lastName);
    setValue(inputObject, Key.FIRST_NAME, fullName);
  }

  private void updatePrivacyConsentTimestamps(Object inputObject) throws IHubException {
    String consentTimestamp = (String) getValue(inputObject, PATIENT_CONSENT_TIMESTAMP);
    String consentTimestampInEPMFormat;
    String consentExpirationTimestampInEPMFormat;
    try {
      consentTimestampInEPMFormat = DateUtils.convertDateFormat(consentTimestamp,
              DocASAPConstants.DATE_TIME_FORMAT, BaseEPMConstants.DATE_TIME_FORMAT);
      String consentExpirationTimestamp = getConsentExpirationTimestamp(consentTimestamp);
      consentExpirationTimestampInEPMFormat = DateUtils.convertDateFormat(
              consentExpirationTimestamp,
              DocASAPConstants.DATE_TIME_FORMAT, BaseEPMConstants.EPM_DATE_FORMAT);
    } catch (ParseException e) {
      log.error("Exception occured while parsing the consent timestamp, expected format is :"
              + DocASAPConstants.DATE_TIME_FORMAT);
      throw new IHubException(UtilityErrors.ERROR_IN_REQUEST.getErrorCode(),
              "Exception occured while parsing the consent timestamp, expected format is :"
                      + DocASAPConstants.DATE_TIME_FORMAT);
    }
    setValue(inputObject, PATIENT_CONSENT_TIMESTAMP, consentTimestampInEPMFormat);
    setValue(inputObject, PATIENT_CONSENT_EXPIRATION_TIMESTAMP,
            consentExpirationTimestampInEPMFormat);
  }

  private void updatePrivacyConsentValues(Object inputObject) throws IHubException {
    String privacyConsent = (String) getValue(inputObject, PATIENT_CONSENT);
    if (!NullChecker.isEmpty(privacyConsent)) {
      setValue(inputObject, PRIVACY_POLICY_CONSENT, privacyConsent);
      setValue(inputObject, RELEASE_BILLING_INFORMATION_CONSENT, privacyConsent);
      setValue(inputObject, ASSIGNMENT_BENEFITS_CONSENT, privacyConsent);
    }
    updateConsentBooleanField(inputObject, PRIVACY_POLICY_CONSENT);
    updateConsentBooleanField(inputObject, RELEASE_BILLING_INFORMATION_CONSENT);
    updateConsentBooleanField(inputObject, ASSIGNMENT_BENEFITS_CONSENT);
  }

  private String getConsentExpirationTimestamp(String consentTimestamp) {
    DateTimeFormatter docASAPDateTimeFormatter = DateTimeFormatter.ofPattern(
            DocASAPConstants.DATE_TIME_FORMAT);
    LocalDateTime localDateTime = LocalDateTime.parse(consentTimestamp, docASAPDateTimeFormatter);
    LocalDateTime expirationDateTime = localDateTime.plusYears(1);
    return expirationDateTime.format(docASAPDateTimeFormatter);
  }

  private String getAthenaBooleanValue(String input) {
    return Objects.equals(Y, input) ? "true" : FALSE;
  }

  private void updateConsentBooleanField(Object inputObject, String field) throws IHubException {
    String fieldValue = (String) getValue(inputObject, field);
    if (!NullChecker.isEmpty(fieldValue)) {
      fieldValue = getAthenaBooleanValue(fieldValue);
      setValue(inputObject, field, fieldValue);
    }
  }

  private boolean isPrivacyConsentPresent(Object inputObject) {
    return getValue(inputObject, PATIENT_CONSENT) != null
            || getValue(inputObject, PRIVACY_POLICY_CONSENT) != null
            || getValue(inputObject, ASSIGNMENT_BENEFITS_CONSENT) != null
            || getValue(inputObject, RELEASE_BILLING_INFORMATION_CONSENT) != null;
  }

  @Observed(name = "integration.registerInsurance", contextualName = "integration")
  private void registerInsurance(Object inputObject, JSONObject outputObject, Object patientId)
          throws IHubException {
    JSONObject demographicData = (JSONObject) getValue(inputObject,
            UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA);
    if (demographicData.has("InsuranceInformation")) {
      JSONObject responseObject;
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      responseObject = athenaApiCaller.call(ApiName.GET_PATIENT_INSURANCE.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
      log.info(sanitizeForLog(PATIENT + patientId + " :: deploymentId : " + deploymentId));
      if (!responseObject.has(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA)) {
        handleInsurance(inputObject, patientId);
      }
    }
  }

  @Observed(name = "integration.handleInsurance", contextualName = "integration")
  private void handleInsurance(Object inputObject, Object patientId) {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    try {
      JSONObject insuranceInputObject = new JSONObject();
      JSONObject insuranceOutputObject;
      copyKey(Key.APPT_LOCATION_ID, inputObject, insuranceInputObject);
      copyKey(Key.DA_PATIENT_ID, inputObject, insuranceInputObject);
      copyKey(Key.INSURANCE_INFORMATION, inputObject, insuranceInputObject);
      setInputJson(inputObject, insuranceInputObject);
      log.info(sanitizeForLog(PATIENT + patientId + " :: " + deploymentId));
      copyKey(UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA, inputObject, insuranceInputObject);
      insuranceOutputObject = patientInsuranceHandler.doExecute(insuranceInputObject);
      if (manageFlagsUtility.containsErrorMessage(insuranceOutputObject)) {
        String daApptId = (String) getValue(inputObject, Key.DA_APPOINTMENT_ID);
        log.error(sanitizeForLog(EXCEPTION + deploymentId
                + " Unable to add policyholder information DA Appointment ID:" + daApptId));
        String error = (String) getValue(insuranceOutputObject, ERROR_MESSAGE);
        error = "Failed to update policyholder details " + error;
        log.error(error); //TODO need to update sync layer in case of Async flow
      }
    } catch (IHubException e) {
      log.error(sanitizeForLog("Error in adding insurance to patient:: " + patientId + " :: " + e));
    }
  }

  @Observed(name = "integration.registerPatient", contextualName = "integration")
  private void registerPatient(Object inputObject, Object externalPatientId) throws IHubException {
    JSONObject responseObject;
    responseObject = athenaApiCaller.call(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject,
            CREATE_APPOINTMENT.getKey());
    String errorMsg = "";
    try {
      errorMsg = (String) getValue(responseObject, ERROR_MESSAGE);
    } catch (Exception e1) {
      // do nothing
    }
    updatePatientData(inputObject, externalPatientId, responseObject, errorMsg);
  }

  private void updatePatientData(Object inputObject, Object externalPatientId,
                                 JSONObject responseObject, String errorMsg) {
    try {
      log.info(sanitizeForLog("errorMsg: " + errorMsg + " for patient::" + externalPatientId));
      if (!NullChecker.isEmpty(errorMsg) && NOT_REGISTERED_MSG.equalsIgnoreCase(errorMsg)) {
        responseObject.clear();
        JSONObject inputJson = new JSONObject();
        setValue(inputJson, REG_PATIENT_IN_DEPARTMENT, AthenaConstants.TRUE);
        String locationId = (String) getValue(inputObject, Key.APPT_LOCATION_ID);
        setValue(inputJson, LOOKUP_DEPARTMENT_ID, locationId);
        setInputJson(inputObject, inputJson);
        copyKey(Key.ADDRESS, inputObject, inputJson);
        log.info(sanitizeForLog(PATIENT + externalPatientId));
        athenaApiCaller.call(ApiName.UPDATE_PATIENT.getKey(), inputJson, CREATE_APPOINTMENT.getKey());
        log.info(sanitizeForLog(PATIENT + externalPatientId + " created in department " + locationId));
      }
    } catch (IHubException e) {
      log.error(sanitizeForLog("Error in adding patient:: " + externalPatientId + " to department:: " + e));
    }
  }

  private void setInputJson(Object inputObject, JSONObject inputJson) throws IHubException {
    copyKey(PATIENT_ID, inputObject, inputJson);
    copyKey(TempKey.PRACTICE_ID, inputObject, inputJson);
    copyKey(DEPLOYMENT_ID, inputObject, inputJson);
    copyKey(UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, inputObject, inputJson);
  }

  @Observed(name = "integration.updateGuarantorInformation", contextualName = "integration")
  private void updateGuarantorInformation(Object inputObject, String patientId) {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    JSONObject guarantorInformation = (JSONObject) getValue(inputObject, Key.GURANTOR_INFORMATION);
    if (NullChecker.isEmpty(guarantorInformation)) {
      return;
    }
    String guarantorRelationOriginal = UtilitiesConstants.CharacterConstants.BLANK;
    try {
      String guarantorRelationship = (String) getValue(inputObject, Key.GURANTOR_RELATIONSHIP);
      if (!NullChecker.isEmpty(guarantorRelationship)) {
        guarantorRelationOriginal = guarantorRelationship;
        guarantorRelationship = guarantorRelationship.toLowerCase();
        String relationConfiguration = manageFlagsUtility.getConfiguration(
                AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId, ATHENA_CONFIG,
                GUARANTOR_RELATIONS);
        String[] relationships = relationConfiguration.split(CharacterConstants.COMMA);
        for (String relation : relationships) {
          if (guarantorRelationship.equals(
                  relation.split(UtilitiesConstants.CharacterConstants.COLON)[0])) {
            setValue(inputObject, Key.GURANTOR_RELATIONSHIP,
                    relation.split(UtilitiesConstants.CharacterConstants.COLON)[1]);
            break;
          }
        }
      }
      Integer isAddressSame = (Integer) getValue(inputObject, Key.ADR_SAME_AS_PATIENT);
      if (!NullChecker.isEmpty(isAddressSame)) {
        boolean isAddressSameAsPatient = isAddressSame != 0;
        setValue(inputObject, Key.ADR_SAME_AS_PATIENT, isAddressSameAsPatient);
      }

      String guarantorDob = (String) getValue(inputObject, Key.GUARANTOR_DOB);
      if (!NullChecker.isEmpty(guarantorDob)) {
        guarantorDob = DateUtils.convertDateFormat(guarantorDob,
                DocASAPConstants.DOCASAP_DATE_FORMAT,
                BaseEPMConstants.EPM_DATE_FORMAT);
        setValue(inputObject, Key.GUARANTOR_DOB, guarantorDob);
      }

      setDob(inputObject);
      JSONObject patientObj = (JSONObject) getValue(inputObject,
              "DemographicData.PatientInformation[0]");
      setValue(inputObject, "DemographicData.PatientInformation", null);

      setValue(inputObject, PATIENT_ID, patientId);
      JSONObject outputObject = athenaApiCaller.call(ApiName.UPDATE_PATIENT.getKey(), inputObject,
              CREATE_APPOINTMENT.getKey());
      setValue(inputObject, PATIENT_ID, null);
      setValue(inputObject, "DemographicData.PatientInformation[0]", patientObj);
      if (!guarantorRelationOriginal.equals(CharacterConstants.BLANK)) {
        setValue(inputObject, Key.GURANTOR_RELATIONSHIP, guarantorRelationOriginal);
      }
      if (manageFlagsUtility.containsErrorMessage(outputObject)) {
        String daApptId = (String) JsonUtils.getValue(inputObject, Key.DA_APPOINTMENT_ID);
        log.info(sanitizeForLog(EXCEPTION + deploymentId
                + " Unable to add guarantor for DA Appointment ID:" + daApptId));
        String error = (String) JsonUtils.getValue(outputObject, TempKey.ERROR_MESSAGE);
        error = "Failed to update guarantor details " + error;
        log.error(error);
        //sendAck(daApptId); TODO need to update sync layer in case of Async flow
      }
    } catch (IHubException exc) {
      log.error("IhubException:: deploymentId:" + deploymentId
              + " While updating the guarantor information " + exc.getMessage());
    } catch (ParseException parseExc) {
      log.error(
              "ParseException:: deploymentId:" + deploymentId + " While parsing the guarantor DOB "
                      + parseExc.getMessage());
    } catch (Exception exc) {
      log.error(
              EXCEPTION + deploymentId + " While updating the guarantor information "
                      + exc.getMessage());
    }
  }

  private void setDob(Object inputObject) {
    try {
      String patientDob = (String) getValue(inputObject, Key.DOB);
      if (!NullChecker.isEmpty(patientDob)) {
        patientDob = DateUtils.convertDateFormat(patientDob, DocASAPConstants.DOCASAP_DATE_FORMAT,
                BaseEPMConstants.EPM_DATE_FORMAT);
        setValue(inputObject, Key.DOB, patientDob);
      }
    } catch (Exception e) {
      log.error(e.getMessage());
    }
  }
}
