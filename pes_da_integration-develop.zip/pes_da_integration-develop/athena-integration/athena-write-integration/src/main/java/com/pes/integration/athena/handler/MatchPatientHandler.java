package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractMatchPatientHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.athena.api.ApiName.GET_PATIENTS;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.athena.constant.AthenaEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_DEPT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.PAT_MATCHING_USE_DEPT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.NullChecker.isEmpty;

@Slf4j
@Service
public class MatchPatientHandler extends AbstractMatchPatientHandler {

  @Autowired
  protected DataCacheManager cacheManager;

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Override
  public JSONObject getPatients(JSONObject inputObject) throws IHubException {

    JSONObject outputObject = new JSONObject();
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    handlerUtils.addPracticeId(deploymentId, inputObject);
    addDepartment(inputObject, deploymentId);
    try {
      outputObject = athenaApiCaller.call(GET_PATIENTS.getKey(), inputObject, inputObject.optString("flowName"));
    } catch (IHubException e) {
      log.error("Error {} ", e.getMessage());
      outputObject.put("Error", e.getMessage());
    }
    return outputObject;
  }

  private void addDepartment(JSONObject inputObject, String deploymentId) throws IHubException {
    String useDepartment;
    try {
      useDepartment = (String) cacheManager.getStoredProvidersConfig(
          EPM_NAME_PREFIX, deploymentId, ATHENA_CONFIG,
          PAT_MATCHING_USE_DEPT, false);
    } catch (Exception e1) {
      useDepartment = "false";
      log.error("Department is not used in patient matching for deploymentId {} with error {}",
          deploymentId, e1.getMessage());
    }
    if (!isEmpty(useDepartment) && useDepartment.equalsIgnoreCase("true")) {
      Object dAPatientDeptId = getValue(inputObject, APPT_LOCATION_ID);
      setValue(inputObject, APPT_DEPT_ID, dAPatientDeptId);
    }
  }

  @Override
  public JSONArray getPatientDemographicsDetails(JSONArray patientsArray) {
    return patientsArray;
  }

  @Override
  public boolean isSingleMatch() throws IHubException {
    return false;
  }
}
