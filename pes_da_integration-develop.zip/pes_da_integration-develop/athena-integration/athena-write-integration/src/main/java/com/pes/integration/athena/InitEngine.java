package com.pes.integration.athena;

import static com.pes.integration.athena.constant.AthenaEngineConstants.EPM_NAME_PREFIX;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.KafkaService;
import com.pes.integration.service.RefreshBaseInitEngine;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class InitEngine implements RefreshBaseInitEngine {

  @Value("${kafka.async.topic}")
  String asyncTopicName;

  @Value("${kafka.config.group.id}")
  String groupId;

  @Autowired
  AthenaInitEngine athenaEngine;

  @Autowired
  KafkaService kafkaService;

  @Autowired
  DataCacheManager cacheManager;

  @PostConstruct
  public void init() throws IHubException {
    athenaEngine.init();
    kafkaService.createTopicAndListener(cacheManager.getRedisConfig(EPM_NAME_PREFIX).toString(),
        asyncTopicName, groupId);
  }
}
