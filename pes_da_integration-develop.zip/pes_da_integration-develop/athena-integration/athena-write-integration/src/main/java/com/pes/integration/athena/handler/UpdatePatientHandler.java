package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.utils.LogUtil;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Set;

import static com.pes.integration.athena.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.athena.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.CONSENT_TO_TEXT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PRACTICE_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP;
import static com.pes.integration.constant.UtilitiesConstants.FALSE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID;
import static com.pes.integration.constant.UtilitiesConstants.TRUE;
import static com.pes.integration.enums.Flow.UPDATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.IN_PROGRESS;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_DATA_STRUCTURE;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static com.pes.integration.utils.PhoneNumberUtils.handlePhoneNumbersD2E;
import static com.pes.integration.utils.PhoneNumberUtils.handlePhoneNumbersE2D;
import static java.util.Objects.isNull;

@Slf4j
@Service(value = "UpdatePatient")
public class UpdatePatientHandler extends BaseHandler {


  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Autowired
  PatientNotificationPreferences patientNotificationPreferences;

  @Autowired
  PatientInsuranceHandler patientInsuranceHandler;

  @Override
  @Observed(name = "integration.athenaUpdateNewPatient", contextualName = "integration")
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    JSONObject outputObject = new JSONObject();
    JSONObject responseObject = new JSONObject();
    try {
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      handlerUtils.addPracticeId(deploymentId, inputObject);
      JSONObject tempInputObject = addLocationDepartmentId(inputObject, new JSONObject(),
          deploymentId);
      dataTransactionService.logData(inputObject, UPDATE_PATIENT.getKey(),
          IN_PROGRESS.getKey(), "EPM Update Patient Request");
      JSONObject updatePatientOutput = athenaApiCaller.call(ApiName.UPDATE_PATIENT.getKey(),
          tempInputObject, UPDATE_PATIENT.getKey());
      String email = (String) getValue(inputObject, EMAIL);
      String finalPatientId = (String) getValue(updatePatientOutput, PATIENT_ID);
      if (!isNull(finalPatientId)) {
        setValue(tempInputObject, PATIENT_ID, finalPatientId);
        JSONObject demographicsData = athenaApiCaller.call(
            GET_PATIENT_DEMOGRAPHICS.getKey(), tempInputObject, UPDATE_PATIENT.getKey());
        finalPatientId = (String) getValue(demographicsData, PATIENT_ID);
        if (!isNull(finalPatientId)) {
          Object updateObject = new JSONObject();
          handlePhoneNumbersE2D(demographicsData);
          getUpdatePatientObject(inputObject, demographicsData, (JSONObject) updateObject);
          patientNotificationPreferences.setPatientNotificationPreferencesUpdatePatient(inputObject,
              updateObject);
          handlePhoneNumbersD2E((JSONObject) updateObject);
          setDob(updateObject);
          setConsentToEmail(demographicsData, updateObject, deploymentId);
          Object notificationStatus = updateNotificationStatus(email, updateObject, inputObject);
          updateObject = addLocationDepartmentId(inputObject, (JSONObject) updateObject, deploymentId);
          removeGuarantorInformation((JSONObject) updateObject, deploymentId);
          updateObject = patientNotificationPreferences.getPatientNotificationPreferences(updateObject);
          updatePatientOutput = athenaApiCaller.call(ApiName.UPDATE_PATIENT.getKey(), updateObject,
              UPDATE_PATIENT.getKey());
          finalPatientId = (String) getValue(updatePatientOutput, PATIENT_ID);
          if (!isNull(finalPatientId)) {
            responseObject = athenaApiCaller.call(GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject,
                UPDATE_PATIENT.getKey());
            updateResponseObject(inputObject, responseObject, deploymentId);
            patientInsuranceHandler.doExecute(responseObject);
            JSONObject insuranceObject = athenaApiCaller.call(GET_PATIENT_INSURANCE.getKey(),
                responseObject, UPDATE_PATIENT.getKey());
            copyKey(INSURANCE_INFORMATION, insuranceObject, responseObject);
            handlePhoneNumbersE2D(responseObject);
            setPatientNotification(responseObject, inputObject);
            setDob(responseObject);
          }
          setValue(responseObject, NON_OAS_NOTIFICATION, notificationStatus);
        }
      }
      setEmail(responseObject, email);
      setValue(outputObject, APPOINTMENT_OBJECT, responseObject);
    } catch (IHubException ihe) {
      log.error("Error in updating the patient {} ", ihe.getMessage());
     throw ihe;
    }
    return outputObject;
  }

  private void updateResponseObject(JSONObject inputObject, JSONObject responseObject,
      String deploymentId) throws IHubException {
    copyKey(DEPLOYMENT_ID, inputObject, responseObject);
    copyKey(DA_PATIENT_ID, inputObject, responseObject);
    copyKey(INSURANCE_INFORMATION, inputObject, responseObject);
    copyKey(MESSAGE_CONTROL_ID, inputObject, responseObject);
    setPolicyHolderInfo(responseObject, inputObject, deploymentId);
  }

  private Object updateNotificationStatus(String email, Object updateObject, JSONObject inputObject)
      throws IHubException {
    Object notificationStatus = getValue(inputObject, NOTIFICATION_STATUS);
    if (!isNull(notificationStatus)) {
      setValue(updateObject, WORK_PHONE, null);
      if (notificationStatus.equals(DAEON)) {
        setValue(updateObject, EMAIL, email);
        setValue(updateObject, CONSENT_TO_TEXT, FALSE);
      } else if (notificationStatus.equals(DATON)) {
        setValue(updateObject, CONSENT_TO_TEXT, TRUE);
        setValue(updateObject, EMAIL, "");
      } else if (notificationStatus.equals(DAOFF)) {
        setValue(updateObject, EMAIL, "");
        setValue(updateObject, CONSENT_TO_TEXT, FALSE);
      }
    }
    return notificationStatus;
  }

  private void setConsentToEmail(JSONObject outputObject, Object updateObject, String deploymentId)
      throws IHubException {
    Object consentToEmail = dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
        ATHENA_CONFIG, CONSENT_TO_EMAIL, false);
    String emailExists = (String) getValue(outputObject, EMAIL_EXISTS);
    if (!isNull(emailExists) && emailExists.equals(TRUE)) {
      //do nothing
      log.info("emailExists {} ", true);
    } else {
      if (consentToEmail.equals(FALSE)) {
        setValue(updateObject, EMAIL, null);
      }
    }
  }

  private void setDob(Object responseObject) throws IHubException {
    String dob = null;
    try {
      dob = (String) getValue(responseObject, DOB);
      if (!isEmpty(dob)) {
        dob = convertDateFormat(dob, DATE_FORMAT, DOCASAP_DATE_FORMAT);
        setValue(responseObject, DOB, dob);
      }
    } catch (ParseException pe) {
      log.info("DOB was invalid or null.dob {} with error {}", sanitizeForLog(dob), pe.getMessage());
      throw new IHubException(pe, DATA_VALIDATION_ERROR.getErrorCode(), "DOB was invalid or null.");
    }
  }


  private void setEmail(JSONObject responseObject, String email) {
    try {
      setValue(responseObject, EMAIL, email);
      setValue(responseObject, TEMP, null);
    } catch (Exception e) {
      log.error("Error {} ", e.getMessage());
    }
  }

  private JSONObject addLocationDepartmentId(JSONObject inputObject, JSONObject updateInputObject, String deploymentId) throws IHubException {
    copyKey(PRACTICE_ID, inputObject, updateInputObject);
    copyKey(PATIENT_ID, inputObject, updateInputObject);
    setValue(updateInputObject, DEPLOYMENT_ID, deploymentId);
    copyKey(MESSAGE_CONTROL_ID, inputObject, updateInputObject);
    setValue(updateInputObject, REG_PATIENT_IN_DEPARTMENT, TRUE);
    Object locationId = getValue(inputObject, APPT_LOCATION_ID);
    setValue(updateInputObject, LOOKUP_DEPARTMENT_ID, locationId);
    return updateInputObject;
  }

  private void setPatientNotification(JSONObject responseObject, JSONObject inputObject) {
    if (patientNotificationPreferences.arePatientNotificationPreferencesPresent(inputObject)) {
      patientNotificationPreferences.setPatientNotificationPreferences(responseObject);
    } else {
      ((JSONObject) getValue(responseObject, DEMOGRAPHIC_PATIENT_INFO)).remove(
          EMAILNOTIFICATIONSTATUS);
      ((JSONObject) getValue(responseObject, DEMOGRAPHIC_PATIENT_INFO)).remove(
          TEXTNOTIFICATIONSTATUS);
      ((JSONObject) getValue(responseObject, DEMOGRAPHIC_PATIENT_INFO)).remove(
          VOICENOTIFICATIONSTATUS);
    }
  }

  public void getUpdatePatientObject(JSONObject docasapObject,
      JSONObject epmObject, JSONObject updateObject) throws IHubException {
    try {
      Set<String> inputKeySet = docasapObject.keySet();
      for (String key : inputKeySet) {
        Object nextDocasapObject = docasapObject.get(key);
        if (epmObject.has(key)) {
          findNextDocasapObject(epmObject, updateObject, key, nextDocasapObject);
        } else {
          updateObject.put(key, nextDocasapObject);
        }
      }
    } catch (Exception e) {
      throw new IHubException(INVALID_DATA_STRUCTURE.getErrorCode(), "data format of epm and docasap do not match :: " + e.getMessage());
    }
  }

  private void findNextDocasapObject(JSONObject epmObject, JSONObject updateObject, String key,
      Object nextDocasapObject) throws IHubException {
    Object nextEpmObject = epmObject.get(key);
    Object nextUpdateObject = null;
    if (nextDocasapObject instanceof JSONArray docasapArray) {
      JSONArray epmArray = (JSONArray) nextEpmObject;
      updateObject.put(key, new JSONArray());
      JSONArray updateArray = updateObject.getJSONArray(key);
      if (docasapArray.isEmpty()) {
        nextDocasapObject = null;
      } else {
        nextDocasapObject = (docasapArray).get(0);
        if (epmArray.isEmpty()) {
          updateArray.put(nextDocasapObject);
          nextDocasapObject = null;
        } else {
          nextEpmObject = (epmArray).get(0);
          updateArray.put(new JSONObject());
          nextUpdateObject = updateArray.get(0);
        }
      }
    }
    updateGetPatientObject(updateObject, key, nextDocasapObject, nextEpmObject, nextUpdateObject);
  }

  private void updateGetPatientObject(JSONObject updateObject, String key, Object nextDocasapObject,
      Object nextEpmObject, Object nextUpdateObject) throws IHubException {
    if (!isEmpty(nextDocasapObject) && nextDocasapObject instanceof JSONObject) {
      if (nextUpdateObject == null) {
        updateObject.put(key, new JSONObject());
        nextUpdateObject = updateObject.get(key);
      }
      getUpdatePatientObject((JSONObject) nextDocasapObject, (JSONObject) nextEpmObject,
          (JSONObject) nextUpdateObject);
    }
  }

  private void removeGuarantorInformation(JSONObject updatePatientInputObject,
      String deploymentId) {
    try {
      setValue(updatePatientInputObject, GURANTOR_INFORMATION_ARR, null);
    } catch (IHubException exc) {
      log.error(new StringBuilder("EXCEPTION:: deploymentId:").append(deploymentId)
          .append(" While removing the guarantor information - UpdatePatient flow ")
          .append(exc.getMessage()).toString());
    }
  }

  private void setPolicyHolderInfo(JSONObject policyholderInputObject, JSONObject inputObject,
      String deploymentId) {
    JSONObject policyholderInformation = (JSONObject) getValue(inputObject,
        POLICYHOLDER_INFORMATION);
    if (isEmpty(policyholderInformation)) {
      return;
    }
    try {
      setValue(policyholderInputObject, POLICYHOLDER_INFORMATION,
          policyholderInformation);
    } catch (IHubException iHubExc) {
      log.error(new StringBuilder("EXCEPTION:: deploymentId:").append(deploymentId)
          .append(" While setting up the policyholder information - UpdatePatient flow")
          .append(iHubExc.getMessage()).toString());
    }
  }
}