package com.pes.integration.athena.service;

import com.pes.integration.athena.handler.CancelAppointmentsHandlerService;
import com.pes.integration.athena.handler.NewAppointmentHandlerService;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.AppointmentsFlowHandler;
import com.pes.integration.service.DataTransactionService;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.CANCEL_APPOINTMENT;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.enums.FlowStatus.CREATED;
import static com.pes.integration.enums.FlowStatus.FAILED;

@Slf4j
@Service
public class ProcessAppointmentsService extends AppointmentsFlowHandler {

  @Autowired
  DataTransactionService dataTransactionService;

  @Autowired
  @Qualifier("CancelAppt")
  CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

  @Autowired
  @Qualifier("NewAppt")
  NewAppointmentHandlerService newAppointmentHandlerService;

  @Override
  public JSONObject createAppointment(JSONObject input) throws IHubException {
    JSONObject response = new JSONObject();
    dataTransactionService.logData(input, CREATE_APPOINTMENT.getKey(), CREATED.getKey(),
        "iHub Create Appointment Request Message");
    try {
      response = newAppointmentHandlerService.doExecute(
          input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));
    } catch (IHubException e) {
      log.error("Error in processing the create appointment request {} ", e.getMessage());
      dataTransactionService.logData(input, CREATE_APPOINTMENT.getKey(), FAILED.getKey(),
          e.getMessage());
      throw e;
    }
    return response;
  }

  @Override
  public JSONObject cancelAppointment(JSONObject input) throws IHubException {
    JSONObject response = new JSONObject();
    dataTransactionService.logData(input, CANCEL_APPOINTMENT.getKey(), CREATED.getKey(),
        "iHub Cancel Appointment Request Message");
    try {
      response = cancelAppointmentsHandlerService.doExecute(
          input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));
    } catch (IHubException e) {
      log.error("Error in processing the cancel appointment request {} ", e.getMessage());
      dataTransactionService.logData(input, CANCEL_APPOINTMENT.getKey(), FAILED.getKey(),
          e.getMessage());
      throw e;
    }
    return response;
  }
}
