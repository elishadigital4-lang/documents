package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;

import static com.pes.integration.athena.api.ApiName.GET_PATIENTS;
import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.DOB;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.SEARCH_PATIENT;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static java.util.Objects.isNull;

@Slf4j
@Service
public class GetPatientHandler extends BaseHandler {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Override
  @Observed(name = "integration.athenaGetPatient", contextualName = "integration")
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    JSONObject outputObject;
    try {
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      handlerUtils.addPracticeId(deploymentId, inputObject);
      setDob(inputObject);
      outputObject = athenaApiCaller.call(GET_PATIENTS.getKey(), inputObject,
          SEARCH_PATIENT.getKey());
    } catch (ParseException e) {
      log.error("Error {} ", e.getMessage());
      throw new IHubException(DATA_VALIDATION_ERROR.getErrorCode(), "DOB was invalid or null.");
    }
    return outputObject;
  }

  private void setDob(JSONObject inputObject) throws ParseException, IHubException {
    String dob = (String) getValue(inputObject, DOB);
    if (!isNull(dob)) {
      dob = convertDateFormat(dob, DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT);
      setValue(inputObject, DOB, dob);
    }
  }
}
