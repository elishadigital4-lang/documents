package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractAthenaNewPatientHandler;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.athena.api.ApiName.NEW_PATIENT;
import static com.pes.integration.athena.api.ApiName.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.DA_PATIENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.PATIENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.ERROR_MESSAGE;
import static com.pes.integration.constant.DocASAPConstants.TempKey.IS_NEW_PATIENT_CREATED;
import static com.pes.integration.constant.EpmConstant.PAT_FOUND;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.FAILED;
import static com.pes.integration.enums.FlowStatus.IN_PROGRESS;
import static com.pes.integration.enums.StatusCodes.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;

@Slf4j
@Service(value = "NewPatient")
public class NewPatientHandlerService extends AbstractAthenaNewPatientHandler {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Autowired
  DataCacheManager cacheManager;

  @Autowired
  MatchPatientHandler matchPatientHandler;

  @Autowired
  PatientNotificationHandler patientNotificationHandler;

  @Autowired
  PatientNotificationPreferences patientNotificationPreferences;

  @Autowired
  PatientInsuranceHandler patientInsuranceHandler;

  @Override
  @Observed(name = "integration.athenaCreateNewPatient", contextualName = "integration")
  public JSONObject createNewPatient(JSONObject inputObject) throws IHubException {
    JSONObject outputObject = new JSONObject();
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    handlerUtils.addPracticeId(deploymentId, inputObject);
    handleNotificationKey(inputObject, deploymentId);
    try {
      JSONObject matchPatientResponse = matchPatient(inputObject, deploymentId);
      var patientId = getValue(matchPatientResponse, APPOINTMENT_PATIENT_ID);
      Object error = getValue(matchPatientResponse, ERROR_CODE);
      matchPatientResponse.clear();
      if ((isNull(patientId) || patientId.equals(0)) && !MULTIPLE_PATIENT.getKey().equals(error)) {
        patientNotificationPreferences.getPatientNotificationPreferences(inputObject);
        dataTransactionService.logData(inputObject, CREATE_PATIENT.getKey(),
                IN_PROGRESS.getKey(), "EPM Create Patient Request");
        outputObject = athenaApiCaller.call(NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey());
        patientId = getValue(outputObject, PATIENT_ID);
        log.info("patientId: {} ", patientId);
        setValue(inputObject, PATIENT_ID, patientId);
        if (!isNull(patientId)) {
          handleInsurance(inputObject, patientId);
        }
        setValue(outputObject, IS_NEW_PATIENT_CREATED, true);
      } else if (!isEmpty(error) && MULTIPLE_PATIENT.getKey()
              .equals(error)) {
        setValue(outputObject, ERROR_MESSAGE, "Multiple matching patients detected");
        setValue(outputObject, ERROR_CODE, MULTIPLE_PATIENT.getKey());
        log.error("Found multiple matching patients.");
      } else {
        log.info("No create patient API call for patient ID {} ", patientId);
        setValue(inputObject, PATIENT_ID, patientId);
        patientNotificationHandler.doExecute(inputObject);
        setValue(outputObject, IS_NEW_PATIENT_CREATED, false);
        copyKey(DEMOGRAPHIC_DATA, inputObject, outputObject);
        setValue(outputObject, PATIENT_ID, patientId);
      }
    }
    catch (Exception e) {
      log.error("Error {} ", e.getMessage());
      outputObject.clear();
      throw newIhubException(e);
    }
    setValue(outputObject, DEPLOYMENT_ID, deploymentId);
    return outputObject;
  }

  private JSONObject matchPatient(JSONObject inputObject, String deploymentId)
          throws IHubException {
    JSONObject matchPatientObject = new JSONObject();
    matchPatientObject.put("patMatchingLayerPriConfStr",
            getPatMatchingLayerPriConfStr(deploymentId));
    matchPatientObject.put("patMatchingAlgoConfigStr", getPatMatchingAlgoConfigStr(deploymentId));
    return matchPatientHandler.processMatchPatient(getSearchPatientObject(inputObject),
            matchPatientObject);
  }

  private void handleNotificationKey(JSONObject inputObject, String deploymentId)
          throws IHubException {
    Object consentToEmail = cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
            ATHENA_CONFIG, CONSENT_TO_EMAIL, false);
    Object consentToText = cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
            ATHENA_CONFIG, AthenaEngineConstants.CONSENT_TO_TEXT, false);
    if (consentToEmail.equals(FALSE)) {
      setValue(inputObject, EMAIL, null);
    }
    if (!isNull(consentToText) && !EMPTY.equals(consentToText)) {
      setValue(inputObject, Key.CONSENT_TO_TEXT, consentToText);
    }
  }

  private JSONObject getSearchPatientObject(JSONObject inputObject) throws IHubException {
    JSONObject searchPatientJson = new JSONObject();
    copyKey(DEMOGRAPHIC_DATA, inputObject, searchPatientJson);
    copyKey(DEPLOYMENT_ID, inputObject, searchPatientJson);
    copyKey(SCHEDULING_DATA, inputObject, searchPatientJson);
    searchPatientJson.put("flowName", CREATE_PATIENT.getKey());
    return searchPatientJson;
  }

  private void handleInsurance(JSONObject inputObject, Object patientId) {
    try {
      JSONObject demographicData = (JSONObject) getValue(inputObject,
              DEMOGRAPHIC_DATA);
      if (demographicData.has("InsuranceInformation")) {
        JSONObject insuranceInputObject = new JSONObject();
        copyKey(DEPLOYMENT_ID, inputObject, insuranceInputObject);
        copyKey(DEMOGRAPHIC_DATA, inputObject, insuranceInputObject);
        copyKey(APPT_LOCATION_ID, inputObject, insuranceInputObject);
        copyKey(PATIENT_ID, inputObject, insuranceInputObject);
        copyKey(DA_PATIENT_ID, inputObject, insuranceInputObject);
        copyKey(INSURANCE_INFORMATION, inputObject, insuranceInputObject);
        patientInsuranceHandler.doExecute(insuranceInputObject);
      }
    } catch (IHubException e) {
      String error = new StringBuilder("Error in adding insurance to patient:: ").append(patientId)
              .append(" :error: ").append(e.getMessage()).toString();
      log.error(error);
      dataTransactionService.logData(inputObject, CREATE_PATIENT.getKey(),
              FAILED.getKey(), error);
    }
  }

  @Override
  public JSONObject getPatientDemographics(JSONObject inputObject)
          throws IHubException {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    handlerUtils.addPracticeId(deploymentId, inputObject);
    return athenaApiCaller
            .call(GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject, CREATE_PATIENT.getKey());
  }

  @Override
  public JSONObject getPatientInsuranceInfo(JSONObject inputObject)
          throws IHubException {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    handlerUtils.addPracticeId(deploymentId, inputObject);
    return athenaApiCaller
            .call(GET_PATIENT_INSURANCE.getKey(), inputObject, CREATE_PATIENT.getKey());
  }

  private String getPatMatchingAlgoConfigStr(String deploymentId) {
    String patMatchingAlgoConfigStr = EMPTY;
    try {
      patMatchingAlgoConfigStr = (String) cacheManager.getStoredProvidersConfig(
              BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
              GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false);
    } catch (Exception e) {
      log.error("Patient Matching Algo Config is not set for org: " + deploymentId
              + ", default will be used");
    }
    return patMatchingAlgoConfigStr;
  }

  private String getPatMatchingLayerPriConfStr(String deploymentId) {
    String patMatchingLayerPriConfStr = null;
    try {
      patMatchingLayerPriConfStr = (String) cacheManager.getStoredProvidersConfig(
              BaseEPMConstants.EPM_NAME_PREFIX, deploymentId, GENERIC_CONFIG,
              PAT_MATCHING_LAYER_PRIORITY_CONFIG,
              false);
    } catch (Exception e) {
      log.error(
              "Patient matching layers priority configuration is not set for org: " + deploymentId);
    }
    return patMatchingLayerPriConfStr;
  }
  private IHubException newIhubException(Exception e) throws IHubException {
    String statusCode = null;
    String message = null;
    if ((e.getMessage() != null && e.getMessage().toString().toLowerCase().contains("lastname".toLowerCase()))) {
      statusCode = NO_LAST_NAME_FOUND.getKey();
      message = "NO LAST NAME FOUND";
    } else if ((e.getMessage() != null && e.getMessage().toString().toLowerCase().contains("firstname".toLowerCase()))) {
      statusCode = NO_FIRST_NAME_FOUND.getKey();
      message = "NO FIRST NAME FOUND";
    } else if ((e.getMessage() != null && e.getMessage().toString().toLowerCase().contains("HOMEPHONE".toLowerCase()))) {
      statusCode = INVALID_FORMAT.getKey();
      message = "HOMEPHONE IS INVALID";
    }
    if (!isNull(message) && !isNull(statusCode))
      throw new IHubException(e, new IHubErrorCode(statusCode), message);
    else
      throw new IHubException(e, ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
              e.getMessage());
  }
}
