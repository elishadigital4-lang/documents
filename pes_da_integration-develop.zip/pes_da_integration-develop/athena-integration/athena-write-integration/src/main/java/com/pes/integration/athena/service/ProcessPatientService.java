package com.pes.integration.athena.service;

import com.pes.integration.athena.handler.GetPatientHandler;
import com.pes.integration.athena.handler.NewPatientHandlerService;
import com.pes.integration.athena.handler.UpdatePatientHandler;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import com.pes.integration.service.PatientFlowHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.ERROR;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.*;
import static com.pes.integration.enums.FlowStatus.*;
import static java.util.Optional.ofNullable;

@Slf4j
@Service
public class ProcessPatientService extends PatientFlowHandler {

  @Autowired
  NewPatientHandlerService newPatientHandlerService;

  @Autowired
  GetPatientHandler getPatientHandler;

  @Autowired
  UpdatePatientHandler updatePatientHandler;

  @Autowired
  DataTransactionService dataTransactionService;

  @Override
  public JSONObject createPatient(JSONObject input) throws IHubException {
    dataTransactionService.logData(input, CREATE_PATIENT.getKey(), CREATED.getKey(),
        "iHub Create Patient Request Message");
    JSONObject response = new JSONObject();
    try {
      response = newPatientHandlerService.doExecute(
          input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC)
              .getJSONObject(0));
    } catch (IHubException e) {
      log.error("Error in processing the create patient request {} ", e.getMessage());
      dataTransactionService.logData(input, CREATE_PATIENT.getKey(), FAILED.getKey(),
          e.getMessage());
      throw e;
    }
    dataTransactionService.logData(input, CREATE_PATIENT.getKey(), SUCCESS.getKey(),
        "iHub Create Patient Successful");
    return response;
  }

  @Override
  public JSONObject updatePatient(JSONObject input) throws IHubException {
    try {
      dataTransactionService.logData(input, UPDATE_PATIENT.getKey(), CREATED.getKey(),
          "iHub Update Patient Request Message");
      return updatePatientHandler.doExecute(
          input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC)
              .getJSONObject(0));
    } catch (IHubException e) {
      dataTransactionService.logData(input, UPDATE_PATIENT.getKey(), FAILED.getKey(),
          e.getMessage());
      throw e;
    }
  }

  @Override
  public JSONObject searchPatient(JSONObject input) throws IHubException {
    dataTransactionService.logData(input, SEARCH_PATIENT.getKey(), CREATED.getKey(),
        "iHub Search Patient Request Message");
    JSONObject responseJson = new JSONObject();
    try {
      JSONObject response = getPatientHandler.doExecute(
          input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));
      responseJson.put(DATA, response);
      JSONArray patientArray = new JSONArray();
      if (response.has("temp")) {
        JSONObject temp = response.getJSONObject("temp");
        patientArray.put(temp);
        temp.put("temp", ofNullable(null));
        responseJson.put(ERROR, patientArray);
      }
    } catch (IHubException e) {
      log.error("Error in searching the patient {} ", e.getMessage());
      dataTransactionService.logData(input, SEARCH_PATIENT.getKey(), FAILED.getKey(),
          e.getMessage());
      throw e;
    }
    return responseJson;
  }

  @Override
  public JSONObject getPatient(JSONObject input) throws IHubException {
    return null;
  }
}