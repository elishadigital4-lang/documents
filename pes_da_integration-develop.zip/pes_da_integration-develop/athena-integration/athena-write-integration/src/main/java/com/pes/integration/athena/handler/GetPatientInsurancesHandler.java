package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.athena.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service(value = "GetInsuranceTypes")
public class GetPatientInsurancesHandler extends BaseHandler {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Override
  @Observed(name = "integration.getPatientInsurance", contextualName = "integration")
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    handlerUtils.addPracticeId(deploymentId, inputObject);
    return athenaApiCaller.call(GET_PATIENT_INSURANCE.getKey(), inputObject, "");
  }
}
