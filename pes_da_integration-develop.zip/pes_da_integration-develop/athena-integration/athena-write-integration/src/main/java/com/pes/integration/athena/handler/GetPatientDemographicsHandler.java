package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.athena.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;

@Slf4j
@Service(value = "getPatientDemographics")
public class GetPatientDemographicsHandler extends BaseHandler {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Override
  @Observed(name = "integration.athenaGetPatientDemographics", contextualName = "integration")
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    String deploymentId = JsonUtils.getValue(inputObject, DEPLOYMENT_ID).toString();
    handlerUtils.addPracticeId(deploymentId, inputObject);
    return athenaApiCaller.call(GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject, "");
  }
}
