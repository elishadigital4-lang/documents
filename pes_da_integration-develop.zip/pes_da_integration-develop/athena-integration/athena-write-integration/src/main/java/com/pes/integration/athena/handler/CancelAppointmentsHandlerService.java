package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractCancelAppointmentsHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.athena.constant.AthenaConstants.SHOULD_IGNORE_SCHEDULABLE_PERMISSION;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_OBJECT;
import static com.pes.integration.constant.DocASAPConstants.Key.EVENT_REASON_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.IGNORE_SCHEDULABLE_PERMISSION;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP;
import static com.pes.integration.constant.UtilitiesConstants.APPT_STATUS;
import static com.pes.integration.constant.UtilitiesConstants.CANCEL_APPT_MESSAGE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_S;
import static com.pes.integration.enums.StatusCodes.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_LOADING_CONFIG;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.util.Objects.isNull;

@Slf4j
@Service(value = "CancelAppt")
public class CancelAppointmentsHandlerService extends AbstractCancelAppointmentsHandler {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  DataCacheManager cacheManager;

  @Autowired
  HandlerUtils handlerUtils;

  @Override
  public JSONObject cancelAppointment(JSONObject inputObject) throws IHubException {
    try {
      JSONObject outputObject;
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      log.info("cancelAppointment for the deployment id {} ", deploymentId);
      handlerUtils.addPracticeId(deploymentId, inputObject);
      getCancelReason(inputObject, deploymentId);
      setValue(inputObject, IGNORE_SCHEDULABLE_PERMISSION, SHOULD_IGNORE_SCHEDULABLE_PERMISSION);
      outputObject = athenaApiCaller.call(ApiName.CANCEL_APPOINTMENT.getKey(), inputObject,
              Flow.CANCEL_APPOINTMENT.getKey());
      if (!isEmpty(outputObject) && outputObject.has(TEMP)) {
          JSONObject tempObject = outputObject.getJSONObject(TEMP);
          if (tempObject.has(APPT_STATUS)) {
            String status = tempObject.getString(APPT_STATUS);
            if (!isEmpty(status) && status.equalsIgnoreCase("x")) {
              log.info("Appointment has been cancelled successfully {} ", tempObject);
              inputObject.put(MESSAGE_S, CANCEL_APPT_MESSAGE);
              inputObject.put(APPT_STATUS, status);
              setValue(outputObject, APPOINTMENT_OBJECT, inputObject);
              return outputObject;
            }
          } else {
            log.info("outputObject :" + outputObject);
          }
      }
      return outputObject;
    }
    catch (Exception e) {
      log.error("Error {} ", e.getMessage());
      throw newIhubException(e);
    }
  }

  public void getCancelReason(JSONObject inputObject, String deploymentId) throws IHubException {
    log.info("start of getCancelReason");
    try {
      String cancelReason = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX,
          deploymentId,
          ATHENA_CONFIG, DEFAULT_CANCEL_REASON, false);
      if (!isEmpty(cancelReason)) {
        setValue(inputObject, EVENT_REASON_ID, Integer.parseInt(cancelReason));
      }
    } catch (IHubException bee) {
      log.error(bee.getMessage());
      throw bee;
    } catch (Exception e) {
      log.error(e.getMessage());
      throw new IHubException(ERROR_LOADING_CONFIG.getErrorCode(), "deploymentPracticeMapping");
    }
  }

  private IHubException newIhubException(Exception e) {
    String statusCode = null;
    String message = null;
    if ((e.getMessage() != null && e.getMessage().toString().toLowerCase().contains("already canceled".toLowerCase()))
            || (e.getMessage() != null && e.getMessage().toString().toLowerCase().contains("This appointment is no longer valid".toLowerCase()))) {
      statusCode = NO_APPOINTMENT_FOUND.getKey();
      message = "APPOINTMENT IS ALREADY CANCELED";
    } else if ((e.getMessage() != null && e.getMessage().toString().toLowerCase().contains("Patient ID".toLowerCase()))) {
      statusCode = INVALID_FORMAT.getKey();
      message = "PATIENT ID IS INVALID";
    }
    if (!isNull(message) && !isNull(statusCode))
      return new IHubException(e, new IHubErrorCode(statusCode), message);
    else
      return new IHubException(e, ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
              e.getMessage());

  }
}