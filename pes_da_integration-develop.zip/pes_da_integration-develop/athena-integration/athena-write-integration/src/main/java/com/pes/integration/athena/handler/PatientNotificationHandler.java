package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;

@Slf4j
@Service
public class PatientNotificationHandler extends BaseHandler {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  PatientNotificationPreferences patientNotificationPreferences;

  @Override
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    JSONObject outputObject = new JSONObject();
    JSONObject updatePatientObject = new JSONObject(inputObject.toString());
    try {
      if (patientNotificationPreferences.arePatientNotificationPreferencesPresent(updatePatientObject)) {
        String patientId = (String) getValue(inputObject, PATIENT_ID);

        updatePatientObject = (JSONObject) patientNotificationPreferences.getPatientNotificationPreferences(updatePatientObject);
        setValue(updatePatientObject, "DemographicData", new JSONObject());
        setValue(updatePatientObject, PATIENT_ID, patientId);
        outputObject = athenaApiCaller.call(ApiName.UPDATE_PATIENT.getKey(), updatePatientObject,
            "");
      }
    } catch (IHubException e) {
      log.error("Error {} ", e.getMessage());
      setValue(outputObject, ERROR_DETAIL, e.getMessage());
      setValue(outputObject, ERROR_CODE, e.getErrorCode());
    } catch (Exception e) {
      log.error("Error {} ", e.getMessage());
    }
    return outputObject;
  }

}

