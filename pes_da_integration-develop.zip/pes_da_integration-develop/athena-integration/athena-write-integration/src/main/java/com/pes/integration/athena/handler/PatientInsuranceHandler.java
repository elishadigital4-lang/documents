package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.ManageFlagsUtility;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicReference;

import static com.pes.integration.constant.DocASAPConstants.Key;
import static com.pes.integration.constant.DocASAPConstants.TempKey;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATE_FORMAT;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;

@Slf4j
@Service
public class PatientInsuranceHandler extends BaseHandler {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  @Autowired
  ManageFlagsUtility manageFlagsUtility;

  @Autowired
  GetPatientInsurancesHandler getPatientInsurancesHandler;



  @Override
  @Observed(name = "integration.PatientInsuranceHandler.doExecute", contextualName = "integration")
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    AtomicReference<JSONArray> inputInsurancesArray = new AtomicReference<>(new JSONArray());
    AtomicReference<JSONArray> outputInsurancesArray = new AtomicReference<>(new JSONArray());
    AtomicReference<HashMap<String, JSONObject>> outputInsuranceMap = new AtomicReference<>(new HashMap<>());
    HashSet<String> addedPlanIds = new HashSet<>();
    AtomicReference<HashSet<String>> availablePlanIds = new AtomicReference<>(new HashSet<>());
  JSONObject outputObject;
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID);
    String insuranceLogic = getInsuranceLogic(deploymentId);
    outputObject = getPatientInsurancesHandler.doExecute(inputObject);
    HashMap<String, Object> retrievedObjects = getInsuranceArrays(inputObject, outputObject, inputInsurancesArray.get(), outputInsurancesArray.get(), outputInsuranceMap.get(),
            availablePlanIds.get());
    retrievedObjects.forEach((key, value) -> {
      if (key.equals("inputInsurancesArray")) {
        inputInsurancesArray.set((JSONArray) value);
      } else if (key.equals("outputInsurancesArray")) {
        outputInsurancesArray.set((JSONArray) value);
      } else if (key.equals("outputInsuranceMap")) {
        outputInsuranceMap.set((HashMap<String, JSONObject>) value);
      } else if (key.equals("availablePlanIds")) {
        availablePlanIds.set((HashSet<String>) value);
      }
    });
    if(insuranceLogic!=null&&insuranceLogic.equals(AthenaEngineConstants.ADD_INSURANCES_AT_BOTTOM)){
      addInsurancesAtBottom(inputObject, outputObject, inputInsurancesArray.get(), outputInsuranceMap.get(),
          addedPlanIds);
    }else{//by default add insurances at top.
      addInsurancesAtTop(inputObject, outputObject, inputInsurancesArray.get(), outputInsurancesArray.get(),
              outputInsuranceMap.get(), addedPlanIds);
    }
    return outputObject;
  }
  private String getInsuranceLogic(String deploymentId) {
    try{
      return (String) dataCacheManager.getStoredProvidersConfig(AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId, AthenaEngineConstants.ATHENA_CONFIG, AthenaEngineConstants.INSURANCE_LOGIC, false);
    }catch(Exception e){
      //do nothing, default value will be used.
      log.info(e.getMessage());
    }
    return null;
  }
  @Observed(name = "integration.getInsuranceArrays", contextualName = "integration")
  private HashMap<String, Object> getInsuranceArrays(JSONObject inputObject, JSONObject outputObject, JSONArray inputInsurancesArray,
                                  JSONArray outputInsurancesArray, HashMap<String, JSONObject> outputInsuranceMap,
                                  HashSet<String> availablePlanIds) throws IHubException {
    HashMap<String, Object> returnObjects = new HashMap<>();
    Object inputInsurancesObject = JsonUtils.getValue(inputObject, Key.INSURANCE_INFORMATION);
    Object outputInsurancesObject = JsonUtils.getValue(outputObject, Key.INSURANCE_INFORMATION);
    if(inputInsurancesObject instanceof JSONArray){
      inputInsurancesArray = (JSONArray) inputInsurancesObject;
      returnObjects.put("inputInsurancesArray", inputInsurancesArray);
    }
    if(outputInsurancesObject instanceof JSONArray){
      outputInsurancesArray = (JSONArray) outputInsurancesObject;
        returnObjects.put("outputInsurancesArray", outputInsurancesArray);
    }
    for (int i=0;i<outputInsurancesArray.length();i++) {
      JSONObject outputInsuranceObject = outputInsurancesArray.getJSONObject(i);
      String sequenceNumber = (String) JsonUtils.getValue(outputInsuranceObject, Key.SEQUENCE_NUMBER);
      String payorId = (String) JsonUtils.getValue(outputInsuranceObject, Key.INSURANCE_PAYOR_ID);// planId is replaced with payorId(PROD-60706)
      if(sequenceNumber!=null){
        outputInsuranceMap.put(sequenceNumber, outputInsuranceObject);
      }
      if(payorId!=null) {
        availablePlanIds.add(payorId);
        returnObjects.put("availablePlanIds", availablePlanIds);
      }
    }
    String insuredFName = (String) JsonUtils.getValue(inputObject, Key.FIRST_NAME);
    String insuredLName = (String) JsonUtils.getValue(inputObject, Key.LAST_NAME);
    String insuredGender = (String) JsonUtils.getValue(inputObject, Key.GENDER);
    Object locationId = JsonUtils.getValue(inputObject, Key.APPT_LOCATION_ID);
    JSONObject inputInsuranceObject1 = new JSONObject();
    for(int i=0;i<inputInsurancesArray.length();i++){
      inputInsuranceObject1 = setInputInsuranceObject(insuredFName, insuredLName, insuredGender, locationId, i, inputInsurancesArray);
    }
    returnObjects.put("inputInsuranceObject", inputInsuranceObject1);
    return returnObjects;
  }
  @Observed(name = "integration.addInsurancesAtBottom", contextualName = "integration")
  private void addInsurancesAtBottom(JSONObject inputObject, JSONObject outputObject, JSONArray inputInsurancesArray,
                                     HashMap<String, JSONObject> outputInsuranceMap,
                                     HashSet<String> addedPlanIds) throws IHubException {
      int remainingElements = inputInsurancesArray.length();
      int remainingPlaces = AthenaEngineConstants.MAX_INSURANCES_ALLOWED;
      int sequenceNumber = 1;

      for (int inputIndex = 0; inputIndex < inputInsurancesArray.length(); inputIndex++) {
          JSONObject inputInsuranceObject = inputInsurancesArray.getJSONObject(inputIndex);
          String payorId = (String) JsonUtils.getValue(inputInsuranceObject, Key.INSURANCE_PAYOR_ID);

          if (payorId == null || addedPlanIds.contains(payorId)) {
              remainingElements--;
              continue;
          }

          boolean added = tryAddInsuranceAtAvailablePlace(
                  inputObject, outputObject, inputInsuranceObject, payorId,
                  outputInsuranceMap, addedPlanIds,
                  remainingElements, remainingPlaces, sequenceNumber
          );

          // Update sequenceNumber, remainingPlaces, remainingElements if insurance was added
          if (added) {
              sequenceNumber++;
              remainingPlaces--;
              remainingElements--;
              continue;
          }

          // If not added and still have places, add insurance
          if (remainingElements >= remainingPlaces && !addedPlanIds.contains(payorId)) {
              checkAndAddInsurance(inputObject, outputObject, inputInsuranceObject, Integer.toString(sequenceNumber), outputInsuranceMap, addedPlanIds);
              sequenceNumber++;
              remainingElements--;
              remainingPlaces--;
          }
      }
  }

  private boolean tryAddInsuranceAtAvailablePlace(
          JSONObject inputObject, JSONObject outputObject, JSONObject inputInsuranceObject, String payorId,
          HashMap<String, JSONObject> outputInsuranceMap, HashSet<String> addedPlanIds,
          int remainingElements, int remainingPlaces, int sequenceNumber) throws IHubException {

      while (remainingElements < remainingPlaces) {
          String seqStr = Integer.toString(sequenceNumber);
          if (!outputInsuranceMap.containsKey(seqStr)) {
              if (!addedPlanIds.contains(payorId)) {
                  checkAndAddInsurance(inputObject, outputObject, inputInsuranceObject, seqStr, outputInsuranceMap, addedPlanIds);
              }
              return true;
          } else {
              JSONObject outputInsuranceObject = outputInsuranceMap.get(seqStr);
              String outputPayorId = (String) JsonUtils.getValue(outputInsuranceObject, Key.INSURANCE_PAYOR_ID);
              if (addedPlanIds.contains(outputPayorId)) {
                  log.info("Skipping already added insurance");
                  if (!addedPlanIds.contains(payorId)) {
                      checkAndAddInsurance(inputObject, outputObject, inputInsuranceObject, seqStr, outputInsuranceMap, addedPlanIds);
                  }
                  return true;
              } else {
                  addedPlanIds.add(outputPayorId);
              }
          }
          sequenceNumber++;
          remainingPlaces--;
      }
      return false;
  }
  @Observed(name = "integration.addInsurancesAtTop", contextualName = "integration")
  private void addInsurancesAtTop(JSONObject inputObject, JSONObject outputObject, JSONArray inputInsurancesArray, JSONArray outputInsurancesArray, HashMap<String, JSONObject> outputInsuranceMap,
                                  HashSet<String> addedPlanIds) throws IHubException {
    int outputIndex = 0;
    int inputIndex = 0;
    final int infinity = 100001; //Any value greater than MAX_INSURANCES_ALLOWED
    for (int sequenceNumber = 1; sequenceNumber <= AthenaEngineConstants.MAX_INSURANCES_ALLOWED; sequenceNumber++) {
      JSONObject inputInsuranceObject = null;
      JSONObject outputInsuranceObject = null;
      int inputSequenceNumber = infinity;
      int outputSequenceNumber = infinity;

      inputSequenceNumber = getSequenceNumberSafe(inputInsurancesArray, inputIndex, infinity);
      outputIndex = getNextValidOutputIndex(outputInsurancesArray, outputIndex, addedPlanIds);
      outputInsuranceObject = outputIndex < outputInsurancesArray.length() ? outputInsurancesArray.getJSONObject(outputIndex) : null;
      outputSequenceNumber = getSequenceNumberSafe(outputInsurancesArray, outputIndex, infinity);

      try {
        if (inputSequenceNumber <= sequenceNumber) {
          checkAndAddInsurance(inputObject, outputObject, inputInsuranceObject, Integer.toString(sequenceNumber), outputInsuranceMap, addedPlanIds);
          inputIndex++;
        } else if (outputSequenceNumber <= sequenceNumber) {
          checkAndAddInsurance(inputObject, outputObject, outputInsuranceObject, Integer.toString(sequenceNumber), outputInsuranceMap, addedPlanIds);
          outputIndex++;
        } else if (inputSequenceNumber != infinity || outputSequenceNumber != infinity) {
          checkAndAddInsurance(inputObject, outputObject, inputInsuranceObject, Integer.toString(sequenceNumber), outputInsuranceMap, addedPlanIds);
          inputIndex++;
        }
      } catch (Exception e) {
        log.error(e.getMessage(), e);
      }
    }
  }

  private int getSequenceNumberSafe(JSONArray array, int index, int defaultValue) {
    try {
      if (index < array.length()) {
        JSONObject obj = array.getJSONObject(index);
        return Integer.parseInt((String) JsonUtils.getValue(obj, Key.SEQUENCE_NUMBER));
      }
    } catch (Exception e) {
      log.error(e.getMessage(), e);
    }
    return defaultValue;
  }

  private int getNextValidOutputIndex(JSONArray outputInsurancesArray, int outputIndex, HashSet<String> addedPlanIds) {
    try {
      while (outputIndex < outputInsurancesArray.length()) {
        JSONObject outputInsuranceObject = outputInsurancesArray.getJSONObject(outputIndex);
        String payorId = (String) JsonUtils.getValue(outputInsuranceObject, Key.INSURANCE_PAYOR_ID);
        if (!addedPlanIds.contains(payorId)) {
          break;
        } else {
          outputIndex++;
        }
      }
    } catch (Exception e) {
      log.error(e.getMessage(), e);
    }
    return outputIndex;
  }

  @Observed(name = "integration.setInputInsuranceObject", contextualName = "integration")
  private JSONObject setInputInsuranceObject(String insuredFName, String insuredLName, String insuredGender,
                                       Object locationId, int i, JSONArray inputInsurancesArray) {
    JSONObject inputInsuranceObject = new JSONObject();
    try {
      inputInsuranceObject = inputInsurancesArray.getJSONObject(i);
      String subscriberId = (String) JsonUtils.getValue(inputInsuranceObject, Key.SUBSCRIBER_ID);
      if(subscriberId==null || subscriberId.replaceAll(AthenaEngineConstants.SPACE, BLANK).equals(BLANK))
        subscriberId="0";
      int sequenceNumber = i+1;
      JsonUtils.setValue(inputInsuranceObject, Key.INSURED_GENDER, insuredGender);
      JsonUtils.setValue(inputInsuranceObject, Key.FNAME_OF_INSURED, insuredFName);
      JsonUtils.setValue(inputInsuranceObject, Key.LNAME_OF_INSURED, insuredLName);
      JsonUtils.setValue(inputInsuranceObject, Key.INS_SEQUENCE_NUMBER, Integer.toString(sequenceNumber));
      JsonUtils.setValue(inputInsuranceObject, Key.SUBSCRIBER_ID, subscriberId);
      JsonUtils.setValue(inputInsuranceObject, Key.LOCATION_ID, locationId);

    } catch (IHubException e) {
      log.error(e.getMessage());
    }

    return inputInsuranceObject;
  }
  @Observed(name = "integration.checkAndAddInsurance", contextualName = "integration")
  private void checkAndAddInsurance(JSONObject inputObject, JSONObject outputObject, JSONObject insuranceObject, String sequenceNumber, HashMap<String, JSONObject> outputInsuranceMap, HashSet<String> addedPlanIds) throws IHubException {
    try{
      JSONObject outputInsuranceObject = outputInsuranceMap.get(sequenceNumber);
      String athenaPayorId = (String) JsonUtils.getValue(outputInsuranceObject, Key.INSURANCE_PAYOR_ID);
      String payorId = (String) JsonUtils.getValue(insuranceObject, Key.INSURANCE_PAYOR_ID);
      if(payorId!=null&&(!payorId.equals(athenaPayorId))){
        log.info("Processing insurance");
        JsonUtils.setValue(insuranceObject, Key.SEQUENCE_NUMBER, sequenceNumber);
        if(!NullChecker.isEmpty(athenaPayorId)) {
          log.info("Deleting existing insurance ");
          deleteSingleInsurance(inputObject, sequenceNumber);
        }
        log.info("Adding new insurance");
        addSingleInsurance(inputObject, insuranceObject, outputObject);
      }
      addedPlanIds.add(payorId);
    }catch(Exception e) {
      log.error(e.getMessage());
      JsonUtils.setValue(inputObject, Key.ADDITIONAL_INFO, "One or more Insurances could not be updated");
    }
  }
  @Observed(name = "integration.addSingleInsurance", contextualName = "integration")
  private void addSingleInsurance(JSONObject inputObject, JSONObject insuranceObject, JSONObject outputObject) throws IHubException {
    Object patientId = JsonUtils.getValue(inputObject, Key.PATIENT_ID);
    JsonUtils.setValue(insuranceObject, TempKey.PATIENT_ID, patientId);
    JsonUtils.copyKey(TempKey.PRACTICE_ID, inputObject, insuranceObject);
    JsonUtils.copyKey(DEPLOYMENT_ID, inputObject, insuranceObject);

    addRelationshipToInsuredId(inputObject, insuranceObject);

    JSONObject addInsOutput;
    addInsOutput = athenaApiCaller.call(ApiName.SET_PATIENT_INSURANCE.getKey(), insuranceObject, "");
    String error = (String) JsonUtils.getValue(addInsOutput, TempKey.ERROR_MESSAGE);
    if(error!=null){
      JsonUtils.setValue(outputObject, TempKey.ERROR_MESSAGE, error);
      throw new IHubException(UtilityErrors.ERROR_IN_REQUEST.getErrorCode(),"Error while adding insurance: "+error);
    }
  }
  @Observed(name = "integration.deleteSingleInsurance", contextualName = "integration")
  private void deleteSingleInsurance(JSONObject inputObject, String sequenceNumber) throws IHubException{
    JSONObject insuranceObject = new JSONObject();
    JsonUtils.setValue(insuranceObject, Key.SEQUENCE_NUMBER, sequenceNumber );
    Object patientId = JsonUtils.getValue(inputObject, Key.PATIENT_ID);
    JsonUtils.setValue(insuranceObject, TempKey.PATIENT_ID, patientId);
    JsonUtils.copyKey(TempKey.PRACTICE_ID, inputObject, insuranceObject);
    JsonUtils.copyKey(DEPLOYMENT_ID, inputObject, insuranceObject);
    athenaApiCaller.call(ApiName.DELETE_PATIENT_INSURANCE.getKey(), insuranceObject, "");
  }
  @Observed(name = "integration.addRelationshipToInsuredId", contextualName = "integration")
  private void addRelationshipToInsuredId(JSONObject inputObject, JSONObject insuranceObject) {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID);
    JSONObject policyholderInformation = (JSONObject)JsonUtils.getValue(inputObject, Key.POLICYHOLDER_INFORMATION);
    if(NullChecker.isEmpty(policyholderInformation))return;
    setPatientInsurance(inputObject, insuranceObject);
    String policyholderRelationShip = (String)JsonUtils.getValue(inputObject, Key.POLICYHOLDER_RELATIONSHIP);
    if(!NullChecker.isEmpty(policyholderRelationShip)) {
      setPolicyholderRelationship(insuranceObject, policyholderInformation, policyholderRelationShip,deploymentId);
    }
  }
  @Observed(name = "integration.setPolicyholderRelationship", contextualName = "integration")
  private void setPolicyholderRelationship(JSONObject insuranceObject, JSONObject policyholderInformation,
                                           String policyholderRelationShip, String deploymentId) {
    try {
      if(!NullChecker.isEmpty(policyholderInformation)) {
        policyholderRelationShip =  policyholderRelationShip.toLowerCase();
        String relationConfiguration =   manageFlagsUtility.getConfiguration("ah",deploymentId, AthenaEngineConstants.ATHENA_CONFIG, AthenaEngineConstants.GUARANTOR_RELATIONS);
        String[] relationships = relationConfiguration.split(COMMA);
        for(String relation : relationships) {
          if(policyholderRelationShip.equals(relation.split(COLON)[0])) {
            JsonUtils.setValue(insuranceObject, Key.RELATIONSHIP_TO_INSURED, relation.split(COLON)[1]);
            break;
          }
        }
      }
    } catch (IHubException e) {
      log.error(sanitizeForLog("EXCEPTION:: deploymentId:"+deploymentId+" While setting up the policyholder information - set_patient_insurance API"));
    }
  }
  @Observed(name = "integration.setPatientInsurance", contextualName = "integration")
  private void setPatientInsurance(JSONObject inputObject, JSONObject insuranceObject) {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID);
    try {
      String dob = getValue(inputObject, Key.INSURANCE_PH_DOB);
      PhoneNumberUtils.handlePhoneNumberD2E(inputObject);
      JsonUtils.setValue(insuranceObject, Key.INS_CO_PHONE, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_PHONE));
      JsonUtils.setValue(insuranceObject, Key.INSURED_GENDER, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_GENDER));
      JsonUtils.setValue(insuranceObject, Key.INS_ADDR_STREET1, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_STREET1));
      JsonUtils.setValue(insuranceObject, Key.INS_ADDR_STREET2, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_STREET2));
      JsonUtils.setValue(insuranceObject, Key.INS_ADDR_CITY, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_CITY));
      JsonUtils.setValue(insuranceObject, Key.INS_ADDR_ZIP, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_ZIP));
      JsonUtils.setValue(insuranceObject, Key.INS_ADDR_STATE, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_STATE));
      JsonUtils.setValue(insuranceObject, Key.INS_ADDR_COUNTRY_CODE, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_COUNTRY_CODE));
      JsonUtils.setValue(insuranceObject, Key.INS_FNAME, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_FNAME));
      JsonUtils.setValue(insuranceObject, Key.INS_MNAME, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_MNAME));
      JsonUtils.setValue(insuranceObject, Key.INS_LNAME, JsonUtils.getValue(inputObject, Key.INSURANCE_PH_LNAME));
      if(!NullChecker.isEmpty(dob)) {
        dob = DateUtils.convertDateFormat(dob, DATE_FORMAT, BaseEPMConstants.EPM_DATE_FORMAT);
      }
      JsonUtils.setValue(insuranceObject, Key.INS_DOB, dob);
    } catch (Exception iHubExc) {
      printError(deploymentId, iHubExc);
    }
  }
  private void printError(String deploymentId, Exception iHubExc) {
    log.error(sanitizeForLog("IHubException:: deploymentId:"+deploymentId+" While setting up the policyholder information - set_patient_insurance API"+ iHubExc));
  }

  private String getValue(JSONObject inputObject, String key) {
    String value = (String)JsonUtils.getValue(inputObject, key);
    if(!NullChecker.isEmpty(value))return value;
    return BLANK;
  }
}
