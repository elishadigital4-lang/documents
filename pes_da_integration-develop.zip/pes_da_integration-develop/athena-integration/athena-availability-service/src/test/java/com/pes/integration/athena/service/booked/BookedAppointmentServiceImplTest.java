package com.pes.integration.athena.service.booked;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.service.open.OpenAppointmentServiceImpl;
import com.pes.integration.athena.task.PrepareBookedSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.athena.constant.AthenaConstants.ATHENA_PRACTICE_ID;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_PROCESSING_STARTED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookedAppointmentServiceImplTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private ObjectMapper objectMapper;
    @InjectMocks
    private BookedAppointmentServiceImpl bookedAppointmentService;

    private AvailabilityRequest availabilityRequest;
    private JSONArray locationJsonArray;

    private JSONObject responseObject;

    private Map<String, JSONArray> providerLocationMap;
    private String startDate;
    private String endDate;
    private String epmPrefix;
    private String deploymentId;

    private RealTimeRequest realTimeRequest;

    @BeforeEach
    void setUp() {
        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("1");
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-31");
        availabilityRequest.setIndex("1");
        availabilityRequest.setTotalSlices("5");
        availabilityRequest.setDeploymentId("deploymentId");

        responseObject = new JSONObject();
        responseObject.put("BookedAppointments", new JSONArray());

        startDate = "2023-01-01";
        endDate = "2023-01-31";
        locationJsonArray = new JSONArray();
        epmPrefix = "epmPrefix";
        deploymentId = "deploymentId";

        providerLocationMap = new HashMap<>();
        providerLocationMap.put(LOCATION_ID_LIST, new JSONArray());
        epmPrefix = "epmPrefix";

        realTimeRequest = new RealTimeRequest();
    }

    @Test
    void testGetInputObject() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                bookedAppointmentService, "getInputObject", startDate, endDate, locationJsonArray, epmPrefix, deploymentId);

        assertEquals(startDate, result.getString(STARTDATE));
        assertEquals(endDate, result.getString(ENDDATE));
        assertEquals("appointment/", result.getString(APPOINTMENT_PATH));
        assertEquals("configValue", result.getString(ATHENA_PRACTICE_ID));
        assertEquals("-1", result.getString("reason_id"));
        assertEquals("configValue", result.getString("limit"));
        assertEquals("configValue", result.getString("ignore_schedulable_permission"));
        assertEquals(locationJsonArray, result.getJSONArray("departmentid"));
        assertEquals("configValue", result.getString(FILTER_DATA));
        assertEquals(epmPrefix, result.getString("epmPrefix"));
        assertEquals(deploymentId, result.getString("deploymentId"));
    }

    @Test
    void testGetFragmentsDetails() {
        Map<String, Object> result = (Map<String, Object>) ReflectionTestUtils.invokeMethod(
                bookedAppointmentService, "getFragmentsDetails", availabilityRequest);

        assertEquals("1", result.get(TOTAL_FRAGMENTS));
        assertEquals("5", result.get(TOTAL_SLICES));
    }

    @Test
    void testGetRealTimeAvailability() {
        JSONObject result = bookedAppointmentService.getRealTimeAvailability(realTimeRequest);
        assertNull(result);
    }

    @Test
    void testGetAvailability_Success() throws JsonProcessingException, IHubException {
        // Mock the necessary methods
        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequest");
        doNothing().when(trackEvents).trackEvent(any(), any(), any(), any());

        // Use a spy to mock the fetchBookedAppointments method
        BookedAppointmentServiceImpl spyService = spy(bookedAppointmentService);
        doNothing().when(spyService).fetchBookedAppointments(anyString(), anyString(), any(), any(), anyString());

        // Call the method and assert the result
        JSONArray result = spyService.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix");

        // Verify the interactions and assert the result
        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
        verify(spyService, times(1)).fetchBookedAppointments(anyString(), anyString(), any(), any(), anyString());
        assertNull(result);
    }

    @Test
    void testFetchBookedAppointments_ParseException() {
        // Arrange
        String invalidDate = "invalid-date";
        ReflectionTestUtils.setField(bookedAppointmentService, "dataCacheManager", dataCacheManager);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            bookedAppointmentService.fetchBookedAppointments(invalidDate, endDate, locationJsonArray, availabilityRequest, epmPrefix);
        });
    }

    @Test
    void fetchBookedAppointments_withValidInput_processesSuccessfully() throws IHubException, ParseException {
        try (MockedConstruction<PrepareBookedSlotsTask> bookedSlotsTaskMockedConstruction
                     = mockConstruction(PrepareBookedSlotsTask.class, (mock, context) -> {
            doNothing().when(mock).processBookedAppointment();
        })) {
            String startDate = "2023-01-01";
            String endDate = "2023-01-10";
            JSONArray locationJsonArray = new JSONArray().put("loc1");
            AvailabilityRequest availabilityRequest = new AvailabilityRequest();
            availabilityRequest.setDeploymentId("deploymentId");
            String epmPrefix = "epmPrefix";
            when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

            Assertions.assertDoesNotThrow(() -> bookedAppointmentService.fetchBookedAppointments(startDate, endDate, locationJsonArray, availabilityRequest, epmPrefix));

        }
    }



    @Test
    void fetchBookedAppointments_withEpmApiCallerException_logsError() throws IHubException, ParseException {
        String startDate = "2023-01-01";
        String endDate = "2023-01-10";
        JSONArray locationJsonArray = new JSONArray().put("loc1");
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setDeploymentId("deploymentId");
        availabilityRequest.setIndex("minusOne");
        String epmPrefix = "epmPrefix";

        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");
        doThrow(new EpmApiCallerException("API error")).when(athenaApiCaller).call(anyString(), any(JSONObject.class), anyString());

        bookedAppointmentService.fetchBookedAppointments(startDate, endDate, locationJsonArray, availabilityRequest, epmPrefix);

        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
    }
}