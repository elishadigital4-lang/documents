package com.pes.integration.athena.task;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;

import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_RESOURCE_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrepareBookedSlotsTaskTest {

    @InjectMocks
    private PrepareBookedSlotsTask prepareBookedSlotsTask;

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private AvailabilityRequest availabilityRequest;

    @Mock
    private JSONObject inputObject;

    @BeforeEach
    void setUp() {
        when(inputObject.getString("startDate")).thenReturn("2023-01-01");
        when(inputObject.getString("endDate")).thenReturn("2023-01-31");
        when(inputObject.optString("locations")).thenReturn("location1,location2");
        when(inputObject.getString("appointmentPath")).thenReturn("/path/to/appointments");
        when(inputObject.optString("epmPrefix")).thenReturn("epmPrefix");
        when(inputObject.optString("deploymentId")).thenReturn("deploymentId");

        prepareBookedSlotsTask = new PrepareBookedSlotsTask(athenaApiCaller, inputObject, fileUploader, trackEvents, availabilityRequest, dataCacheManager);
    }

    @Test
    void testGetBookedAppointment() throws Exception {
        // Prepare the response object
        JSONObject responseObject = new JSONObject();
        responseObject.put("BookedAppointments", new JSONArray());
        when(athenaApiCaller.call(any(), any(), any())).thenReturn(responseObject);

        // Access the private method using reflection
        Method method = PrepareBookedSlotsTask.class.getDeclaredMethod("getBookedAppointment");
        method.setAccessible(true);

        // Invoke the method
        JSONObject result = (JSONObject) method.invoke(prepareBookedSlotsTask);

        // Verify the result
        assertNotNull(result);
    }

//    @Test
//    void testExtractBookedSlots() throws Exception {
//        JSONObject outputObject = new JSONObject();
//        JSONArray tempAppointmentsArray = new JSONArray();
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put("LocalProviderId", "localProviderId");
//        appointmentObject.put("ProviderId", "providerId");
//        appointmentObject.put("ApptReasonId", "reasonId");
//        JSONObject temp = new JSONObject();
//        temp.put("start_time", "10:00");
//        temp.put("start_date", "01/01/2023");
//        appointmentObject.put("temp", temp);
//        appointmentObject.put("LocationId", "locationId");
//        appointmentObject.put("Duration", 30);
//        appointmentObject.put("ExternalApptId", "slotId");
//        appointmentObject.put("CreateDateTime", "2023/01/01 10:00:00");
//        tempAppointmentsArray.put(appointmentObject);
//        outputObject.put("BookedAppointments", tempAppointmentsArray);
//
//        JSONObject transformedAppointment = new JSONObject();
//        transformedAppointment.put("transformedKey", "transformedValue");
//
//        PrepareBookedSlotsTask spyTask = spy(prepareBookedSlotsTask);
//        // Access the private method using reflection
//        Method method = PrepareBookedSlotsTask.class.getDeclaredMethod("extractBookedSlots", JSONObject.class);
//        method.setAccessible(true);
//
//        // Invoke the method
//        JSONArray result = (JSONArray) method.invoke(spyTask, outputObject);
//
//        // Verify the result
//        assertNotNull(result);
//        assertEquals(1, result.length());
//    }

    @Test
    void testTrackEventToNifi() {
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "1";
        String fragmentId = "fragmentId";

        when(availabilityRequest.getMessageControlId()).thenReturn("messageControlId");
        when(availabilityRequest.getAppointmentType()).thenReturn("appointmentType");
        when(availabilityRequest.getSliceId()).thenReturn("sliceId");
        when(availabilityRequest.getDeploymentId()).thenReturn("deploymentId");
        when(availabilityRequest.getEntityType()).thenReturn("entityType");
        when(availabilityRequest.getEntityId()).thenReturn("entityId");
        when(availabilityRequest.getTotalSlices()).thenReturn("totalSlices");
        when(availabilityRequest.getFlow()).thenReturn("flow");

        prepareBookedSlotsTask.trackEventToNifi(trackEvents, availabilityRequest, dataflowStatus, totalFragments, fragmentId);

        ArgumentCaptor<NifiTrackingEvent> argumentCaptor = ArgumentCaptor.forClass(NifiTrackingEvent.class);
        verify(trackEvents).trackEventToNifi(argumentCaptor.capture());

        NifiTrackingEvent capturedEvent = argumentCaptor.getValue();
        assertEquals(dataflowStatus.toString(), capturedEvent.getFlowPoint());
        assertEquals("messageControlId", capturedEvent.getMessageControlId());
        assertEquals("appointmentType", capturedEvent.getAppointmentType());
        assertEquals("sliceId", capturedEvent.getSliceId());
        assertEquals("deploymentId", capturedEvent.getDeploymentId());
        assertEquals(totalFragments, capturedEvent.getTotalFragments());
        assertEquals("entityType", capturedEvent.getEntityType());
        assertEquals("entityId", capturedEvent.getEntityId());
        assertEquals(fragmentId, capturedEvent.getFragmentId());
        assertEquals("totalSlices", capturedEvent.getTotalSlices());
        assertEquals("flow", capturedEvent.getFlow());
    }

    @Test
    void testGetLocationIdStr() {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put("location1");
        jsonArray.put("location2");
        jsonArray.put("location3");

        String result = PrepareBookedSlotsTask.getLocationIdStr(jsonArray);

        assertEquals("location1,location2,location3", result);
    }

    @Test
    void testBookedAppointments() throws Exception {
        // Prepare input
        String startDate = "2023-01-01";
        String endDate = "2023-01-31";
        String locations = "location1,location2";

        // Mock inputObject methods
        when(inputObject.has("departmentid")).thenReturn(true);
        when(inputObject.getJSONArray("departmentid")).thenReturn(new JSONArray().put("dept1").put("dept2"));
        when(inputObject.getString("limit")).thenReturn("10");
        when(inputObject.getString(IGNORE_SHCED_PERMISSION)).thenReturn("true");
        when(inputObject.getString(ATHENA_PRACTICE_ID)).thenReturn("practiceId");
        when(inputObject.getString(AthenaConstants.REASON_ID)).thenReturn("reasonId");
        when(inputObject.has(APPT_RESOURCE_ID)).thenReturn(true);

        JSONObject expectedResponse = new JSONObject().put("key", "value");
        when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        // Access the private method using reflection
        Method method = PrepareBookedSlotsTask.class.getDeclaredMethod("bookedAppointments", AthenaApiCaller.class, String.class, String.class, String.class);
        method.setAccessible(true);

        // Invoke the method
        JSONObject result = (JSONObject) method.invoke(prepareBookedSlotsTask, athenaApiCaller, startDate, endDate, locations);

        // Verify the result
        assertNotNull(result);
        assertEquals(expectedResponse.toString(), result.toString());
    }
}