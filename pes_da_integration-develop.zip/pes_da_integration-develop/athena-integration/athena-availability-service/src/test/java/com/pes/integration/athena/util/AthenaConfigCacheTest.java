package com.pes.integration.athena.util;


import org.json.JSONArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AthenaConfigCacheTest {

    private AthenaConfigCache cache;

    @BeforeEach
    void setUp() {
        cache = AthenaConfigCache.getInstance();
    }

    @Test
    void getInstance_returnsSameInstance() {
        AthenaConfigCache anotherInstance = AthenaConfigCache.getInstance();
        assertSame(cache, anotherInstance);
    }

    @Test
    void getAppointmentTypeList_returnsCorrectMap() {
        Map<String, String> apptTypeMap = new HashMap<>();
        apptTypeMap.put("type1", "description1");
        cache.setAppointmentTypeList("practice1", apptTypeMap);

        Map<String, String> result = cache.getAppointmentTypeList("practice1");
        assertEquals(apptTypeMap, result);
    }

    @Test
    void getAppointmentTypeList_returnsNullForUnknownPracticeId() {
        assertNull(cache.getAppointmentTypeList("unknownPractice"));
    }

    @Test
    void getVisitReasonArray_returnsCorrectArray() {
        JSONArray visitReasonArray = new JSONArray();
        visitReasonArray.put("reason1");
        cache.setVisitReasonArrayMap("deployment1", visitReasonArray);

        JSONArray result = cache.getVisitReasonArray("deployment1");
        assertEquals(visitReasonArray, result);
    }

    @Test
    void getVisitReasonArray_returnsNullForUnknownDeploymentId() {
        assertNull(cache.getVisitReasonArray("unknownDeployment"));
    }

    @Test
    void getPacticeLocationMap_returnsCorrectArray() {
        JSONArray locationArray = new JSONArray();
        locationArray.put("location1");
        cache.setPacticeLocationMap("practice1", locationArray);

        JSONArray result = cache.getPacticeLocationMap("practice1");
        assertEquals(locationArray, result);
    }

    @Test
    void getPacticeLocationMap_returnsNullForUnknownPracticeId() {
        assertNull(cache.getPacticeLocationMap("unknownPractice"));
    }
}