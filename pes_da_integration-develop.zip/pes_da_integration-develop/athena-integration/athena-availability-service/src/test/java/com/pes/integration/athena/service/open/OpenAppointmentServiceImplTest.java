package com.pes.integration.athena.service.open;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.task.RealTimeOpenSlotsTask;
import com.pes.integration.athena.util.AthenaUtil;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.component.EventTracker;
import com.pes.integration.utils.DateUtils;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaConstants.DEPARTMENT_ID;
import static com.pes.integration.athena.constant.AthenaConstants.GENERIC_APPT_TYPE;
import static com.pes.integration.athena.constant.AthenaConstants.PRACTICE_ID;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.FILTER_DATA;
import static com.pes.integration.constant.EpmConstant.LOCATION_ID;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.IS_MINIBASELINE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpenAppointmentServiceImplTest {

    @Mock
    private EventTracker trackEvents;

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private RealTimeOpenSlotsTask realTimeOpenSlotsTask;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;
    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private OpenAppointmentServiceImpl openAppointmentServiceImpl;

    private AvailabilityRequest availabilityRequest;
    private JSONObject inputParam;
    private JSONObject outputObject;
    private JSONObject provLocObj;
    private RealTimeRequest realTimeRequest;
    private Map<String, JSONArray> providerLocationMap;
    private String startDate;
    private String endDate;
    private JSONArray locations;
    private String deploymentId;
    private String providerId;
    private String epmPrefix;
    private JSONObject appointmentTypeRequest;

    @BeforeEach
    void setUp() throws IHubException {
        startDate = "2023-01-01";
        endDate = "2023-01-10";
        locations = new JSONArray().put("location1");
        deploymentId = "deploymentId";
        providerId = "providerId";
        epmPrefix = "epmPrefix";

        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("messageControlId");
        availabilityRequest.setAppointmentType("appointmentType");
        availabilityRequest.setSliceId("sliceId");
        availabilityRequest.setDeploymentId("deploymentId");
        availabilityRequest.setTotalSlices("5");
        availabilityRequest.setFlow("flow");
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-10");
        availabilityRequest.setIndex("1");
        availabilityRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));

        providerLocationMap = new HashMap<>();
        providerLocationMap.put("locationIdList", new JSONArray().put("location1"));
        providerLocationMap.put("providerIdList", new JSONArray().put("provider1"));
        realTimeRequest = new RealTimeRequest();
        realTimeRequest.setDeploymentId("deploymentId");
        realTimeRequest.setMessageControlId("messageControlId");
        realTimeRequest.setStartDate("2023-01-01");
        realTimeRequest.setEndDate("2023-01-10");
        realTimeRequest.setEntityType("entityType");
        realTimeRequest.setFlow("flow");
        realTimeRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));


        provLocObj = new JSONObject();
        provLocObj.put("locationId", "location1");
        provLocObj.put("providerId", "provider1");
        provLocObj.put("reasonId", "reason1");

        inputParam = new JSONObject();
        inputParam.put("departmentid", new JSONArray().put("location1"));
        inputParam.put("providerId", "providerId");
        inputParam.put("deploymentId", "deployment123");
        inputParam.put("reasonMapExist", "true");
        inputParam.put("maxPoolSize", "10");
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-10");
        inputParam.put("practice_id", "practiceId");
        inputParam.put("ignoreSchedPermission", "ignoreSchedPermission");
        inputParam.put("limit", "10");
        inputParam.put("reason_id", "reasonId");
        inputParam.put("appt_resource_id", "resourceId");
        inputParam.put("appt_location_id", "locationId");

        ReflectionTestUtils.setField(openAppointmentServiceImpl, "trackEvents", trackEvents);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataCacheManager", dataCacheManager);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "iHubDataServiceDelegator", iHubDataServiceDelegator);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "fileUploader", fileUploader);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "datediff", 5);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "threadSize", 10);
    }

    @Test
    void testGetFragmentsDetails() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setTotalSlices("5");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        providerLocationMap.put("LOCATION_ID_LIST", new JSONArray().put("location1"));

        // Use reflection to invoke the private method
        Map<String, Object> result = (Map<String, Object>) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getFragmentsDetails", availabilityRequest, providerLocationMap);

        // Verify the result
        assertEquals("1", result.get(TOTAL_FRAGMENTS));
        assertEquals("5", result.get(TOTAL_SLICES));
    }

    @Test
    void testGetLocationIdStr() {
        JSONArray array = new JSONArray();
        array.put("location1");
        array.put("location2");
        array.put("location3");
        String result = OpenAppointmentServiceImpl.getLocationIdStr(array);
        assertEquals("location1,location2,location3", result);

        array = new JSONArray();
        array.put("location1");
        result = OpenAppointmentServiceImpl.getLocationIdStr(array);
        assertEquals("location1", result);

        array = new JSONArray();
        result = OpenAppointmentServiceImpl.getLocationIdStr(array);
        assertEquals("", result);
    }

    @Test
    void testGetRealTimeInputObject_Success() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getRealTimeInputObject", realTimeRequest, provLocObj);

        assertEquals("location1", result.getString(APPT_LOCATION_ID));
        assertEquals("provider1", result.getString(APPT_RESOURCE_ID));
        assertEquals("deploymentId", result.getString(DEPLOYMENT_ID));
        assertEquals("2023-01-01", result.getString(STARTDATE));
        assertEquals("2023-01-10", result.getString(ENDDATE));
        assertEquals("configValue", result.getString(ATHENA_PRACTICE_ID));
        assertEquals("configValue", result.getString(IGNORE_SHCED_PERMISSION));
        assertEquals("false", result.getString(IS_MINIBASELINE));
    }

    @Test
    void testGetRealTimeBaselineInputObject_Success() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        realTimeRequest.setFlow("MiniBaseline");
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getRealTimeInputObject", realTimeRequest, provLocObj);

        assertEquals("location1", result.getString(APPT_LOCATION_ID));
        assertEquals("provider1", result.getString(APPT_RESOURCE_ID));
        assertEquals("deploymentId", result.getString(DEPLOYMENT_ID));
        assertEquals("2023-01-01", result.getString(STARTDATE));
        assertEquals("2023-01-10", result.getString(ENDDATE));
        assertEquals("configValue", result.getString(ATHENA_PRACTICE_ID));
        assertEquals("configValue", result.getString(IGNORE_SHCED_PERMISSION));
        assertEquals("true", result.getString(IS_MINIBASELINE));
    }

    @Test
    void testGetInputObject() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("storedConfigValue");

        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getInputObject", startDate, endDate, locations, deploymentId, providerId, epmPrefix);

        assertEquals(startDate, result.getString(STARTDATE));
        assertEquals(endDate, result.getString(ENDDATE));
        assertEquals("appointment/", result.getString(APPOINTMENT_PATH));
        assertEquals("configValue", result.getString(ATHENA_PRACTICE_ID));
        assertEquals("configValue", result.getString(PRACTICE_ID));
        assertEquals(deploymentId, result.getString(DEPLOYMENT_ID));
        assertEquals("configValue", result.getString(LIMIT));
        assertEquals("configValue", result.getString(IGNORE_SHCED_PERMISSION));
        assertEquals(locations, result.getJSONArray(DEPARTMENT_ID));
        assertEquals(10, result.getInt(THREAD_SIZE)); // Assuming threadSize is set to 10
        assertEquals("configValue", result.getString(FILTER_CONFIG));
        assertEquals("configValue", result.getString(MAX_POOL_SIZE));
        assertEquals("configValue", result.getString(GENERIC_APPT_TYPE));
        assertEquals("configValue", result.getString(REASON_MAP_EXIST));
        assertEquals("configValue", result.getString(USE_LOCAL_PROVIDER));
        assertEquals("configValue", result.getString(FILTER_DATA));
        assertEquals("storedConfigValue", result.getString(LOCATION_PROVIDER_FILTER));
        assertEquals(providerId, result.getString(PROVIDER_ID));
    }

    @Test
    void testGetInputObject_WithDepartmentId() {
        JSONObject inputParam = new JSONObject();
        inputParam.put("departmentid", new JSONArray().put("location1"));
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-10");
        inputParam.put("practiceid", "practice_id");
        inputParam.put("reason_id", "reasonId");
        inputParam.put("ignore_schedulable_permission", "ignore_sched_permission");

        OpenAppointmentServiceImpl service = new OpenAppointmentServiceImpl();

        JSONObject result = service.getInputObject(inputParam);

        assertTrue(result.has("SchedulingData"));
        assertTrue(result.has("temp"));
        assertEquals("location1", result.getJSONObject("SchedulingData").getJSONArray("Provider").getJSONObject(0).getString(LOCATION_ID));
        assertEquals("2023-01-01", result.getJSONObject("temp").getString("start_date"));
        assertEquals("2023-01-10", result.getJSONObject("temp").getString("end_date"));
        assertEquals("practice_id", result.getJSONObject("temp").getString("practice_id"));
        assertEquals("reasonId", result.getJSONObject("temp").getString("reason_id"));
        assertEquals("ignore_sched_permission", result.getJSONObject("temp").getString("ignore_schedulable_permission"));
    }

    @Test
    void testGetOpenAppointment_InvalidIdException() throws Exception {
        when(athenaApiCaller.call(any(), any(), any())).thenThrow(new InvalidIdException("Invalid ID"));

        EpmApiCallerException exception = assertThrows(EpmApiCallerException.class, () -> {
            ReflectionTestUtils.invokeMethod(openAppointmentServiceImpl, "getOpenAppointment", athenaApiCaller, inputParam, availabilityRequest);
        });

        verify(athenaApiCaller, times(1)).call(any(), any(), any());
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGetAvailability_Success() throws JsonProcessingException, ParseException {
        // Mock the necessary methods
        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequest");
        doNothing().when(trackEvents).trackEvent(any(), any(), any(), any());

        // Use a spy to mock the fetchOpenAppointments method
        OpenAppointmentServiceImpl spyService = spy(openAppointmentServiceImpl);
        doReturn(new JSONArray()).when(spyService).fetchOpenAppointments(anyString(), anyString(), any(), any(), anyString());

        // Call the method and assert the result
        JSONArray result = spyService.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix");

        // Verify the interactions and assert the result
        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
        assertNotNull(result);
    }

    @Test
    void testGetAvailability_ParseException() throws ParseException {
        // Mock the necessary methods to throw ParseException
        try (MockedStatic<DateUtils> mockedStatic = mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString())).thenThrow(new ParseException("ParseException", 0));

            // Call the method and assert the exception
            assertThrows(RuntimeException.class, () -> openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix"));
        }
    }

    @Test
    void testFetchOpenAppointments_ParseException() {
        // Arrange
        String invalidDate = "invalid-date";
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataCacheManager", dataCacheManager);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            openAppointmentServiceImpl.fetchOpenAppointments(invalidDate, endDate, providerLocationMap, availabilityRequest, epmPrefix);
        });
    }

    @Test
    void getRealTimeAvailability_withValidRequest_returnsOpenAppointments() throws JsonProcessingException, IHubException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        JSONObject jsonObject = new JSONObject().put("locationId", "loc1").put("providerId", "prov1").put("reasonId", "reason1");
        realTimeRequest.setEntityId(List.of(jsonObject));
        realTimeRequest.setDeploymentId("deploymentId");
        realTimeRequest.setStartDate("2023-01-01");
        realTimeRequest.setEndDate("2023-01-10");

        JSONObject inputParam = new JSONObject();
        inputParam.put("locationId", "loc1");
        inputParam.put("providerId", "prov1");
        inputParam.put("reasonId", "reason1");
        inputParam.put("deploymentId", "deploymentId");
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-10");

        JSONArray expectedOpenAppointments = new JSONArray();
        expectedOpenAppointments.put(new JSONObject().put("appointmentId", "appt1"));

        when(athenaApiCaller.call(any(), any(), any())).thenReturn(new JSONObject());
        ObjectWriter objectWriter = Mockito.mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(any())).thenReturn(new JSONArray().put(jsonObject).toString());

        JSONObject result = openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest);

        assertNotNull(result);
    }

    @Test
    void fetchOpenAppointments_withValidInput_returnsOpenAppointments() throws IHubException {
        try (MockedStatic<AthenaUtil> aStatic = mockStatic(AthenaUtil.class)) {

            JSONObject inputObject = new JSONObject();
            inputObject.put(STARTDATE, startDate);
            inputObject.put(ENDDATE, endDate);
            inputObject.put(LOCATION_ID, "loc1");
            inputObject.put(PROVIDER_ID, "prov1");
            inputObject.put(VISIT_REASONS, "reason1");
            inputObject.put(DEPLOYMENT_ID, "deploymentId");
            inputObject.put(ATHENA_PRACTICE_ID, "practiceId");
            inputObject.put(IGNORE_SHCED_PERMISSION, "schedPermission");
            aStatic.when(() -> AthenaUtil.getVisitReasonArray(any(),any())).thenReturn(new JSONArray().put(inputObject));
            String startDate = "2023-01-01";
            String endDate = "2023-01-10";
            Map<String, JSONArray> providerLocationMap = new HashMap<>();
            providerLocationMap.put(LOCATION_ID_LIST, new JSONArray().put("loc1"));
            providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("prov1"));
            AvailabilityRequest availabilityRequest = new AvailabilityRequest();
            availabilityRequest.setDeploymentId("deploymentId");



            when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");
            when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("storedConfigValue");

            when(dataCacheManager.getConfiguration(anyString(), anyString(), eq(ATHENA_CONFIG),
                    eq(REASON_MAP_EXIST))).thenReturn("true");
            when(dataCacheManager.getConfiguration(anyString(), anyString(), eq(ATHENA_CONFIG),
                    eq(MAX_POOL_SIZE))).thenReturn("1");
            JSONArray result = openAppointmentServiceImpl.fetchOpenAppointments(startDate, endDate, providerLocationMap, availabilityRequest, "epmPrefix");

            assertNotNull(result);

        }
    }

}