package com.pes.integration.athena.task;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;
import java.util.Map;

import static com.pes.integration.athena.constant.AthenaConstants.REASON_ID;
import static com.pes.integration.constant.EpmConstant.OPEN_APPOINTMENTS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RealTimeOpenSlotsTaskTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;
    @Mock
    private JSONObject requestConfig;

    @Mock
    private JSONObject requestMapping;

    @Mock
    private JSONObject responseMapping;

    @InjectMocks
    private RealTimeOpenSlotsTask realTimeOpenSlotsTask;
    private JSONObject inputParam;
    private String engineName;
    private String appDescription;

    @BeforeEach
    void setUp() {
        JSONObject inputObject = new JSONObject();
        inputObject.put("startDate", "2023-10-01");
        inputObject.put("endDate", "2023-10-02");
        inputObject.put("providerId", "provider1");
        inputObject.put("practiceid", "practice_id");
        inputObject.put("limit", "10");
        inputObject.put("departmentid", new JSONArray().put("location1"));
        inputObject.put("ignore_schedulable_permission", "ignoreSchedPermission");
        inputObject.put("reason_id", "-1");
        inputObject.put("SchedulingData.Provider[0].ResourceId", "86");
        inputObject.put("SchedulingData.Provider[0].LocationId", "150");
        inputParam = inputObject;
        engineName="athena";
        appDescription="Athena Availability Integration";

        realTimeOpenSlotsTask = new RealTimeOpenSlotsTask(athenaApiCaller, inputObject,engineName,appDescription);
        ReflectionTestUtils.setField(realTimeOpenSlotsTask, "contextMap", Map.of());
        ReflectionTestUtils.setField(realTimeOpenSlotsTask, "engineName", "testEngineName");
        ReflectionTestUtils.setField(realTimeOpenSlotsTask, "appDescription", "appDescription");
    }

    @Test
    void testGet_Success() throws Exception {
        // Mock the response from athenaApiCaller
        JSONObject responseObject = new JSONObject();
        responseObject.put("OPEN_APPOINTMENTS", new JSONArray().put(new JSONObject().put("slot", "slot1")));
        when(athenaApiCaller.call(any(), any(), any())).thenReturn(responseObject);

        // Call the method
        JSONArray result = realTimeOpenSlotsTask.get();

        // Assertions
        assertNotNull(result);
        verify(athenaApiCaller, times(1)).call(any(), any(), any());
    }

    @Test
    void testGet_InvalidIdException() throws Exception {
        // Mock the response to throw InvalidIdException
        when(athenaApiCaller.call(any(), any(), any())).thenThrow(new InvalidIdException("Invalid ID"));

        // Call the method and assert exception
        EpmApiCallerException exception = assertThrows(EpmApiCallerException.class, () -> {
            realTimeOpenSlotsTask.get();
        });

        // Verify the log message
        verify(athenaApiCaller, times(1)).call(any(), any(), any());
        assertNotNull(exception.getMessage());
    }

    @Test
    void testGet_EpmApiCallerException() throws Exception {
        // Mock the response to throw EpmApiCallerException
        when(athenaApiCaller.call(any(), any(), any())).thenThrow(new EpmApiCallerException("API Caller Exception"));

        // Call the method and assert exception
        EpmApiCallerException exception = assertThrows(EpmApiCallerException.class, () -> {
            realTimeOpenSlotsTask.get();
        });

        // Verify the log message
        verify(athenaApiCaller, times(1)).call(any(), any(), any());
        assertNotNull(exception.getMessage());
    }

//    @Test
//    void testExtractSlots() {
//        JSONObject outputObject = new JSONObject();
//        JSONArray appointmentsArray = new JSONArray();
//        JSONObject appointment = new JSONObject();
//        appointment.put("Duration", 30);
//        appointment.put("SlotId", "slot1");
//        appointment.put("ProviderId", "provider1");
//        appointment.put("temp", new JSONObject().put("start_time", "10:00").put("start_date", "10/01/2023"));
//        appointmentsArray.put(appointment);
//        outputObject.put(OPEN_APPOINTMENTS, appointmentsArray);
//
//        JSONArray result = RealTimeOpenSlotsTask.extractSlots(outputObject);
//
//        assertNotNull(result);
//        assertEquals(1, result.length());
//        assertEquals("slot1", result.getJSONObject(0).getString("slotId"));
//    }

    @Test
    void testExtractSlots_NullAppointments() {
        JSONObject outputObject = new JSONObject();
        JSONObject inputParam = new JSONObject();
        inputParam.put(REASON_ID, "1");
        outputObject.put(OPEN_APPOINTMENTS, (JSONArray) null);

        JSONArray result = RealTimeOpenSlotsTask.extractSlots(outputObject,inputParam);

        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void testExtractSlots_ParseException() {
        JSONObject outputObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointment = new JSONObject();
        JSONObject inputParam = new JSONObject();
        inputParam.put(REASON_ID, "1");
        appointment.put("Duration", 30);
        appointment.put("SlotId", "slot1");
        appointment.put("ProviderId", "provider1");
        appointment.put("temp", new JSONObject().put("start_time", "10:00").put("start_date", "invalid_date"));
        appointmentsArray.put(appointment);
        outputObject.put(OPEN_APPOINTMENTS, appointmentsArray);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            RealTimeOpenSlotsTask.extractSlots(outputObject,inputParam);
        });

        assertNotNull(exception.getCause());
        assertEquals(ParseException.class, exception.getCause().getClass());
    }

//    @Test
//    void testTransformOpenAppointment() throws ParseException {
//        // Prepare the input appointment object
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put("Duration", 30);
//        appointmentObject.put("SlotId", "slot1");
//        appointmentObject.put("ProviderId", "provider1");
//        appointmentObject.put("temp", new JSONObject().put("start_time", "10:00").put("start_date", "10/01/2023"));
//
//        // Call the method to test
//        JSONObject result = RealTimeOpenSlotsTask.transformOpenAppointment(appointmentObject);
//
//        // Verify the result
//        assertNotNull(result);
//        assertEquals(30, result.getInt("duration"));
//        assertEquals("slot1", result.getString("slotId"));
//        assertEquals("provider1", result.getString("providerId"));
//        assertEquals("1000", result.getString("startTime"));
//        assertEquals("2023-10-01T00:00:00", result.getString("date"));
//    }

    @Test
    void testTransformOpenAppointment_ParseException() {
        // Prepare the input appointment object with invalid date
        JSONObject appointmentObject = new JSONObject();
        JSONObject inputParam = new JSONObject();
        inputParam.put(REASON_ID, "1");
        appointmentObject.put("Duration", 30);
        appointmentObject.put("SlotId", "slot1");
        appointmentObject.put("ProviderId", "provider1");
        appointmentObject.put("temp", new JSONObject().put("start_time", "10:00").put("start_date", "invalid_date"));

        // Call the method to test and assert exception
        assertThrows(ParseException.class, () -> {
            RealTimeOpenSlotsTask.transformOpenAppointment(appointmentObject,inputParam);
        });
    }
}