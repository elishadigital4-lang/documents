package com.pes.integration.athena.util;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.constant.EpmConstant;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Method;

import static com.pes.integration.athena.api.ApiName.*;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.USE_LOCAL_PROVIDER;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.Key.SLOT_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.LIMIT;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.DATE_TIME_FORMAT;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.UtilitiesConstants.LOCATION_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AthenaUtilTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSetApptReasonIdsFromApptArray_UsingReflection() throws Exception {
        // Arrange
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("ApptReasonId", new JSONArray().put("111").put("222").put("333"));
        appointmentsArray.put(appointmentObject);

        // Use reflection to access the private method
        Method method = AthenaUtil.class.getDeclaredMethod("setApptReasonIdsFromApptArray", JSONArray.class, int.class);
        method.setAccessible(true);

        // Act
        method.invoke(null, appointmentsArray, 0);

        // Assert
        JSONObject updatedAppointmentObject = appointmentsArray.getJSONObject(0);
        assertEquals("111^222^333", updatedAppointmentObject.getString("ApptReasonId"));
    }

    @Test
    void testApplyFilter() {
        // Arrange
        JSONArray appointmentsArray = new JSONArray();
        JSONObject inputObject = new JSONObject();

        // Case 1: Empty appointmentsArray
        JSONArray result = AthenaUtil.applyFilter(appointmentsArray, inputObject);
        assertNotNull(result);
        assertEquals(0, result.length());

        // Case 2: Non-empty appointmentsArray with null filterData
        appointmentsArray.put(new JSONObject().put("LocationId", "123").put("ProviderId", "456"));
        appointmentsArray.put(new JSONObject().put("LocationId", "789").put("ProviderId", "012"));
        inputObject.put("filterData", JSONObject.NULL);

        try (MockedStatic<EPMFilter> mockedFilter = Mockito.mockStatic(EPMFilter.class)) {
            mockedFilter.when(EPMFilter::getInstance).thenReturn(mock(EPMFilter.class));
            when(EPMFilter.getInstance().isAllowed("123", "456", inputObject)).thenReturn(true);
            when(EPMFilter.getInstance().isAllowed("789", "012", inputObject)).thenReturn(false);

            result = AthenaUtil.applyFilter(appointmentsArray, inputObject);

            // Assert
            assertNotNull(result);
            assertEquals(1, result.length());
            assertEquals("123", result.getJSONObject(0).getString("LocationId"));
            assertEquals("456", result.getJSONObject(0).getString("ProviderId"));
        }

        // Case 3: Non-empty appointmentsArray with non-null filterData
        inputObject.put("filterData", new JSONObject());
        result = AthenaUtil.applyFilter(appointmentsArray, inputObject);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.length());
    }

    @Test
    void getVisitReasonArray_withValidDeploymentId_returnsVisitReasonArray() throws IHubException {
        JSONObject inputParam = new JSONObject();
        inputParam.put("deploymentId", "validDeploymentId");

        JSONArray expectedVisitReasonArray = new JSONArray();
        expectedVisitReasonArray.put("reason1");

        AthenaConfigCache.getInstance().setVisitReasonArrayMap("validDeploymentId", expectedVisitReasonArray);

        JSONArray result = AthenaUtil.getVisitReasonArray(athenaApiCaller, inputParam);

        assertEquals(expectedVisitReasonArray, result);
    }

    @Test
    void getVisitReasonArray_withUnknownDeploymentId_callsApiAndReturnsVisitReasonArray() throws IHubException {
        JSONObject inputParam = new JSONObject();
        inputParam.put("deploymentId", "unknownDeploymentId");
        inputParam.put("departmentid", new JSONArray().put("1234"));
        inputParam.put(STARTDATE, "2021-09-01");
        inputParam.put(ENDDATE, "2021-09-02");
        inputParam.put(ATHENA_PRACTICE_ID, "1234");
        inputParam.put(AthenaConstants.REASON_ID, "22");
        inputParam.put(IGNORE_SHCED_PERMISSION, "33");
        JSONArray provider = new JSONArray();
        provider.put(new JSONObject().put("ResourceId", "444").put("LocationId", "555"));
        inputParam.put("SchedulingData", new JSONObject().put("Provider", provider));
        inputParam.put(APPT_RESOURCE_ID, "444");
        inputParam.put(APPT_LOCATION_ID, "555");
        inputParam.put(LIMIT, "3");
        JSONArray filter = new JSONArray();
        filter.put(new JSONObject().put(PROVIDER_ID, "444").put(LOCATION_ID, "555"));
        inputParam.put(LOCATION_PROVIDER_FILTER, new JSONObject().put(LOCATION_PROVIDER_FILTER, filter));
        JSONArray locProvfilterArray = new JSONArray();
        inputParam.put("locationProviderFilter", locProvfilterArray);

        JSONArray expectedVisitReasonArray = new JSONArray();
        expectedVisitReasonArray.put(new JSONObject().put("Id", "reason1"));

        when(athenaApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(new JSONObject().put(VISIT_REASONS, expectedVisitReasonArray));

        JSONArray result = AthenaUtil.getVisitReasonArray(athenaApiCaller, inputParam);

        assertNotNull(result);
        System.out.println(result);
        Assertions.assertEquals("reason1", result.getJSONObject(0).getString("VisitReasons"));
        Assertions.assertEquals("444", result.getJSONObject(0).getString("ProviderId"));
        Assertions.assertEquals("555", result.getJSONObject(0).getString("LocationId"));
    }

    @Test
    void getVisitReasonArray_withEmptyVisitReasonArray_callsApiAndReturnsVisitReasonArray() throws IHubException {
        JSONObject inputParam = new JSONObject();
        inputParam.put("deploymentId", "callsApiAndReturnsVisitReasonArray");
        inputParam.put("departmentid", new JSONArray().put("1234"));
        inputParam.put(STARTDATE, "2021-09-01");
        inputParam.put(ENDDATE, "2021-09-02");
        inputParam.put(ATHENA_PRACTICE_ID, "1234");
        inputParam.put(AthenaConstants.REASON_ID, "22");
        inputParam.put(IGNORE_SHCED_PERMISSION, "33");
        JSONArray provider = new JSONArray();
        provider.put(new JSONObject().put("ResourceId", "444").put("LocationId", "555"));
        inputParam.put("SchedulingData", new JSONObject().put("Provider", provider));
        inputParam.put(APPT_RESOURCE_ID, "444");
        inputParam.put(APPT_LOCATION_ID, "555");
        inputParam.put(LIMIT, "3");
        JSONArray filter = new JSONArray();
        inputParam.put(LOCATION_PROVIDER_FILTER, new JSONObject().put(LOCATION_PROVIDER_FILTER, filter));

        JSONObject locationsObj = new JSONObject().put("Locations", new JSONArray().put(new JSONObject()
                .put("LocationId", "555").put("ProviderIdList", new JSONArray().put("444"))));

        when(athenaApiCaller.call(eq(GET_LOCATIONS.getKey()), any(), eq(""))).thenReturn(locationsObj);

        JSONArray expectedVisitReasonArray = new JSONArray();
        expectedVisitReasonArray.put(new JSONObject().put("Id", "reason1"));

        when(athenaApiCaller.call(eq(GET_PATIENT_VISIT_REASONS.getKey()), any(JSONObject.class), anyString())).thenReturn(new JSONObject().put(VISIT_REASONS, expectedVisitReasonArray));

        JSONArray result = AthenaUtil.getVisitReasonArray(athenaApiCaller, inputParam);

        assertNotNull(result);
        System.out.println(result);
        Assertions.assertEquals("reason1", result.getJSONObject(0).getString("VisitReasons"));
        Assertions.assertEquals("444", result.getJSONObject(0).getString("ProviderId"));
        Assertions.assertEquals("555", result.getJSONObject(0).getString("LocationId"));
    }

//    @Test
//    void transformOpenAppointment_withValidInput_returnsTransformedAppointment() throws Exception {
//        JSONObject appointmentObject = new JSONObject();
//        appointmentObject.put(SLOT_ID, "12345");
//        appointmentObject.put(DURATION_IN_MINUTES, 30);
//        appointmentObject.put("Duration", 30);
//        appointmentObject.put(LOCATION_ID, "67890");
//        appointmentObject.put(PROVIDER_ID, "11111");
//        appointmentObject.put(LOCAL_PROVIDER_ID, "22222");
//        appointmentObject.put(APPTREASON_ID, "33333");
//        JSONObject temp = new JSONObject();
//        temp.put("start_time", "10:00");
//        temp.put("start_date", "08/20/2024");
//        appointmentObject.put("temp", temp);
//
//        JSONObject result = AthenaUtil.transformOpenAppointment(appointmentObject, false);
//
//        assertEquals("12345", result.getString(SLOT_ID_KEY));
//        assertEquals(30, result.getInt(DURATION));
//        assertEquals("minutes", result.getString(DURATION_UNIT_KEY));
//        assertEquals("67890", result.getString(LOCATION_ID_KEY));
//        assertEquals("11111", result.getString(PROVIDER_ID_KEY));
//        assertEquals("22222", result.getString(LOCAL_PROVIDER_ID));
//        assertEquals("33333", result.getString(REASON_ID_KEY));
//        assertEquals("1000", result.getString(START_TIME));
//        assertEquals("2024-08-20T00:00:00", result.getString(DATE_KEY));
//    }


    @Test
    void testSetApptReasonIdsFromApptArray() throws IHubException {

        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), eq("HH:mm"), eq(DOCASAP_TIME_FORMAT))).thenReturn("1000");
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), eq("MM/dd/yyyy"), eq(DATE_TIME_FORMAT))).thenReturn("2024-08-20T00:00:00");
            JSONObject inputParam = new JSONObject();
            inputParam.put(USE_LOCAL_PROVIDER, true);
            inputParam.put(GENERIC_APPT_TYPE, "33333:33333,33333");
            inputParam.put("practiceid", "1234");

            JSONObject appointmentObject = new JSONObject();
            appointmentObject.put(SLOT_ID, "12345");
            appointmentObject.put(DURATION_IN_MINUTES, 30);
            appointmentObject.put("Duration", 30);
            appointmentObject.put(LOCATION_ID, "67890");
            appointmentObject.put(PROVIDER_ID, "11111");
            appointmentObject.put(LOCAL_PROVIDER_ID, "22222");
            appointmentObject.put(APPTREASON_ID, "33333");
            JSONObject temp = new JSONObject();
            temp.put("start_time", "10:00");
            temp.put("start_date", "08/20/2024");
            appointmentObject.put("temp", temp);

            JSONObject outputObject = new JSONObject();
            outputObject.put(EpmConstant.OPEN_APPOINTMENTS, new JSONArray().put(appointmentObject));
            when(athenaApiCaller.call(eq(GET_APPOINTMENT_TYPES.getKey()), any(), eq(""))).thenReturn(new JSONObject().put("AppointmentTypes", new JSONArray().put(new JSONObject().put("AppointmentTypeId", "1").put("Duration", "minutes"))));
            JSONArray resultArray = AthenaUtil.extractOpenSlotsFromResponse(outputObject, false, athenaApiCaller, inputParam);
            System.out.println(resultArray);

            assertNotNull(resultArray);
            JSONObject result = resultArray.getJSONObject(0);


            assertEquals("12345", result.getString(SLOT_ID_KEY));
            assertEquals(30, result.getInt("duration"));
            assertEquals("minutes", result.getString(DURATION_UNIT_KEY));
            assertEquals("67890", result.getString(LOCATION_ID_KEY));
            assertEquals("22222", result.getString(PROVIDER_ID_KEY));
            assertEquals("22222", result.getString(LOCAL_PROVIDER_ID));
            assertEquals("1000", result.getString(START_TIME));
            assertEquals("2024-08-20T00:00:00", result.getString(DATE_KEY));
        }
    }

    @Test
    void testGetInputObject_Success_RealTime() {
        // Arrange
        JSONObject inputParam = new JSONObject();
        inputParam.put("departmentid", new JSONArray().put("1234"));
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-10");
        inputParam.put("practiceid", "5678");
        inputParam.put("reason_id", "22");
        inputParam.put("ignore_schedulable_permission", "33");
        inputParam.put("ResourceId", "444");
        inputParam.put("appt_location_id", "555");
        inputParam.put("temp.limit", "3");
        inputParam.put("isMinibaseline", false);

        // Act
        JSONObject result = AthenaUtil.getInputObject(inputParam, true);

        // Assert
        assertNotNull(result);
        assertTrue(result.has("SchedulingData"));
        assertTrue(result.has("temp"));

        JSONObject schedulingData = result.getJSONObject("SchedulingData");
        assertTrue(schedulingData.has("Provider"));
        JSONArray providerArray = schedulingData.getJSONArray("Provider");
        assertEquals(1, providerArray.length());
        JSONObject providerObj = providerArray.getJSONObject(0);
        assertEquals("1234", providerObj.getString("LocationId"));


        JSONObject temp = result.getJSONObject("temp");
        assertEquals("2023-01-01", temp.getString("start_date"));
        assertEquals("2023-01-10", temp.getString("end_date"));
        assertEquals("5678", temp.getString("practice_id"));
        assertEquals("22", temp.getString("appointmenttypeid"));
        assertEquals("33", temp.getString("ignore_schedulable_permission"));
        assertEquals("3", temp.getString("temp.limit"));
    }


    @Test
    void testGetInputObject_Success_NonRealTime() {
        // Arrange
        JSONObject inputParam = new JSONObject();
        inputParam.put("departmentid", new JSONArray().put("1234"));
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-10");
        inputParam.put("practiceid", "5678");
        inputParam.put("reason_id", "-1");
        inputParam.put("ignore_schedulable_permission", "33");
        inputParam.put("ResourceId", "444");
        inputParam.put("appt_location_id", "555");
        inputParam.put("temp.limit", "3");
        inputParam.put("is_minibaseline", true);

        // Act
        JSONObject result = AthenaUtil.getInputObject(inputParam, false);

        // Assert
        assertNotNull(result);
        assertTrue(result.has("SchedulingData"));
        assertTrue(result.has("temp"));

        JSONObject schedulingData = result.getJSONObject("SchedulingData");
        assertTrue(schedulingData.has("Provider"));
        JSONArray providerArray = schedulingData.getJSONArray("Provider");
        assertEquals(1, providerArray.length());
        JSONObject providerObj = providerArray.getJSONObject(0);
        assertEquals("1234", providerObj.getString("LocationId"));

        JSONObject temp = result.getJSONObject("temp");
        assertEquals("2023-01-01", temp.getString("start_date"));
        assertEquals("2023-01-10", temp.getString("end_date"));
        assertEquals("5678", temp.getString("practice_id"));
        assertEquals("-1", temp.getString("reason_id"));
        assertEquals("33", temp.getString("ignore_schedulable_permission"));
        assertEquals("3", temp.getString("temp.limit"));
    }
}