package com.pes.integration.athena.task;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;
import java.util.Map;

import static com.pes.integration.athena.api.ApiName.GET_PROVIDERS;
import static com.pes.integration.athena.constant.AthenaConstants.DEPLOYMENTID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_TYPES;
import static com.pes.integration.constant.DocASAPConstants.Key.PROVIDERS;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.RESOURCES;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrepareOpenSlotsTaskTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    private PrepareOpenSlotsTask prepareOpenSlotsTask;
    private JSONObject inputParam;
    private AvailabilityRequest availabilityRequest;

    @BeforeEach
    void setUp() {
        JSONObject openAppointmentRequest = new JSONObject();
        inputParam = new JSONObject();
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-31");
        inputParam.put("deploymentId", "deployment123");
        inputParam.put("ATHENA_PRACTICE_ID", "practice123");

        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setIndex("someIndex");
        availabilityRequest.setDeploymentId("deployment123");
        availabilityRequest.setMessageControlId("messageControl123");
        availabilityRequest.setAppointmentType("appointmentType123");
        availabilityRequest.setSliceId("sliceId123");

        prepareOpenSlotsTask = new PrepareOpenSlotsTask(athenaApiCaller, iHubDataServiceDelegator, openAppointmentRequest, fileUploader,
                trackEvents, true, inputParam, availabilityRequest, "provider123");
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "contextMap", Map.of());
    }

    @Test
    void testGet_Success() throws Exception {
        // Mock responses for each call to athenaApiCaller.call
        JSONObject openAppointmentsResponse = new JSONObject();
        openAppointmentsResponse.put(OPEN_APPOINTMENTS, new JSONArray());

        JSONObject appointmentTypesResponse = new JSONObject();
        appointmentTypesResponse.put(APPOINTMENT_TYPES, new JSONArray());

        JSONObject providersResponse = new JSONObject();
        providersResponse.put("PROVIDERS", new JSONArray());

        // Mock the call method to return the appropriate response for each call
        when(athenaApiCaller.call(eq(ApiName.OPEN_APPOINTMENTS.getKey()), any(), any())).thenReturn(openAppointmentsResponse);
        when(athenaApiCaller.call(eq(ApiName.GET_APPOINTMENT_TYPES.getKey()), any(), any())).thenReturn(appointmentTypesResponse);
        when(athenaApiCaller.call(eq(ApiName.GET_PROVIDERS.getKey()), any(), any())).thenReturn(providersResponse);

        // Call the get method and verify the result
        prepareOpenSlotsTask.get();

        // Verify interactions with mocks
        verify(athenaApiCaller, times(1)).call(eq(ApiName.OPEN_APPOINTMENTS.getKey()), any(), any());
        verify(athenaApiCaller, times(1)).call(eq(ApiName.GET_APPOINTMENT_TYPES.getKey()), any(), any());
        verify(athenaApiCaller, times(1)).call(eq(ApiName.GET_PROVIDERS.getKey()), any(), any());
        verify(fileUploader, times(1)).uploadFile(any(), any(), any(), any());
    }

    @Test
    void testGet_WithEpmApiCallerException() throws Exception {
        // Mock the athenaApiCaller.call method to throw EpmApiCallerException
        when(athenaApiCaller.call(any(), any(), any())).thenThrow(new EpmApiCallerException("API Caller Exception"));

        // Call the get method and verify that the exception is thrown
        prepareOpenSlotsTask.get();

        // Verify interactions with mocks
        verify(athenaApiCaller, times(1)).call(any(), any(), any());
        verify(fileUploader, never()).uploadFile(any(), any(), any(), any());
    }


    @Test
    void testAddGenericAppointmentTypesToDB() throws Exception {
        JSONObject mockResponse = new JSONObject();
        mockResponse.put(APPOINTMENT_TYPES, new JSONArray());
        when(athenaApiCaller.call(any(), any(), any())).thenReturn(mockResponse);

        JSONArray result = prepareOpenSlotsTask.addGenericAppointmentTypesToDB();

        assertNotNull(result);
        verify(athenaApiCaller, times(1)).call(any(), any(), any());
    }

    @Test
    void testGetOpenAppointmentObject() throws Exception {
        // Mock input data
        JSONArray openAppointmentsArray = new JSONArray();
        openAppointmentsArray.put(new JSONObject().put("appointment", "details"));

        JSONArray apptTypes = new JSONArray();
        apptTypes.put(new JSONObject().put("type", "general"));

        JSONArray resources = new JSONArray();
        resources.put(new JSONObject().put("provider", "details"));

        // Expected values
        String expectedDeploymentId = "deployment123";
        String expectedMessageControlId = "messageControl123";

        // Mock the availabilityRequest methods
        AvailabilityRequest mockAvailabilityRequest = mock(AvailabilityRequest.class);
        when(mockAvailabilityRequest.getDeploymentId()).thenReturn(expectedDeploymentId);
        when(mockAvailabilityRequest.getMessageControlId()).thenReturn(expectedMessageControlId);

        // Set the mock object in the prepareOpenSlotsTask instance
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "availabilityRequest", mockAvailabilityRequest);

        // Access the private method using reflection
        Method method = PrepareOpenSlotsTask.class.getDeclaredMethod("getOpenAppointmentObject", JSONArray.class, JSONArray.class, JSONArray.class);
        method.setAccessible(true);

        // Invoke the method
        JSONObject result = (JSONObject) method.invoke(prepareOpenSlotsTask, openAppointmentsArray, apptTypes, resources);

        // Verify the result
        assertNotNull(result);
        assertEquals(expectedDeploymentId, result.getString(DEPLOYMENTID));
        assertEquals(expectedMessageControlId, result.getString(MESSAGE_CONTROL_ID));
        assertEquals(openAppointmentsArray.length(), result.getInt(TOTAL_COUNT));
        assertEquals(openAppointmentsArray, result.getJSONArray(DATA));
        assertEquals(apptTypes, result.getJSONArray(APPOINTMENT_TYPES));
        assertEquals(resources, result.getJSONArray(RESOURCES));
    }
    @Test
    void testGetOpenAppointment_Success() throws Exception {
        // Mock responses for each call to athenaApiCaller.call
        JSONObject openAppointmentsResponse = new JSONObject();
        openAppointmentsResponse.put(OPEN_APPOINTMENTS, new JSONArray());

        JSONObject appointmentTypesResponse = new JSONObject();
        appointmentTypesResponse.put(APPOINTMENT_TYPES, new JSONArray());

        JSONObject providersResponse = new JSONObject();
        providersResponse.put("PROVIDERS", new JSONArray());

        // Mock the call method to return the appropriate response for each call
        when(athenaApiCaller.call(eq(ApiName.OPEN_APPOINTMENTS.getKey()), any(), any())).thenReturn(openAppointmentsResponse);
        when(athenaApiCaller.call(eq(ApiName.GET_APPOINTMENT_TYPES.getKey()), any(), any())).thenReturn(appointmentTypesResponse);
        when(athenaApiCaller.call(eq(ApiName.GET_PROVIDERS.getKey()), any(), any())).thenReturn(providersResponse);

        // Call the getOpenAppointment method and verify the result
        JSONObject result = prepareOpenSlotsTask.getOpenAppointment();

        // Verify the result
        assertNotNull(result);
        assertEquals("deployment123", result.getString(DEPLOYMENTID));
        assertEquals("messageControl123", result.getString(MESSAGE_CONTROL_ID));
        assertEquals(0, result.getInt(TOTAL_COUNT));
        assertNotNull(result.getJSONArray(DATA));
        assertNotNull(result.getJSONArray(APPOINTMENT_TYPES));
//        assertNotNull(result.getJSONArray(RESOURCES));

        // Verify interactions with mocks
        verify(athenaApiCaller, times(1)).call(eq(ApiName.OPEN_APPOINTMENTS.getKey()), any(), any());
        verify(athenaApiCaller, times(1)).call(eq(ApiName.GET_APPOINTMENT_TYPES.getKey()), any(), any());
        verify(athenaApiCaller, times(1)).call(eq(ApiName.GET_PROVIDERS.getKey()), any(), any());
    }

    @Test
    void testGetProviders_Success() throws Exception {
        // Mock response for athenaApiCaller.call
        JSONObject providersResponse = new JSONObject();
        providersResponse.put(PROVIDERS, new JSONArray());

        // Mock the call method to return the appropriate response
        when(athenaApiCaller.call(eq(GET_PROVIDERS.getKey()), any(), any())).thenReturn(providersResponse);

        // Call the getProviders method and verify the result
        JSONArray result = prepareOpenSlotsTask.getProviders();

        // Verify the result
        assertNotNull(result);
        assertEquals(0, result.length());

        // Verify interactions with mocks
        verify(athenaApiCaller, times(1)).call(eq(GET_PROVIDERS.getKey()), any(), any());
    }

}