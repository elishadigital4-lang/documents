package com.pes.integration.athena.util;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static org.junit.jupiter.api.Assertions.*;

class EPMFilterTest {

    private EPMFilter epmFilter;

    @BeforeEach
    void setUp() {
        epmFilter = EPMFilter.getInstance();
    }

    @Test
    void isAllowed_withValidLocationAndProvider_returnsTrue() {
        JSONObject inputObject = new JSONObject();
        JSONObject filterConfig = new JSONObject();
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject locProvFilter = new JSONObject();
        locProvFilter.put(LOCATION_ID, "loc1");
        locProvFilter.put(PROVIDER_ID, "prov1");
        locProvFilterArray.put(locProvFilter);
        filterConfig.put(LOCATION_PROVIDER_FILTER, locProvFilterArray);
        inputObject.put(FILTER_CONFIG, filterConfig);

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void isAllowed_withInvalidLocationAndProvider_returnsFalse() {
        JSONObject inputObject = new JSONObject();
        JSONObject filterConfig = new JSONObject();
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject locProvFilter = new JSONObject();
        locProvFilter.put(LOCATION_ID, "loc1");
        locProvFilter.put(PROVIDER_ID, "prov1");
        locProvFilterArray.put(locProvFilter);
        filterConfig.put(LOCATION_PROVIDER_FILTER, locProvFilterArray);
        inputObject.put(FILTER_CONFIG, filterConfig);

        assertTrue(epmFilter.isAllowed("loc2", "prov2", inputObject));
    }

    @Test
    void isAllowed_withEmptyFilterConfig_returnsTrue() {
        JSONObject inputObject = new JSONObject();

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void isAllowed_withNullFilterConfig_returnsTrue() {
        JSONObject inputObject = new JSONObject();
        inputObject.put(FILTER_CONFIG, JSONObject.NULL);

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void isAllowed_withOnlyProviderFilter_returnsTrueForValidProvider() {
        JSONObject inputObject = new JSONObject();
        JSONObject filterConfig = new JSONObject();
        JSONArray provFilterArray = new JSONArray();
        JSONObject provFilter = new JSONObject();
        provFilter.put(PROVIDER_ID, "prov1");
        provFilterArray.put(provFilter);
        filterConfig.put(PROVIDER_FILTER, provFilterArray);
        inputObject.put(FILTER_CONFIG, filterConfig);

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void isAllowed_withOnlyLocationFilter_returnsTrueForValidLocation() {
        JSONObject inputObject = new JSONObject();
        JSONObject filterConfig = new JSONObject();
        JSONArray locFilterArray = new JSONArray();
        JSONObject locFilter = new JSONObject();
        locFilter.put(LOCATION_ID, "loc1");
        locFilterArray.put(locFilter);
        filterConfig.put(LOCATION_FILTER, locFilterArray);
        inputObject.put(FILTER_CONFIG, filterConfig);

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void isAllowed_withEmptyLocationProviderFilter_returnsTrue() {
        JSONObject inputObject = new JSONObject();
        JSONObject filterConfig = new JSONObject();
        JSONArray locProvFilterArray = new JSONArray();
        filterConfig.put(LOCATION_PROVIDER_FILTER, locProvFilterArray);
        inputObject.put(FILTER_CONFIG, filterConfig);

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void isAllowed_withEmptyProviderFilter_returnsTrue() {
        JSONObject inputObject = new JSONObject();
        JSONObject filterConfig = new JSONObject();
        JSONArray provFilterArray = new JSONArray();
        filterConfig.put(PROVIDER_FILTER, provFilterArray);
        inputObject.put(FILTER_CONFIG, filterConfig);

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void isAllowed_withEmptyLocationFilter_returnsTrue() {
        JSONObject inputObject = new JSONObject();
        JSONObject filterConfig = new JSONObject();
        JSONArray locFilterArray = new JSONArray();
        filterConfig.put(LOCATION_FILTER, locFilterArray);
        inputObject.put(FILTER_CONFIG, filterConfig);

        assertTrue(epmFilter.isAllowed("loc1", "prov1", inputObject));
    }

    @Test
    void testGetAllowedLocations_withValidLocation_returnsTrue() throws Exception {
        // Arrange
        JSONArray locFilterArray = new JSONArray();
        JSONObject locFilter = new JSONObject();
        locFilter.put(LOCATION_ID, "loc1");
        locFilterArray.put(locFilter);

        String locationId = "loc1";

        // Use reflection to access the private method
        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocations", JSONArray.class, String.class);
        method.setAccessible(true);

        // Act
        boolean result = (boolean) method.invoke(EPMFilter.getInstance(), locFilterArray, locationId);

        // Assert
        assertTrue(result);
    }

    @Test
    void testGetAllowedLocations_withInvalidLocation_returnsFalse() throws Exception {
        // Arrange
        JSONArray locFilterArray = new JSONArray();
        JSONObject locFilter = new JSONObject();
        locFilter.put(LOCATION_ID, "loc1");
        locFilterArray.put(locFilter);

        String locationId = "loc2";

        // Use reflection to access the private method
        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocations", JSONArray.class, String.class);
        method.setAccessible(true);

        // Act
        boolean result = (boolean) method.invoke(EPMFilter.getInstance(), locFilterArray, locationId);

        // Assert
        assertFalse(result);
    }

    @Test
    void testGetAllowedProviders_withValidProvider_returnsTrue() throws Exception {
        // Arrange
        JSONArray provFilterArray = new JSONArray();
        JSONObject provFilter = new JSONObject();
        provFilter.put(PROVIDER_ID, "prov1");
        provFilterArray.put(provFilter);

        String providerId = "prov1";

        // Use reflection to access the private method
        Method method = EPMFilter.class.getDeclaredMethod("getAllowedProviders", JSONArray.class, String.class);
        method.setAccessible(true);

        // Act
        boolean result = (boolean) method.invoke(EPMFilter.getInstance(), provFilterArray, providerId);

        // Assert
        assertTrue(result);
    }

    @Test
    void testGetAllowedProviders_withInvalidProvider_returnsFalse() throws Exception {
        // Arrange
        JSONArray provFilterArray = new JSONArray();
        JSONObject provFilter = new JSONObject();
        provFilter.put(PROVIDER_ID, "prov1");
        provFilterArray.put(provFilter);

        String providerId = "prov2";

        // Use reflection to access the private method
        Method method = EPMFilter.class.getDeclaredMethod("getAllowedProviders", JSONArray.class, String.class);
        method.setAccessible(true);

        // Act
        boolean result = (boolean) method.invoke(EPMFilter.getInstance(), provFilterArray, providerId);

        // Assert
        assertFalse(result);
    }

    @Test
    void testGetAllowedLocationProviders_withValidLocationAndProvider_returnsTrue() throws Exception {
        // Arrange
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject locProvFilter = new JSONObject();
        locProvFilter.put(LOCATION_ID, "loc1");
        locProvFilter.put(PROVIDER_ID, "prov1");
        locProvFilterArray.put(locProvFilter);

        String locationId = "loc1";
        String providerId = "prov1";

        // Use reflection to access the private method
        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);

        // Act
        boolean result = (boolean) method.invoke(EPMFilter.getInstance(), locProvFilterArray, locationId, providerId);

        // Assert
        assertTrue(result);
    }

    @Test
    void testGetAllowedLocationProviders_withInvalidLocationAndProvider_returnsFalse() throws Exception {
        // Arrange
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject locProvFilter = new JSONObject();
        locProvFilter.put(LOCATION_ID, "loc1");
        locProvFilter.put(PROVIDER_ID, "prov1");
        locProvFilterArray.put(locProvFilter);

        String locationId = "loc2";
        String providerId = "prov2";

        // Use reflection to access the private method
        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);

        // Act
        boolean result = (boolean) method.invoke(EPMFilter.getInstance(), locProvFilterArray, locationId, providerId);

        // Assert
        assertFalse(result);
    }
}