package com.pes.integration.athena;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.AthenaInitEngine;
import com.pes.integration.athena.InitEngine;
import com.pes.integration.exceptions.IHubException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class InitEngineTest {

    @Mock
    private AthenaInitEngine athenaInitEngine;

    @InjectMocks
    private InitEngine initEngine;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInit_Success() throws IHubException {
        // Act
        initEngine.init();

        // Assert
        verify(athenaInitEngine, times(1)).init();
    }
}