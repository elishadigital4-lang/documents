package com.pes.integration.athena.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.athena.service.open.OpenAppointmentServiceImpl;
import com.pes.integration.dto.RealTimeRequest;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.OK;

@ExtendWith(MockitoExtension.class)
class AvailabilityControllerTest {

    @Mock
    private OpenAppointmentServiceImpl openAppointmentService;

    @InjectMocks
    private AvailabilityController availabilityController;

    private RealTimeRequest realTimeRequest;
    private JSONObject mockResponse;

    @BeforeEach
    void setUp() {
        realTimeRequest = new RealTimeRequest();
        realTimeRequest.setMessageControlId("testMessageControlId");
        realTimeRequest.setEntityId("testEntityId");
        realTimeRequest.setReasonId("testReasonId");
        realTimeRequest.setFlow("MiniBaseline");
        realTimeRequest.setDeploymentId("testDeploymentId");
        realTimeRequest.setEntityType("testEntityType");
        realTimeRequest.setStartDate("2024-08-20");
        realTimeRequest.setEndDate("2024-08-26");

        mockResponse = new JSONObject();
        mockResponse.put("key", "value");
        ReflectionTestUtils.setField(availabilityController, "engineName", "testEngineName");
        ReflectionTestUtils.setField(availabilityController, "appDescription", "testAppDescription");
    }

    @Test
    void testGetRealTimeData_Success() throws JsonProcessingException {
        when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class)))
                .thenReturn(mockResponse);

        ResponseEntity<Object> response = availabilityController.getRealTimeData(realTimeRequest);

        assertEquals(OK, response.getStatusCode());
        assertEquals(mockResponse.toString(), response.getBody());
    }

    @Test
    void testGetRealTimeDataBaseline_Success() throws JsonProcessingException {
        when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class)))
                .thenReturn(mockResponse);

        ResponseEntity<Object> response = availabilityController.getRealTimeData(realTimeRequest);

        assertEquals(OK, response.getStatusCode());
        assertEquals(mockResponse.toString(), response.getBody());
    }
}