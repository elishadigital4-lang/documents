package com.pes.integration.athena.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.repository.RedisRepository;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.adapter.Utils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.MockedStatic;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpenAppointmentConsumerTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private RedisRepository terminateBaselineRepository;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private AppointmentService openAppointmentService;

    @InjectMocks
    private OpenAppointmentConsumer openAppointmentConsumer;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testConsume_Success() throws Exception {
        String request = "{\"messageControlId\":\"12345\"}";
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("-1");

        when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);
        when(terminateBaselineRepository.findCacheById("terminateFlowCache", "terminated-msid-", "12345")).thenReturn("false");

        openAppointmentConsumer.consume(request);
    }

    @Test
    void testConsume_JsonProcessingException() throws Exception {
        String request = "{\"messageControlId\":\"12345\"}";
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("-1");

        when(objectMapper.readValue(request, AvailabilityRequest.class)).thenThrow(new JsonProcessingException("Error") {});

        try (MockedStatic<Utils> utilities = mockStatic(Utils.class)) {
            openAppointmentConsumer.consume(request);

            utilities.verify(() -> Utils.trackOpenSliceError(any(), any(), contains("Error while parsing the request")), times(1));
        }
    }

    @Test
    void testConsume_GeneralException() throws Exception {
        String request = "{\"messageControlId\":\"12345\"}";
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("-1");

        when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);
        doThrow(new RuntimeException("General error")).when(openAppointmentService).getAppointments(any(), any());

        try (MockedStatic<Utils> utilities = mockStatic(Utils.class)) {
            openAppointmentConsumer.consume(request);

            utilities.verify(() -> Utils.trackOpenSliceError(any(), any(), contains("Error in processing the data")), times(1));
        }
    }
}