package com.pes.integration.athena.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.repository.RedisRepository;
import com.pes.integration.service.AppointmentService;
import io.awspring.cloud.sqs.annotation.SqsListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.constant.EpmConstant.OPEN_APPOINTMENT;
import static com.pes.integration.constant.UtilitiesConstants.MESSAGE_CONTROL_ID;
import static org.slf4j.MDC.put;
import static org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy.ON_SUCCESS;

@Service
@Slf4j
public class OpenAppointmentConsumer {
    @Value("${application.data.path}")
    private String dataLocation;

    @Autowired
    @Qualifier(OPEN_APPOINTMENT)
    AppointmentService openAppointmentService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private EventTracker trackEvents;

    @Autowired
    private RedisRepository terminateBaselineRepository;
    @Value("${application.queue.openAppt.process}")
    private String queue;

    @SqsListener(value = "${application.queue.openAppt.process}")
    public void consume(String request) throws JsonProcessingException {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        log.info("Open Appointment data request received is {}", request);
        try {
            availabilityRequest = objectMapper.readValue(request, AvailabilityRequest.class);
            if (isTerminatedBaseline(terminateBaselineRepository, trackEvents, availabilityRequest)) {
                log.info("Baseline for messagecontrolId {} is terminated ",
                        availabilityRequest.getMessageControlId());
                return;
            }
            validateInput(availabilityRequest);
            put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
            openAppointmentService.getAppointments(availabilityRequest, AthenaEngineConstants.EPM_NAME_PREFIX);
        } catch (JsonProcessingException jpe) {
            String message = "Error while parsing the request " + availabilityRequest + jpe.getMessage();
            log.error(message);
            trackOpenSliceError(availabilityRequest, trackEvents, message);
        } catch (Exception ex) {
            String message = "Error in processing the data , Details: " + ex.getMessage();
            log.error(message);
            trackOpenSliceError(availabilityRequest, trackEvents, message);
        }
    }

    // Note: Used Strictly For Testing Purpose
    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }


}

