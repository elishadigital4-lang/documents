package com.pes.integration.athena.util;

import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class AthenaConfigCache {

    private static AthenaConfigCache keeperInstance = null;
    Map<String, Map<String, String>> pacticeApptTypeMap = new HashMap<>();
    Map<String, JSONArray> visitReasonMap = new HashMap<>();
    Map<String, JSONArray> pacticeLocationMap = new HashMap<>();

    public static AthenaConfigCache getInstance(){
        if(keeperInstance==null){
            keeperInstance = new AthenaConfigCache();
        }
        return keeperInstance;
    }



    public Map<String, String> getAppointmentTypeList(String practiceId) {
        return pacticeApptTypeMap.get(practiceId);
    }

    public void setAppointmentTypeList(String practiceId, Map<String, String> appttypeMap) {
        pacticeApptTypeMap.put(practiceId, appttypeMap);
    }

    public void setVisitReasonArrayMap(String deploymentId, JSONArray visistReasonArray) {
        visitReasonMap.put(deploymentId, visistReasonArray);
    }

    public JSONArray getVisitReasonArray(String deploymentId) {
        return visitReasonMap.get(deploymentId);
    }

    public JSONArray getPacticeLocationMap(String practiceId) {
        return pacticeLocationMap.get(practiceId);
    }

    public void setPacticeLocationMap(String practiceId, JSONArray pacticeLocationArray) {
        this.pacticeLocationMap.put(practiceId, pacticeLocationArray);
    }
}
