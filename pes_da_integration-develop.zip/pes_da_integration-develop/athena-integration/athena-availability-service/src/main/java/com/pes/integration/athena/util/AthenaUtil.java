package com.pes.integration.athena.util;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.constant.EpmConstant;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.ParseException;
import java.util.*;

import static com.pes.integration.athena.api.ApiName.*;
import static com.pes.integration.athena.api.ApiName.OPEN_APPOINTMENTS;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaConstants.REASONID;
import static com.pes.integration.athena.constant.AthenaEngineConstants.USE_LOCAL_PROVIDER;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.LIMIT;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.DATE_TIME_FORMAT;
import static com.pes.integration.constant.EpmConstant.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.FILTER_DATA;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.EpmConstant.SLOT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.IS_MINIBASELINE;
import static com.pes.integration.constant.UtilitiesConstants.LOCATION_ID;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static java.util.Objects.nonNull;

@Slf4j
public class AthenaUtil {

    @Autowired
    AthenaApiCaller athenaApiCaller;

    public static void trackEventToNifi(EventTracker trackEvents,
                                        AvailabilityRequest availabilityRequest, DataflowStatus dataflowStatus, String totalFragments,
                                        String fragmentId, Map<String, Object> payload) {
        NifiTrackingEvent nifiEvent =
                getNifiEvent(availabilityRequest, dataflowStatus, totalFragments, fragmentId, payload);
        trackEvents.trackEventToNifi(nifiEvent);
    }

    public static NifiTrackingEvent getNifiEvent(AvailabilityRequest availabilityRequest,
                                                 DataflowStatus dataflowStatus, String totalFragments, String fragmentId,
                                                 Map<String, Object> payload) {
        return NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
                .messageControlId(availabilityRequest.getMessageControlId())
                .appointmentType(availabilityRequest.getAppointmentType())
                .sliceId(availabilityRequest.getSliceId())
                .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
                .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices()).payload(payload)
                .entityType(availabilityRequest.getEntityType()).entityId(availabilityRequest.getEntityId())
                .flow(availabilityRequest.getFlow()).build();
    }

    public static JSONObject openAppointments(AthenaApiCaller athenaApiCaller,JSONObject inputParam)
            throws InvalidResourceException, IHubException {
        JSONObject openAppointmentRequest  = getInputObject(inputParam, true);

        return athenaApiCaller.call(OPEN_APPOINTMENTS.getKey(), openAppointmentRequest, "");
    }

    public static JSONArray getVisitReasonArray(AthenaApiCaller athenaApiCaller, JSONObject inputParam) throws IHubException {
        String deploymentId = inputParam.optString(DEPLOYMENT_ID);
        JSONArray patientApptReasonsArray =  AthenaConfigCache.getInstance().getVisitReasonArray(deploymentId);
        if(Objects.isNull(patientApptReasonsArray) || patientApptReasonsArray.isEmpty()) {
            JSONArray visitReasonArray;
            JSONObject visitReasonRequest = getInputObject(inputParam,false);
            JSONArray locProvfilterArray = getFilterData(deploymentId, inputParam.optJSONObject(LOCATION_PROVIDER_FILTER));
            if (!NullChecker.isEmpty(locProvfilterArray) && !locProvfilterArray.isEmpty()) {
                visitReasonArray = pullPatientVisitReasonFromFilter(locProvfilterArray, inputParam, athenaApiCaller);
            } else {
                visitReasonArray = getPatientVisitReasons(inputParam, visitReasonRequest, athenaApiCaller);
            }
            AthenaConfigCache.getInstance().setVisitReasonArrayMap(deploymentId, visitReasonArray);
            return visitReasonArray;
        }
        return patientApptReasonsArray;
    }

    private static JSONArray getLocations(JSONObject inputParam,AthenaApiCaller athenaApiCaller,JSONObject visitReasonRequest) {
        JSONArray locationObjectsArray = new JSONArray();
        try {
            locationObjectsArray = getLocationList(inputParam,athenaApiCaller,visitReasonRequest);
        } catch (Exception e) {
            log.info("Error in fetching locations");
        }
        return locationObjectsArray;
    }

    public static JSONArray getLocationList(JSONObject inputParam,AthenaApiCaller athenaApiCaller,JSONObject visitReasonRequest) throws IHubException {
        String practiceId = inputParam.optString(TEMP_PRACTICE_ID);
        if(NullChecker.isEmpty(practiceId)){
            practiceId = inputParam.optString(ATHENA_PRACTICE_ID);
            inputParam.put(TEMP_PRACTICE_ID,practiceId);
        }
        JSONArray locationArray = AthenaConfigCache.getInstance().getPacticeLocationMap(practiceId);
        if (NullChecker.isEmpty(locationArray) || locationArray.isEmpty()) {
            visitReasonRequest.put("temp.provider_list","true");
            JSONObject outputObject = athenaApiCaller.call(GET_LOCATIONS.getKey(), visitReasonRequest,"");

            //store location id's list for future use
            locationArray = outputObject.optJSONArray("Locations");
            AthenaConfigCache.getInstance().setPacticeLocationMap(practiceId, locationArray);
        }
        return locationArray;
    }


    private static JSONArray getPatientVisitReasons(JSONObject inputParam,JSONObject visitReasonRequest,AthenaApiCaller athenaApiCaller) throws IHubException {
        JSONArray locationObjectsArray = getLocations(inputParam, athenaApiCaller, visitReasonRequest);
        JSONArray visitReasonArray = new JSONArray();
        JSONArray visitReasonArrayList = new JSONArray();

        if (!NullChecker.isEmpty(locationObjectsArray) && !locationObjectsArray.isEmpty() ) {
            for (Object locationObj : locationObjectsArray) {
                String locationId = ((JSONObject)locationObj).optString(LOCATION_ID);
                JSONArray providerArray = ((JSONObject)locationObj).optJSONArray("ProviderIdList");
                if (!NullChecker.isEmpty(providerArray) && !providerArray.isEmpty()) {
                    for (Object providerId : providerArray) {
                        visitReasonRequest.put(LOCATION_ID,locationId);
                        visitReasonRequest.put("ProviderId",providerId);

                        JSONObject visitReasonJson = new JSONObject();
                        JSONObject visitReasonOutputObj = athenaApiCaller.call(GET_PATIENT_VISIT_REASONS.getKey(), visitReasonRequest,"");
                        visitReasonJson.put(LOCATION_ID,locationId);
                        visitReasonJson.put("ProviderId",providerId);
                        if(!NullChecker.isEmpty(visitReasonOutputObj) && !visitReasonOutputObj.isEmpty()){
                            visitReasonJson.put(VISIT_REASONS,visitReasonOutputObj.optJSONObject(VISIT_REASONS));
                            visitReasonArray.put(visitReasonJson);
                        } else continue;
                        JSONArray visitReasonsArrayForProvider = visitReasonOutputObj.getJSONArray(VISIT_REASONS);
                        JSONArray visitReasonsList = new JSONArray();
                        List<String> visitReasons = new ArrayList<>();

                        setVisitReasonList(visitReasonsArrayForProvider, visitReasonsList, visitReasons);

                        JSONObject visitReasonListJson = new JSONObject();
                        visitReasonListJson.put(LOCATION_ID,locationId);
                        visitReasonListJson.put(PROVIDER_ID,providerId);
                        visitReasonListJson.put(VISIT_REASONS, StringUtils.join(visitReasonsList, ","));
                        visitReasonArrayList.put(visitReasonListJson);
                    }
                }
            }
        }
        AthenaConfigCache.getInstance().setVisitReasonArrayMap(inputParam.optString(DEPLOYMENT_ID), visitReasonArrayList);
        return visitReasonArrayList;
    }

    private static void setVisitReasonList(JSONArray visitReasonsArrayForProvider, JSONArray visitReasonsList,
                                           List<String> visitReasons) {
        for (Object obj : visitReasonsArrayForProvider) {
            JSONObject visitReasonForProvider = (JSONObject) obj;
            String visitReasonId = visitReasonForProvider.getString("Id");
            visitReasons.add(visitReasonId);
            visitReasonsList.put(visitReasonId);
        }
    }

    private static JSONArray pullPatientVisitReasonFromFilter(JSONArray locProvfilterArray,JSONObject inputParam,AthenaApiCaller athenaApiCaller) {
        JSONArray visitReasonArrayList = new JSONArray();
        JSONObject visitReasonRequest = new JSONObject();
        JSONObject tempObj = new JSONObject();
        try{
            JSONArray visitReasonArray = new JSONArray();
            for(int i=0;i<locProvfilterArray.length();i++){
                JSONObject filterObject = locProvfilterArray.getJSONObject(i);

                String providerId = filterObject.getString(PROVIDER_ID);
                String locationId = filterObject.getString(LOCATION_ID);
                visitReasonRequest.put(LOCATION_ID,locationId);
                visitReasonRequest.put(PROVIDER_ID,providerId);
                tempObj.put(PRACTICE_ID1, inputParam.optString(ATHENA_PRACTICE_ID));
                visitReasonRequest.put("temp", tempObj);

                JSONObject visitReasonJson = new JSONObject();
                JSONObject visitReasonOutputObj = athenaApiCaller.call(GET_PATIENT_VISIT_REASONS.getKey(), visitReasonRequest,"");
                visitReasonJson.put(LOCATION_ID,locationId);
                visitReasonJson.put(PROVIDER_ID,providerId);

                if(visitReasonOutputObj!=null && visitReasonOutputObj.has(VISIT_REASONS)){
                    visitReasonJson.put(VISIT_REASONS,visitReasonOutputObj.optString(VISIT_REASONS));
                    visitReasonArray.put(visitReasonJson);
                } else continue;

                JSONArray visitReasonsArrayForProvider = visitReasonOutputObj.getJSONArray(VISIT_REASONS);
                JSONArray visitReasonsList = new JSONArray();
                List<String> visitReasons = new ArrayList<>();

                setVisitReasonList(visitReasonsArrayForProvider, visitReasonsList, visitReasons);

                JSONObject visitReasonListJson = new JSONObject();
                visitReasonListJson.put(LOCATION_ID,locationId);
                visitReasonListJson.put(PROVIDER_ID,providerId);
                visitReasonListJson.put(VISIT_REASONS,StringUtils.join(visitReasonsList, ","));
                visitReasonArrayList.put(visitReasonListJson);
            }
            //AthenaConfigCache.getInstance().setVisitReasonArrayMap(inputParam.optString(DEPLOYMENT_ID), visitReasonArrayList);
        }catch (Exception e){
            log.error(e.getMessage());
        }
        return visitReasonArrayList;
    }


    public static JSONArray getFilterData(String deploymentId, JSONObject filter){
        if(NullChecker.isEmpty(deploymentId)){
            return null;
        }
        JSONArray filterJsonArray = null;
        try {
            if (!NullChecker.isEmpty(filter)) {
                if (filter.has(LOCATION_PROVIDER_FILTER)) {
                    filterJsonArray = filter.getJSONArray(LOCATION_PROVIDER_FILTER);
                }
            }
        }catch(Exception e){
            log.error(e.getMessage());
        }
        return filterJsonArray;
    }

    public static JSONObject getInputObject(JSONObject inputParam, boolean isRealTime) {
        JSONObject openAppointmentRequest = new JSONObject();
        JSONObject providerObj = new JSONObject();
        JSONObject provider = new JSONObject();
        if(inputParam.has("departmentid")){
            String locationId = getLocationIdStr(inputParam.getJSONArray("departmentid"));
            providerObj.put(LOCATION_ID, locationId);
            JSONArray providerArray = new JSONArray();
            providerArray.put(providerObj);
            provider.put("Provider", providerArray);
        }

        JSONObject tempObj = new JSONObject();
        tempObj.put("start_date", inputParam.getString(STARTDATE));
        tempObj.put("end_date", inputParam.getString(ENDDATE));
        tempObj.put(PRACTICE_ID1, inputParam.optString(ATHENA_PRACTICE_ID));
        boolean isMiniBaseline = inputParam.optBoolean(IS_MINIBASELINE);
        if(isRealTime && !isMiniBaseline){
            tempObj.put(AthenaConstants.APPOINTMENTTYPEID, inputParam.optString(AthenaConstants.REASON_ID));
        }else{
            tempObj.put(AthenaConstants.REASON_ID, inputParam.optString(AthenaConstants.REASON_ID));
        }
        tempObj.put(IGNORE_SHCED_PERMISSION, inputParam.optString(IGNORE_SHCED_PERMISSION));
        if(inputParam.has(APPT_RESOURCE_ID)){
            providerObj = new JSONObject();
            providerObj.put(LOCATION_ID, inputParam.optString(APPT_LOCATION_ID));
            providerObj.put("ResourceId", inputParam.optString(APPT_RESOURCE_ID));
            JSONArray providerArray = new JSONArray();
            providerArray.put(providerObj);
            provider.put("Provider", providerArray);
        }
        if(inputParam.has(LIMIT)){
            tempObj.put(LIMIT, inputParam.optString(LIMIT));
        }
        openAppointmentRequest.put("SchedulingData", provider);
        openAppointmentRequest.put("temp", tempObj);
        return openAppointmentRequest;
    }

    public static JSONArray extractOpenSlotsFromResponse(JSONObject outputObject,boolean isOrgConfigTrue, AthenaApiCaller athenaApiCaller, JSONObject inputparam) {
        boolean useLocalProviderId = "true".equals(inputparam.optString(USE_LOCAL_PROVIDER));
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray appointmentsArray = outputObject.optJSONArray(EpmConstant.OPEN_APPOINTMENTS);
        if (nonNull(appointmentsArray)) {
            appointmentsArray.forEach(appointmentObject -> {
                        try {
                            openAppointmentsArray.put(transformOpenAppointment((JSONObject) appointmentObject,useLocalProviderId));
                        } catch (ParseException e) {
                            throw new RuntimeException(e);
                        }
                    }
            );
        }
        if (isOrgConfigTrue) {
            for (int i = 0; i < openAppointmentsArray.length(); i++) {
                setApptReasonIdsFromApptArray(openAppointmentsArray, i);
            }
        } else {
            updateGenericAppointmentTypes(openAppointmentsArray,athenaApiCaller,inputparam);
        }

        return openAppointmentsArray;
    }

    public static JSONObject transformOpenAppointment(JSONObject appointmentObject,boolean useLocalProviderId) throws ParseException {

        JSONObject openAppointment = new JSONObject();
        openAppointment.put(SLOT_ID_KEY, appointmentObject.opt(SLOT_ID));
        openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
        openAppointment.put(DURATION, appointmentObject.opt("Duration"));
        openAppointment.put(LOCATION_ID_KEY, appointmentObject.opt(LOCATION_ID));
        if(useLocalProviderId) {
            openAppointment.put(PROVIDER_ID_KEY, appointmentObject.optString(LOCAL_PROVIDER_ID));
        }
        else {
            openAppointment.put(PROVIDER_ID_KEY, appointmentObject.opt(PROVIDER_ID));
        }
        openAppointment.put(LOCAL_PROVIDER_ID, appointmentObject.optString(LOCAL_PROVIDER_ID));
        openAppointment.put(REASON_ID_KEY, appointmentObject.opt(APPTREASON_ID));
        JSONObject temp=(JSONObject) appointmentObject.opt("temp");
        String startTime = (String) temp.opt("start_time");
        openAppointment.put(START_TIME,
                convertDateFormat(startTime.trim(),"HH:mm", DOCASAP_TIME_FORMAT));
        String date = (String) temp.opt("start_date");
        openAppointment.put(DATE_KEY, convertDateFormat(date.trim(), "MM/dd/yyyy", DATE_TIME_FORMAT));

        return openAppointment;
    }

    private static void setApptReasonIdsFromApptArray(JSONArray appointmentsArray, int i) {
        try {
            JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
            appointmentObject.put(APPTREASON_ID, StringUtils.join(appointmentObject.getJSONArray(APPTREASON_ID), "^"));

        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    private static void updateGenericAppointmentTypes(JSONArray appointmentsArray, AthenaApiCaller athenaApiCaller, JSONObject inputparam) {

        List<String> genAptTypesWithSpAptTypes = getGenericApptType(inputparam.optString(GENERIC_APPT_TYPE));

        for (int j = 0; j < genAptTypesWithSpAptTypes.size(); j++) {
            String genApptTypeWithSpAptTypeIds = genAptTypesWithSpAptTypes.get(j);
            String genApptTypeId;
            String schedulableAapptTypes = getSchedulableAppointmentTypes(genApptTypeWithSpAptTypeIds,inputparam,athenaApiCaller);
            for (int i = 0; i < appointmentsArray.length(); i++) {
                JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
                //   String apptReasonId = appointmentObject.optString("ApptReasonId");
                String apptReasonId = appointmentObject.optString(REASONID);
                if (genApptTypeWithSpAptTypeIds.contains(":")) {
                    int index = genAptTypesWithSpAptTypes.get(j).indexOf(":");
                    genApptTypeId = genAptTypesWithSpAptTypes.get(j).substring(0, index);
                    String spApptTypeIdsString = genAptTypesWithSpAptTypes.get(j).substring(index + 1);

                    if(genApptTypeId != null && genApptTypeId.equals(apptReasonId)){
                        //   appointmentObject.put("ApptReasonId",spApptTypeIdsString);
                        appointmentObject.put(REASONID,spApptTypeIdsString);
                    }
                } else {
                    if(genApptTypeWithSpAptTypeIds.equals(apptReasonId)){
                        //   appointmentObject.put("ApptReasonId",schedulableAapptTypes);
                        appointmentObject.put(REASONID,schedulableAapptTypes);
                    }
                }
            }
        }
    }

    public static String getSchedulableAppointmentTypes (String genApptTypeId, JSONObject inputparam,AthenaApiCaller athenaApiCaller){
        String schedulableAapptTypesStr = "";
        try {
            Map<String, String> apptTypeMap = getAppointmentTypeList(inputparam,athenaApiCaller);
            if (apptTypeMap != null){
                String schedulableDuration = apptTypeMap.get(genApptTypeId);
                Set<String> apptTypeKeySet = apptTypeMap.keySet();
                Iterator<String> apptTypeIterator = apptTypeKeySet.iterator();
                while (apptTypeIterator.hasNext()){
                    String apptTypeId = apptTypeIterator.next();
                    String apptDuration = apptTypeMap.get(apptTypeId);
                    if (!NullChecker.isEmpty(apptDuration)
                            && !NullChecker.isEmpty(schedulableDuration)
                            && !NullChecker.isEmpty(apptTypeId)
                            && (Integer.parseInt(apptDuration) % Integer.parseInt(schedulableDuration)) == 0) {
                        schedulableAapptTypesStr += apptTypeId+"^";
                    }
                }
                if(!NullChecker.isEmpty(schedulableAapptTypesStr))
                    schedulableAapptTypesStr = schedulableAapptTypesStr.substring(0, schedulableAapptTypesStr.length()-1);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return schedulableAapptTypesStr;
    }

    public static Map<String, String> getAppointmentTypeList(JSONObject inputparam,AthenaApiCaller athenaApiCaller) throws IHubException {
        String practiceid = inputparam.optString("practiceid");
        Map<String, String> apptTypeMap = AthenaConfigCache.getInstance().getAppointmentTypeList(practiceid);
        if (apptTypeMap == null || apptTypeMap.isEmpty()) {
            Map<String, String> appointmentTypeMap = new HashMap<>();
            JSONObject appointmentTypeRequest = new JSONObject();
            JSONObject temObj = new JSONObject();

            temObj.put(PRACTICE_ID1, practiceid);
            appointmentTypeRequest.put("temp", temObj);
            JSONObject outputObject = athenaApiCaller.call(GET_APPOINTMENT_TYPES.getKey(), appointmentTypeRequest,"");
            //store appointmentType id's list for future use
            Object appointmentTypeObject = outputObject.get("AppointmentTypes");
            if(appointmentTypeObject!=null){
                JSONArray appointmentTypeArray = (JSONArray) appointmentTypeObject;
                for(int i = 0;i<appointmentTypeArray.length();i++){
                    JSONObject apptTypeObj = appointmentTypeArray.getJSONObject(i);
                    String apptTypeId = apptTypeObj.optString("AppointmentTypeId");
                    String apptTypeDuration = apptTypeObj.optString("Duration");
                    if(apptTypeId!=null && apptTypeDuration!=null){
                        appointmentTypeMap.put(apptTypeId, apptTypeDuration);
                    }
                }
                AthenaConfigCache.getInstance().setAppointmentTypeList(practiceid, appointmentTypeMap);
            }
            return appointmentTypeMap;
        }
        return apptTypeMap;
    }

    public static List<String> getGenericApptType(String genapptype){
        List<String> genAptTypesWithSpAptTypes = new ArrayList<>();
        try {
            if(!NullChecker.isEmpty(genapptype))
                genAptTypesWithSpAptTypes = Arrays.asList(genapptype.split(","));
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return genAptTypesWithSpAptTypes;
    }

    public static String getLocationIdStr(JSONArray array) {
        StringBuilder providerIdStr = new StringBuilder();
        for (Object item : array) {
            if (providerIdStr.toString().isEmpty()) {
                providerIdStr = providerIdStr.append(item);
            } else providerIdStr = providerIdStr.append("," + item);
        }
        return providerIdStr.toString();
    }

    public static JSONArray applyFilter(JSONArray appointmentsArray, JSONObject inputObject) {
        if(appointmentsArray==null || appointmentsArray.length()==0){
            return new JSONArray();
        }
        JSONObject filterData = inputObject.optJSONObject(FILTER_DATA);
        JSONArray filteredArray = new JSONArray();
        //PROD-37122
        if (NullChecker.isEmpty(filterData)){

            for (int i = 0; i < appointmentsArray.length(); i++) {
                JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
                String locationId = appointmentObject.optString(LOCATION_ID);
                String providerId = appointmentObject.optString(PROVIDER_ID);

                if (EPMFilter.getInstance().isAllowed(locationId, providerId,inputObject)) {
                    filteredArray.put(appointmentObject);
                }
            }
            return filteredArray;
        } else return appointmentsArray;

    }


}
