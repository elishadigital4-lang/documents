package com.pes.integration.athena.task;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.athena.util.AthenaUtil;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.adapter.Utils.getBookedDataFlowNifiStatus;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.DATE_TIME_FORMAT;
import static com.pes.integration.constant.EpmConstant.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.LOCATION_ID;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext;
import static java.lang.String.valueOf;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class PrepareBookedSlotsTask {

    private String startDate;
    private String endDate;
    private String locations;
    private String dataLocation;
    private EventTracker trackEvents;
    private FileUploader fileUploader;
    private AthenaApiCaller athenaApiCaller;
    private AvailabilityRequest availabilityRequest;
    private Map<String, String> contextMap = getCopyOfContextMap();
    private JSONObject inputObject;
    private DataCacheManager dataCacheManager;

    private String epmPrefix;

    private String deploymentId;

    public PrepareBookedSlotsTask(AthenaApiCaller athenaApiCaller, JSONObject inputObject,
                                  FileUploader fileUploader, EventTracker trackEvents, AvailabilityRequest availabilityRequest, DataCacheManager dataCacheManager) {
        this.startDate = inputObject.getString(STARTDATE);
        this.endDate = inputObject.getString(ENDDATE);
        this.locations = inputObject.optString("locations");
        this.dataLocation = inputObject.getString(APPOINTMENT_PATH);
        this.athenaApiCaller = athenaApiCaller;
        this.fileUploader = fileUploader;
        this.trackEvents = trackEvents;
        this.availabilityRequest = availabilityRequest;
        this.dataCacheManager=dataCacheManager;
        this.inputObject = inputObject;
        this.epmPrefix=inputObject.optString("epmPrefix");
        this.deploymentId=inputObject.optString("deploymentId");
    }

    public void processBookedAppointment() {
        setContext(contextMap);
        Map<String, File> appointmentDataFiles = new HashMap<>();
        try {
            JSONObject bookedApptOutput = getBookedAppointment();
            uploadBookedFiles(appointmentDataFiles, bookedApptOutput);
            trackEventToNifi(trackEvents, availabilityRequest,
                    getBookedDataFlowNifiStatus(availabilityRequest), valueOf(ONE), EMPTY);
        } catch (InvalidResourceException | IHubException exception) {
            log.error("INVALID RESOURCE");
        } finally {
            deleteFiles(appointmentDataFiles);
        }
    }

    private JSONObject getBookedAppointment() throws InvalidResourceException, IHubException {
        JSONArray bookedAppointmentsArray = new JSONArray();
        JSONObject responseObject =
                bookedAppointments(athenaApiCaller, startDate, endDate, locations);
        if (nonNull(responseObject) && (!responseObject.isEmpty())) {
            bookedAppointmentsArray.putAll(extractBookedSlots(responseObject));
        }
        bookedAppointmentsArray = AthenaUtil.applyFilter(bookedAppointmentsArray, inputObject);
        JSONArray blockedAppointmentsArray = new JSONArray();
        if (responseObject.has("BlockedAppointments")) {
            blockedAppointmentsArray = responseObject.optJSONArray("BlockedAppointments");
        }

        return getBookedAppointmentObject(bookedAppointmentsArray, blockedAppointmentsArray);
    }


    private void uploadBookedFiles(Map<String, File> appointmentDataFiles,
                                   JSONObject bookedApptOutput) {
        appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
                prepareBookedFile(bookedApptOutput, availabilityRequest));
        fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
                availabilityRequest.getAppointmentType(), availabilityRequest.getSliceId(),
                appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    }

    private JSONObject getBookedAppointmentObject(JSONArray bookedAppointmentsArray, JSONArray blockedAppointmentsArray) {
        JSONObject bookedApptOutput = new JSONObject();
        bookedApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
        bookedApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
        bookedApptOutput.put(TOTAL_COUNT, bookedAppointmentsArray.length());
        bookedApptOutput.put(DATA, bookedAppointmentsArray);
        if (blockedAppointmentsArray != null && blockedAppointmentsArray.length() > 0) {
            bookedApptOutput.accumulate(DATA, bookedAppointmentsArray);
        }
        return bookedApptOutput;
    }

    private File prepareBookedFile(JSONObject apptresponse, AvailabilityRequest availabilityRequest) {
        return prepareFile(apptresponse.toString(),
                dataLocation + availabilityRequest.getMessageControlId() + SLASH
                        + availabilityRequest.getSliceId(),
                SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
    }

    private JSONObject bookedAppointments(AthenaApiCaller athenaApiCaller, String startDate,
                                            String endDate, String locations)
            throws InvalidResourceException, IHubException {

        JSONObject bookedAppointmentRequest = new JSONObject();
        JSONObject providerObj = new JSONObject();
        JSONObject provider = new JSONObject();
        if (inputObject.has("departmentid")) {
            String locationId = getLocationIdStr(inputObject.getJSONArray("departmentid"));
            providerObj.put("LocationId", locationId);
            JSONArray providerArray = new JSONArray();
            providerArray.put(providerObj);
            provider.put("Provider", providerArray);
        }


        JSONObject temObj = new JSONObject();
        temObj.put("start_date", startDate);
        temObj.put("end_date", endDate);
        temObj.put("practice_id", inputObject.getString(ATHENA_PRACTICE_ID));
        temObj.put("reason_id", inputObject.getString(AthenaConstants.REASON_ID));
        temObj.put("limit", inputObject.getString("limit"));
        temObj.put(IGNORE_SHCED_PERMISSION, inputObject.getString(IGNORE_SHCED_PERMISSION));
        if (inputObject.has(APPT_RESOURCE_ID)) {
            providerObj = new JSONObject();
            providerObj.put(LOCATION_ID_KEY, inputObject.optString(APPT_LOCATION_ID));
            providerObj.put("ResourceId", inputObject.optString(APPT_RESOURCE_ID));
            JSONArray providerArray = new JSONArray();
            providerArray.put(providerObj);
            provider.put("Provider", providerArray);
        }
        bookedAppointmentRequest.put("SchedulingData", provider);
        bookedAppointmentRequest.put("temp", temObj);
        return athenaApiCaller.call(ApiName.BOOKED_APPOINTMENTS.getKey(), bookedAppointmentRequest,"");
    }

    public static String getLocationIdStr(JSONArray array) {
        StringBuilder providerIdStr = new StringBuilder();
        for (Object item : array) {
            if (providerIdStr.toString().isEmpty()) {
                providerIdStr = providerIdStr.append(item);
            } else providerIdStr = providerIdStr.append("," + item);
        }
        return providerIdStr.toString();
    }

    private JSONArray extractBookedSlots(JSONObject outputObject) throws IHubException {
        JSONArray tempAppointmentsArray = outputObject.optJSONArray("BookedAppointments");
        boolean useLocalProviderId = "true".equals(dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, "uselocalprovider"));
        JSONArray bookedAppointmentsArray = new JSONArray();
        tempAppointmentsArray.forEach(
                bookedAppointment -> {
                    try {
                        bookedAppointmentsArray.put(transformBookedAppointment((JSONObject) bookedAppointment,useLocalProviderId));
                    } catch (ParseException | IHubException e) {
                        throw new RuntimeException(e);
                    }
                });
        return bookedAppointmentsArray;
    }

    private JSONObject transformBookedAppointment(JSONObject appointmentObject,boolean useLocalProviderId) throws ParseException, IHubException {
        JSONObject bookedAppointment = new JSONObject();
        if (useLocalProviderId) {
            bookedAppointment.put(PROVIDER_ID_KEY, appointmentObject.optString("LocalProviderId"));
        } else {
            bookedAppointment.put(PROVIDER_ID_KEY, appointmentObject.opt(PROVIDER_ID));
        }
        bookedAppointment.put(REASON_ID_KEY, appointmentObject.opt(APPTREASON_ID));
        JSONObject temp = appointmentObject.optJSONObject("temp");
        String startTime = temp.optString("start_time");
        bookedAppointment.put(START_TIME, convertDateFormat(startTime.trim(), "HH:mm", DOCASAP_TIME_FORMAT));
        bookedAppointment.put(LOCATION_ID_KEY, appointmentObject.opt(LOCATION_ID));
        bookedAppointment.put(DURATION, appointmentObject.opt("Duration"));
        bookedAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
        bookedAppointment.put(SLOT_ID_KEY, appointmentObject.opt("ExternalApptId"));
        String createDateTime = appointmentObject.optString(CREATE_DATE_TIME);
        bookedAppointment.put("scheduleddatetime", convertDateFormat(createDateTime, AthenaConstants.DATE_TIME_FORMAT, DATE_TIME_FORMAT_DA));
        String date = (String) temp.opt("start_date");
        bookedAppointment.put(DATE_KEY, convertDateFormat(date.trim(), "MM/dd/yyyy", DATE_TIME_FORMAT));

        return bookedAppointment;
    }

    public static void trackEventToNifi(EventTracker trackEvents,
                                        AvailabilityRequest availabilityRequest, DataflowStatus dataflowStatus, String totalFragments,
                                        String fragmentId) {
        NifiTrackingEvent nifiEvent = NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
                .messageControlId(availabilityRequest.getMessageControlId())
                .appointmentType(availabilityRequest.getAppointmentType())
                .sliceId(availabilityRequest.getSliceId())
                .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
                .entityType(availabilityRequest.getEntityType()).entityId(availabilityRequest.getEntityId())
                .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices())
                .flow(availabilityRequest.getFlow()).build();
        trackEvents.trackEventToNifi(nifiEvent);
    }

}
