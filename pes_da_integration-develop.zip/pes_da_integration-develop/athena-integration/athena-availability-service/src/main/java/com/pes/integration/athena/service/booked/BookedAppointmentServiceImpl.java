package com.pes.integration.athena.service.booked;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.task.PrepareBookedSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.athena.constant.AthenaConstants.ATHENA_PRACTICE_ID;
import static com.pes.integration.athena.constant.AthenaConstants.WEB_SCHEDILABLE_FLAG;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.constant.EpmConstant.BOOKED_APPOINTMENT;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.adapter.Utils.trackBookedFragmentError;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.String.format;
import static java.lang.Thread.currentThread;
import static java.util.Objects.nonNull;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static java.util.stream.Collectors.toList;

@Qualifier(BOOKED_APPOINTMENT)
@Slf4j
@Service
public class BookedAppointmentServiceImpl extends AppointmentService {

    private static final String REQUEST_RECEIVED = "Booked request has been received with input %s";
    private static final int TOTAL_BOOKED_CALLS = 1;
    private static final String ERROR_PROCESSING_DATA =
            "Error in processing the data for booked appointment slot, Details:- Start Date : %s, End date: %s with error %s";

    @Value("${application.data.path}")
    private String dataLocation;

    @Autowired
    private AthenaApiCaller athenaApiCaller;

    @Autowired
    private FileUploader fileUploader;

    @Autowired
    private EventTracker trackEvents;

    @Autowired
    DataCacheManager dataCacheManager;

    @Override
    public JSONArray getAvailability(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap, String epmPrefix) throws JsonProcessingException, IHubException {
        String startDate = availabilityRequest.getStartDate();
        String endDate = availabilityRequest.getEndDate();
        if (availabilityRequest.getIndex().equals(valueOf(FIRST_INDEX))) {
            trackEvents.trackEvent(availabilityRequest, BOOKED_APPOINTMENT_PROCESSING_STARTED,
                    format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
                    getFragmentsDetails(availabilityRequest));
        }
        fetchBookedAppointments(startDate, endDate,
                providerLocationMap.get(LOCATION_ID_LIST), availabilityRequest,epmPrefix);
        return null;
    }

    public void fetchBookedAppointments(String startDate, String endDate,
                                        JSONArray locationJsonArray, AvailabilityRequest availabilityRequest,String epmPrefix) throws IHubException {
        try {
            startDate = convertDateFormat(startDate, DATE_FORMAT, "MM/dd/yyyy");
            endDate = convertDateFormat(endDate, DATE_FORMAT, "MM/dd/yyyy");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        JSONObject inputObject = getInputObject(startDate, endDate, locationJsonArray,epmPrefix,availabilityRequest.getDeploymentId());
        try {
            new PrepareBookedSlotsTask(athenaApiCaller, inputObject, fileUploader, trackEvents,
                    availabilityRequest,dataCacheManager).processBookedAppointment();
        } catch (InvalidIdException e) {
            String message = format(ERROR_PROCESSING_DATA, startDate, endDate, e.getMessage());
            log.error(message);
            trackBookedFragmentError(availabilityRequest, trackEvents, message);
        } catch (EpmApiCallerException ee) {
            String message = "Error in getting the booked appointment slot " + ee.getMessage();
            log.error(message);
            trackBookedFragmentError(availabilityRequest, trackEvents, message);
        }
    }

    private JSONObject getInputObject(String startDate, String endDate, JSONArray locationJsonArray, String epmPrefix, String deploymentId) throws IHubException {
        JSONObject inputParameter = new JSONObject();
        inputParameter.put(STARTDATE, startDate);
        inputParameter.put(ENDDATE, endDate);
        inputParameter.put(APPOINTMENT_PATH, "appointment/");
        inputParameter.put(ATHENA_PRACTICE_ID,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, ATHENA_PRACTICE_ID));
        inputParameter.put("reason_id", "-1");
        inputParameter.put("limit", dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, "limit"));
        inputParameter.put("ignore_schedulable_permission", dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, WEB_SCHEDILABLE_FLAG));
        inputParameter.put("departmentid", locationJsonArray);
        inputParameter.put(FILTER_DATA,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, FILTER_DATA));
        inputParameter.put("epmPrefix",epmPrefix);
        inputParameter.put("deploymentId",deploymentId);

        return inputParameter;
    }

    private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest) {
        Map<String, Object> providerDetails = new HashMap<>();
        providerDetails.put(TOTAL_FRAGMENTS, valueOf(TOTAL_BOOKED_CALLS));
        providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        return providerDetails;
    }

    @Override
    public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
        // TODO Auto-generated method stub
        return null;
    }

}
