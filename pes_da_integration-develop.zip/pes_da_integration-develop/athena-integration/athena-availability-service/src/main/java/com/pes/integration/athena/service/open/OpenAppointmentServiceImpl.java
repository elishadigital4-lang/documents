package com.pes.integration.athena.service.open;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaConstants;
//import com.pes.integration.athena.task.PrepareOpenSlotsTask;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.athena.task.PrepareOpenSlotsTask;
import com.pes.integration.athena.task.RealTimeOpenSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.NumberConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.*;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaConstants.DEPARTMENT_ID;
import static com.pes.integration.athena.constant.AthenaConstants.GENERIC_APPT_TYPE;
import static com.pes.integration.athena.constant.AthenaConstants.PRACTICE_ID;
import static com.pes.integration.athena.constant.AthenaConstants.REASON_ID;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.athena.util.AthenaUtil.getVisitReasonArray;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.DATE_FORMAT;
import static com.pes.integration.constant.EpmConstant.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.FILTER_DATA;
import static com.pes.integration.constant.EpmConstant.LOCATION_ID;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.IS_MINIBASELINE;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeErrorCount;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.util.Objects.nonNull;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static javax.swing.UIManager.put;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;

@Slf4j
@Service
@Qualifier(OPEN_APPOINTMENT)
public class OpenAppointmentServiceImpl extends AppointmentService {

    @Value("#{${configuration.api.datediff}}")
    private int datediff;

    @Value("#{${configuration.api.threadsize}}")
    private int threadSize;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;

    @Autowired
    private EventTracker trackEvents;

    @Autowired
    private AthenaApiCaller athenaApiCaller;

    @Autowired
    private FileUploader fileUploader;

    @Autowired
    DataCacheManager dataCacheManager;


    @Autowired
    IHubDataServiceDelegator iHubDataServiceDelegator;

    private static final String ERROR_PROCESSING_DATA = "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";


    @Override
    public JSONArray getAvailability(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap, String epmPrefix) throws JsonProcessingException {
        String startDate = null;
        String endDate = null;
        try {
            startDate = convertDateFormat(availabilityRequest.getStartDate(),DATE_FORMAT,ATHENA_DATE_FORMAT);
            endDate = convertDateFormat(availabilityRequest.getEndDate(),DATE_FORMAT, ATHENA_DATE_FORMAT);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        if (availabilityRequest.getIndex().equals(valueOf(FIRST_INDEX))) {
            trackEvents.trackEvent(availabilityRequest, OPEN_APPOINTMENT_PROCESSING_STARTED,
                    format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
                    getFragmentsDetails(availabilityRequest, providerLocationMap));
        }
        return fetchOpenAppointments(startDate, endDate, providerLocationMap,
                availabilityRequest,epmPrefix);
    }

    public JSONArray fetchOpenAppointments(String startDate, String endDate, Map<String,
            JSONArray> providerLocationMap, AvailabilityRequest availabilityRequest,String epmPrefix) {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray locationList = new JSONArray();
        if (nonNull(availabilityRequest.getEntityId())) {
            JSONArray providers = new JSONArray(availabilityRequest.getEntityId().toString());
            locationList.putAll(providers);
        } else {
            locationList = providerLocationMap.get(LOCATION_ID_LIST);
        }
        try {
            JSONObject inputObject = getInputObject(startDate, endDate, locationList,
                    availabilityRequest.getDeploymentId(),providerLocationMap.get(PROVIDER_ID_LIST).optString(0),epmPrefix);
            getOpenAppointment(athenaApiCaller, inputObject,availabilityRequest);
        } catch (InvalidIdException e) {
            String message = format("Error", startDate, endDate, e.getMessage());
            log.error(message);
        } catch (EpmApiCallerException | InvalidResourceException | IHubException ee) {
            String message = "Error in getting the open appointment slot " + ee.getMessage();
            log.error(message);
            trackBookedFragmentError(availabilityRequest, trackEvents, message);
        }
        return openAppointmentsArray;
    }

    private void getOpenAppointment(AthenaApiCaller athenaApiCaller, JSONObject inputParam, AvailabilityRequest availabilityRequest) throws InvalidResourceException, IHubException {
        String providerId = inputParam.optString(PROVIDER_ID);
        String cacheKeyValue = inputParam.getString(DEPLOYMENT_ID) + ":" + providerId;
//        if (dataCacheManager.isInvalidResourceDataInCache(cacheKeyValue)) {
//            String message = "INVALID OPEN RESOURCE: " + providerId;
//            trackInvalidOpenFragmentError(availabilityRequest, trackEvents, message, providerId);
//            throw new InvalidResourceException("Invalid Open Appointment");
//        }
        try {
            boolean isOrgConfigTrue = "true".equalsIgnoreCase(inputParam.optString(REASON_MAP_EXIST));
            if (isOrgConfigTrue) {
                String configuredPoolSize = inputParam.optString(MAX_POOL_SIZE);
                int maxPoolSize = !isEmpty(configuredPoolSize) ? parseInt(configuredPoolSize) : inputParam.optInt(THREAD_SIZE);
                ExecutorService executorService = newFixedThreadPool(maxPoolSize);
                JSONArray patientApptReasonsArray = getVisitReasonArray(athenaApiCaller, inputParam);

                if (!NullChecker.isEmpty(patientApptReasonsArray) && !patientApptReasonsArray.isEmpty()) {
                    try {
                        List<CompletableFuture<Void>> openApptFutureList = new ArrayList<>();
                        for (Object patientApptReason : patientApptReasonsArray) {
                            JSONObject patientApptReasonObj = (JSONObject) patientApptReason;
                            JSONObject inputObject = new JSONObject();
                            providerId = patientApptReasonObj.getString(PROVIDER_ID);
                            inputObject.put(APPT_LOCATION_ID, patientApptReasonObj.getString(LOCATION_ID));
                            inputObject.put(APPT_RESOURCE_ID, providerId);
                            inputObject.put(REASON_ID, patientApptReasonObj.getString(VISIT_REASONS));
                            inputObject.put(DEPLOYMENT_ID, inputParam.optString(DEPLOYMENT_ID));
                            inputObject.put(STARTDATE, inputParam.getString(STARTDATE));
                            inputObject.put(ENDDATE, inputParam.getString(ENDDATE));
                            inputObject.put(ATHENA_PRACTICE_ID, inputParam.optString(ATHENA_PRACTICE_ID));
                            inputObject.put(IGNORE_SHCED_PERMISSION, inputParam.optString(IGNORE_SHCED_PERMISSION));
                            JSONObject openAppointmentRequest = getInputObject(inputObject);
                            openAppointmentRequest.put("deploymentId",availabilityRequest.getDeploymentId());


                            openApptFutureList.add(CompletableFuture.supplyAsync(
                                    new PrepareOpenSlotsTask(athenaApiCaller,iHubDataServiceDelegator, openAppointmentRequest, fileUploader, trackEvents,
                                            isOrgConfigTrue, inputParam, availabilityRequest, providerId),
                                    executorService));
                        }
                        CompletableFuture<Void> openApptAllFutures = CompletableFuture
                                .allOf(openApptFutureList.toArray(new CompletableFuture[openApptFutureList.size()]));

                        CompletableFuture<List<Void>> openApptAllCompletableFuture =
                                openApptAllFutures.thenApply(future -> openApptFutureList.stream()
                                        .map(CompletableFuture<Void>::join).collect(Collectors.toList()));

                        CompletableFuture<List<Void>> openApptCompletableFuture =
                                openApptAllCompletableFuture.toCompletableFuture();
                        openApptCompletableFuture.get();
                    } catch (InterruptedException e) {
                        log.error("Error in getting the slotId " + e.getMessage());
                    } catch (ExecutionException e) {
                        log.error("Error in getting the slotId " + e.getMessage());
                    } finally {
                        executorService.shutdown();
                    }
                }
            } else {
                JSONObject openAppointmentRequest = getInputObject(inputParam);
                openAppointmentRequest.put("deploymentId",availabilityRequest.getDeploymentId());
                new PrepareOpenSlotsTask(athenaApiCaller, iHubDataServiceDelegator, openAppointmentRequest, fileUploader, trackEvents,
                        isOrgConfigTrue, inputParam, availabilityRequest, providerId).get();
            }
        } catch (InvalidIdException ide) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, inputParam.getString(STARTDATE), inputParam.getString(ENDDATE), providerId, ide.getMessage());
            log.error(escapeJava(exceptionDetails));
            trackOpenFragmentError(availabilityRequest, trackEvents, providerId, exceptionDetails);
            throw new EpmApiCallerException(exceptionDetails);
        } catch (EpmApiCallerException ee) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, inputParam.getString(STARTDATE), inputParam.getString(ENDDATE), providerId, ee.getMessage());
            log.error(escapeJava(exceptionDetails));
            trackOpenFragmentError(availabilityRequest, trackEvents, providerId, exceptionDetails);
            throw new EpmApiCallerException(exceptionDetails);
        } catch (IHubException exception) {
            String message = "Invalid Open Resource";
//            cacheService.updateInvalidResourceCache(cacheKeyValue, cacheKeyValue);
            trackInvalidOpenFragmentError(availabilityRequest, trackEvents, message, providerId);
            throw exception;
        }
    }

    public JSONObject getInputObject(JSONObject inputParam) {
        JSONObject openAppointmentRequest = new JSONObject();
        JSONObject providerObj = new JSONObject();
        JSONObject provider = new JSONObject();
        if(inputParam.has("departmentid")){
            String locationId = getLocationIdStr(inputParam.getJSONArray("departmentid"));
            providerObj.put(LOCATION_ID, locationId);
            JSONArray providerArray = new JSONArray();
            providerArray.put(providerObj);
            provider.put("Provider", providerArray);
        }

        JSONObject tempObj = new JSONObject();
        tempObj.put("start_date", inputParam.getString(STARTDATE));
        tempObj.put("end_date", inputParam.getString(ENDDATE));
        tempObj.put("practice_id", inputParam.optString(ATHENA_PRACTICE_ID));
        tempObj.put(REASON_ID, inputParam.optString(REASON_ID));
        tempObj.put(IGNORE_SHCED_PERMISSION, inputParam.optString(IGNORE_SHCED_PERMISSION));
        if(inputParam.has(APPT_RESOURCE_ID)){
            providerObj = new JSONObject();
            providerObj.put(LOCATION_ID, inputParam.optString(APPT_LOCATION_ID));
            providerObj.put("ResourceId", inputParam.optString(APPT_RESOURCE_ID));
            JSONArray providerArray = new JSONArray();
            providerArray.put(providerObj);
            provider.put("Provider", providerArray);
        }
        if(inputParam.has(LIMIT)){
            tempObj.put(LIMIT, inputParam.optString(LIMIT));
        }
        openAppointmentRequest.put("SchedulingData", provider);
        openAppointmentRequest.put("temp", tempObj);
        return openAppointmentRequest;
    }

    public static String getLocationIdStr(JSONArray array) {
        StringBuilder providerIdStr = new StringBuilder();
        for (Object item : array) {
            if (providerIdStr.toString().isEmpty()) {
                providerIdStr = providerIdStr.append(item);
            } else providerIdStr = providerIdStr.append("," + item);
        }
        return providerIdStr.toString();
    }

    private JSONObject getInputObject(String startDate, String endDate, JSONArray locations, String deploymentId,String providerId, String epmPrefix) throws IHubException {
        JSONObject inputParameter = new JSONObject();
        inputParameter.put(STARTDATE, startDate);
        inputParameter.put(ENDDATE, endDate);
        inputParameter.put(APPOINTMENT_PATH, "appointment/");
        inputParameter.put(ATHENA_PRACTICE_ID, dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, ATHENA_PRACTICE_ID));
        inputParameter.put(PRACTICE_ID, dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, PRACTICE_ID));
        inputParameter.put(DEPLOYMENT_ID, deploymentId);
        inputParameter.put(REASON_ID, "-1");
        inputParameter.put(LIMIT, dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, BS_LIMIT));
        inputParameter.put(IGNORE_SHCED_PERMISSION, dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, WEB_SCHEDILABLE_FLAG));
        inputParameter.put(DEPARTMENT_ID, locations);
        inputParameter.put(THREAD_SIZE, threadSize);
        inputParameter.put(FILTER_CONFIG,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, FILTER_CONFIG));
        inputParameter.put(MAX_POOL_SIZE,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, MAX_POOL_SIZE));
        inputParameter.put(GENERIC_APPT_TYPE,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, GENERIC_APPT_TYPE));
        inputParameter.put(REASON_MAP_EXIST,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, REASON_MAP_EXIST));
        inputParameter.put(USE_LOCAL_PROVIDER,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, USE_LOCAL_PROVIDER));
        inputParameter.put(FILTER_DATA,dataCacheManager.getConfiguration(epmPrefix, deploymentId, ATHENA_CONFIG, FILTER_DATA));
        inputParameter.put(LOCATION_PROVIDER_FILTER,dataCacheManager.getStoredProvidersConfig(epmPrefix, deploymentId, FILTER_CONFIG, LOCATION_PROVIDER_FILTER,false));
        inputParameter.put(PROVIDER_ID,providerId);
        return inputParameter;
    }

    private JSONObject getRealTimeInputObject(RealTimeRequest realTimeRequest, JSONObject provLocObj) throws IHubException {
        JSONObject inputParameter = new JSONObject();
        inputParameter.putOpt(APPT_LOCATION_ID, provLocObj.opt("locationId"));
        inputParameter.putOpt(APPT_RESOURCE_ID, provLocObj.opt("providerId"));
        inputParameter.putOpt(REASON_ID, provLocObj.opt("reasonId"));
        inputParameter.put(DEPLOYMENT_ID, realTimeRequest.getDeploymentId());
        inputParameter.put(STARTDATE, realTimeRequest.getStartDate());
        inputParameter.put(ENDDATE, realTimeRequest.getEndDate());
        inputParameter.put(ATHENA_PRACTICE_ID, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, realTimeRequest.getDeploymentId(), ATHENA_CONFIG, ATHENA_PRACTICE_ID));
        inputParameter.put(IGNORE_SHCED_PERMISSION, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, realTimeRequest.getDeploymentId(), ATHENA_CONFIG, WEB_SCHEDILABLE_FLAG));
        if (realTimeRequest.getFlow() != null) {
            inputParameter.put(IS_MINIBASELINE, realTimeRequest.getFlow().equalsIgnoreCase("MiniBaseline") ? "true" : "false");
        }
        return inputParameter;
    }


    private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest,
                                                    Map<String, JSONArray> providerLocationMap) {
        Map<String, Object> providerDetails = new HashMap<>();
        providerDetails.put(TOTAL_FRAGMENTS, "1");
        put(TOTAL_FRAGMENTS, "1");
        providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        return providerDetails;
    }

    public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
        JSONArray openAppointmentsArray = new JSONArray();
        if (nonNull(realTimeRequest.getEntityId())) {
            List<Object> list = (List<Object>) realTimeRequest.getEntityId();
            try {
                JSONArray providerLocList =
                        new JSONArray(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(list));
                providerLocList.forEach(obj -> {
                    JSONObject inputParam = null;
                    try {
                        inputParam = getRealTimeInputObject(realTimeRequest, new JSONObject(obj.toString()));
                    } catch (IHubException e) {
                        metricRealTimeErrorCount(engineName, appDescription, "realTimeAvailability- " + e.getMessage());
                        throw new RuntimeException(e);
                    }
//                    String token = tokenService.getToken(realTimeRequest.getDeploymentId(), configurationData);
//                    AthenaApiCaller athenaAdapter = getAthenaAdapter(configurationData, athenaRestClientHelper, realTimeRequest.getDeploymentId(), token);
                    openAppointmentsArray.putAll(
                            new RealTimeOpenSlotsTask( athenaApiCaller,inputParam,engineName,appDescription).get());
                });
            } catch (JSONException | JsonProcessingException e) {
                log.error("error in getting provider/location list from request {} ", e.getMessage());
                metricRealTimeErrorCount(engineName, appDescription, "realTimeAvailability- " + e.getMessage());
                throw new EpmApiCallerException(
                        "error in getting provider/location list from request " + e.getMessage());
            }
        }
        return getOpenAppointmentObject(openAppointmentsArray, realTimeRequest);
    }
}