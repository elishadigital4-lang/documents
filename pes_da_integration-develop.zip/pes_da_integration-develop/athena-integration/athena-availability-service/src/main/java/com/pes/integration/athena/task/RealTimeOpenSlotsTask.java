package com.pes.integration.athena.task;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.text.ParseException;
import java.util.Map;
import java.util.function.Supplier;

import static com.pes.integration.athena.constant.AthenaConstants.REASON_ID;
import static com.pes.integration.athena.util.AthenaUtil.openAppointments;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.MdcUtil.setContext;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeErrorCount;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.String.format;
import static java.util.Objects.nonNull;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class RealTimeOpenSlotsTask implements Supplier<JSONArray> {

    private static final String ERROR_PROCESSING_DATA = "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";

    private String startDate;
    private String endDate;
    private String providerId;
    private JSONObject inputParam;
    private AthenaApiCaller athenaApiCaller;
    private Map<String, String> contextMap = getCopyOfContextMap();

    private static String engineName;

    private static String appDescription;

    public RealTimeOpenSlotsTask(AthenaApiCaller athenaApiCaller,JSONObject inputObject,String engineName,String appDescription) {
        this.startDate = inputObject.getString(STARTDATE);
        this.endDate = inputObject.getString(ENDDATE);
        this.athenaApiCaller=athenaApiCaller;
        this.inputParam = inputObject;
        this.engineName = engineName;
        this.appDescription = appDescription;

    }

    @Override
    public JSONArray get() {
        setContext(contextMap);
        JSONArray openAppointmentsArray = new JSONArray();
        try {
            JSONObject responseObject = openAppointments(athenaApiCaller,inputParam);

            if (!isEmpty(responseObject)) {
                openAppointmentsArray.putAll(extractSlots(responseObject,inputParam));
            }

        } catch (InvalidIdException ide) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ide.getMessage());
            log.error(escapeJava(exceptionDetails));
            metricRealTimeErrorCount(engineName, appDescription, escapeJava(exceptionDetails));
            throw new EpmApiCallerException(exceptionDetails);
        } catch (EpmApiCallerException | InvalidResourceException | IHubException ee) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ee.getMessage());
            log.error(escapeJava(exceptionDetails));
            metricRealTimeErrorCount(engineName, appDescription, escapeJava(exceptionDetails));
            throw new EpmApiCallerException(exceptionDetails);
        }
        return openAppointmentsArray;
    }

    public static JSONArray extractSlots(JSONObject outputObject, JSONObject inputParam) {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray appointmentsArray = outputObject.optJSONArray(OPEN_APPOINTMENTS);
        if (nonNull(appointmentsArray)) {
            appointmentsArray.forEach(appointmentObject -> {
                JSONObject apptObject = new JSONObject(appointmentObject.toString());
                try {
                    openAppointmentsArray.put(transformOpenAppointment(apptObject,inputParam));
                } catch (ParseException e) {
                    metricRealTimeErrorCount(engineName, appDescription, e.getMessage());
                    throw new RuntimeException(e);
                }
            });
        }
        return openAppointmentsArray;
    }


    public static JSONObject transformOpenAppointment(JSONObject appointmentObject,JSONObject inputParam) throws ParseException {
        JSONObject openAppointment = new JSONObject();
        openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
        openAppointment.put("duration", appointmentObject.opt("Duration"));
        openAppointment.put("slotId", appointmentObject.opt("SlotId"));
        openAppointment.put(LOCATION_ID_KEY, appointmentObject.opt(LOCATION_ID));
        openAppointment.put(PROVIDER_ID_KEY, appointmentObject.opt("ProviderId"));
        openAppointment.put(REASON_ID_KEY, inputParam.optString(REASON_ID));
        String startTime = (String) appointmentObject.optJSONObject("temp").opt("start_time");
        String startDate = (String) appointmentObject.optJSONObject("temp").opt("start_date");
        openAppointment.put(START_TIME,
                convertDateFormat(startTime.trim(),"HH:mm", DOCASAP_TIME_FORMAT));
        openAppointment.put(DATE_KEY, convertDateFormat(startDate.trim(), "MM/dd/yyyy", DATE_TIME_FORMAT));

        return openAppointment;
    }
}
