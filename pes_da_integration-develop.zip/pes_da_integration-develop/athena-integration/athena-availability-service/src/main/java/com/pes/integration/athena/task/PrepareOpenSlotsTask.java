package com.pes.integration.athena.task;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.athena.util.AthenaUtil;
import com.pes.integration.component.EventTracker;
import com.pes.integration.constant.EpmConstant;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Supplier;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.athena.api.ApiName.GET_APPOINTMENT_TYPES;
import static com.pes.integration.athena.api.ApiName.GET_PROVIDERS;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.EPM_CONFIG_GROUPS;
import static com.pes.integration.athena.util.AthenaUtil.extractOpenSlotsFromResponse;
import static com.pes.integration.athena.util.AthenaUtil.trackEventToNifi;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.CharacterConstants.COMMA;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_TYPES;
import static com.pes.integration.constant.DocASAPConstants.Key.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.MESSAGE_CONTROL_ID;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.String.format;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class PrepareOpenSlotsTask implements Supplier<Void> {

    private static final String ERROR_PROCESSING_DATA =
            "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";


    private String startDate;
    private String endDate;
    private String providerId;
    private boolean isOrgConfigTrue;
    private String dataLocation;
    private EventTracker trackEvents;
    private FileUploader fileUploader;
    private AthenaApiCaller athenaApiCaller;
    private AvailabilityRequest availabilityRequest;
    private JSONObject openAppointmentRequest;
    private JSONObject inputParam;
    private Map<String, String> contextMap = getCopyOfContextMap();

    private IHubDataServiceDelegator iHubDataServiceDelegator;

    public PrepareOpenSlotsTask(AthenaApiCaller athenaApiCaller, IHubDataServiceDelegator iHubDataServiceDelegator, JSONObject openAppointmentRequest, FileUploader fileUploader,
                                EventTracker trackEvents, boolean isOrgConfigTrue, JSONObject inputParam,
                                AvailabilityRequest availabilityRequest, String providerId) {
        this.startDate = inputParam.getString(STARTDATE);
        this.endDate =  inputParam.getString(ENDDATE);
        this.athenaApiCaller = athenaApiCaller;
        this.fileUploader = fileUploader;
        this.dataLocation = "appointment/";
        this.trackEvents = trackEvents;
        this.openAppointmentRequest = openAppointmentRequest;
        this.inputParam = inputParam;
        this.isOrgConfigTrue = isOrgConfigTrue;
        this.iHubDataServiceDelegator=iHubDataServiceDelegator;
        this.availabilityRequest = availabilityRequest;
        this.providerId = providerId;
    }

    @Override
    public Void get() {
        setContext(contextMap);
        Map<String, File> appointmentDataFiles = new HashMap<>();
        try {
            JSONObject openApptOutput = getOpenAppointment();
            uploadFiles(appointmentDataFiles, openApptOutput);
            trackEventToNifi(trackEvents, availabilityRequest,
                    getOpenDataFlowNifiStatus(availabilityRequest), MDC.get(TOTAL_FRAGMENTS), providerId,
                    createNifiErrorPayload(getNifiPayload()));
        } catch (EpmApiCallerException | IHubException ee) {
            log.error("Error in getting the open slotId " + ee.getMessage());
        } finally {
            deleteFiles(appointmentDataFiles);
        }
        return null;
    }


    public JSONObject getOpenAppointment() throws IHubException {

        JSONArray openAppointmentsArray = new JSONArray();
        JSONObject outputObject = new JSONObject();
        try {
            outputObject  = athenaApiCaller.call(ApiName.OPEN_APPOINTMENTS.getKey(), openAppointmentRequest,"");
        } catch (EpmApiCallerException | IHubException ee) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ee.getMessage());
            log.error(escapeJava(exceptionDetails));
            trackOpenFragmentError(availabilityRequest, trackEvents, providerId, exceptionDetails);
            throw new EpmApiCallerException(exceptionDetails);
        }
        if (!isEmpty(outputObject)) {
            openAppointmentsArray.putAll(extractOpenSlotsFromResponse(outputObject, isOrgConfigTrue, athenaApiCaller, inputParam));
        }
        openAppointmentsArray = AthenaUtil.applyFilter(openAppointmentsArray, inputParam);
        String currentDate = new SimpleDateFormat(ATHENA_DATE_FORMAT).format(new Date());
        int diff = DateUtils.getDateDiff(currentDate, startDate, ATHENA_DATE_FORMAT);
        JSONArray apptTypes = null;
        JSONArray resources = null;
        if (diff < 1) {
            // Add appointment types to database and get array back to add to baseline
            apptTypes = addGenericAppointmentTypesToDB();
            // Add resources (providers) to baseline
            resources = getProviders();
        }
        JSONObject openApptOutput = getOpenAppointmentObject(openAppointmentsArray, apptTypes, resources);
        return openApptOutput;
    }

    protected JSONArray addGenericAppointmentTypesToDB() throws IHubException {
        String genApptType = inputParam.optString(GENERIC_APPT_TYPE);
        JSONObject appointmentTypeRequest = new JSONObject();
        appointmentTypeRequest.put(DEPLOYMENT_ID, inputParam.getString(EpmConstant.DEPLOYMENT_ID));
        JSONObject temObj = new JSONObject();
        temObj.put("practice_id", inputParam.optString(ATHENA_PRACTICE_ID));
        appointmentTypeRequest.put("temp", temObj);
        JSONObject outputObject = athenaApiCaller.call(GET_APPOINTMENT_TYPES.getKey(), appointmentTypeRequest,"");
        JSONArray apptTypes = null;
        if (outputObject.has(APPOINTMENT_TYPES)) {
            apptTypes = outputObject.getJSONArray(APPOINTMENT_TYPES);
        }
        //If Generic appointment types - genapptype config not present for org add during baseline: IHUB-5601
        if (NullChecker.isEmpty(genApptType) || genApptType.isEmpty()) {
            List<String> apptTypeIdList = new ArrayList<>();
            for (Object apptType : apptTypes) {
                JSONObject apptTypeObj = (JSONObject) apptType;
                if (apptTypeObj.has(IS_GENERIC)
                        && apptTypeObj.getString(IS_GENERIC).equalsIgnoreCase(TRUE_STR)
                        && apptTypeObj.has(APPOINTMENT_TYPE_ID)) {
                    apptTypeIdList.add(apptTypeObj.getString(APPOINTMENT_TYPE_ID));
                }
            }
            // put if block here to check if config present in DB
            String genApptTypeIds = BLANK;
            if (!NullChecker.isEmpty(apptTypeIdList)) {
                genApptTypeIds = StringUtils.join(apptTypeIdList, COMMA);
            }

            JSONObject saveConfigJson = new JSONObject();
            JSONObject data = new JSONObject();
            JSONObject orgDetails = new JSONObject();
            orgDetails.put("deployment_id", inputParam.optString(EpmConstant.DEPLOYMENT_ID));
            List<String> configGroupNames = Arrays.asList(StringUtils.split(EPM_CONFIG_GROUPS, COMMA));
            orgDetails.put(CONFIG_GROUP_NAMES, configGroupNames);
            data.put(ORG_DETAILS, orgDetails);
            JSONObject orgConfigs = new JSONObject();
            orgConfigs.put(GENERIC_APPT_TYPE, genApptTypeIds);
            data.put(ORG_CONFIGS, orgConfigs);
            saveConfigJson.put(DATA, data);
            iHubDataServiceDelegator.iHubAddUpdateOrg(saveConfigJson.toString());
        }
        return apptTypes;
    }

    protected JSONArray getProviders() {
        JSONArray providers = new JSONArray();
        JSONObject tempOutputObject;
        JSONObject tempInputObject = new JSONObject();
        JSONObject temObj = new JSONObject();
        temObj.put("practice_id", inputParam.optString(ATHENA_PRACTICE_ID));
        tempInputObject.put("temp", temObj);
        tempInputObject.put(DEPLOYMENT_ID, inputParam.getString(EpmConstant.DEPLOYMENT_ID));
        try {
            tempOutputObject = athenaApiCaller.call(GET_PROVIDERS.getKey(), tempInputObject,"");
            providers = tempOutputObject.optJSONArray(PROVIDERS);
        } catch (Exception e) {
            log.error("Could not add providers (resources) to baseline data.");
            log.error(e.getMessage());
        }
        return providers;
    }

    private JSONObject getOpenAppointmentObject(JSONArray openAppointmentsArray, JSONArray apptTypes, JSONArray resources) {
        JSONObject openApptOutput = new JSONObject();
        openApptOutput.put(DEPLOYMENTID, availabilityRequest.getDeploymentId());
        openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
        openApptOutput.put(TOTAL_COUNT, openAppointmentsArray.length());
        openApptOutput.put(DATA, openAppointmentsArray);
        openApptOutput.put(APPOINTMENT_TYPES, apptTypes);
        openApptOutput.put(RESOURCES, resources);
        return openApptOutput;
    }

    private void uploadFiles(Map<String, File> appointmentDataFiles, JSONObject openApptOutput) {
        appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
                prepareOpenAppointmentFile(openApptOutput, availabilityRequest));
        fileUploader.uploadFile(availabilityRequest.getMessageControlId(), availabilityRequest.getAppointmentType(),
                availabilityRequest.getSliceId() + SLASH + providerId,
                appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    }

    private File prepareOpenAppointmentFile(JSONObject apptresponse, AvailabilityRequest availabilityRequest) {
        return prepareFile(
                apptresponse.toString(), dataLocation + availabilityRequest.getMessageControlId() + SLASH
                        + availabilityRequest.getSliceId() + SLASH + providerId,
                SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
    }

    private JSONObject getNifiPayload() {
        JSONObject nifiObject = new JSONObject();
        nifiObject.put(STARTDATE, startDate);
        nifiObject.put(ENDDATE, endDate);
        nifiObject.put(FRAGMENT_ID_KEY, providerId);
        return nifiObject;
    }

}
