package com.pes.integration.athena.util;

import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;

import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;

@Slf4j
public class EPMFilter {

    private static EPMFilter epmFilterInstance = null;


    public static EPMFilter getInstance() {
        if (epmFilterInstance == null) {
            epmFilterInstance = new EPMFilter();
        }
        return epmFilterInstance;
    }


    public boolean isAllowed(String locationId, String providerId, JSONObject inputObject) {
        boolean isAllowed = false;
        JSONObject filterJson = null;
        JSONArray provFilterArray = null;
        JSONArray locFilterArray = null;
        JSONArray locProvfilterArray = null;
        try {
            Object filterObj = null;
            try {
                filterObj = inputObject.get(FILTER_CONFIG);
            } catch (Exception e) {
                //Allow all in case of exception.
            }
            if (!NullChecker.isEmpty(filterObj)) {
                filterJson = (JSONObject) filterObj;
                if (filterJson.has(LOCATION_PROVIDER_FILTER)) {
                    JSONObject locProvfilterJson = filterJson.getJSONObject(LOCATION_PROVIDER_FILTER);
                    locProvfilterArray = locProvfilterJson.getJSONArray(LOCATION_PROVIDER_FILTER);
                    isAllowed = getAllowedLocationProviders(locProvfilterArray, locationId, providerId);
                }
                if (!isAllowed && filterJson.has(PROVIDER_FILTER)) {
                    JSONObject provfilterJson = filterJson.getJSONObject(PROVIDER_FILTER);
                    provFilterArray = provfilterJson.getJSONArray(PROVIDER_FILTER);
                    isAllowed = getAllowedProviders(provFilterArray, providerId);
                }
                if (!isAllowed && filterJson.has(LOCATION_FILTER)) {
                    JSONObject locfilterJson = filterJson.getJSONObject(LOCATION_FILTER);
                    locFilterArray = locfilterJson.getJSONArray(LOCATION_FILTER);
                    isAllowed = getAllowedLocations(locFilterArray, locationId);
                }
            } else {
                isAllowed = true;
            }

            if (NullChecker.isEmpty(locProvfilterArray) && NullChecker.isEmpty(provFilterArray) && NullChecker.isEmpty(locFilterArray)) {
                isAllowed = true;
            }

        } catch (Exception e) {
            isAllowed = true;
        }
        return isAllowed;
    }


    private static boolean getAllowedLocationProviders(JSONArray locProvfilterArray, String locationId, String providerId) {
        for (int i = 0; i < locProvfilterArray.length(); i++) {
            JSONObject filterObject = locProvfilterArray.getJSONObject(i);

            String allowedProviderId = BLANK;
            String allowedLocationId = BLANK;

            if (filterObject.has(PROVIDER_ID)) {
                allowedProviderId = filterObject.getString(PROVIDER_ID);
            }
            if (filterObject.has(LOCATION_ID)) {
                allowedLocationId = filterObject.getString(LOCATION_ID);
            }
            if (!allowedProviderId.equals(BLANK)
                    && allowedProviderId.equals(providerId)
                    && !allowedLocationId.equals(BLANK)
                    && allowedLocationId.equals(locationId)) {
                return true;
            }
        }
        return false;
    }

    private static boolean getAllowedProviders(JSONArray provFilterArray, String providerId) {
        for (int i = 0; i < provFilterArray.length(); i++) {
            JSONObject filterObject = provFilterArray.getJSONObject(i);

            String allowedProviderId = BLANK;

            if (filterObject.has(PROVIDER_ID)) {
                allowedProviderId = filterObject.getString(PROVIDER_ID);
            }
            if (!allowedProviderId.equals(BLANK) && allowedProviderId.equals(providerId)) {
                return true;
            }
        }
        return false;
    }

    private static boolean getAllowedLocations(JSONArray locFilterArray, String locationId) {
        for (int i = 0; i < locFilterArray.length(); i++) {
            JSONObject filterObject = locFilterArray.getJSONObject(i);

            String allowedLocationId = BLANK;

            if (filterObject.has(LOCATION_ID)) {
                allowedLocationId = filterObject.getString(LOCATION_ID);
            }
            if (!allowedLocationId.equals(BLANK) && allowedLocationId.equals(locationId)) {
                return true;
            }
        }
        return false;
    }
}