package com.pes.integration.athena.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.athena.service.open.OpenAppointmentServiceImpl;
import com.pes.integration.dto.EngineAppInfo;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.service.AvailabilityOperations;
import jakarta.validation.Valid;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.utils.MetricsUtil.*;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
public class AvailabilityController implements AvailabilityOperations {

    public static final String GET_REAL_TIME_DATA = "getRealTimeData";
    public static final String GET_REAL_TIME_MINI_BASELINE_DATA = "getRealTimeMiniBaselineData";
    @Autowired
    private OpenAppointmentServiceImpl openAppointmentService;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;
    @Override
    public ResponseEntity<Object> getRealTimeData(@Valid RealTimeRequest realTimeRequest)
            throws JsonProcessingException {
        metricRealTimeRequestCount(engineName, appDescription, GET_REAL_TIME_DATA);
        AvailabilityOperations.validateInput(realTimeRequest,new EngineAppInfo(engineName, appDescription));
        JSONObject openAppointments = openAppointmentService.getRealTimeAvailability(realTimeRequest);
        metricRealTimeSuccessCount(engineName, appDescription, GET_REAL_TIME_DATA);

        return new ResponseEntity<>(openAppointments.toString(), OK);
    }


    @PostMapping(value = "/minibaseline", consumes = APPLICATION_JSON_VALUE,
            produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getRealTimeDataBaseline(@Valid @RequestBody RealTimeRequest realTimeRequest)
            throws JsonProcessingException {
        String deploymentId = realTimeRequest.getDeploymentId() != null ? realTimeRequest.getDeploymentId() : EMPTY;
        String requestType = realTimeRequest.getRequestType() != null ? realTimeRequest.getRequestType() : EMPTY;
        metricRealTimeRequestCountWithDeploymentId(engineName, appDescription,deploymentId,requestType, GET_REAL_TIME_MINI_BASELINE_DATA);
        AvailabilityOperations.validateInput(realTimeRequest,new EngineAppInfo(engineName, appDescription));
        JSONObject openAppointments = openAppointmentService.getRealTimeAvailability(realTimeRequest);
        metricRealTimeSuccessCountWithDeploymentId(engineName, appDescription,deploymentId,requestType, GET_REAL_TIME_MINI_BASELINE_DATA);

        return new ResponseEntity<>(openAppointments.toString(), OK);
    }
}