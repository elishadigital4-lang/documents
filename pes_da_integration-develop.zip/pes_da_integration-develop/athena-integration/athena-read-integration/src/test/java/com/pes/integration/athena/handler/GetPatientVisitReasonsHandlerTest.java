package com.pes.integration.athena.handler;

import static com.pes.integration.constant.DocASAPConstants.Key.ID;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATION_PROVIDER_FILTER;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PRACTICE_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.lang.reflect.Method;

class GetPatientVisitReasonsHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private AthenaConfigCache athenaConfigCache;

    @InjectMocks
    private GetPatientVisitReasonsHandler getPatientVisitReasonsHandler;

    @BeforeEach
    void setUp() {

        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getLocations_logsErrorOnException() throws Exception {
        GetPatientVisitReasonsHandler handler = new GetPatientVisitReasonsHandler();
        java.lang.reflect.Field handlerUtilsField = GetPatientVisitReasonsHandler.class.getDeclaredField("handlerUtils");
        handlerUtilsField.setAccessible(true);
        HandlerUtils mockHandlerUtils = mock(HandlerUtils.class);
        when(mockHandlerUtils.getLocationList(any())).thenThrow(new RuntimeException("Test Exception"));
        handlerUtilsField.set(handler, mockHandlerUtils);

        JSONObject inputObject = new JSONObject();
        JSONArray result = null;
        // Should not throw, should log error
        java.lang.reflect.Method getLocationsMethod = GetPatientVisitReasonsHandler.class
                .getDeclaredMethod("getLocations", JSONArray.class, JSONObject.class);
        getLocationsMethod.setAccessible(true);
        result = (JSONArray) getLocationsMethod.invoke(handler, new JSONArray(), inputObject);

        assertNotNull(result);
    }

    @Test
    void pullPatientVisitReasonFromFilter_logsErrorOnException() throws Exception {
        GetPatientVisitReasonsHandler handler = new GetPatientVisitReasonsHandler();
        java.lang.reflect.Field athenaApiCallerField = GetPatientVisitReasonsHandler.class.getDeclaredField("athenaApiCaller");
        athenaApiCallerField.setAccessible(true);
        athenaApiCallerField.set(handler, mock(AthenaApiCaller.class));
        java.lang.reflect.Field handlerUtilsField = GetPatientVisitReasonsHandler.class.getDeclaredField("handlerUtils");
        handlerUtilsField.setAccessible(true);
        handlerUtilsField.set(handler, mock(HandlerUtils.class));
        java.lang.reflect.Field athenaConfigCacheField = GetPatientVisitReasonsHandler.class.getDeclaredField("athenaConfigCache");
        athenaConfigCacheField.setAccessible(true);
        athenaConfigCacheField.set(handler, mock(AthenaConfigCache.class));

        JSONArray locProvFilterArray = new JSONArray();
        locProvFilterArray.put(new JSONObject().put("dummy", "value")); // will cause NPE
        JSONObject inputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();

        java.lang.reflect.Method method = GetPatientVisitReasonsHandler.class.getDeclaredMethod(
                "pullPatientVisitReasonFromFilter", JSONArray.class, JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        // No assertion needed, just ensure no exception is thrown and log.error is called
        method.invoke(handler, locProvFilterArray, inputObject, outputObject);
    }

    @Test
    void doExecuteWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            String deploymentId = "testDeploymentId";
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn(deploymentId);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PRACTICE_ID))).thenReturn("testPracticeId");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject outputObject = new JSONObject();
            outputObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
            outputObject.put(UtilitiesConstants.LOCATION_ID, "location1");
            JSONArray locProvFilterArray = new JSONArray();
            locProvFilterArray.put(outputObject);
            when(handlerUtils.getFilterData(eq(deploymentId), eq(LOCATION_PROVIDER_FILTER))).thenReturn(locProvFilterArray);
            doNothing().when(handlerUtils).addPracticeId(deploymentId, inputObject);
            doNothing().when(athenaConfigCache).setVisitReasonArrayMap(anyString(), any());
            JSONObject toBeReturned = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jsonArray.put(new JSONObject().put(ID, "id"));
            toBeReturned.put(DocASAPConstants.Key.VISIT_REASONS, jsonArray);
            doReturn(toBeReturned).when(athenaApiCaller).call(eq(ApiName.GET_PATIENT_VISIT_REASONS.getKey()), any(), anyString());

            getPatientVisitReasonsHandler.doExecute(inputObject);

            verify(handlerUtils, times(1)).addPracticeId(deploymentId, inputObject);
            verify(handlerUtils, times(1)).getFilterData(deploymentId, LOCATION_PROVIDER_FILTER);
        }
    }

    @Test
    void doExecuteWithValidInput_2() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            String deploymentId = "testDeploymentId";
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn(deploymentId);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PRACTICE_ID))).thenReturn("testPracticeId");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.LOCATION_ID))).thenReturn("testLocationId");
            jsonUtilsMockedStatic.when(() -> JsonUtils.copyKey(eq(DocASAPConstants.Key.VISIT_REASONS), any(), any(JSONObject.class))).thenAnswer(invocation -> {
                System.out.println(invocation);
                return invocation;
            });

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject outputObject = new JSONObject();
            outputObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
            outputObject.put(UtilitiesConstants.LOCATION_ID, "location1");
            JSONArray locProvFilterArray = new JSONArray();
            locProvFilterArray.put(outputObject);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq("ProviderIdList"))).thenReturn(locProvFilterArray);
            when(handlerUtils.getFilterData(eq(deploymentId), eq(LOCATION_PROVIDER_FILTER))).thenReturn(null);
            doNothing().when(handlerUtils).addPracticeId(deploymentId, inputObject);
            doReturn(locProvFilterArray).when(handlerUtils).getLocationList(any());
            doNothing().when(athenaConfigCache).setVisitReasonArrayMap(anyString(), any());
            JSONObject toBeReturned = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            jsonArray.put(new JSONObject().put(ID, "id"));
            toBeReturned.put(DocASAPConstants.Key.VISIT_REASONS, jsonArray);
            doReturn(null).when(athenaApiCaller).call(eq(ApiName.GET_PATIENT_VISIT_REASONS.getKey()), any(), anyString());

            getPatientVisitReasonsHandler.doExecute(inputObject);

            verify(handlerUtils, times(1)).addPracticeId(deploymentId, inputObject);
            verify(handlerUtils, times(1)).getFilterData(deploymentId, LOCATION_PROVIDER_FILTER);
        }
    }

}