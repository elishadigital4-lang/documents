package com.pes.integration.athena.handler;

import static com.pes.integration.athena.constant.AthenaConstants.DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_TYPE;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.PhoneNumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

class ChangedPatientsHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    PatientNotificationPreferences patientNotificationPreferences;
    @InjectMocks
    private ChangedPatientsHandler changedPatientsHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void buildE2DSyncObject_handlesSetPatientNotificationPreferencesException() throws Exception {
        String deploymentId = "testDeploymentId";
        JSONArray patientArray = new JSONArray();
        JSONObject patientObject = new JSONObject();
        patientObject.put("PATIENT_ID", "patient1");
        patientArray.put(patientObject);

        JSONObject demographics = new JSONObject();
        demographics.put("DOB", "1980-01-01");
        when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq("E2D")))
                .thenReturn(demographics);

        doNothing().when(handlerUtils).addPracticeId(anyString(), any());

        // Use reflection to inject a mock that throws an exception
        PatientNotificationPreferences mockPreferences = mock(PatientNotificationPreferences.class);
        doThrow(new RuntimeException("Test Exception")).when(mockPreferences).setPatientNotificationPreferences(any(JSONObject.class));
        Field field = ChangedPatientsHandler.class.getDeclaredField("patientNotificationPreferences");
        field.setAccessible(true);
        field.set(changedPatientsHandler, mockPreferences);

        JSONArray result = changedPatientsHandler.buildE2DSyncObject(patientArray, deploymentId);
        assertNotNull(result);
        assertEquals(1, result.length());
    }

    @Test
    void buildE2DSyncObject_handlesPhoneNumberUtilsException() throws Exception {
        String deploymentId = "testDeploymentId";
        JSONArray patientArray = new JSONArray();
        JSONObject patientObject = new JSONObject();
        patientObject.put("PATIENT_ID", "patient1");
        patientArray.put(patientObject);

        JSONObject demographics = new JSONObject();
        demographics.put("DOB", "1980-01-01");
        when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq("E2D")))
                .thenReturn(demographics);

        doNothing().when(handlerUtils).addPracticeId(anyString(), any());
        doNothing().when(patientNotificationPreferences).setPatientNotificationPreferences(any(JSONObject.class));

        try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class)) {
            phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any()))
                    .thenThrow(new com.pes.integration.exceptions.IHubException(null, "Phone error"));

            JSONArray result = changedPatientsHandler.buildE2DSyncObject(patientArray, deploymentId);
            assertNotNull(result);
            assertEquals(1, result.length());
        }
    }

    @Test
    void getChangedPatientsWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            String deploymentId = "testDeploymentId";
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject expectedResponse = new JSONObject();
            expectedResponse.put("result", "success");

            doNothing().when(handlerUtils).addPracticeId(anyString(), any());
            doReturn("testLocationId").when(handlerUtils).addLocationIdList(anyString(), any());
            when(athenaApiCaller.call(ApiName.CHANGED_PATIENTS.getKey(), inputObject, "E2D"))
                    .thenReturn(expectedResponse);

            JSONObject result = changedPatientsHandler.getChangedPatients(inputObject);

            assertNotNull(result);
            assertEquals("success", result.getString("result"));
            verify(handlerUtils, times(1)).addPracticeId(deploymentId, inputObject);
            verify(athenaApiCaller, times(1)).call(ApiName.CHANGED_PATIENTS.getKey(), inputObject, "E2D");
        }
    }

    @Test
    void buildE2DSyncObjectWithValidPatients() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class, CALLS_REAL_METHODS)) {
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("testPatientId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LANGUAGE_PREFERENCE))).thenReturn("US");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("patient123");
                    dateUtilsMockedStatic.when(() -> DateUtils.getDocasapDateTime(any(String.class), anyString())).thenReturn("2023-10-01T10:00:00");
                    dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DATE_FORMAT), eq(DOCASAP_DATE_FORMAT))).thenReturn("19900101");
                    phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any())).thenAnswer(invocation -> null);

                    String deploymentId = "testDeploymentId";
                    JSONArray patientArray = new JSONArray();
                    JSONObject patientObject = new JSONObject();
                    patientObject.put("PATIENT_ID", "patient1");
                    patientArray.put(patientObject);

                    JSONObject demographics = new JSONObject();
                    demographics.put("DOB", "1980-01-01");
                    when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq("E2D")))
                            .thenReturn(demographics);

                    doNothing().when(handlerUtils).addPracticeId(anyString(), any());
                    doNothing().when(patientNotificationPreferences).setPatientNotificationPreferences(any(JSONObject.class));

                    JSONArray result = changedPatientsHandler.buildE2DSyncObject(patientArray, deploymentId);
                    System.out.println(result);
                    assertNotNull(result);
                    assertEquals(1, result.length());
                    JSONObject resultPatient = result.getJSONObject(0);
                    assertEquals("patient1", resultPatient.getString("PATIENT_ID"));
                    assertEquals("UpdatePatient", resultPatient.getString("message_type"));
                    assertEquals("testDeploymentId", resultPatient.getString("deployment_id"));
                    assertEquals("19900101", resultPatient.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("DOB"));
                }
            }
        }
    }

    @Test
    void buildE2DSyncObjectWithException() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONArray patientArray = new JSONArray();
        JSONObject patientObject = new JSONObject();
        patientObject.put("PATIENT_ID", "patient1");
        patientArray.put(patientObject);

        when(athenaApiCaller.call(eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq("E2D")))
                .thenThrow(new IHubException(new IHubErrorCode("333"), "Error fetching demographics"));

        JSONArray result = changedPatientsHandler.buildE2DSyncObject(patientArray, deploymentId);

        assertNotNull(result);
        assertEquals(1, result.length());
    }

    @Test
    void applyFilter() {
        JSONArray patientArray = new JSONArray();
        patientArray.put(new JSONObject().put("PATIENT_ID", "patient1"));
        JSONArray jsonArray = changedPatientsHandler.applyFilter(patientArray);
        Assertions.assertEquals(patientArray.toString(), jsonArray.toString());
    }

    @Test
    void postE2DSyncAction() {
        JSONArray patientArray = new JSONArray();
        patientArray.put(new JSONObject().put("PATIENT_ID", "patient1"));
        Assertions.assertDoesNotThrow(() -> changedPatientsHandler.postE2DSyncAction(patientArray));
    }

    @Test
    void updateIsNewOrgConfig() {
        Assertions.assertDoesNotThrow(() -> changedPatientsHandler.updateIsNewOrgConfig());
    }

    @Test
    void isNewOrg() throws IHubException {
        Assertions.assertFalse(changedPatientsHandler.isNewOrg());
    }
}