package com.pes.integration.athena.handler;

import static com.pes.integration.athena.api.ApiName.GET_APPOINTMENT_TYPES;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PRACTICE_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;

class GetAppointmentTypesHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private AthenaConfigCache athenaConfigCache;

    @InjectMocks
    private GetAppointmentTypesHandler getAppointmentTypesHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_TYPE_ID))).thenReturn("type1");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_TYPE_DURATION))).thenReturn("40");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PRACTICE_ID))).thenReturn("testPracticeId");

            String deploymentId = "testDeploymentId";
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject outputObject = new JSONObject();
            JSONArray appointmentTypeArray = new JSONArray();
            JSONObject appointmentType = new JSONObject();
            appointmentType.put("APPOINTMENT_TYPE_ID", "type1");
            appointmentType.put("APPOINTMENT_TYPE_DURATION", "30");
            appointmentTypeArray.put(appointmentType);
            outputObject.put("APPOINTMENT_TYPES", appointmentTypeArray);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_TYPES))).thenReturn(appointmentTypeArray);

            doNothing().when(handlerUtils).addPracticeId(anyString(), any());
            when(athenaApiCaller.call(eq(GET_APPOINTMENT_TYPES.getKey()), any(), anyString())).thenReturn(outputObject);

            JSONObject result = getAppointmentTypesHandler.doExecute(inputObject);
            System.out.println(result);
            assertNotNull(result);
            assertEquals("type1", result.getJSONArray("APPOINTMENT_TYPES").getJSONObject(0).getString("APPOINTMENT_TYPE_ID"));
            assertEquals("30", result.getJSONArray("APPOINTMENT_TYPES").getJSONObject(0).getString("APPOINTMENT_TYPE_DURATION"));
            verify(athenaConfigCache, times(1)).setAppointmentTypeList(anyString(), anyMap());
        }
    }  @Test
    void doExecuteWithValidInput_Error() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_TYPE_ID))).thenReturn("type1");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_TYPE_DURATION))).thenReturn("40");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PRACTICE_ID))).thenReturn("testPracticeId");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.TempKey.ERROR_MESSAGE))).thenReturn("errorMessage");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.TempKey.ERROR_DETAIL))).thenReturn("errorDetails");

            String deploymentId = "testDeploymentId";
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject outputObject = new JSONObject();
            JSONArray appointmentTypeArray = new JSONArray();
            JSONObject appointmentType = new JSONObject();
            appointmentType.put("APPOINTMENT_TYPE_ID", "type1");
            appointmentType.put("APPOINTMENT_TYPE_DURATION", "30");
            appointmentTypeArray.put(appointmentType);
            outputObject.put("APPOINTMENT_TYPES", appointmentTypeArray);

            doNothing().when(handlerUtils).addPracticeId(anyString(), any());
            when(athenaApiCaller.call(eq(GET_APPOINTMENT_TYPES.getKey()), any(), anyString())).thenReturn(outputObject);

            JSONObject result = getAppointmentTypesHandler.doExecute(inputObject);
            System.out.println(result);
            assertNotNull(result);
            assertEquals("errorMessage", result.getString("error_message"));
            assertEquals("errorDetails", result.getString("error_detail"));
            assertEquals(400, result.getInt("error_code"));
            assertEquals("type1", result.getJSONArray("APPOINTMENT_TYPES").getJSONObject(0).getString("APPOINTMENT_TYPE_ID"));
            assertEquals("30", result.getJSONArray("APPOINTMENT_TYPES").getJSONObject(0).getString("APPOINTMENT_TYPE_DURATION"));
            verify(athenaConfigCache, times(0)).setAppointmentTypeList(anyString(), anyMap());
        }
    }

}