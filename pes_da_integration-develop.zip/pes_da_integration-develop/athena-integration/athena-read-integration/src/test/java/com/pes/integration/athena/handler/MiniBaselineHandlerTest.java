package com.pes.integration.athena.handler;

import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_RESOURCE_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.END_DATE;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_DATE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.SendSyncDataService;
import com.pes.integration.service.impl.ApiCallService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

class MiniBaselineHandlerTest {

    @Mock
    private ApiCallService apiCallService;

    @Mock
    private SendSyncDataService syncDataService;

    @InjectMocks
    private MiniBaselineHandler miniBaselineHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteWithValidInput() throws Exception {
        try (MockedStatic<JsonUtils> ju = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            String deploymentId = "testDeploymentId";
            ju.when(() -> getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn(deploymentId);
            ju.when(() -> getValue(any(JSONObject.class), eq(APPT_LOCATION_ID))).thenReturn("location1");
            ju.when(() -> getValue(any(JSONObject.class), eq(APPT_RESOURCE_ID))).thenReturn("provider1");
            ju.when(() -> getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2021-09-01");
            ju.when(() -> getValue(any(JSONObject.class), eq(END_DATE))).thenReturn("2021-10-01");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject realTimeResponse = new JSONObject();
            realTimeResponse.put("totalCount", 1);
            realTimeResponse.put("deploymentId", deploymentId);
            realTimeResponse.put("messageControlId", "messageControlId");
            JSONArray dataArray = new JSONArray();
            JSONObject dataObject = new JSONObject();
            dataObject.put("slotId", "slot1");
            dataObject.put("duration", "30");
            dataObject.put("durationUnit", "minutes");
            dataObject.put("startTime", "10:00");
            dataObject.put("reasonId", "reason1");
            dataObject.put("locationId", "location1");
            dataObject.put("providerId", "provider1");
            dataArray.put(dataObject);
            realTimeResponse.put("data", dataArray);

            when(apiCallService.callApi(any(), anyString())).thenReturn(realTimeResponse.toString());

            JSONObject result = miniBaselineHandler.doExecute(inputObject);

            assertNotNull(result);
            assertEquals(deploymentId, result.getString("DEPLOYMENT_ID"));
            verify(syncDataService, times(1)).processSendSyncData(any(JSONObject.class), anyBoolean());
        }
    }

    @Test
    void doExecuteWithEmptySlot() throws Exception {
        try (MockedStatic<JsonUtils> ju = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            String deploymentId = "testDeploymentId";
            ju.when(() -> getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn(deploymentId);
            ju.when(() -> getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn(deploymentId);
            ju.when(() -> getValue(any(JSONObject.class), eq(APPT_LOCATION_ID))).thenReturn("location1");
            ju.when(() -> getValue(any(JSONObject.class), eq(APPT_RESOURCE_ID))).thenReturn("provider1");
            ju.when(() -> getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2021-09-01");
            ju.when(() -> getValue(any(JSONObject.class), eq(END_DATE))).thenReturn("2021-10-01");

            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject realTimeResponse = new JSONObject();
            realTimeResponse.put("totalCount", 0);

            when(apiCallService.callApi(any(), anyString())).thenReturn(realTimeResponse.toString());

            JSONObject result = miniBaselineHandler.doExecute(inputObject);

            assertNull(result);
            verify(syncDataService, times(0)).processSendSyncData(any(JSONObject.class), anyBoolean());
        }
    }


}