package com.pes.integration.athena.consumer;

import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.utils.MetricsUtil;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SendSyncDataConsumerTest {

    @InjectMocks
    @Spy
    SendSyncDataConsumer sendSyncDataConsumer;


    @Mock
    SyncDataConsumerService syncDataConsumerService;

    @Test
    void consumeSendSyncDataMessageWithValidPayload() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String payload = "{\"key\":\"value\"}";
            doNothing().when(syncDataConsumerService).processSendSyncData(payload);

            sendSyncDataConsumer.consumeSendSyncDataMessage(payload);

            verify(syncDataConsumerService, times(1)).processSendSyncData(payload);
        }
    }

    @Test
    void consumeSendSyncDataMessageWithNullPayload() {
        try (MockedStatic<MetricsUtil> mockedStaticMetrics = mockStatic(MetricsUtil.class)) {
            mockedStaticMetrics.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString())).thenAnswer(invocation -> null);

            String payload = null;
            doNothing().when(syncDataConsumerService).processSendSyncData(payload);

            sendSyncDataConsumer.consumeSendSyncDataMessage(payload);

            verify(syncDataConsumerService, times(1)).processSendSyncData(payload);
        }
    }

    @Test
    void listenWithValidMessage() {
        try (MockedStatic<MetricsUtil> mockedStaticMetrics = mockStatic(MetricsUtil.class)) {
            mockedStaticMetrics.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString())).thenAnswer(invocation -> null);

            String topic = "testTopic";
            String message = "{\"key\":\"value\"}";
            doNothing().when(syncDataConsumerService).processSendSyncData(message);

            sendSyncDataConsumer.listen(topic, message);

            verify(syncDataConsumerService, times(1)).processSendSyncData(message);
        }
    }

    @Test
    void listenWithEmptyMessage() {
        try (MockedStatic<MetricsUtil> mockedStaticMetrics = mockStatic(MetricsUtil.class)) {
            mockedStaticMetrics.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString())).thenAnswer(invocation -> null);

            String topic = "testTopic";
            String message = "";
            doNothing().when(syncDataConsumerService).processSendSyncData(message);

            sendSyncDataConsumer.listen(topic, message);

            verify(syncDataConsumerService, times(1)).processSendSyncData(message);
        }
    }

}