package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.EPMFilter;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.ListUtil;
import com.pes.integration.utils.PhoneNumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.pes.integration.athena.api.ApiName.CHANGED_APPOINTMENTS;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.PATIENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.CANCEL_REASON;
import static com.pes.integration.constant.DocASAPConstants.TempKey.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_TYPE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ChangedAppointmentsHandlerTest {

    @InjectMocks
    @Spy
    ChangedAppointmentsHandler changedAppointmentsHandler;
    @Mock
    AthenaApiCaller athenaApiCaller;

    @Mock
    DataCacheManager dataCacheManager;
    @Mock
    IHubDataServiceDelegator iHubDataServiceDelegator;

    @Mock
    HandlerUtils handlerUtils;

    @Mock
    AthenaConfigCache athenaConfigCache;

    @Mock
    GetAppointmentTypesHandler getAppointmentTypesHandler;

    @Mock
    EPMFilter epmFilter;

    @Mock
    MiniBaselineHandler miniBaselineHandler;

    @Test
    void postE2DSyncAction_ShouldDefaultToTrueOnException() throws Exception {
        String deploymentId = "testDeploymentId";
        JSONArray appointmentsArray = new JSONArray();

        // Mock to throw IHubException
        when(dataCacheManager.getStoredProvidersConfig(
                anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("99"), "Test Exception"));

        // Use reflection to invoke the protected method
        Method postE2DSyncAction = ChangedAppointmentsHandler.class.getDeclaredMethod("postE2DSyncAction", JSONArray.class, String.class);
        postE2DSyncAction.setAccessible(true);

        // Should not throw, just log and default to TRUE
        Assertions.assertDoesNotThrow(() -> postE2DSyncAction.invoke(changedAppointmentsHandler, appointmentsArray, deploymentId));
    }

    @Test
    void runMiniBaseline_shouldLogErrorOnException() throws Exception {
        ChangedAppointmentsHandler handler = new ChangedAppointmentsHandler();
        MiniBaselineHandler mockMiniBaselineHandler = mock(MiniBaselineHandler.class);
        // Use reflection to set the private field
        java.lang.reflect.Field field = ChangedAppointmentsHandler.class.getDeclaredField("miniBaselineHandler");
        field.setAccessible(true);
        field.set(handler, mockMiniBaselineHandler);

        JSONObject payload = new JSONObject();
        lenient().doThrow(new RuntimeException("Test Exception")).when(mockMiniBaselineHandler).doExecute(any(JSONObject.class));
        // Use reflection to invoke athe private method
        Method runMiniBaseline = ChangedAppointmentsHandler.class.getDeclaredMethod("runMiniBaseline", JSONObject.class);
        runMiniBaseline.setAccessible(true);
        runMiniBaseline.invoke(handler, payload);
    }

    @Test
    void setDob_shouldLogErrorOnException() throws Exception {
        ChangedAppointmentsHandler handler = new ChangedAppointmentsHandler();
        JSONObject appointmentObject = new JSONObject();
        // Set DOB to an object that will cause a ClassCastException
        appointmentObject.put("dob", new Object());

        Method setDob = ChangedAppointmentsHandler.class.getDeclaredMethod("setDob", JSONObject.class);
        setDob.setAccessible(true);

        // Should not throw, just log error
        setDob.invoke(handler, appointmentObject);
    }

    @Test
    void getNoShowIds_shouldLogErrorOnException() throws Exception {
        ChangedAppointmentsHandler handler = new ChangedAppointmentsHandler();
        Method getNoShowIds = ChangedAppointmentsHandler.class.getDeclaredMethod("getNoShowIds", Object.class, String[].class);
        getNoShowIds.setAccessible(true);

        // Pass a non-String object to trigger the exception
        Object result = getNoShowIds.invoke(handler, 12345, new String[0]);
        assertNotNull(result);
        assertTrue(result instanceof String[]);
    }

    @Test
    void setEventReasonId_shouldLogErrorOnIHubException() throws Exception {
        ChangedAppointmentsHandler handler = spy(new ChangedAppointmentsHandler());
        JSONObject appointmentObject = new JSONObject();

        // Use reflection to access the private method
        Method setEventReasonId = ChangedAppointmentsHandler.class.getDeclaredMethod("setEventReasonId", JSONObject.class, String.class);
        setEventReasonId.setAccessible(true);

        // Mock static setValue to throw IHubException
        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtilsMockedStatic.when(() -> com.pes.integration.jsonmapper.JsonUtils.setValue(any(), any(), any()))
                    .thenThrow(new IHubException(new com.pes.integration.exceptions.IHubErrorCode("1"), "Test Exception"));

            // Should not throw, just log error
            setEventReasonId.invoke(handler, appointmentObject, "value");
        }
    }

    @Test
    void buildE2DSyncObject_CanceledAppointment_NotNoShow() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class, CALLS_REAL_METHODS)) {
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2023-10-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_TIME))).thenReturn("10:00");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_STATUS))).thenReturn(APPOINTMENT_TYPE_CANCELED);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(RESCHEDULED_APPOINTMENT_ID))).thenReturn(null);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LOCAL_RESOURCE_ID))).thenReturn("localProviderId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CANCEL_REASON))).thenReturn("reason999"); // not in noShowIds
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LANGUAGE_PREFERENCE))).thenReturn("US");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("patient123");
                    dateUtilsMockedStatic.when(() -> DateUtils.getDocasapDateTime(any(String.class), anyString())).thenReturn("2023-10-01T10:00:00");
                    dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DATE_FORMAT), eq(DOCASAP_DATE_FORMAT))).thenReturn("19900101");
                    phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any())).thenAnswer(invocation -> null);

                    JSONArray appointmentsArray = new JSONArray();
                    JSONObject appointmentObject = new JSONObject();
                    appointmentObject.put("start_date", "2023-10-01");
                    appointmentObject.put("start_time", "10:00");
                    appointmentObject.put("appointment_status", "CANCELED");
                    appointmentObject.put("local_resource_id", "localProviderId");
                    appointmentObject.put("patient_id", "patient123");
                    appointmentObject.put("cancel_reason", "reason999");
                    appointmentsArray.put(appointmentObject);

                    JSONObject inputObject = new JSONObject();
                    String deploymentId = "testDeploymentId";

                    when(handlerUtils.getUseLocalProviderId(deploymentId)).thenReturn(true);
                    when(dataCacheManager.getStoredProvidersConfig(
                            eq(AthenaEngineConstants.EPM_NAME_PREFIX),
                            anyString(),
                            eq(AthenaEngineConstants.ATHENA_CONFIG),
                            eq(AthenaEngineConstants.NO_SHOW_ID), eq(false)))
                            .thenReturn("reason123,reason456"); // reason999 is not in this list

                    Method buildE2DSyncObject = ChangedAppointmentsHandler.class.getDeclaredMethod(
                            "buildE2DSyncObject", JSONArray.class, JSONObject.class, String.class);
                    buildE2DSyncObject.setAccessible(true);

                    JSONArray result = (JSONArray) buildE2DSyncObject.invoke(changedAppointmentsHandler, appointmentsArray, inputObject, deploymentId);
                    assertEquals(1, result.length());
                    JSONObject resultObject = result.getJSONObject(0);
                    Assertions.assertEquals("CancelAppt", resultObject.getString("message_type"));
                }
            }
        }
    }

    @Test
    void buildE2DSyncObjectWithNoShowCancelReason() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class, CALLS_REAL_METHODS)) {
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2023-10-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_TIME))).thenReturn("10:00");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_STATUS))).thenReturn(APPOINTMENT_TYPE_CANCELED);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(RESCHEDULED_APPOINTMENT_ID))).thenReturn(null);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LOCAL_RESOURCE_ID))).thenReturn("localProviderId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CANCEL_REASON))).thenReturn("reason456");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LANGUAGE_PREFERENCE))).thenReturn("US");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("patient123");
                    dateUtilsMockedStatic.when(() -> DateUtils.getDocasapDateTime(any(String.class), anyString())).thenReturn("2023-10-01T10:00:00");
                    dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DATE_FORMAT), eq(DOCASAP_DATE_FORMAT))).thenReturn("19900101");
                    phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any())).thenAnswer(invocation -> null);

                    JSONArray appointmentsArray = new JSONArray();
                    JSONObject appointmentObject = new JSONObject();
                    appointmentObject.put("start_date", "2023-10-01");
                    appointmentObject.put("start_time", "10:00");
                    appointmentObject.put("appointment_status", "CANCELED");
                    appointmentObject.put("local_resource_id", "localProviderId");
                    appointmentObject.put("patient_id", "patient123");
                    appointmentObject.put("cancel_reason", "reason456");
                    appointmentsArray.put(appointmentObject);

                    JSONObject inputObject = new JSONObject();
                    String deploymentId = "testDeploymentId";

                    when(handlerUtils.getUseLocalProviderId(deploymentId)).thenReturn(true);
                    when(dataCacheManager.getStoredProvidersConfig(
                            eq(AthenaEngineConstants.EPM_NAME_PREFIX),
                            anyString(),
                            eq(AthenaEngineConstants.ATHENA_CONFIG),
                            eq(AthenaEngineConstants.NO_SHOW_ID), eq(false)))
                            .thenReturn("reason123,reason456");

                    Method buildE2DSyncObject = ChangedAppointmentsHandler.class.getDeclaredMethod(
                            "buildE2DSyncObject", JSONArray.class, JSONObject.class, String.class);
                    buildE2DSyncObject.setAccessible(true);

                    JSONArray result = (JSONArray) buildE2DSyncObject.invoke(changedAppointmentsHandler, appointmentsArray, inputObject, deploymentId);
                    assertEquals(1, result.length());
                    JSONObject resultObject = result.getJSONObject(0);
                    Assertions.assertEquals("NoShowAppt", resultObject.getString("message_type"));
                }
            }
        }
    }

    @Test
    void getChangedAppointmentsWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<ListUtil> listUtilMockedStatic = Mockito.mockStatic(ListUtil.class, CALLS_REAL_METHODS)) {
                jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                listUtilMockedStatic.when(() -> ListUtil.chunkList(anyString(), anyInt())).thenReturn(List.of(List.of("11", "22")));
                JSONObject inputObject = new JSONObject();
                inputObject.put("deployment_id", "testDeploymentId");

                JSONObject expectedResponse = new JSONObject();
                expectedResponse.put("fetchStartTime", System.currentTimeMillis());
                JSONArray jsonArray = new JSONArray();
                jsonArray.put(new JSONObject().put("key", "value"));
                expectedResponse.put(APPOINTMENT_SYNC, jsonArray);

                when(athenaApiCaller.call(eq(CHANGED_APPOINTMENTS.getKey()), any(JSONObject.class), eq("E2D")))
                        .thenReturn(expectedResponse);
                when(dataCacheManager.getStoredProvidersConfig(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(),
                        eq(AthenaEngineConstants.ATHENA_CONFIG),
                        eq(AthenaEngineConstants.SHOW_PATIENT_DETAIL), eq(false))).thenReturn("true");
                when(dataCacheManager.getStoredProvidersConfig(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(),
                        eq(AthenaEngineConstants.ATHENA_CONFIG),
                        eq(AthenaEngineConstants.PULL_BY_DEPT_CHUNK), eq(false))).thenReturn("true");
                when(dataCacheManager.getStoredProvidersConfig(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(),
                        eq(AthenaEngineConstants.ATHENA_CONFIG),
                        eq(AthenaEngineConstants.DEPT_CHUNK_SIZE), eq(false))).thenReturn("2");
                doNothing().when(handlerUtils).addPracticeId(any(), any());
                doReturn("testLocationId").when(handlerUtils).addLocationIdList(any(), any());
                doNothing().when(handlerUtils).getLimit(any(), any());
                JSONObject result = changedAppointmentsHandler.getChangedAppointments(inputObject);
                System.out.println(result);
                assertNotNull(result);
                assertTrue(result.has("fetchStartTime"));
                assertTrue(result.has("appointment_sync"));
                verify(athenaApiCaller, times(1)).call(eq(CHANGED_APPOINTMENTS.getKey()), any(JSONObject.class), eq("E2D"));
            }
        }
    }

    @Test
    void getChangedAppointmentsWithValidInput_pullChangeApptByChunkOfDept_false() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<ListUtil> listUtilMockedStatic = Mockito.mockStatic(ListUtil.class, CALLS_REAL_METHODS)) {
                jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
                listUtilMockedStatic.when(() -> ListUtil.chunkList(anyString(), anyInt())).thenReturn(List.of(List.of("11", "22")));
                JSONObject inputObject = new JSONObject();
                inputObject.put("deployment_id", "testDeploymentId");

                JSONObject expectedResponse = new JSONObject();
                expectedResponse.put("fetchStartTime", System.currentTimeMillis());
                JSONArray jsonArray = new JSONArray();
                jsonArray.put(new JSONObject().put("key", "value"));
                expectedResponse.put(APPOINTMENT_SYNC, jsonArray);

                when(athenaApiCaller.call(eq(CHANGED_APPOINTMENTS.getKey()), any(JSONObject.class), eq("E2D")))
                        .thenReturn(expectedResponse);
                when(dataCacheManager.getStoredProvidersConfig(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(),
                        eq(AthenaEngineConstants.ATHENA_CONFIG),
                        eq(AthenaEngineConstants.SHOW_PATIENT_DETAIL), eq(false))).thenReturn("true");
                when(dataCacheManager.getStoredProvidersConfig(
                        eq(AthenaEngineConstants.EPM_NAME_PREFIX), anyString(),
                        eq(AthenaEngineConstants.ATHENA_CONFIG),
                        eq(AthenaEngineConstants.PULL_BY_DEPT_CHUNK), eq(false))).thenReturn("false");
                doNothing().when(handlerUtils).addPracticeId(any(), any());
                doReturn("testLocationId").when(handlerUtils).addLocationIdList(any(), any());
                doNothing().when(handlerUtils).getLimit(any(), any());
                JSONObject result = changedAppointmentsHandler.getChangedAppointments(inputObject);
                System.out.println(result);
                assertNotNull(result);
                assertTrue(result.has("fetchStartTime"));
                assertTrue(result.has("appointment_sync[0]"));
                verify(athenaApiCaller, times(1)).call(eq(CHANGED_APPOINTMENTS.getKey()), any(JSONObject.class), eq("E2D"));
            }
        }
    }

    @Test
    void buildE2DSyncObjectWithValidAppointments_APPOINTMENT_TYPE_CANCELED() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class, CALLS_REAL_METHODS)) {
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2023-10-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_TIME))).thenReturn("10:00");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_STATUS))).thenReturn(APPOINTMENT_TYPE_CANCELED);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(RESCHEDULED_APPOINTMENT_ID))).thenReturn("rescheduledAppointmentId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LOCAL_RESOURCE_ID))).thenReturn("localProviderId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CANCEL_REASON))).thenReturn("reason123");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LANGUAGE_PREFERENCE))).thenReturn("US");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("patient123");
                    dateUtilsMockedStatic.when(() -> DateUtils.getDocasapDateTime(any(String.class), anyString())).thenReturn("2023-10-01T10:00:00");
                    dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DATE_FORMAT), eq(DOCASAP_DATE_FORMAT))).thenReturn("19900101");
                    phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any())).thenAnswer(invocation -> null);

                    JSONArray appointmentsArray = new JSONArray();
                    JSONObject appointmentObject = new JSONObject();
                    appointmentObject.put("start_date", "2023-10-01");
                    appointmentObject.put("start_time", "10:00");
                    appointmentObject.put("appointment_status", "FUTURE");
                    appointmentObject.put("local_resource_id", "localProviderId");
                    appointmentObject.put("patient_id", "patient123");
                    appointmentsArray.put(appointmentObject);

                    JSONObject inputObject = new JSONObject();
                    String deploymentId = "testDeploymentId";

                    when(handlerUtils.getUseLocalProviderId(deploymentId)).thenReturn(true);
                    when(dataCacheManager.getStoredProvidersConfig(
                            eq(AthenaEngineConstants.EPM_NAME_PREFIX),
                            anyString(),
                            eq(AthenaEngineConstants.ATHENA_CONFIG),
                            eq(AthenaEngineConstants.NO_SHOW_ID), eq(false)))
                            .thenReturn("reason123,reason456");

                    JSONArray result = changedAppointmentsHandler.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);
                    System.out.println(result);
                    assertEquals(1, result.length());
                    JSONObject resultObject = result.getJSONObject(0);
                    Assertions.assertEquals("CancelAppt", resultObject.getString("message_type"));
                    Assertions.assertTrue(resultObject.has("SchedulingData"));
                    JSONArray jsonArray = resultObject.getJSONObject("SchedulingData").getJSONArray("Schedule");
                    System.out.println(jsonArray);
                    assertEquals("2023-10-01T10:00:00", jsonArray.getJSONObject(0).getString("ApptTimingStart"));
                }
            }
        }
    }

    @Test
    void buildE2DSyncObjectWithValidAppointments_NewAppt() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class, CALLS_REAL_METHODS)) {
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2023-10-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_TIME))).thenReturn("10:00");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_STATUS))).thenReturn(APPOINTMENT_TYPE_FUTURE);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(RESCHEDULED_APPOINTMENT_ID))).thenReturn("rescheduledAppointmentId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LOCAL_RESOURCE_ID))).thenReturn("localProviderId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CANCEL_REASON))).thenReturn("reason123");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LANGUAGE_PREFERENCE))).thenReturn("US");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("patient123");
                    dateUtilsMockedStatic.when(() -> DateUtils.getDocasapDateTime(any(String.class), anyString())).thenReturn("2023-10-01T10:00:00");
                    dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DATE_FORMAT), eq(DOCASAP_DATE_FORMAT))).thenReturn("19900101");
                    phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any())).thenAnswer(invocation -> null);

                    JSONArray appointmentsArray = new JSONArray();
                    JSONObject appointmentObject = new JSONObject();
                    appointmentObject.put("start_date", "2023-10-01");
                    appointmentObject.put("start_time", "10:00");
                    appointmentObject.put("appointment_status", "FUTURE");
                    appointmentObject.put("local_resource_id", "localProviderId");
                    appointmentObject.put("patient_id", "patient123");
                    appointmentsArray.put(appointmentObject);

                    JSONObject inputObject = new JSONObject();
                    String deploymentId = "testDeploymentId";

                    when(handlerUtils.getUseLocalProviderId(deploymentId)).thenReturn(true);


                    JSONArray result = changedAppointmentsHandler.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);
                    System.out.println(result);
                    assertEquals(1, result.length());
                    JSONObject resultObject = result.getJSONObject(0);
                    Assertions.assertTrue(resultObject.has("SchedulingData"));
                    Assertions.assertEquals("NewAppt", resultObject.getString("message_type"));
                    JSONArray jsonArray = resultObject.getJSONObject("SchedulingData").getJSONArray("Schedule");
                    System.out.println(jsonArray);
                    assertEquals("2023-10-01T10:00:00", jsonArray.getJSONObject(0).getString("ApptTimingStart"));
                }
            }
        }
    }

    @Test
    void buildE2DSyncObjectWithValidAppointments_BlockSync() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class, CALLS_REAL_METHODS)) {
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2023-10-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_TIME))).thenReturn("10:00");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_STATUS))).thenReturn(APPOINTMENT_TYPE_OPEN);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(RESCHEDULED_APPOINTMENT_ID))).thenReturn("rescheduledAppointmentId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LOCAL_RESOURCE_ID))).thenReturn("localProviderId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CANCEL_REASON))).thenReturn("reason123");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LANGUAGE_PREFERENCE))).thenReturn("US");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("patient123");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(FROZEN))).thenReturn("true");
                    dateUtilsMockedStatic.when(() -> DateUtils.getDocasapDateTime(any(String.class), anyString())).thenReturn("2023-10-01T10:00:00");
                    dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DATE_FORMAT), eq(DOCASAP_DATE_FORMAT))).thenReturn("19900101");
                    phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any())).thenAnswer(invocation -> null);

                    JSONArray appointmentsArray = new JSONArray();
                    JSONObject appointmentObject = new JSONObject();
                    appointmentObject.put("start_date", "2023-10-01");
                    appointmentObject.put("start_time", "10:00");
                    appointmentObject.put("appointment_status", "FUTURE");
                    appointmentObject.put("local_resource_id", "localProviderId");
                    appointmentObject.put("patient_id", "patient123");
                    appointmentsArray.put(appointmentObject);

                    JSONObject inputObject = new JSONObject();
                    String deploymentId = "testDeploymentId";

                    when(handlerUtils.getUseLocalProviderId(deploymentId)).thenReturn(true);


                    JSONArray result = changedAppointmentsHandler.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);
                    System.out.println(result);
                    assertEquals(1, result.length());
                    JSONObject resultObject = result.getJSONObject(0);
                    Assertions.assertTrue(resultObject.has("SchedulingData"));
                    Assertions.assertEquals("BlockSync", resultObject.getString("message_type"));
                    JSONArray jsonArray = resultObject.getJSONObject("SchedulingData").getJSONArray("Schedule");
                    System.out.println(jsonArray);
                    assertEquals("2023-10-01T10:00:00", jsonArray.getJSONObject(0).getString("ApptTimingStart"));
                }
            }
        }
    }

    @Test
    void buildE2DSyncObjectWithValidAppointments_UnblockSync() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            try (MockedStatic<DateUtils> dateUtilsMockedStatic = Mockito.mockStatic(DateUtils.class, CALLS_REAL_METHODS)) {
                try (MockedStatic<PhoneNumberUtils> phoneNumberUtilsMockedStatic = Mockito.mockStatic(PhoneNumberUtils.class, CALLS_REAL_METHODS)) {
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_DATE))).thenReturn("2023-10-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(START_TIME))).thenReturn("10:00");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPOINTMENT_STATUS))).thenReturn(APPOINTMENT_TYPE_OPEN);
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(RESCHEDULED_APPOINTMENT_ID))).thenReturn("rescheduledAppointmentId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LOCAL_RESOURCE_ID))).thenReturn("localProviderId");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CANCEL_REASON))).thenReturn("reason123");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DOB))).thenReturn("1990-01-01");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LANGUAGE_PREFERENCE))).thenReturn("US");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PATIENT_ID))).thenReturn("patient123");
                    jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(FROZEN))).thenReturn("false");
                    dateUtilsMockedStatic.when(() -> DateUtils.getDocasapDateTime(any(String.class), anyString())).thenReturn("2023-10-01T10:00:00");
                    dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(String.class), eq(DATE_FORMAT), eq(DOCASAP_DATE_FORMAT))).thenReturn("19900101");
                    phoneNumberUtilsMockedStatic.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any())).thenAnswer(invocation -> null);

                    JSONArray appointmentsArray = new JSONArray();
                    JSONObject appointmentObject = new JSONObject();
                    appointmentObject.put("start_date", "2023-10-01");
                    appointmentObject.put("start_time", "10:00");
                    appointmentObject.put("appointment_status", "FUTURE");
                    appointmentObject.put("local_resource_id", "localProviderId");
                    appointmentObject.put("patient_id", "patient123");
                    appointmentsArray.put(appointmentObject);

                    JSONObject inputObject = new JSONObject();
                    String deploymentId = "testDeploymentId";

                    when(handlerUtils.getUseLocalProviderId(deploymentId)).thenReturn(true);


                    JSONArray result = changedAppointmentsHandler.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);
                    System.out.println(result);
                    assertEquals(1, result.length());
                    JSONObject resultObject = result.getJSONObject(0);
                    Assertions.assertTrue(resultObject.has("SchedulingData"));
                    Assertions.assertEquals("UnblockSync", resultObject.getString("message_type"));
                    JSONArray jsonArray = resultObject.getJSONObject("SchedulingData").getJSONArray("Schedule");
                    System.out.println(jsonArray);
                    assertEquals("2023-10-01T10:00:00", jsonArray.getJSONObject(0).getString("ApptTimingStart"));
                }
            }
        }
    }

    @Test
    void updateGenericAppointmentTypes() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(EVENT_REASON_ID))).thenReturn("reason123");
            when(handlerUtils.getGenericApptTypeDBConfig(anyString())).thenReturn(List.of("status:reason123"));
            Method updateGenericAppointmentTypes = getMethod("updateGenericAppointmentTypes", JSONObject.class, JSONObject.class, String.class);
            Assertions.assertDoesNotThrow(() -> updateGenericAppointmentTypes.invoke(changedAppointmentsHandler, new JSONObject(), new JSONObject(), "testDeploymentId"));
        }
    }

    @Test
    void updateGenericAppointmentTypes_2() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(EVENT_REASON_ID))).thenReturn("reason123");
            when(handlerUtils.getGenericApptTypeDBConfig(anyString())).thenReturn(List.of("reason123"));
            when(handlerUtils.getScheduleAbleAppointmentTypes(anyString(), any())).thenReturn("scheduleAbleApptTypes");
            when(athenaConfigCache.getAppointmentTypeList(any())).thenReturn(Map.of());
            when(getAppointmentTypesHandler.doExecute(any())).thenReturn(new JSONObject());
            Method updateGenericAppointmentTypes = getMethod("updateGenericAppointmentTypes", JSONObject.class, JSONObject.class, String.class);
            Assertions.assertDoesNotThrow(() -> updateGenericAppointmentTypes.invoke(changedAppointmentsHandler, new JSONObject(), new JSONObject(), "testDeploymentId"));
        }
    }

    @Test
    void setNotifications_DAON_1() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CONSENT_TO_TEXT))).thenReturn("true");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(EMAIL))).thenReturn("email");
            Method setNotifications = getMethod("setNotifications", JSONObject.class, Object.class, String.class);
            JSONObject jsonObject = new JSONObject();
            Assertions.assertDoesNotThrow(() -> setNotifications.invoke(changedAppointmentsHandler, jsonObject, new JSONObject(), "testDeploymentId"));
            System.out.println(jsonObject);
            Assertions.assertEquals("DAON", jsonObject.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("NonOASNotification"));
        }
    }

    @Test
    void setNotifications_DATON() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CONSENT_TO_TEXT))).thenReturn("true");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(EMAIL))).thenReturn("");
            Method setNotifications = getMethod("setNotifications", JSONObject.class, Object.class, String.class);
            JSONObject jsonObject = new JSONObject();
            Assertions.assertDoesNotThrow(() -> setNotifications.invoke(changedAppointmentsHandler, jsonObject, new JSONObject(), "testDeploymentId"));
            System.out.println(jsonObject);
            Assertions.assertEquals("DATON", jsonObject.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("NonOASNotification"));
        }
    }

    @Test
    void setNotifications_DAEON() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CONSENT_TO_TEXT))).thenReturn("false");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(EMAIL))).thenReturn("email");
            Method setNotifications = getMethod("setNotifications", JSONObject.class, Object.class, String.class);
            JSONObject jsonObject = new JSONObject();
            Assertions.assertDoesNotThrow(() -> setNotifications.invoke(changedAppointmentsHandler, jsonObject, new JSONObject(), "testDeploymentId"));
            System.out.println(jsonObject);
            Assertions.assertEquals("DAEON", jsonObject.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("NonOASNotification"));
        }
    }

    @Test
    void setNotifications_DAOFF() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CONSENT_TO_TEXT))).thenReturn("false");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(EMAIL))).thenReturn("");
            Method setNotifications = getMethod("setNotifications", JSONObject.class, Object.class, String.class);
            JSONObject jsonObject = new JSONObject();
            Assertions.assertDoesNotThrow(() -> setNotifications.invoke(changedAppointmentsHandler, jsonObject, new JSONObject(), "testDeploymentId"));
            System.out.println(jsonObject);
            Assertions.assertEquals("DAOFF", jsonObject.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("NonOASNotification"));
        }
    }

    @Test
    void setNotifications_DAON_2() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CONSENT_TO_TEXT))).thenReturn("consentToText");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(EMAIL))).thenReturn("email");
            Method setNotifications = getMethod("setNotifications", JSONObject.class, Object.class, String.class);
            JSONObject jsonObject = new JSONObject();
            Assertions.assertDoesNotThrow(() -> setNotifications.invoke(changedAppointmentsHandler, jsonObject, new JSONObject(), "testDeploymentId"));
            System.out.println(jsonObject);
            Assertions.assertEquals("DAON", jsonObject.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("NonOASNotification"));
        }
    }

    @Test
    void setNotifications_Exception() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(CONSENT_TO_TEXT))).thenThrow(new RuntimeException("Test Exception"));
            Method setNotifications = getMethod("setNotifications", JSONObject.class, Object.class, String.class);
            JSONObject jsonObject = new JSONObject();
            Assertions.assertDoesNotThrow(() -> setNotifications.invoke(changedAppointmentsHandler, jsonObject, new JSONObject(), "testDeploymentId"));
            Assertions.assertTrue(jsonObject.isEmpty());
        }
    }
    @Test
    void applyFilterWithValidAppointments() {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPT_LOCATION_ID))).thenReturn("location1");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPT_RESOURCE_ID))).thenReturn("provider1");

            String deploymentId = "testDeploymentId";
            JSONArray appointmentsArray = new JSONArray();
            JSONObject appointmentObject = new JSONObject();
            appointmentObject.put("APPT_LOCATION_ID", "location1");
            appointmentObject.put("APPT_RESOURCE_ID", "provider1");
            appointmentsArray.put(appointmentObject);

            when(handlerUtils.shouldStoreFilterLocationInCache(deploymentId)).thenReturn(false);
            when(epmFilter.isAllowed(deploymentId, "location1", "provider1")).thenReturn(true);

            JSONArray result = changedAppointmentsHandler.applyFilter(deploymentId, appointmentsArray);

            assertNotNull(result);
            assertEquals(1, result.length());
        }
    }

    @Test
    void applyFilterWithInvalidAppointments() {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPT_LOCATION_ID))).thenReturn("location1");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(APPT_RESOURCE_ID))).thenReturn("provider1");

            String deploymentId = "testDeploymentId";
            JSONArray appointmentsArray = new JSONArray();
            JSONObject appointmentObject = new JSONObject();
            appointmentObject.put("APPT_LOCATION_ID", "location1");
            appointmentObject.put("APPT_RESOURCE_ID", "provider1");
            appointmentsArray.put(appointmentObject);

            when(handlerUtils.shouldStoreFilterLocationInCache(deploymentId)).thenReturn(false);
            when(epmFilter.isAllowed(deploymentId, "location1", "provider1")).thenReturn(false);

            JSONArray result = changedAppointmentsHandler.applyFilter(deploymentId, appointmentsArray);

            assertNotNull(result);
            assertEquals(0, result.length());
        }
    }

    @Test
    void applyFilterWithNullAppointments() {
        String deploymentId = "testDeploymentId";
        JSONArray result = changedAppointmentsHandler.applyFilter(deploymentId, null);

        assertNull(result);
    }

    @Test
    void applyFilterWithStoreFilterLocationInCache() {
        String deploymentId = "testDeploymentId";
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("APPT_LOCATION_ID", "location1");
        appointmentObject.put("APPT_RESOURCE_ID", "provider1");
        appointmentsArray.put(appointmentObject);

        when(handlerUtils.shouldStoreFilterLocationInCache(deploymentId)).thenReturn(true);

        JSONArray result = changedAppointmentsHandler.applyFilter(deploymentId, appointmentsArray);

        assertNotNull(result);
        assertEquals(1, result.length());
    }

    @Test
    void isNewOrgReturnsTrue() throws IHubException {
        String deploymentId = "testDeploymentId";
        when(dataCacheManager.getStoredProvidersConfig(
                AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.JsonConstants.IS_NEW, false))
                .thenReturn(UtilitiesConstants.TRUE);

        boolean result = changedAppointmentsHandler.isNewOrg(deploymentId);

        assertTrue(result);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(
                AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.JsonConstants.IS_NEW, false);
    }

    @Test
    void isNewOrgReturnsFalse() throws IHubException {
        String deploymentId = "testDeploymentId";
        when(dataCacheManager.getStoredProvidersConfig(
                AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.JsonConstants.IS_NEW, false))
                .thenReturn(UtilitiesConstants.FALSE);

        boolean result = changedAppointmentsHandler.isNewOrg(deploymentId);

        assertFalse(result);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(
                AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.JsonConstants.IS_NEW, false);
    }

    @Test
    void isNewOrgThrowsException() throws IHubException {
        String deploymentId = "testDeploymentId";
        when(dataCacheManager.getStoredProvidersConfig(
                AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.JsonConstants.IS_NEW, false))
                .thenThrow(new IHubException(new IHubErrorCode("22"),"Error fetching config"));

        boolean result = changedAppointmentsHandler.isNewOrg(deploymentId);

        assertFalse(result);
        verify(dataCacheManager, times(1)).getStoredProvidersConfig(
                AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.JsonConstants.IS_NEW, false);
    }

    @Test
    void updateIsNewOrgConfig() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONObject saveConfigJson = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject orgDetails = new JSONObject();
        orgDetails.put(UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
        List<String> configGroupNames = Arrays.asList(StringUtils.split(AthenaEngineConstants.EPM_CONFIG_GROUPS, UtilitiesConstants.CharacterConstants.COMMA));
        orgDetails.put(UtilitiesConstants.JsonConstants.CONFIG_GROUP_NAMES, configGroupNames);
        data.put(UtilitiesConstants.JsonConstants.ORG_DETAILS, orgDetails);
        JSONObject orgConfigs = new JSONObject();
        orgConfigs.put(UtilitiesConstants.JsonConstants.IS_NEW, UtilitiesConstants.FALSE);
        data.put(UtilitiesConstants.JsonConstants.ORG_CONFIGS, orgConfigs);
        saveConfigJson.put(UtilitiesConstants.JsonConstants.DATA, data);

        doNothing().when(iHubDataServiceDelegator).iHubAddUpdateOrg(saveConfigJson.toString());

        changedAppointmentsHandler.updateIsNewOrgConfig(deploymentId);

        verify(iHubDataServiceDelegator, times(1)).iHubAddUpdateOrg(saveConfigJson.toString());
    }

    @Test
    void runBaselineAfterCancelWithCancelAppointment() throws Exception {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(MESSAGE_TYPE))).thenReturn("CancelAppt");
            Method runBaselineAfterCancel = getMethod("runBaselineAfterCancel", JSONArray.class,  String.class);
            JSONObject jsonObject = new JSONObject();
            Assertions.assertTrue(jsonObject.isEmpty());

            String deploymentId = "testDeploymentId";
            JSONArray appointmentsArray = new JSONArray();
            JSONObject appointmentObject = new JSONObject();
            appointmentObject.put("APPT_LOCATION_ID", "location1");
            appointmentObject.put("APPT_RESOURCE_ID", "provider1");
            appointmentObject.put("APPOINTMENT_TIMING_START", "2023-10-01T10:00:00");
            appointmentObject.put("MESSAGE_TYPE", "CANCEL_APPOINTMENT");
            appointmentsArray.put(appointmentObject);

            JSONObject miniBaselinePayload = new JSONObject();
            miniBaselinePayload.put("DEPLOYMENT_ID", deploymentId);
            miniBaselinePayload.put("START_DATE", "2023-10-01T10:00:00");
            miniBaselinePayload.put("END_DATE", "2023-10-01T10:00:00");
            miniBaselinePayload.put("APPT_RESOURCE_ID", "provider1");
            miniBaselinePayload.put("APPT_LOCATION_ID", "location1");

            Assertions.assertDoesNotThrow(() -> runBaselineAfterCancel.invoke(changedAppointmentsHandler, appointmentsArray, deploymentId));

        }
    }

    public Method getMethod(String name, Class<?>... args) throws NoSuchMethodException {
        Method method = ChangedAppointmentsHandler.class.getDeclaredMethod(name, args);
        method.setAccessible(true);
        return method;
    }


    @Test
    void postE2DSyncAction_WithMiniBaseline() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("MESSAGE_TYPE", "CANCEL_APPOINTMENT");
        appointmentObject.put("APPT_RESOURCE_ID", "provider1");
        appointmentObject.put("APPT_LOCATION_ID", "location1");
        appointmentObject.put("APPOINTMENT_TIMING_START", "2023-10-01T10:00:00");
        appointmentsArray.put(appointmentObject);

        when(dataCacheManager.getStoredProvidersConfig(
                anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("TRUE");

        changedAppointmentsHandler.postE2DSyncAction(appointmentsArray, deploymentId);

    }

    @Test
    void postE2DSyncAction_WithoutMiniBaseline() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("MESSAGE_TYPE", "CANCEL_APPOINTMENT");
        appointmentObject.put("APPT_RESOURCE_ID", "provider1");
        appointmentObject.put("APPT_LOCATION_ID", "location1");
        appointmentObject.put("APPOINTMENT_TIMING_START", "2023-10-01T10:00:00");
        appointmentsArray.put(appointmentObject);

        when(dataCacheManager.getStoredProvidersConfig(
                anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("FALSE");

        changedAppointmentsHandler.postE2DSyncAction(appointmentsArray, deploymentId);
    }

    @Test
    void postE2DSyncAction_WithNullIsMinibaseline() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("MESSAGE_TYPE", "CANCEL_APPOINTMENT");
        appointmentObject.put("APPT_RESOURCE_ID", "provider1");
        appointmentObject.put("APPT_LOCATION_ID", "location1");
        appointmentObject.put("APPOINTMENT_TIMING_START", "2023-10-01T10:00:00");
        appointmentsArray.put(appointmentObject);

        when(dataCacheManager.getStoredProvidersConfig(
                anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(null);

        changedAppointmentsHandler.postE2DSyncAction(appointmentsArray, deploymentId);
    }

    @Test
    void postE2DSyncAction_WithEmptyAppointmentsArray() throws IHubException {
        String deploymentId = "testDeploymentId";
        JSONArray appointmentsArray = new JSONArray();

        when(dataCacheManager.getStoredProvidersConfig(
                anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("TRUE");

        changedAppointmentsHandler.postE2DSyncAction(appointmentsArray, deploymentId);
    }

    @Test
    void setShowPatientDetailFlag_shouldSetTrueOnException() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put("show_patient_detail", true);
        String deploymentId = "testDeploymentId";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("99"), "Test Exception"));

        Method method = ChangedAppointmentsHandler.class.getDeclaredMethod("setShowPatientDetailFlag", JSONObject.class, String.class);
        method.setAccessible(true);
        method.invoke(changedAppointmentsHandler, inputObject, deploymentId);

        assertTrue(inputObject.getBoolean("show_patient_detail"));
    }

    @Test
    void pullChangeApptByChunkOfDept_shouldSetTrueOnException() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put("show_patient_detail", true);
        String deploymentId = "testDeploymentId";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("99"), "Test Exception"));

        Method method = ChangedAppointmentsHandler.class.getDeclaredMethod("pullChangeApptByChunkOfDept", String.class);
        method.setAccessible(true);
        method.invoke(changedAppointmentsHandler, deploymentId);

        assertTrue(inputObject.getBoolean("show_patient_detail"));
    }

    @Test
    void getDeptChunkConfig_shouldSetTrueOnException() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put("show_patient_detail", true);
        String deploymentId = "testDeploymentId";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("99"), "Test Exception"));

        Method method = ChangedAppointmentsHandler.class.getDeclaredMethod("getDeptChunkConfig", String.class);
        method.setAccessible(true);
        method.invoke(changedAppointmentsHandler, deploymentId);

        assertTrue(inputObject.getBoolean("show_patient_detail"));
    }

    @Test
    void getAppointmentTypeList_ReturnsFromCache() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put("practice_id", "practice123");
        Map<String, String> expectedMap = Map.of("type1", "desc1");

        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic =
                     Mockito.mockStatic(JsonUtils.class, Mockito.CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(), anyString()))
                    .thenReturn(null);

            when(athenaConfigCache.getAppointmentTypeList(any())).thenReturn(null);
            when(getAppointmentTypesHandler.doExecute(any())).thenThrow(new IHubException(null, "error"));

            Map<String, String> result = changedAppointmentsHandler.getAppointmentTypeList(inputObject);
            assertTrue(true);
        }
    }


    @Test
    void setDob_shouldSetConvertedDob_whenDobIsValid() throws Exception {
        ChangedAppointmentsHandler handler = new ChangedAppointmentsHandler();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("dob", "1990-01-01");

        try (MockedStatic<DateUtils> dateUtilsMockedStatic = mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat("1990-01-01", DATE_FORMAT, DOCASAP_DATE_FORMAT))
                    .thenReturn("19900101");

            var method = ChangedAppointmentsHandler.class.getDeclaredMethod("setDob", JSONObject.class);
            method.setAccessible(true);
            method.invoke(handler, appointmentObject);

            assertEquals("1990-01-01", appointmentObject.getString("dob"));
        }
    }

    @Test
    void setDob_shouldSetConvertedDob_whenDobIsValid_exception() throws Exception {
        ChangedAppointmentsHandler handler = new ChangedAppointmentsHandler();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("dob", "1990-01-01");

        try (MockedStatic<DateUtils> dateUtilsMockedStatic = mockStatic(DateUtils.class);
             MockedStatic<JsonUtils> jsonUtilsMockedStatic = mockStatic(JsonUtils.class)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(appointmentObject, DOB)).thenThrow(new RuntimeException("Test Exception"));
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat("1990-01-01", DATE_FORMAT, DOCASAP_DATE_FORMAT))
                    .thenReturn("19900101");

            var method = ChangedAppointmentsHandler.class.getDeclaredMethod("setDob", JSONObject.class);
            method.setAccessible(true);
            method.invoke(handler, appointmentObject);

            assertEquals("1990-01-01", appointmentObject.getString("dob"));
        }
    }


}

