package com.pes.integration.athena.handler;

import static com.pes.integration.athena.api.ApiName.GET_LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PRACTICE_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

class GetLocationsHandlerTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private AthenaConfigCache athenaConfigCache;

    @InjectMocks
    private GetLocationsHandler getLocationsHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteWithValidInput() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = Mockito.mockStatic(JsonUtils.class, CALLS_REAL_METHODS)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(PRACTICE_ID))).thenReturn("testPracticeId");

            String deploymentId = "testDeploymentId";
            JSONObject inputObject = new JSONObject();
            inputObject.put("DEPLOYMENT_ID", deploymentId);

            JSONObject outputObject = new JSONObject();
            JSONArray locationArray = new JSONArray();
            JSONObject location = new JSONObject();
            location.put("LOCATION_ID", "location1");
            locationArray.put(location);
            outputObject.put("LOCATIONS", locationArray);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(LOCATIONS))).thenReturn(locationArray);

            doNothing().when(handlerUtils).addPracticeId(deploymentId, inputObject);
            when(athenaApiCaller.call(eq(GET_LOCATIONS.getKey()), any(), anyString())).thenReturn(outputObject);
            doNothing().when(athenaConfigCache).setPracticeLocationMap(anyString(), any(JSONArray.class));

            JSONObject result = getLocationsHandler.doExecute(inputObject);
            System.out.println(result);
            assertNotNull(result);
            assertEquals("location1", result.getJSONArray("LOCATIONS").getJSONObject(0).getString("LOCATION_ID"));
            verify(athenaConfigCache, times(1)).setPracticeLocationMap(anyString(), any(JSONArray.class));
        }
    }

}