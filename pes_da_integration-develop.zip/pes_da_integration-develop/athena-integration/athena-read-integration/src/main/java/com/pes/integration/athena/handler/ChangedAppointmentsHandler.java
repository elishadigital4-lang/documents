package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.EPMFilter;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractE2DSyncHandler;
import com.pes.integration.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.pes.integration.athena.api.ApiName.CHANGED_APPOINTMENTS;
import static com.pes.integration.athena.constant.AthenaConstants.DATE_FORMAT;
import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_SYNC;
import static com.pes.integration.constant.DocASAPConstants.Key.DOB;
import static com.pes.integration.constant.DocASAPConstants.Key.PATIENT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.CANCEL_REASON;
import static com.pes.integration.constant.DocASAPConstants.TempKey.END_DATE;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_DATE;
import static com.pes.integration.constant.DocASAPConstants.TempKey.*;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.COMMA;
import static com.pes.integration.constant.UtilitiesConstants.FALSE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_TYPE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.TRUE;
import static com.pes.integration.enums.HandlerType.CANCEL_APPOINTMENT;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static java.util.concurrent.CompletableFuture.runAsync;

@Slf4j
@Service(value = "ChangedAppt")
public class ChangedAppointmentsHandler extends AbstractE2DSyncHandler {

    @Autowired
    AthenaApiCaller athenaApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    AthenaConfigCache athenaConfigCache;

    @Autowired
    GetAppointmentTypesHandler getAppointmentTypesHandler;

    @Autowired
    EPMFilter epmFilter;

    @Autowired
    MiniBaselineHandler miniBaselineHandler;

    /**
     * defines the EPM specific way of getting changed appointments
     *
     * @throws IHubException
     */
    @Override
    protected JSONObject getChangedAppointments(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        if (!NullChecker.isEmpty(getValue(inputObject, "lastPulled"))) {
            inputObject.remove("lastPulled");
        }
        log.info("getChangedAppointments for the deployment id {} ", deploymentId);
        handlerUtils.addPracticeId(deploymentId, inputObject);
        String locationIdStr = handlerUtils.addLocationIdList(deploymentId, inputObject);
        setShowPatientDetailFlag(inputObject, deploymentId);
        handlerUtils.getLimit(deploymentId, inputObject);
        long curTime = getCurrentTime();
        if (pullChangeApptByChunkOfDept(deploymentId)) {
            log.info("pullChangeApptByChunkOfDept {} ", true);
            List<List<String>> chunkDeptList = ListUtil.chunkList(locationIdStr,
                    getDeptChunkConfig(deploymentId));
            JSONArray fullAppointmentsArray = new JSONArray();
            int batch = 1;
            for (List<String> locationIds : chunkDeptList) {
                if (!NullChecker.isEmpty(locationIds)) {
                    locationIdStr = StringUtils.join(locationIds, COMMA);
                    setValue(inputObject, APPT_LOCATION_ID, locationIdStr);
                    long batchCurTime = getCurrentTime();
                    outputObject = athenaApiCaller.call(CHANGED_APPOINTMENTS.getKey(), inputObject, "E2D");
                    JSONObject outputJson = outputObject;
                    if (outputJson.has(APPOINTMENT_SYNC)) {
                        JSONArray appointmentsArray = outputJson.getJSONArray(APPOINTMENT_SYNC);
                        fullAppointmentsArray.putAll(appointmentsArray);
                    }
                    log.info(
                            "Time taken to pull realtime data for deploymentId: " + deploymentId + " for batch-"
                                    + batch + " with size-" + locationIds.size() + " is: " + getTimeDiff(batchCurTime,
                                    getCurrentTime()) + " ms");
                    outputObject.clear();
                    batch++;
                }
            }
            setValue(outputObject, APPOINTMENT_SYNC, fullAppointmentsArray);

        } else {
            outputObject = athenaApiCaller.call(CHANGED_APPOINTMENTS.getKey(), inputObject, "E2D");
            log.info("Time taken to pull realtime data for deploymentId: " + deploymentId
                    + " without batching is: " + getTimeDiff(curTime, getCurrentTime()) + " ms");
        }
        setValue(outputObject, "fetchStartTime", curTime);
        return outputObject;
    }

    private void setShowPatientDetailFlag(JSONObject inputObject, String deploymentId)
            throws IHubException {
        boolean showPatDetailFlag = true;
        try {
            String showPatDetail = (String) dataCacheManager.getStoredProvidersConfig(
                    AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                    AthenaEngineConstants.ATHENA_CONFIG, AthenaEngineConstants.SHOW_PATIENT_DETAIL, false);
            showPatDetailFlag = !showPatDetail.equalsIgnoreCase(FALSE);
        } catch (IHubException e) {
            showPatDetailFlag = true;
        }
        setValue(inputObject, TempKey.SHOW_PATIENT_DETAIL, showPatDetailFlag);
    }

    private boolean pullChangeApptByChunkOfDept(String deploymentId) {
        try {
            //dept_chunk_size
            String pullByDeptChunk = (String) dataCacheManager.getStoredProvidersConfig(
                    AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId, AthenaEngineConstants.ATHENA_CONFIG,
                    AthenaEngineConstants.PULL_BY_DEPT_CHUNK, false);

            return pullByDeptChunk.equalsIgnoreCase(TRUE);
        } catch (IHubException e) {
            return false;
        }
    }

    private int getDeptChunkConfig(String deploymentId) {
        int chunkSize = 50;
        try {
            String chunkSizeConfig = (String) dataCacheManager.getStoredProvidersConfig(
                    AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                    AthenaEngineConstants.ATHENA_CONFIG, AthenaEngineConstants.DEPT_CHUNK_SIZE, false);
            if (!NullChecker.isEmpty(chunkSizeConfig) && !chunkSizeConfig.equals("0")) {
                chunkSize = Integer.parseInt(chunkSizeConfig);
            }
            return chunkSize;
        } catch (IHubException e) {
            return 50;
        }
    }

    /**
     * @param appointmentsArray
     * @throws IHubException
     */
    @Override
    protected JSONArray buildE2DSyncObject(JSONArray appointmentsArray, JSONObject inputObject,
                                           String deploymentId) throws IHubException {
        for (int i = 0; i < appointmentsArray.length(); i++) {
            JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
            String startDate = (String) getValue(appointmentObject, START_DATE);
            String startTime = (String) getValue(appointmentObject, START_TIME);
            String startDateTime = DateUtils.getDocasapDateTime(startDate, startTime);
            setValue(appointmentObject, APPOINTMENT_TIMING_START, startDateTime);
            Object appointmentStatus = getValue(appointmentObject, APPOINTMENT_STATUS);
            Object rescheduledAppointmentId = getValue(appointmentObject,
                    RESCHEDULED_APPOINTMENT_ID);
            if (handlerUtils.getUseLocalProviderId(deploymentId)) {
                String localProviderId = (String) getValue(appointmentObject, LOCAL_RESOURCE_ID);
                setValue(appointmentObject, APPT_RESOURCE_ID, localProviderId);
            }
            String messageType = null;
            if (appointmentStatus.equals(APPOINTMENT_TYPE_CANCELED)) {
                Object cancelReasonId = getValue(appointmentObject, CANCEL_REASON);
                Object noShowReasonIdString = dataCacheManager.getStoredProvidersConfig(
                        AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId,
                        AthenaEngineConstants.ATHENA_CONFIG, AthenaEngineConstants.NO_SHOW_ID, false);
                String[] noShowIds = new String[0];
                noShowIds = getNoShowIds(noShowReasonIdString, noShowIds);
                if (rescheduledAppointmentId != null) {
                    messageType = CANCEL_APPOINTMENT.getKey();
                } else if (cancelReasonId != null && Arrays.asList(noShowIds).contains(cancelReasonId)) {
                    messageType = HandlerType.NO_SHOW_APPOINTMENT.getKey();
                } else {
                    messageType = CANCEL_APPOINTMENT.getKey();
                }
            } else if (appointmentStatus.equals(APPOINTMENT_TYPE_FUTURE)) {
                messageType = HandlerType.NEW_APPOINTMENT.getKey();
            } else if (appointmentStatus.equals(APPOINTMENT_TYPE_OPEN)) {
                Object isFrozen = getValue(appointmentObject, FROZEN);
                if (!NullChecker.isEmpty(isFrozen) && isFrozen.equals(TRUE)) {
                    messageType = BLOCK_SYNC;
                } else if (!NullChecker.isEmpty(isFrozen) && isFrozen.equals(FALSE)) {
                    updateGenericAppointmentTypes(appointmentObject, inputObject, deploymentId);
                    messageType = UNBLOCK_SYNC;
                }
            }
            setValue(appointmentObject, DocASAPConstants.TempKey.TEMP, null);
            setValue(appointmentObject, MESSAGE_TYPE, messageType);

            String messageControlId = MessageControlIdGenerator.generateMessageControlId();
            setValue(appointmentObject, DEPLOYMENT_ID, deploymentId);
            setValue(appointmentObject, MESSAGE_CONTROL_ID, messageControlId);
            if (messageType == null) {
                appointmentsArray.remove(i);
                i--;
            } else {
                PhoneNumberUtils.handlePhoneNumbersE2D(appointmentObject);
                setDob(appointmentObject);
                Object languagePref = getValue(appointmentObject, LANGUAGE_PREFERENCE);
                if (!NullChecker.isEmpty(languagePref)) {
                    String languagePreference = (String) languagePref;
                    String languageName = LanguageUtil.getNameFromISO6392Code(languagePreference);
                    if (!NullChecker.isEmpty(languageName)) {
                        setValue(appointmentObject, LANGUAGE_PREFERENCE, languageName);
                    } else {
                        setValue(appointmentObject, LANGUAGE_PREFERENCE, null);
                    }
                }
                Object externalPatientId = getValue(appointmentObject, PATIENT_ID);
                if (!NullChecker.isEmpty(externalPatientId)) {
                    setNotifications(appointmentObject, externalPatientId, deploymentId);
                }
            }
        }
        return appointmentsArray;
    }

    private void updateGenericAppointmentTypes(JSONObject appointmentObject, JSONObject inputObject,
                                               String deploymentId) {
        if (appointmentObject == null) {
            return;
        }
        List<String> genAptTypesWithSpAptTypes = handlerUtils.getGenericApptTypeDBConfig(deploymentId);

        for (String genApptTypeWithSpAptTypeIds : genAptTypesWithSpAptTypes) {
            //new code to check if ":" present in string
            String genApptTypeId;

            String apptReasonId = (String) getValue(appointmentObject, EVENT_REASON_ID);
            if (genApptTypeWithSpAptTypeIds.contains(":")) {
                int index = genApptTypeWithSpAptTypeIds.indexOf(":");
                genApptTypeId = genApptTypeWithSpAptTypeIds.substring(0, index);
                String spApptTypeIdsString = genApptTypeWithSpAptTypeIds.substring(index + 1);
                if (genApptTypeId != null && genApptTypeId.equals(apptReasonId)) {
                    setEventReasonId(appointmentObject, spApptTypeIdsString);
                }
            } else {
                if (genApptTypeWithSpAptTypeIds.equals(apptReasonId)) {
                    String scheduleAbleApptTypes = handlerUtils.getScheduleAbleAppointmentTypes(
                            genApptTypeWithSpAptTypeIds, getAppointmentTypeList(inputObject));
                    setEventReasonId(appointmentObject, scheduleAbleApptTypes);
                }
            }
        }
    }

    private void setEventReasonId(JSONObject appointmentObject, String value) {
        try {
            setValue(appointmentObject, EVENT_REASON_ID, value);
        } catch (IHubException e) {
            log.error(e.getMessage());
        }
    }

    public Map<String, String> getAppointmentTypeList(JSONObject inputObject) {
        String practiceId = (String) getValue(inputObject,
                DocASAPConstants.TempKey.PRACTICE_ID);
        Map<String, String> apptTypeMap = athenaConfigCache.getAppointmentTypeList(practiceId);
        try {
            if (apptTypeMap == null || apptTypeMap.isEmpty()) {
                JSONObject apptTypeObject;
                apptTypeObject = getAppointmentTypesHandler.doExecute(inputObject);
                apptTypeObject.clear();
                apptTypeMap = athenaConfigCache.getAppointmentTypeList(practiceId);
            }
        } catch (IHubException e) {
            log.error(e.getMessage());
        }
        return apptTypeMap;
    }

    private void setDob(JSONObject appointmentObject) {
        String dob = null;
        try {
            Object dobObj = getValue(appointmentObject, DOB);
            if (!NullChecker.isEmpty(dobObj)) {
                dob = (String) dobObj;
                dob = convertDateFormat(dob, DATE_FORMAT, DOCASAP_DATE_FORMAT);
                setValue(appointmentObject, DOB, dob);
            }
        } catch (Exception e) {
            log.info("DOB received was invalid or null: {} ", dob);
            log.error(e.getMessage());
        }
    }

    private void setNotifications(JSONObject appointmentObject, Object externalPatientId,
                                  String deploymentId) {
        try {
            String consentToText = (String) getValue(appointmentObject, CONSENT_TO_TEXT);
            String email = (String) getValue(appointmentObject, EMAIL);
            if (!NullChecker.isEmpty(consentToText) && consentToText.equals(TRUE) && !NullChecker.isEmpty(
                    email)) {
                setValue(appointmentObject, DocASAPConstants.Key.NON_OAS_NOTIFICATION, DAON);
            } else if (!NullChecker.isEmpty(consentToText) && consentToText.equals(TRUE)
                    && NullChecker.isEmpty(email)) {
                setValue(appointmentObject, DocASAPConstants.Key.NON_OAS_NOTIFICATION,
                        DocASAPConstants.Key.DATON);
            } else if (!NullChecker.isEmpty(consentToText) && consentToText.equals(FALSE)
                    && !NullChecker.isEmpty(email)) {
                setValue(appointmentObject, DocASAPConstants.Key.NON_OAS_NOTIFICATION,
                        DocASAPConstants.Key.DAEON);
            } else if (!NullChecker.isEmpty(consentToText) && consentToText.equals(FALSE)
                    && NullChecker.isEmpty(email)) {
                setValue(appointmentObject, DocASAPConstants.Key.NON_OAS_NOTIFICATION,
                        DocASAPConstants.Key.DAOFF);
            } else {
                setValue(appointmentObject, DocASAPConstants.Key.NON_OAS_NOTIFICATION, DAON);
            }
        } catch (Exception e) {
            log.info(
                    "Error in setting NonOASNotification for patient " + externalPatientId + ", deploymentId:"
                            + deploymentId);
        }
    }

    private String[] getNoShowIds(Object noShowReasonIdString, String[] noShowIds) {
        try {
            noShowIds = ((String) noShowReasonIdString).split(",");
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return noShowIds;
    }

    /**
     * defines the EPM specific way of filtering out the unwanted appointments
     *
     * @param appointmentsArray
     * @return
     */
    @Override
    protected JSONArray applyFilter(String deploymentId, JSONArray appointmentsArray) {
        if (appointmentsArray == null) {
            return null;
        }
        if (handlerUtils.shouldStoreFilterLocationInCache(deploymentId)) {
            return appointmentsArray;
        }
        JSONArray filteredArray = new JSONArray();
        for (int i = 0; i < appointmentsArray.length(); i++) {
            JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
            String locationId = (String) getValue(appointmentObject, APPT_LOCATION_ID);
            String providerId = (String) getValue(appointmentObject, APPT_RESOURCE_ID);
            if (epmFilter.isAllowed(deploymentId, locationId, providerId)) {
                filteredArray.put(appointmentObject);
            }
        }
        return filteredArray;
    }

    @Override
    protected void postE2DSyncAction(JSONArray appointmentsArray, String deploymentId) {
        String isMinibaseline;
        try {
                isMinibaseline = (String) dataCacheManager.getStoredProvidersConfig(
                        AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId, ATHENA_CONFIG,
                        UtilitiesConstants.JsonConstants.IS_MINIBASELINE, false);
                if (StringUtils.isBlank(isMinibaseline)) {
                    log.warn("isMinibaseline is null, defaulting to TRUE");
                    isMinibaseline = TRUE;
                }

        } catch (IHubException e) {
            log.info("Exception : isMinibaseline, defaulting to TRUE");
            isMinibaseline=TRUE;
        }
        log.info("isMinibaseline {}", isMinibaseline);
        if (TRUE.equalsIgnoreCase(isMinibaseline)) {
            runBaselineAfterCancel(appointmentsArray, deploymentId);
        }
    }

    @Override
    protected boolean isNewOrg(String deploymentId) throws IHubException {
        try {
            String isNewOrgVal = (String) dataCacheManager.getStoredProvidersConfig(
                    AthenaEngineConstants.EPM_NAME_PREFIX, deploymentId, UtilitiesConstants.GENERIC_CONFIG,
                    UtilitiesConstants.JsonConstants.IS_NEW, false);
            log.info("isNewOrgVal {}", isNewOrgVal);

            return isNewOrgVal.equalsIgnoreCase(UtilitiesConstants.TRUE);
        } catch (IHubException e) {
            return false;
        }
    }

    @Override
    protected void updateIsNewOrgConfig(String deploymentId) throws IHubException {
        JSONObject saveConfigJson = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject orgDetails = new JSONObject();
        orgDetails.put(DEPLOYMENT_ID, deploymentId);
        List<String> configGroupNames = Arrays.asList(StringUtils.split(AthenaEngineConstants.EPM_CONFIG_GROUPS, UtilitiesConstants.CharacterConstants.COMMA));
        orgDetails.put(UtilitiesConstants.JsonConstants.CONFIG_GROUP_NAMES, configGroupNames);
        data.put(UtilitiesConstants.JsonConstants.ORG_DETAILS, orgDetails);
        JSONObject orgConfigs = new JSONObject();
        orgConfigs.put(UtilitiesConstants.JsonConstants.IS_NEW, UtilitiesConstants.FALSE);
        data.put(UtilitiesConstants.JsonConstants.ORG_CONFIGS, orgConfigs);
        saveConfigJson.put(UtilitiesConstants.JsonConstants.DATA, data);
        iHubDataServiceDelegator.iHubAddUpdateOrg(saveConfigJson.toString());
    }

    private void runBaselineAfterCancel(JSONArray appointmentsArray,String deploymentId) {
        if (!NullChecker.isEmpty(appointmentsArray)) {
            for (int i = 0; i < appointmentsArray.length(); i++) {
                JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
                String messageType = (String) getValue(appointmentObject, MESSAGE_TYPE);
                if (CANCEL_APPOINTMENT.getKey().equals(messageType)) {
                    try {
                        JSONObject baselineInputObject = new JSONObject();
                        copyKey(DEPLOYMENT_ID, appointmentObject, baselineInputObject);
                        String startDate = (String) getValue(appointmentObject, APPOINTMENT_TIMING_START);
                        String providerId = (String) getValue(appointmentObject, APPT_RESOURCE_ID);
                        String locationId = (String) getValue(appointmentObject, APPT_LOCATION_ID);
                        JSONObject miniBaselinePayload = getMiniBaseLinePayload(deploymentId, providerId, startDate, locationId);
                        runMiniBaseline(miniBaselinePayload);
                    } catch (Exception e) {
                        log.error("Couldn't run baseline sync After Cancel Appointment in E2D for appointment: {} ", appointmentObject);
                    }
                }
            }
        }
    }

    private static JSONObject getMiniBaseLinePayload(String deploymentId, String providerId, String startDate, String locationId) throws IHubException {
        JSONObject  miniBaselineObject = new JSONObject();
        miniBaselineObject.put(DEPLOYMENT_ID, deploymentId);
        setValue(miniBaselineObject, START_DATE, startDate);
        setValue(miniBaselineObject, END_DATE, startDate);
        setValue(miniBaselineObject, APPT_RESOURCE_ID, providerId);
        setValue(miniBaselineObject, APPT_LOCATION_ID, locationId);
        return miniBaselineObject;
    }

    private void runMiniBaseline(JSONObject payload) {
        runAsync(() -> {
            try {
               miniBaselineHandler.doExecute(payload);
            } catch (Exception e) {
                log.error("Error occurred while running mini baseline : with payload {} : Error {} ", payload, e.getMessage());
            }
        });
    }
}
