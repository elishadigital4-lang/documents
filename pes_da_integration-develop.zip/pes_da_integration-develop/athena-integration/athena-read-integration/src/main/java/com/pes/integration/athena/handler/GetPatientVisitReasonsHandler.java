package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service
public class GetPatientVisitReasonsHandler extends BaseHandler {

    @Autowired
    AthenaApiCaller athenaApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    AthenaConfigCache athenaConfigCache;

    @Override
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        log.info("Get patient visit reason for deployment id {} ",deploymentId);
        handlerUtils.addPracticeId(deploymentId, inputObject);
        JSONArray locProvFilterArray = handlerUtils.getFilterData(deploymentId, LOCATION_PROVIDER_FILTER);
        if (!NullChecker.isEmpty(locProvFilterArray)) {
            pullPatientVisitReasonFromFilter(locProvFilterArray, inputObject, outputObject);
        } else {
            getPatientVisitReasons(inputObject,outputObject,deploymentId);

        }
        return outputObject;
    }

    private void getPatientVisitReasons(JSONObject inputObject, JSONObject outputObject, String deploymentId) throws IHubException {
        JSONArray locationObjectsArray = new JSONArray();
        locationObjectsArray = getLocations(locationObjectsArray, inputObject);

        JSONArray visitReasonArray = new JSONArray();
        JSONArray visitReasonArrayList = new JSONArray();
        if (!NullChecker.isEmpty(locationObjectsArray)) {
            for (Object locationObj : locationObjectsArray) {
                String locationId = (String) JsonUtils.getValue(locationObj, DocASAPConstants.Key.LOCATION_ID);
                JSONArray providerArray = (JSONArray) JsonUtils.getValue(
                        locationObj, "ProviderIdList");
                if (!NullChecker.isEmpty(providerArray)) {
                    for (Object providerId : providerArray) {
                        JsonUtils.setValue(inputObject, DocASAPConstants.Key.LOCATION_ID, locationId);
                        JsonUtils.setValue(inputObject, DocASAPConstants.Key.PROVIDER_ID, providerId);
                        JSONObject visitReasonOutputObj;
                        JSONObject visitReasonJson = new JSONObject();
                        visitReasonOutputObj = athenaApiCaller.call( ApiName.GET_PATIENT_VISIT_REASONS.getKey(), inputObject,
                            "");
                        JsonUtils.setValue(visitReasonJson, DocASAPConstants.Key.PROVIDER_ID, providerId);
                        JsonUtils.setValue(visitReasonJson, DocASAPConstants.Key.LOCATION_ID, locationId);
                        if (!NullChecker.isEmpty(visitReasonOutputObj)) {
                            JsonUtils.copyKey(DocASAPConstants.Key.VISIT_REASONS, visitReasonOutputObj, visitReasonJson);
                            visitReasonArray.putAll(visitReasonJson);
                        } else
                            continue;

                        JSONArray visitReasonsArrayForProvider = visitReasonOutputObj.getJSONArray(DocASAPConstants.Key.VISIT_REASONS);
                        JSONArray visitReasonsList = new JSONArray();
                        List<String> visitReasons = new ArrayList<>();

                        setVisitReasonList(visitReasonsArrayForProvider, visitReasonsList, visitReasons);

                        JSONObject visitReasonListJson = new JSONObject();
                        JsonUtils.setValue(visitReasonListJson,	DocASAPConstants.Key.PROVIDER_ID, providerId);
                        JsonUtils.setValue(visitReasonListJson, DocASAPConstants.Key.LOCATION_ID, locationId);
                        JsonUtils.setValue(visitReasonListJson, DocASAPConstants.Key.VISIT_REASONS, StringUtils.join(visitReasonsList, CharacterConstants.COMMA));
                        visitReasonArrayList.putAll(visitReasonListJson);
                    }
                }
            }
        }
        JsonUtils.setValue(outputObject, PATIENT_APPT_REASONS, visitReasonArray);
        athenaConfigCache.setVisitReasonArrayMap(deploymentId, visitReasonArrayList);
        JsonUtils.setValue(outputObject, PATIENT_APPT_REASONS_ARRAY, visitReasonArrayList);
    }

    private void setVisitReasonList(JSONArray visitReasonsArrayForProvider, JSONArray visitReasonsList,
                                    List<String> visitReasons) {
        for (Object obj : visitReasonsArrayForProvider) {
            JSONObject visitReasonForProvider = (JSONObject) obj;
            String visitReasonId = visitReasonForProvider.getString(ID);
            visitReasons.add(visitReasonId);
            visitReasonsList.put(visitReasonId);
        }
    }

    private JSONArray getLocations(JSONArray locationObjectsArray, JSONObject inputObject) {
        try {
            locationObjectsArray = handlerUtils.getLocationList(inputObject);
        } catch (Exception e) {
            log.info("Error in fetching locations");
        }
        return locationObjectsArray;
    }

    private void pullPatientVisitReasonFromFilter(JSONArray locProvFilterArray, JSONObject inputObject, JSONObject outputObject) throws IHubException{
        try{
            String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
            JSONArray visitReasonArray = new JSONArray();
            JSONArray visitReasonArrayList = new JSONArray();
            for(int i=0;i<locProvFilterArray.length();i++){
                JSONObject filterObject = locProvFilterArray.getJSONObject(i);

                String providerId = filterObject.getString(UtilitiesConstants.PROVIDER_ID);
                String locationId = filterObject.getString(UtilitiesConstants.LOCATION_ID);

                JsonUtils.setValue(inputObject, DocASAPConstants.Key.LOCATION_ID, locationId);
                JsonUtils.setValue(inputObject, DocASAPConstants.Key.PROVIDER_ID, providerId);
                JSONObject visitReasonOutputObj;
                JSONObject visitReasonJson = new JSONObject();
                visitReasonOutputObj = athenaApiCaller.call(ApiName.GET_PATIENT_VISIT_REASONS.getKey(), inputObject,
                    "");
                JsonUtils.setValue(visitReasonJson, DocASAPConstants.Key.PROVIDER_ID, providerId);
                JsonUtils.setValue(visitReasonJson, DocASAPConstants.Key.LOCATION_ID, locationId);
                if(!NullChecker.isEmpty(visitReasonOutputObj)){
                    JsonUtils.copyKey(DocASAPConstants.Key.VISIT_REASONS, visitReasonOutputObj, visitReasonJson);
                    visitReasonArray.put(visitReasonJson);
                } else continue;

                JSONArray visitReasonsArrayForProvider = visitReasonOutputObj.getJSONArray(DocASAPConstants.Key.VISIT_REASONS);
                JSONArray visitReasonsList = new JSONArray();
                List<String> visitReasons = new ArrayList<>();

                setVisitReasonList(visitReasonsArrayForProvider, visitReasonsList, visitReasons);

                JSONObject visitReasonListJson = new JSONObject();
                JsonUtils.setValue(visitReasonListJson, DocASAPConstants.Key.PROVIDER_ID, providerId);
                JsonUtils.setValue(visitReasonListJson, DocASAPConstants.Key.LOCATION_ID, locationId);
                JsonUtils.setValue(visitReasonListJson, DocASAPConstants.Key.VISIT_REASONS, StringUtils.join(visitReasonsList, CharacterConstants.COMMA));
                visitReasonArrayList.put(visitReasonListJson);
            }
            JsonUtils.setValue(outputObject, DocASAPConstants.Key.PATIENT_APPT_REASONS, visitReasonArray);
            athenaConfigCache.setVisitReasonArrayMap(deploymentId, visitReasonArrayList);
            JsonUtils.setValue(outputObject, DocASAPConstants.Key.PATIENT_APPT_REASONS_ARRAY, visitReasonArrayList);
        }catch (Exception e){
            log.error(e.getMessage());
        }
    }


}
