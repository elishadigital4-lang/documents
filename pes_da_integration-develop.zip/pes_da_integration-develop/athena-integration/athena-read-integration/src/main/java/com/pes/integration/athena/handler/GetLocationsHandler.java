package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.athena.api.ApiName.GET_LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PRACTICE_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PROVIDER_LIST;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.TRUE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service
public class GetLocationsHandler extends BaseHandler {

    @Autowired
    AthenaApiCaller athenaApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    AthenaConfigCache athenaConfigCache;

    @Override
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        log.info("Get Location for deployment id {} ",deploymentId);
        handlerUtils.addPracticeId(deploymentId, inputObject);
        JsonUtils.setValue(inputObject, PROVIDER_LIST, TRUE);
        JSONObject outputObject = athenaApiCaller.call(GET_LOCATIONS.getKey(), inputObject, "");
        //store location id's list for future use
        JSONArray locationObjectsArray = (JSONArray) JsonUtils.getValue(outputObject, LOCATIONS);
        String practiceId = (String) JsonUtils.getValue(inputObject, PRACTICE_ID);
        athenaConfigCache.setPracticeLocationMap(practiceId, locationObjectsArray);
        return outputObject;
    }

}
