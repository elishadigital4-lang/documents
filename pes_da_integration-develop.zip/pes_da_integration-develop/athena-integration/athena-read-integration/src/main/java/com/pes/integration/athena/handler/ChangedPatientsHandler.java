package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.ApiName;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.athena.component.PatientNotificationPreferences;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractE2DSyncPatientHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.MessageControlIdGenerator;
import com.pes.integration.utils.PhoneNumberUtils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.athena.api.ApiName.CHANGED_PATIENTS;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service(value = "ChangedPatient")
public class ChangedPatientsHandler extends AbstractE2DSyncPatientHandler {

    @Autowired
    AthenaApiCaller athenaApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    PatientNotificationPreferences patientNotificationPreferences;


    @Override
    protected JSONObject getChangedPatients(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        log.info("getChangedPatients for the deployment id {} " , deploymentId);
        handlerUtils.addPracticeId(deploymentId, inputObject);
        String locationIdStr = getLocationIds(inputObject, deploymentId);
        log.info("locationIds :: {} ", locationIdStr);
        JsonUtils.setValue(inputObject, APPT_LOCATION_ID, locationIdStr);
        return athenaApiCaller.call(CHANGED_PATIENTS.getKey(), inputObject, "E2D");
    }

    private String getLocationIds(JSONObject inputObject, String deploymentId) throws IHubException {
        return handlerUtils.addLocationIdList(deploymentId, inputObject);
    }

    @Override
    protected JSONArray buildE2DSyncObject(JSONArray patientArray, String deploymentId) throws IHubException {
        JSONObject outputJson = new JSONObject();
        JSONArray newPatientsArray = new JSONArray();
        for (int i = 0; i < patientArray.length(); i++) {
            JSONObject patientObject = patientArray.getJSONObject(i);
            String messageType =  HandlerType.UPDATE_PATIENT.getKey();
            Object patientID = JsonUtils.getValue(patientObject, PATIENT_ID);

            try {
                outputJson = new JSONObject(getPatientDemographics(patientID, deploymentId).toString());
            } catch (IHubException e1) {
                log.error(e1.getMessage());
            }
            try {
                PhoneNumberUtils.handlePhoneNumbersE2D(outputJson);
            } catch (IHubException e) {
                log.error(e.getMessage());
            }
            try {
                String dob = (String) JsonUtils.getValue(outputJson, DOB);
                dob = DateUtils.convertDateFormat(dob, AthenaConstants.DATE_FORMAT,
                        DOCASAP_DATE_FORMAT);
                JsonUtils.setValue(outputJson, DOB, dob);
            } catch (Exception e) {
                log.info("DOB received was invalid or null.");
                log.error(e.getMessage());
            }
            try {
                patientNotificationPreferences.setPatientNotificationPreferences(outputJson);
            } catch (Exception e) {
                log.error(e.getMessage());
            }
            JsonUtils.copyKey("DemographicData", outputJson, patientObject);
            JsonUtils.setValue(patientObject, DocASAPConstants.TempKey.TEMP, null);
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.MESSAGE_TYPE, messageType);

            String messageControlId = MessageControlIdGenerator.generateMessageControlId();
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, messageControlId);
            if (messageType != null)
                newPatientsArray.put(patientObject);
        }
        return newPatientsArray;
    }

    @Override
    protected JSONArray applyFilter(JSONArray patientArray) {
        return patientArray;
    }

    @Override
    protected void postE2DSyncAction(JSONArray patientArray) {
        // TODO Auto-generated method stub

    }

    @Override
    protected boolean isNewOrg() throws IHubException {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    protected void updateIsNewOrgConfig() throws IHubException {
        // TODO Auto-generated method stub

    }
    public Object getPatientDemographics(Object patientId, String deploymentId) throws IHubException {
        Object inputJson = new JSONObject();
        handlerUtils.addPracticeId(deploymentId, inputJson);
        JsonUtils.setValue(inputJson, PATIENT_ID, patientId);
        return athenaApiCaller.call(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputJson, "E2D");
    }

}
