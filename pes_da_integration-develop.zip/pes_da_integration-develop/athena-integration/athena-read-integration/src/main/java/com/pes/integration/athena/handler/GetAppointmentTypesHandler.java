package com.pes.integration.athena.handler;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.component.AthenaConfigCache;
import com.pes.integration.athena.component.HandlerUtils;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.MessageControlIdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.athena.api.ApiName.GET_APPOINTMENT_TYPES;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PRACTICE_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_TYPE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service
public class GetAppointmentTypesHandler extends BaseHandler {

    @Autowired
    AthenaApiCaller athenaApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    AthenaConfigCache athenaConfigCache;

    @Override
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        log.info("Get appointment types for deployment id {} ",deploymentId);
        handlerUtils.addPracticeId(deploymentId, inputObject);
        JSONObject outputObject = athenaApiCaller.call(GET_APPOINTMENT_TYPES.getKey(), inputObject,
            "");
        //store appointmentType id's list for future use
        Object appointmentTypeObject = JsonUtils.getValue(outputObject, APPOINTMENT_TYPES);
        if(appointmentTypeObject!=null){
            JSONArray appointmentTypeArray = (JSONArray) appointmentTypeObject;

            Map<String, String> appointmentTypeMap = new HashMap<>();
            for(int i = 0;i<appointmentTypeArray.length();i++){
                JSONObject apptTypeObject = appointmentTypeArray.getJSONObject(i);
                String apptTypeId = (String)JsonUtils.getValue(apptTypeObject, APPOINTMENT_TYPE_ID);
                String apptTypeDuration = (String)JsonUtils.getValue(apptTypeObject, APPOINTMENT_TYPE_DURATION);
                if(apptTypeId!=null && apptTypeDuration!=null){
                    appointmentTypeMap.put(apptTypeId, apptTypeDuration);
                }
            }
            String practiceId = (String) JsonUtils.getValue(inputObject, PRACTICE_ID);
            athenaConfigCache.setAppointmentTypeList(practiceId, appointmentTypeMap);
        }else {
            JsonUtils.setValue(outputObject, ERROR_CODE, HttpStatus.BAD_REQUEST.value());
            JsonUtils.setValue(outputObject, ERROR_MESSAGE, JsonUtils.getValue(outputObject, DocASAPConstants.TempKey.ERROR_MESSAGE));
            JsonUtils.setValue(outputObject, ERROR_DETAIL, JsonUtils.getValue(outputObject, DocASAPConstants.TempKey.ERROR_DETAIL));
        }
        String messageControlId = MessageControlIdGenerator.generateMessageControlId();
        JsonUtils.setValue(outputObject, MESSAGE_TYPE, HandlerType.GET_APPOINTMENT_TYPES.getKey());
        JsonUtils.setValue(outputObject, MESSAGE_CONTROL_ID, messageControlId);
        JsonUtils.setValue(outputObject, TEMP, null);
        return outputObject;
    }
}
