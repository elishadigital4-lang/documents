package com.pes.integration.athena.handler;

import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.service.SendSyncDataService;
import com.pes.integration.service.impl.ApiCallService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Objects;

import static com.pes.integration.athena.constant.AthenaConstants.PROVIDERID;
import static com.pes.integration.constant.DocASAPConstants.DATE_TIME_FORMAT;

import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.END_DATE;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_DATE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.RESET_TYPE;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.MessageControlIdGenerator.generateMessageControlId;

@Slf4j
@Service
public class MiniBaselineHandler extends BaseHandler {

    @Value("${realtime.api.endpoints}")
    String realtimeApiEndpoints;

    @Value("${baseline.api.endpoints}")
    String miniBaselineEndpoint;

    @Autowired
    ApiCallService apiCallService;

    @Autowired
    SendSyncDataService syncDataService;

    @Override
    public JSONObject doExecute(JSONObject inputObject) {
        String deploymentId = (String) getValue(inputObject, DEPLOYMENT_ID);
        JSONObject realTimeResponse = getRealTimeData(deploymentId, inputObject);
        if (!Objects.isNull(realTimeResponse) && realTimeResponse.get("totalCount").equals(0)) {
            log.info("Empty Slot fetched for deploymentId {} and realtimeRequestObject: {}", sanitizeForLog(deploymentId), sanitizeForLog(String.valueOf(inputObject)));
            return null;
        }
        syncDataService.processSendSyncData(getSyncRequestObject(inputObject, realTimeResponse), false);
        log.info("E2D Cancel slot update send to sync layer");
        return inputObject;
    }

    @SneakyThrows
    public JSONObject getRealTimeData(String deploymentId, JSONObject inputObject) {
        String realtimeRequestObject = getRealTimeRequestObject(deploymentId, inputObject);
        String realTimeResponse = apiCallService.callApi(miniBaselineEndpoint, realtimeRequestObject);
        log.info("Realtime data fetched for deploymentId {} and  realtimeRequestObject: {}", sanitizeForLog(deploymentId), sanitizeForLog(realtimeRequestObject));
        return new JSONObject(realTimeResponse);
    }

    @SneakyThrows
    private JSONObject getSyncRequestObject(JSONObject inputObject, JSONObject realTimeResponse) {
        JSONObject syncRequestObject = new JSONObject();
        syncRequestObject.put(DEPLOYMENT_ID, realTimeResponse.getString("deploymentId"));
        syncRequestObject.put(MESSAGE_CONTROL_ID,  realTimeResponse.getString("messageControlId"));
        syncRequestObject.put(RESET, "true");
        syncRequestObject.put("save_status", "false");
        syncRequestObject.put("is_new", true);
        syncRequestObject.put(MESSAGE_TYPE, "BaselineSync");
        String date = convertDateFormat((String) getValue(inputObject, START_DATE), DATE_TIME_FORMAT, "yyyyMMdd");
        syncRequestObject.put("Date", date);
        JSONArray openAppointments = new JSONArray();
        realTimeResponse.getJSONArray("data").forEach(appointment -> {
            JSONObject appointmentObject = new JSONObject();
            JSONObject dataObject = new JSONObject(appointment.toString());
            appointmentObject.put(SLOT_ID, dataObject.getString("slotId"));
            appointmentObject.put("Duration", dataObject.getString("duration"));
            appointmentObject.put("AppointmentDurationUnits", dataObject.getString("durationUnit"));
            appointmentObject.put("ApptTimingStart", dataObject.getString("startTime"));
            appointmentObject.put("ApptReasonId", dataObject.getString("reasonId"));
            appointmentObject.put("LocationId", dataObject.getString("locationId"));
            appointmentObject.put("ProviderId", dataObject.getString(PROVIDERID));
            appointmentObject.put("LocalProviderId", dataObject.getString(PROVIDERID));
            appointmentObject.put("Date", date);
            openAppointments.put(appointmentObject);
        });
        syncRequestObject.put(OPEN_APPOINTMENTS, openAppointments);
        JSONArray resetType = new JSONArray();
        JSONObject resetObject = new JSONObject();
        resetObject.put("ProviderId", getValue(inputObject, APPT_RESOURCE_ID));
        resetObject.put("LocationId",  getValue(inputObject, APPT_LOCATION_ID));
        resetObject.put("Date", date);
        resetType.put(resetObject);
        syncRequestObject.put(RESET_TYPE, resetType);
        JSONObject response = new JSONObject();
        setValue(response, BASELINE_OBJECT, syncRequestObject);
        return response;
    }

    private String getRealTimeRequestObject(String deploymentId, JSONObject inputObject) throws ParseException {
        String locationId = (String) getValue(inputObject, APPT_LOCATION_ID);
        String providerId = (String) getValue(inputObject, APPT_RESOURCE_ID);
        String startDate = (String) getValue(inputObject, START_DATE);
        String endDate = (String) getValue(inputObject, END_DATE);

        JSONObject provLocObject = new JSONObject();
        provLocObject.put("locationId", locationId);
        provLocObject.put("providerId", providerId);
        provLocObject.put("reasonId", "-1");
        JSONArray provLocArray = new JSONArray();
        provLocArray.put(provLocObject);
        JSONObject requestObject = new JSONObject();
        requestObject.put("deploymentId", deploymentId);
        requestObject.put("startDate", convertDateFormat(startDate, DATE_TIME_FORMAT, "yyyy-MM-dd"));
        requestObject.put("endDate", convertDateFormat(endDate, DATE_TIME_FORMAT, "yyyy-MM-dd"));
        requestObject.put("entityId", provLocArray);
        requestObject.put("entityType", "location/provider/reason");
        requestObject.put("messageControlId", generateMessageControlId());
        requestObject.put("flow", "MiniBaseline");
        return requestObject.toString();
    }
}
