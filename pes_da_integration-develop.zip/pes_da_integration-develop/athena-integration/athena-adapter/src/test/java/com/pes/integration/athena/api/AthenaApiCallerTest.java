package com.pes.integration.athena.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.athena.component.AthenaClientCaller;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.athena.dto.Token;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.athena.constant.AthenaConstants.UTF_8;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_REQUEST;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AthenaApiCallerTest {

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    AthenaClientCaller athenaClientCaller;
    @Mock
    RedisService redisService;
    @InjectMocks
    private AthenaApiCaller athenaApiCaller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void encodeUrl_throwsExceptionOnError() throws Exception {
        // Use reflection to access the protected method
        java.lang.reflect.Method method = AthenaApiCaller.class.getDeclaredMethod("encodeUrl", Map.class);
        method.setAccessible(true);

        // Create a map with a value that will cause a NullPointerException
        Map<String, String> params = new java.util.HashMap<>();
        params.put("key", null); // null value will cause parameters.get(keyObj).toString() to throw

        Throwable thrown = assertThrows(InvocationTargetException.class, () -> method.invoke(athenaApiCaller, params));
        assertTrue(thrown.getCause() instanceof IHubException);
        assertEquals(ERROR_IN_REQUEST.getErrorCode(), ((IHubException) thrown.getCause()).getErrorCode());
    }

    @Test
    void buildUrl_removesParameterWhenUrlPartIsColonPrefixed() throws Exception {
        AthenaApiCaller caller = new AthenaApiCaller();
        String url = "/:param1/other";
        Map<String, String> params = new java.util.HashMap<>();
        params.put(":param1", "value1");
        params.put("other", "value2");

        java.lang.reflect.Method method = AthenaApiCaller.class.getDeclaredMethod("buildUrl", String.class, Map.class);
        method.setAccessible(true);
        String result = (String) method.invoke(caller, url, params);

        assertTrue(result.contains("/value1/other"));
    }

    @Test
    void customizeResponseMapping_exceptionIsLogged() throws Exception {
        JSONObject apiResponseMapping = new JSONObject();
        String apiName = "open_appointments";
        // inputObject is not a JSONObject, will cause ClassCastException
        Object inputObject = "not a JSONObject";

        // Use reflection to invoke the protected method
        java.lang.reflect.Method method = AthenaApiCaller.class.getDeclaredMethod(
                "customizeResponseMapping", JSONObject.class, String.class, Object.class);
        method.setAccessible(true);

        // Should not throw, just log error
        JSONObject result = (JSONObject) method.invoke(athenaApiCaller, apiResponseMapping, apiName, inputObject);
        assertEquals(apiResponseMapping, result);
    }

    @Test
    void getMappingConfig_doesNothing() throws Exception {
        // Use reflection to invoke the protected method
        java.lang.reflect.Method method = AthenaApiCaller.class.getDeclaredMethod("getMappingConfig", String.class);
        method.setAccessible(true);
        // Should not throw any exception and do nothing
        method.invoke(athenaApiCaller, "testDeploymentId");
    }

    @Test
    void callApi_throwsExceptionOnJsonProcessingError() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(METHOD, "POST");
        apiConfig.put("url", "http://testUrl");
        JSONObject requestObject = new JSONObject();
        requestObject.put("param1", "value1");

        // Use reflection to set a mock ObjectMapper that throws JsonProcessingException
        ObjectMapper mockMapper = mock(ObjectMapper.class);
        when(mockMapper.readValue(anyString(), eq(Map.class))).thenThrow(new com.fasterxml.jackson.core.JsonProcessingException("Test") {});
        Field mapperField = AthenaApiCaller.class.getDeclaredField("mapper");
        mapperField.setAccessible(true);
        mapperField.set(athenaApiCaller, mockMapper);

        IHubException thrown = assertThrows(IHubException.class, () -> athenaApiCaller.callApi(apiConfig, requestObject));
        assertEquals(ERROR_IN_REQUEST.getErrorCode(), thrown.getErrorCode());
        assertTrue(thrown.getMessage().contains("Error in requestObject parsing"));
    }

    @Test
    void initializeObjectLoadsConfigurationsCorrectly() throws IHubException {
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();
        String version = "v1";
        String key = "testKey";
        String secret = "testSecret";
        String baseUrl = "http://testBaseUrl";
        String tokenUrl = "/token";
        String oauthVersion = "oauth2";

        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG),
                eq(REQUEST_CONFIG_KEY_NAME), eq(false))).thenReturn(requestConfig);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(REQUEST_MAPPING_KEY_NAME), eq(false))).thenReturn(requestMapping);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(RESPONSE_MAPPING_KEY_NAME), eq(false))).thenReturn(responseMapping);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(VERSION), eq(false))).thenReturn(version);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(CLIENT_ID), eq(false))).thenReturn(key);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(CLIENT_SECRET), eq(false))).thenReturn(secret);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(AthenaEngineConstants.BASE_URL), eq(false))).thenReturn(baseUrl);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(TOKEN_URL), eq(false))).thenReturn(tokenUrl);
        when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(ATHENA_CONFIG), eq(OAUTH_VERSION), eq(false))).thenReturn(oauthVersion);

        athenaApiCaller.initializeObject();

        verify(cacheManager, times(9)).getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean());
    }

    @Test
    public void callApi_POST() throws IHubException, NoSuchFieldException, IllegalAccessException {
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();
        String version = "v1";
        String key = "testKey";
        String secret = "testSecret";
        String baseUrl = "http://testBaseUrl";
        String tokenUrl = "/token";
        String oauthVersion = "oauth2";
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(METHOD, "POST");
        apiConfig.put("url", "http://testUrl");
        JSONObject requestObject = new JSONObject();
        requestObject.put("param1", "value1");
        athenaApiCaller.mapper = new ObjectMapper();

        setPrivateField("baseUrl", baseUrl);
        setPrivateField("version", version);
        setPrivateField("oauthVersion", oauthVersion);
        setPrivateField("tokenUrl", tokenUrl);
        setPrivateField("key", key);
        setPrivateField("secret", secret);

        Token token = new Token();
        token.setAccessToken("testToken");
        token.setExpiresIn("20");
        String responseJson = "{\"data\": \"testData\"}";
        when(athenaClientCaller.getData(eq("POST"), anyString(), anyString(), anyString())).thenReturn(responseJson);
        when(redisService.get(anyString())).thenReturn("");
        doNothing().when(redisService).saveWithTtl("athena_token", token.getAccessToken(), 20);
        when(athenaClientCaller.generateToken(anyString(), any())).thenReturn(token);

        Object response = athenaApiCaller.callApi(apiConfig, requestObject);

        assertTrue(response instanceof JSONObject);
        assertEquals("testData", ((JSONObject) response).getString("data"));

    }
    @Test
    public void callApi_GET() throws IHubException, NoSuchFieldException, IllegalAccessException {
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();
        String version = "v1";
        String key = "testKey";
        String secret = "testSecret";
        String baseUrl = "http://testBaseUrl";
        String tokenUrl = "/token";
        String oauthVersion = "oauth2";
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(METHOD, "GET");
        apiConfig.put("url", "http://testUrl");
        JSONObject requestObject = new JSONObject();
        requestObject.put("param1", "value1");
        athenaApiCaller.mapper = new ObjectMapper();

        setPrivateField("baseUrl", baseUrl);
        setPrivateField("version", version);
        setPrivateField("oauthVersion", oauthVersion);
        setPrivateField("tokenUrl", tokenUrl);
        setPrivateField("key", key);
        setPrivateField("secret", secret);

        Token token = new Token();
        token.setAccessToken("testToken");
        token.setExpiresIn("20");
        String responseJson = "{\"data\": \"testData\"}";
        when(athenaClientCaller.getData(eq("GET"), anyString(), anyString(), anyString())).thenReturn(responseJson);
        when(redisService.get(anyString())).thenReturn("");
        doNothing().when(redisService).saveWithTtl("athena_token", token.getAccessToken(), 20);
        when(athenaClientCaller.generateToken(anyString(), any())).thenReturn(token);

        Object response = athenaApiCaller.callApi(apiConfig, requestObject);

        assertTrue(response instanceof JSONObject);
        assertEquals("testData", ((JSONObject) response).getString("data"));

    }
    @Test
    void customizeResponseMappingForOpenAppointmentsWithReasonMapTrue() throws Exception {
        JSONObject apiResponseMapping = new JSONObject();
        apiResponseMapping.put(APPT_TYPE_ID, "someValue");
        apiResponseMapping.put(REASON_ID_ARRAY, "someArray");

        JSONObject inputObject = new JSONObject();
        inputObject.put(DA_APPOINTMENT_ID, "testDeploymentId");

        when(cacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("true");

        JSONObject result = athenaApiCaller.customizeResponseMapping(apiResponseMapping, "open_appointments", inputObject);

        assertFalse(result.has(APPT_TYPE_ID));
        assertEquals("OpenAppointments[].ApptReasonId[]", result.getString(REASON_ID_ARRAY));
    }

    @Test
    void customizeResponseMappingForOpenAppointmentsWithReasonMapFalse() throws Exception {
        JSONObject apiResponseMapping = new JSONObject();
        apiResponseMapping.put(APPT_TYPE_ID, "someValue");
        apiResponseMapping.put(REASON_ID_ARRAY, "someArray");

        JSONObject inputObject = new JSONObject();
        inputObject.put(DA_APPOINTMENT_ID, "testDeploymentId");

        when(cacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("false");

        JSONObject result = athenaApiCaller.customizeResponseMapping(apiResponseMapping, "open_appointments", inputObject);

        assertFalse(result.has(REASON_ID_ARRAY));
        assertEquals("OpenAppointments[].ApptReasonId", result.getString(APPT_TYPE_ID));
    }
    private void setPrivateField(String name, String value) throws NoSuchFieldException, IllegalAccessException {
        Field declaredField = AthenaApiCaller.class.getDeclaredField(name);
        declaredField.setAccessible(true);
        declaredField.set(athenaApiCaller, value);
    }

    @Test
    public void callApi_POST_JsonArray() throws IHubException, NoSuchFieldException, IllegalAccessException {
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();
        String version = "v1";
        String key = "testKey";
        String secret = "testSecret";
        String baseUrl = "http://testBaseUrl";
        String tokenUrl = "/token";
        String oauthVersion = "oauth2";
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(METHOD, "POST");
        apiConfig.put("url", "http://testUrl");
        JSONObject requestObject = new JSONObject();
        requestObject.put("param1", "value1");
        athenaApiCaller.mapper = new ObjectMapper();

        setPrivateField("baseUrl", baseUrl);
        setPrivateField("version", version);
        setPrivateField("oauthVersion", oauthVersion);
        setPrivateField("tokenUrl", tokenUrl);
        setPrivateField("key", key);
        setPrivateField("secret", secret);

        Token token = new Token();
        token.setAccessToken("testToken");
        token.setExpiresIn("20");
        String responseJson = "[{\"message_status\":\"recfromda\",\"deployment_id\":\"747292^0001\"}]";
        when(athenaClientCaller.getData(eq("POST"), anyString(), anyString(), anyString())).thenReturn(responseJson);
        when(redisService.get(anyString())).thenReturn("");
        doNothing().when(redisService).saveWithTtl("athena_token", token.getAccessToken(), 20);
        when(athenaClientCaller.generateToken(anyString(), any())).thenReturn(token);

        Object response = athenaApiCaller.callApi(apiConfig, requestObject);

        assertTrue(response instanceof JSONArray);

    }

    @Test
    public void callApi_Exception() throws IHubException, NoSuchFieldException, IllegalAccessException {
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();
        String version = "v1";
        String key = "testKey";
        String secret = "testSecret";
        String baseUrl = "http://testBaseUrl";
        String tokenUrl = "/token";
        String oauthVersion = "oauth2";
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(METHOD, "POST");
        apiConfig.put("url", "http://testUrl");
        JSONObject requestObject = new JSONObject();
        requestObject.put("param1", "value1");
        athenaApiCaller.mapper = new ObjectMapper();

        setPrivateField("baseUrl", baseUrl);
        setPrivateField("version", version);
        setPrivateField("oauthVersion", oauthVersion);
        setPrivateField("tokenUrl", tokenUrl);
        setPrivateField("key", key);
        setPrivateField("secret", secret);

        Token token = new Token();
        token.setAccessToken("testToken");
        token.setExpiresIn("20");
        String responseJson = "[{\"message_status\":\"recfromda\",\"deployment_id\":\"747292^0001\"}]";
        when(athenaClientCaller.getData(eq("POST"), anyString(), anyString(), anyString())).thenThrow(new RuntimeException("error"));
        when(redisService.get(anyString())).thenReturn("");
        doNothing().when(redisService).saveWithTtl("athena_token", token.getAccessToken(), 20);
        when(athenaClientCaller.generateToken(anyString(), any())).thenReturn(token);

        assertThrows(Exception.class, () ->  athenaApiCaller.callApi(apiConfig, requestObject));
    }

    @Test
    public void callApi_GET_JsonArray() throws IHubException, NoSuchFieldException, IllegalAccessException {
        JSONObject requestConfig = new JSONObject();
        JSONObject requestMapping = new JSONObject();
        JSONObject responseMapping = new JSONObject();
        String version = "v1";
        String key = "testKey";
        String secret = "testSecret";
        String baseUrl = "http://testBaseUrl";
        String tokenUrl = "/token";
        String oauthVersion = "oauth2";
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(METHOD, "GET");
        apiConfig.put("url", "http://testUrl");
        JSONObject requestObject = new JSONObject();
        requestObject.put("param1", "value1");
        athenaApiCaller.mapper = new ObjectMapper();

        setPrivateField("baseUrl", baseUrl);
        setPrivateField("version", version);
        setPrivateField("oauthVersion", oauthVersion);
        setPrivateField("tokenUrl", tokenUrl);
        setPrivateField("key", key);
        setPrivateField("secret", secret);

        Token token = new Token();
        token.setAccessToken("testToken");
        token.setExpiresIn("20");
        String responseJson = "[{\"message_status\":\"recfromda\",\"deployment_id\":\"747292^0001\"}]";
        when(athenaClientCaller.getData(eq("GET"), anyString(), anyString(), anyString())).thenReturn(responseJson);
        when(redisService.get(anyString())).thenReturn("");
        doNothing().when(redisService).saveWithTtl("athena_token", token.getAccessToken(), 20);
        when(athenaClientCaller.generateToken(anyString(), any())).thenReturn(token);

        Object response = athenaApiCaller.callApi(apiConfig, requestObject);

        assertTrue(response instanceof JSONArray);
    }

    @Test
    void encodeUrl_encodesParametersCorrectly() throws Exception {
        AthenaApiCaller caller = new AthenaApiCaller();
        Method method = AthenaApiCaller.class.getDeclaredMethod("encodeUrl", Map.class);
        method.setAccessible(true);

        try (MockedStatic<URLEncoder> mockedURLEncoder = mockStatic(URLEncoder.class)) {
            mockedURLEncoder.when(() -> URLEncoder.encode(anyString(), eq(UTF_8))).thenThrow(new UnsupportedEncodingException("Test"));

            Map<String, String> params = new HashMap<>();
            params.put("key1", "value1");
            params.put("key2", "value2");

            String result = (String) method.invoke(caller, params);

            assertTrue(true);
        }
    }

    @Test
    void encodeUrl_throwsIHubExceptionOnError() throws Exception {
        AthenaApiCaller caller = new AthenaApiCaller();
        Method method = AthenaApiCaller.class.getDeclaredMethod("encodeUrl", Map.class);
        method.setAccessible(true);

        // Create a map that will cause a NullPointerException
        Map<Object, Object> params = new HashMap<>();
        params.put(null, "value");

        Exception thrown = assertThrows(Exception.class, () -> method.invoke(caller, params));
        assertTrue(thrown.getCause() instanceof IHubException);
    }


}