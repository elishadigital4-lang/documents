package com.pes.integration.athena.api;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ApiNameTest {

    @Test
    void getKeyReturnsCorrectKey() {
        assertEquals("new_appointment", ApiName.NEW_APPOINTMENT.getKey());
        assertEquals("cancel_appointment", ApiName.CANCEL_APPOINTMENT.getKey());
        assertEquals("open_appointments", ApiName.OPEN_APPOINTMENTS.getKey());
        assertEquals("changed_appointments", ApiName.CHANGED_APPOINTMENTS.getKey());
        assertEquals("changed_appointments_subscription", ApiName.CHANGED_APPOINTMENTS_SUBSCRIPTION.getKey());
        assertEquals("reschedule_appointment", ApiName.RESCHEDULE_APPOINTMENT.getKey());
        assertEquals("changed_patients", ApiName.CHANGED_PATIENTS.getKey());
        assertEquals("get_patients", ApiName.GET_PATIENTS.getKey());
        assertEquals("get_patient_insurance", ApiName.GET_PATIENT_INSURANCE.getKey());
        assertEquals("get_patient_demographics", ApiName.GET_PATIENT_DEMOGRAPHICS.getKey());
        assertEquals("set_patient_insurance", ApiName.SET_PATIENT_INSURANCE.getKey());
        assertEquals("update_patient_insurance", ApiName.UPDATE_PATIENT_INSURANCE.getKey());
        assertEquals("delete_patient_insurance", ApiName.DELETE_PATIENT_INSURANCE.getKey());
        assertEquals("new_patient", ApiName.NEW_PATIENT.getKey());
        assertEquals("get_locations", ApiName.GET_LOCATIONS.getKey());
        assertEquals("get_practices", ApiName.GET_PRACTICES.getKey());
        assertEquals("get_providers", ApiName.GET_PROVIDERS.getKey());
        assertEquals("get_insurance_types", ApiName.GET_INSURANCE_TYPES.getKey());
        assertEquals("get_insurance_packages", ApiName.GET_INSURANCE_PACKAGES.getKey());
        assertEquals("get_appointment_types", ApiName.GET_APPOINTMENT_TYPES.getKey());
        assertEquals("update_patient", ApiName.UPDATE_PATIENT.getKey());
        assertEquals("booked_appointments", ApiName.BOOKED_APPOINTMENTS.getKey());
        assertEquals("freeze_appointment", ApiName.FREEZE_APPOINTMENT.getKey());
        assertEquals("get_appointment_cancel_reasons", ApiName.GET_APPOINTMENT_CANCEL_REASONS.getKey());
        assertEquals("get_patient_visit_reasons", ApiName.GET_PATIENT_VISIT_REASONS.getKey());
        assertEquals("verify_patient_privacy_information", ApiName.VERIFY_PATIENT_PRIVACY_INFORMATION.getKey());
        assertEquals("add_custom_fields", ApiName.ADD_CUSTOM_FIELDS.getKey());
        assertEquals("update_appointment_checkin", ApiName.UPDATE_APPOINTMENT_CHECKIN.getKey());
        assertEquals("check_if_patient_registered", ApiName.CHECK_IF_PATIENT_REGISTERED.getKey());
        assertEquals("register_patient_with_department", ApiName.REGISTER_PATIENT_DPPT.getKey());
        assertEquals("is_patient_insured", ApiName.CHECK_IF_PATIENT_INSURED.getKey());
        assertEquals("get_payments", ApiName.GET_PAYMENTS.getKey());
    }

    @Test
    void getEnumReturnsCorrectEnum() {
        assertEquals(ApiName.NEW_APPOINTMENT, ApiName.NEW_APPOINTMENT.getEnum("new_appointment"));
        assertEquals(ApiName.CANCEL_APPOINTMENT, ApiName.CANCEL_APPOINTMENT.getEnum("cancel_appointment"));
        assertEquals(ApiName.OPEN_APPOINTMENTS, ApiName.OPEN_APPOINTMENTS.getEnum("open_appointments"));
        assertEquals(ApiName.CHANGED_APPOINTMENTS, ApiName.CHANGED_APPOINTMENTS.getEnum("changed_appointments"));
        assertEquals(ApiName.CHANGED_APPOINTMENTS_SUBSCRIPTION, ApiName.CHANGED_APPOINTMENTS_SUBSCRIPTION.getEnum("changed_appointments_subscription"));
        assertEquals(ApiName.RESCHEDULE_APPOINTMENT, ApiName.RESCHEDULE_APPOINTMENT.getEnum("reschedule_appointment"));
        assertEquals(ApiName.CHANGED_PATIENTS, ApiName.CHANGED_PATIENTS.getEnum("changed_patients"));
        assertEquals(ApiName.GET_PATIENTS, ApiName.GET_PATIENTS.getEnum("get_patients"));
        assertEquals(ApiName.GET_PATIENT_INSURANCE, ApiName.GET_PATIENT_INSURANCE.getEnum("get_patient_insurance"));
        assertEquals(ApiName.GET_PATIENT_DEMOGRAPHICS, ApiName.GET_PATIENT_DEMOGRAPHICS.getEnum("get_patient_demographics"));
        assertEquals(ApiName.SET_PATIENT_INSURANCE, ApiName.SET_PATIENT_INSURANCE.getEnum("set_patient_insurance"));
        assertEquals(ApiName.UPDATE_PATIENT_INSURANCE, ApiName.UPDATE_PATIENT_INSURANCE.getEnum("update_patient_insurance"));
        assertEquals(ApiName.DELETE_PATIENT_INSURANCE, ApiName.DELETE_PATIENT_INSURANCE.getEnum("delete_patient_insurance"));
        assertEquals(ApiName.NEW_PATIENT, ApiName.NEW_PATIENT.getEnum("new_patient"));
        assertEquals(ApiName.GET_LOCATIONS, ApiName.GET_LOCATIONS.getEnum("get_locations"));
        assertEquals(ApiName.GET_PRACTICES, ApiName.GET_PRACTICES.getEnum("get_practices"));
        assertEquals(ApiName.GET_PROVIDERS, ApiName.GET_PROVIDERS.getEnum("get_providers"));
        assertEquals(ApiName.GET_INSURANCE_TYPES, ApiName.GET_INSURANCE_TYPES.getEnum("get_insurance_types"));
        assertEquals(ApiName.GET_INSURANCE_PACKAGES, ApiName.GET_INSURANCE_PACKAGES.getEnum("get_insurance_packages"));
        assertEquals(ApiName.GET_APPOINTMENT_TYPES, ApiName.GET_APPOINTMENT_TYPES.getEnum("get_appointment_types"));
        assertEquals(ApiName.UPDATE_PATIENT, ApiName.UPDATE_PATIENT.getEnum("update_patient"));
        assertEquals(ApiName.BOOKED_APPOINTMENTS, ApiName.BOOKED_APPOINTMENTS.getEnum("booked_appointments"));
        assertEquals(ApiName.FREEZE_APPOINTMENT, ApiName.FREEZE_APPOINTMENT.getEnum("freeze_appointment"));
        assertEquals(ApiName.GET_APPOINTMENT_CANCEL_REASONS, ApiName.GET_APPOINTMENT_CANCEL_REASONS.getEnum("get_appointment_cancel_reasons"));
        assertEquals(ApiName.GET_PATIENT_VISIT_REASONS, ApiName.GET_PATIENT_VISIT_REASONS.getEnum("get_patient_visit_reasons"));
        assertEquals(ApiName.VERIFY_PATIENT_PRIVACY_INFORMATION, ApiName.VERIFY_PATIENT_PRIVACY_INFORMATION.getEnum("verify_patient_privacy_information"));
        assertEquals(ApiName.ADD_CUSTOM_FIELDS, ApiName.ADD_CUSTOM_FIELDS.getEnum("add_custom_fields"));
        assertEquals(ApiName.UPDATE_APPOINTMENT_CHECKIN, ApiName.UPDATE_APPOINTMENT_CHECKIN.getEnum("update_appointment_checkin"));
        assertEquals(ApiName.CHECK_IF_PATIENT_REGISTERED, ApiName.CHECK_IF_PATIENT_REGISTERED.getEnum("check_if_patient_registered"));
        assertEquals(ApiName.REGISTER_PATIENT_DPPT, ApiName.REGISTER_PATIENT_DPPT.getEnum("register_patient_with_department"));
        assertEquals(ApiName.CHECK_IF_PATIENT_INSURED, ApiName.CHECK_IF_PATIENT_INSURED.getEnum("is_patient_insured"));
        assertEquals(ApiName.GET_PAYMENTS, ApiName.GET_PAYMENTS.getEnum("get_payments"));
    }

    @Test
    void getEnumReturnsNullForInvalidKey() {
        assertNull(ApiName.NEW_APPOINTMENT.getEnum("invalid_key"));
    }

    @Test
    void getEnumIsCaseSensitive() {
        assertNull(ApiName.NEW_APPOINTMENT.getEnum("New_Appointment"));
    }
}