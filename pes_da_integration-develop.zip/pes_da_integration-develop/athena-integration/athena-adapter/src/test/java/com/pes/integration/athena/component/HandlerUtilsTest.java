package com.pes.integration.athena.component;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.FilterDataService;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PRACTICE_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HandlerUtilsTest {

    @InjectMocks
    private HandlerUtils handlerUtils;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private AthenaConfigCache athenaConfigCache;

    @Mock
    private FilterDataService filterDataService;

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

    }

    @Test
    void getLimit_logsErrorWhenComponentConfigThrowsException() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();

        // Simulate getStoredProvidersConfig returning null so getStoredComponentConfig is called
        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(null);
        // Simulate getStoredComponentConfig throwing an exception
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("component config error"));

        handlerUtils.getLimit(deploymentId, inputObject);

        // No assertion needed, just ensure no exception is thrown and log is called
    }

    @Test
    void getLimit_callsGetStoredComponentConfigWhenLimitIsEmpty() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();

        // Simulate getLimitFromOrg and getLimitFromComponent returning null
        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(null);
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("25");

        handlerUtils.getLimit(deploymentId, inputObject);

        assertEquals("25", JsonUtils.getValue(inputObject, DocASAPConstants.TempKey.LIMIT));
    }

    @Test
    void getLimitFromOrg_logsErrorOnException() throws Exception {
        HandlerUtils handlerUtils = new HandlerUtils();
        DataCacheManager mockDataCacheManager = mock(DataCacheManager.class);
        // Inject mock using reflection
        Field field = HandlerUtils.class.getDeclaredField("dataCacheManager");
        field.setAccessible(true);
        field.set(handlerUtils, mockDataCacheManager);

        String deploymentId = "deployment123";
        // Simulate exception
        when(mockDataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("test error"));

        Method method = HandlerUtils.class.getDeclaredMethod("getLimitFromOrg", String.class, Object.class);
        method.setAccessible(true);
        Object result = method.invoke(handlerUtils, deploymentId, null);

        assertNull(result); // Should return null if exception occurs
    }

    @Test
    void getLimitFromComponent_logsErrorOnException() throws Exception {
        HandlerUtils handlerUtils = new HandlerUtils();
        DataCacheManager mockDataCacheManager = mock(DataCacheManager.class);
        // Inject mock using reflection
        Field field = HandlerUtils.class.getDeclaredField("dataCacheManager");
        field.setAccessible(true);
        field.set(handlerUtils, mockDataCacheManager);

        // Simulate exception when getStoredComponentConfig is called
        when(mockDataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("test error"));

        Method method = HandlerUtils.class.getDeclaredMethod("getLimitFromComponent", Object.class);
        method.setAccessible(true);
        // Should not throw, just log error
        Object result = method.invoke(handlerUtils, (Object) null);
        assertNull(result); // Should return null if limit was null and exception occurred
    }

    @Test
    void getUseLocalProviderIdReturnsFalseWhenIHubExceptionThrown() throws Exception {
        String deploymentId = "deployment123";
        when(dataCacheManager.getStoredProvidersConfig(
                anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(null, "error"));

        assertFalse(handlerUtils.getUseLocalProviderId(deploymentId));
    }

    @Test
    void addLocationIdListCallsGetLocationIdsListWhenNotStoringInCache() throws Exception {
        String deploymentId = "deployment123";
        JSONObject inputObject = new JSONObject();
        String expectedLocationIdList = "loc1,loc2";

        // shouldStoreFilterLocationInCache returns false
        when(dataCacheManager.getStoredProvidersConfig(
                BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                ATHENA_CONFIG, AthenaEngineConstants.RUN_REALTIME_BY_FILTER, false)).thenReturn("false");

        // athenaConfigCache.getLocationIdsList should be called
        when(athenaConfigCache.getLocationIdsList(inputObject)).thenReturn(expectedLocationIdList);

        String result = handlerUtils.addLocationIdList(deploymentId, inputObject);

        assertEquals(expectedLocationIdList, result);
        verify(athenaConfigCache).getLocationIdsList(inputObject);
    }

    @Test
    void getLimitFromComponentFetchesLimitWhenLimitIsEmpty() throws Exception {
        HandlerUtils handlerUtils = new HandlerUtils();
        DataCacheManager mockDataCacheManager = mock(DataCacheManager.class);
        // Use reflection to inject the mock
        Field field = HandlerUtils.class.getDeclaredField("dataCacheManager");
        field.setAccessible(true);
        field.set(handlerUtils, mockDataCacheManager);

        String expectedLimit = "15";
        when(mockDataCacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, ATHENA_CONFIG, LIMIT, false)).thenReturn(expectedLimit);

        Method method = HandlerUtils.class.getDeclaredMethod("getLimitFromComponent", Object.class);
        method.setAccessible(true);
        Object result = method.invoke(handlerUtils, (Object) null);

        assertEquals(expectedLimit, result);
    }

    @Test
    void getLocationIdsListReturnsCommaSeparatedString() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        JSONArray locationIds = new JSONArray();
        locationIds.put("location1");
        locationIds.put("location2");

        Method method = getMethod("getLocationIdsList", JSONArray.class);
        String result = method.invoke(handlerUtils, locationIds).toString();

        assertEquals("location1,location2", result);
    }

    @Test
    void getLocationIdsListReturnsEmptyStringForEmptyArray() throws Exception {
        JSONArray locationIds = new JSONArray();

        Method method = getMethod("getLocationIdsList", JSONArray.class);
        String result = method.invoke(handlerUtils, locationIds).toString();

        assertEquals("", result);
    }

    @Test
    void addPracticeIdAddsPracticeIdToInputObject() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();
        String practiceId = "practice123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(practiceId);

        handlerUtils.addPracticeId(deploymentId, inputObject);

        assertEquals(practiceId, JsonUtils.getValue(inputObject, PRACTICE_ID));
    }

    @Test
    void addPracticeIdAddsPracticeIdToInputObject_IHubException() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();
        String practiceId = "practice123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode(ERROR_CODE), ERROR_MESSAGE));

        Assertions.assertThrows(IHubException.class, () -> handlerUtils.addPracticeId(deploymentId, inputObject));

    }

    @Test
    void addPracticeIdAddsPracticeIdToInputObject_Exception() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();
        String practiceId = "practice123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException(ERROR_MESSAGE));

        Assertions.assertThrows(IHubException.class, () -> handlerUtils.addPracticeId(deploymentId, inputObject));

    }

    @Test
    void addPracticeIdHandlesEmptyDeploymentId() throws Exception {
        Object inputObject = new JSONObject();

        handlerUtils.addPracticeId("", inputObject);

        assertNull(JsonUtils.getValue(inputObject, PRACTICE_ID));
    }

    @Test
    void getGenericApptTypeDBConfigReturnsListOfApptTypes() throws IHubException {
        String deploymentId = "deployment123";
        String genApptTypesStr = "type1,type2";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(genApptTypesStr);

        List<String> result = handlerUtils.getGenericApptTypeDBConfig(deploymentId);

        assertEquals(2, result.size());
        assertTrue(result.contains("type1"));
        assertTrue(result.contains("type2"));
    }

    @Test
    void getGenericApptTypeDBConfigReturnsListOfApptTypes_Exception() throws IHubException {
        String deploymentId = "deployment123";
        String genApptTypesStr = "type1,type2";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(new RuntimeException("test error"));

        List<String> result = handlerUtils.getGenericApptTypeDBConfig(deploymentId);

        assertEquals(0, result.size());
    }

    @Test
    void getGenericApptTypeDBConfigReturnsEmptyListForEmptyConfig() throws IHubException {
        String deploymentId = "deployment123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn("");

        List<String> result = handlerUtils.getGenericApptTypeDBConfig(deploymentId);

        assertTrue(result.isEmpty());
    }

    @Test
    void getFilterDataReturnsFilterJsonArray() throws Exception {
        String deploymentId = "deployment123";
        String filter = "filter1";
        JSONObject filterListJson = new JSONObject();
        JSONArray filterJsonArray = new JSONArray();
        filterJsonArray.put("value1");
        filterListJson.put(filter, filterJsonArray);

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), eq(filter), anyBoolean()))
                .thenReturn(filterListJson);

        JSONArray result = handlerUtils.getFilterData(deploymentId, filter);

        assertEquals(filterJsonArray.toString(), result.toString());
    }

    @Test
    void getFilterDataReturnsFilterJsonArray_IHubException() throws Exception {
        String deploymentId = "deployment123";
        String filter = "filter1";
        JSONObject filterListJson = new JSONObject();
        JSONArray filterJsonArray = new JSONArray();
        filterJsonArray.put("value1");
        filterListJson.put(filter, filterJsonArray);

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), eq(filter), anyBoolean()))
                .thenReturn(new IHubException(new IHubErrorCode(ERROR_CODE), ERROR_MESSAGE));

        Assertions.assertThrows(IHubException.class, ()-> handlerUtils.getFilterData(deploymentId, filter));

    }

    @Test
    void getFilterDataReturnsFilterJsonArray_Exception() throws Exception {
        String deploymentId = "deployment123";
        String filter = "filter1";
        JSONObject filterListJson = new JSONObject();
        JSONArray filterJsonArray = new JSONArray();
        filterJsonArray.put("value1");
        filterListJson.put(filter, filterJsonArray);

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), eq(filter), anyBoolean()))
                .thenReturn(new RuntimeException( ERROR_MESSAGE));

        Assertions.assertThrows(IHubException.class, ()-> handlerUtils.getFilterData(deploymentId, filter));

    }

    @Test
    void getFilterDataReturnsNullForEmptyDeploymentId() throws Exception {
        JSONArray result = handlerUtils.getFilterData("", "filter1");

        assertNull(result);
    }


    @Test
    void getLimitSetsLimitInInputObject() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();
        String limit = "10";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(limit);

        handlerUtils.getLimit(deploymentId, inputObject);

        assertEquals(limit, JsonUtils.getValue(inputObject, DocASAPConstants.TempKey.LIMIT));
    }

    @Test
    void getUseLocalProviderIdReturnsTrueForTrueConfig() throws Exception {
        String deploymentId = "deployment123";
        String useLocalProviderId = "true";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(useLocalProviderId);

        assertTrue(handlerUtils.getUseLocalProviderId(deploymentId));
    }

    @Test
    void getUseLocalProviderIdReturnsFalseForFalseConfig() throws Exception {
        String deploymentId = "deployment123";
        String useLocalProviderId = "false";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(useLocalProviderId);

        assertFalse(handlerUtils.getUseLocalProviderId(deploymentId));
    }

    @Test
    void addLocationIdListReturnsLocationIdList() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();
        JSONArray locationIds = new JSONArray();
        locationIds.put("location1");
        locationIds.put("location2");
        JSONObject filterData = new JSONObject();
        filterData.put(EXT_LOCATION_IDS, locationIds);

        when(athenaConfigCache.getFilterDataMap(deploymentId)).thenReturn(filterData);
        when(dataCacheManager.getStoredProvidersConfig(
                BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                ATHENA_CONFIG, AthenaEngineConstants.RUN_REALTIME_BY_FILTER, false)).thenReturn("true");
        String result = handlerUtils.addLocationIdList(deploymentId, inputObject);

        assertEquals("location1,location2", result);
    }

    @Test
    void addLocationIdListFetchesAndStoresFilterDataIfNotCached() throws Exception {
        String deploymentId = "deployment123";
        Object inputObject = new JSONObject();
        JSONArray locationIds = new JSONArray();
        locationIds.put("location1");
        locationIds.put("location2");
        JSONObject filterData = new JSONObject();
        filterData.put(EXT_LOCATION_IDS, locationIds);

        when(athenaConfigCache.getFilterDataMap(deploymentId)).thenReturn(null);
        when(filterDataService.getFilterDataFromDocASAP(deploymentId)).thenReturn(filterData);
        when(dataCacheManager.getStoredProvidersConfig(
                BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                ATHENA_CONFIG, AthenaEngineConstants.RUN_REALTIME_BY_FILTER, false)).thenReturn("true");
        String result = handlerUtils.addLocationIdList(deploymentId, inputObject);

        verify(athenaConfigCache).setFilterDataMap(deploymentId, filterData);
        assertEquals("location1,location2", result);
    }

    @Test
    void shouldStoreFilterLocationInCacheReturnsTrueForTrueConfig() throws Exception {
        String deploymentId = "deployment123";
        String realtimeByFilter = "true";

        when(dataCacheManager.getStoredProvidersConfig(
                BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                ATHENA_CONFIG, AthenaEngineConstants.RUN_REALTIME_BY_FILTER, false)).thenReturn("true");

        assertTrue(handlerUtils.shouldStoreFilterLocationInCache(deploymentId));
    }

    @Test
    void shouldStoreFilterLocationInCacheReturnsFalseForFalseConfig() throws Exception {
        String deploymentId = "deployment123";
        String realtimeByFilter = "false";

        when(dataCacheManager.getStoredProvidersConfig(
                BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                ATHENA_CONFIG, AthenaEngineConstants.RUN_REALTIME_BY_FILTER, false)).thenReturn(realtimeByFilter);

        assertFalse(handlerUtils.shouldStoreFilterLocationInCache(deploymentId));
    }

    @Test
    void getScheduleAbleAppointmentTypesReturnsCorrectTypes() {
        String genApptTypeId = "genType1";
        Map<String, String> apptTypeMap = Map.of(
                "type1", "30",
                "type2", "60",
                "genType1", "30"
        );

        String result = handlerUtils.getScheduleAbleAppointmentTypes(genApptTypeId, apptTypeMap);

        assertTrue(result.contains("type1") && result.contains("^") && result.contains("type2"));
    }

    @Test
    void getScheduleAbleAppointmentTypesReturnsEmptyStringForEmptyMap() {
        String genApptTypeId = "genType1";
        Map<String, String> apptTypeMap = Map.of();

        String result = handlerUtils.getScheduleAbleAppointmentTypes(genApptTypeId, apptTypeMap);

        assertEquals("", result);
    }
    @Test
    void getLocationListReturnsLocationArrayFromCache() throws Exception {
        String practiceId = "practice123";
        JSONArray locationArray = new JSONArray();
        locationArray.put("location1");
        locationArray.put("location2");

        JSONObject inputObject = new JSONObject();
        inputObject.put(PRACTICE_ID, practiceId);
        inputObject.put(DEPLOYMENT_ID, "");
        JSONObject locationObject = new JSONObject();
        locationObject.put(LOCATIONS, locationArray);
        when(athenaConfigCache.getPracticeLocationMap(practiceId)).thenReturn(null);
        when(athenaApiCaller.call(anyString(), any(), anyString())).thenReturn(locationObject);

        JSONArray result = handlerUtils.getLocationList(inputObject);
        System.out.println(result);
        assertNull(result);
    }

    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = HandlerUtils.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

    @Test
    void getFilterData_throwsIHubException() throws Exception {
        try (MockedStatic<NullChecker> nullCheckerMock = mockStatic(NullChecker.class)) {
            nullCheckerMock.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);

            when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                    .thenThrow(new IHubException(UtilityErrors.ERROR_LOADING_CONFIG.getErrorCode(), "err"));

            Method method = HandlerUtils.class.getDeclaredMethod("getFilterData", String.class, String.class);
            method.setAccessible(true);

            assertThrows(Exception.class, () -> method.invoke(handlerUtils, "depId", "filter1"));
        }
    }

    @Test
    void shouldStoreFilterLocationInCache_returnsFalseOnException() throws Exception {
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq(BaseEPMConstants.EPM_NAME_PREFIX), eq("deploymentId"),
                        eq(ATHENA_CONFIG), eq(AthenaEngineConstants.RUN_REALTIME_BY_FILTER), eq(false)))
                .thenThrow(new IHubException(null, "error"));

        Method method = HandlerUtils.class.getDeclaredMethod("shouldStoreFilterLocationInCache", String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(handlerUtils, "deploymentId");
        assertFalse(result);
    }
}