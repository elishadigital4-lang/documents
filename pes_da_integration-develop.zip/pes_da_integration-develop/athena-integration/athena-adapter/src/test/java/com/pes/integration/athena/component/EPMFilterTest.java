package com.pes.integration.athena.component;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.LOCATION_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EPMFilterTest {

    @InjectMocks
    private EPMFilter epmFilter;

    @Mock
    private DataCacheManager dataCacheManager;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAllowedLocationsReturnsTrueForAllowedLocation_Reflection() throws Exception {
        JSONArray locFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location123");
        locFilterArray.put(filterObject);

        java.lang.reflect.Method method = EPMFilter.class.getDeclaredMethod(
                "getAllowedLocations", JSONArray.class, String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(null, locFilterArray, "location123");
        assertTrue(result);
    }

    @Test
    void isAllowed_ReturnsTrue_WhenExceptionIsThrown() throws IHubException {
        String deploymentId = "deployment123";
        String locationId = "location1";
        String providerId = "provider1";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Simulated Exception"));

        assertTrue(epmFilter.isAllowed(deploymentId, locationId, providerId));
    }

    @Test
    void getAllowedProvidersReturnsTrueForAllowedProvider_Reflection() throws Exception {
        JSONArray provFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider123");
        provFilterArray.put(filterObject);

        java.lang.reflect.Method method = EPMFilter.class.getDeclaredMethod(
                "getAllowedProviders", JSONArray.class, String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(null, provFilterArray, "provider123");
        assertTrue(result);
    }

    @Test
    void testGetAllowedLocationProviders_Reflection_CoversTrueBranch() throws Exception {
        JSONArray locProvfilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locProvfilterArray.put(filterObject);

        java.lang.reflect.Method method = EPMFilter.class.getDeclaredMethod(
                "getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(null, locProvfilterArray, "location1", "provider1");
        assertTrue(result);
    }

    @Test
    void getAllowedLocationsReturnsCorrectLocations() throws Exception {
        String deploymentId = "deployment123";
        JSONArray filterArray = new JSONArray();
        JSONObject filterObject1 = new JSONObject();
        filterObject1.put(LOCATION_ID, "location1");
        filterArray.put(filterObject1);
        JSONObject filterObject2 = new JSONObject();
        filterObject2.put(LOCATION_ID, "location2");
        filterArray.put(filterObject2);

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(filterArray);

        List<String> allowedLocations = epmFilter.getAllowedLocations(deploymentId);

        assertEquals(2, allowedLocations.size());
        assertTrue(allowedLocations.contains("location1"));
        assertTrue(allowedLocations.contains("location2"));
    }

    @Test
    void getAllowedLocationsHandlesException() throws Exception {
        String deploymentId = "deployment123";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Test Exception"));

        List<String> allowedLocations = epmFilter.getAllowedLocations(deploymentId);

        assertTrue(allowedLocations.isEmpty());
    }

    @Test
    void isAllowedReturnsTrueForAllowedLocationProvider() throws Exception {
        String deploymentId = "deployment123";
        String locationId = "location1";
        String providerId = "provider1";
        JSONObject filterJson = new JSONObject();
        JSONArray locProvfilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put("locationId", locationId);
        filterObject.put("providerId", providerId);
        locProvfilterArray.put(filterObject);
        filterJson.put(LOCATION_PROVIDER_FILTER, new JSONObject().put(LOCATION_PROVIDER_FILTER, locProvfilterArray));

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyBoolean()))
                .thenReturn(filterJson);

        assertFalse(epmFilter.isAllowed(deploymentId, locationId, providerId));
    }
    @Test
    void isAllowedReturnsTrueForAllowedProvider() throws Exception {
        String deploymentId = "deployment123";
        String locationId = "location1";
        String providerId = "provider1";
        JSONObject filterJson = new JSONObject();
        JSONArray locProvfilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put("locationId", locationId);
        filterObject.put("providerId", providerId);
        locProvfilterArray.put(filterObject);
        filterJson.put(PROVIDER_FILTER, new JSONObject().put(PROVIDER_FILTER, locProvfilterArray));

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyBoolean()))
                .thenReturn(filterJson);

        assertFalse(epmFilter.isAllowed(deploymentId, locationId, providerId));
    }

    @Test
    void isAllowedReturnsTrueForAllowedLocations() throws Exception {
        String deploymentId = "deployment123";
        String locationId = "location1";
        String providerId = "provider1";
        JSONObject filterJson = new JSONObject();
        JSONArray locProvfilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put("locationId", locationId);
        filterObject.put("providerId", providerId);
        locProvfilterArray.put(filterObject);
        filterJson.put(LOCATION_FILTER, new JSONObject().put(LOCATION_FILTER, locProvfilterArray));

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyBoolean()))
                .thenReturn(filterJson);

        assertFalse(epmFilter.isAllowed(deploymentId, locationId, providerId));
    }

    @Test
    void isAllowedReturnsFalseForDisallowedLocationProvider() throws Exception {
        String deploymentId = "deployment123";
        String locationId = "location1";
        String providerId = "provider1";
        JSONObject filterJson = new JSONObject();
        JSONArray locProvfilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(LOCATION_ID, locationId);
        filterObject.put("providerId", "provider2");
        locProvfilterArray.put(filterObject);
        filterJson.put("locationProviderFilter", locProvfilterArray);

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyBoolean()))
                .thenReturn(filterJson);

        assertTrue(epmFilter.isAllowed(deploymentId, locationId, providerId));
    }

    @Test
    void isAllowedReturnsTrueForEmptyFilter() throws Exception {
        String deploymentId = "deployment123";
        String locationId = "location1";
        String providerId = "provider1";

        when(dataCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyBoolean()))
                .thenReturn(null);

        assertTrue(epmFilter.isAllowed(deploymentId, locationId, providerId));
    }


//
//    @Test
//    void getAllowedProvidersReturnsFalseForNotAllowedProvider() {
//        JSONArray provFilterArray = new JSONArray();
//        JSONObject filterObject = new JSONObject();
//        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider123");
//        provFilterArray.put(filterObject);
//
//        boolean result = EPMFilter.getAllowedProviders(provFilterArray, "provider456");
//
//        assertFalse(result);
//    }
//
//    @Test
//    void getAllowedProvidersReturnsFalseForEmptyProviderId() {
//        JSONArray provFilterArray = new JSONArray();
//        JSONObject filterObject = new JSONObject();
//        filterObject.put(UtilitiesConstants.PROVIDER_ID, "");
//        provFilterArray.put(filterObject);
//
//        boolean result = EPMFilter.getAllowedProviders(provFilterArray, "provider123");
//
//        assertFalse(result);
//    }
//
//    @Test
//    void getAllowedProvidersReturnsFalseForEmptyFilterArray() {
//        JSONArray provFilterArray = new JSONArray();
//
//        boolean result = EPMFilter.getAllowedProviders(provFilterArray, "provider123");
//
//        assertFalse(result);
//    }
}