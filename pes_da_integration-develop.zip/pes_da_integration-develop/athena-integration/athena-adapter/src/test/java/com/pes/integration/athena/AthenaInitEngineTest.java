package com.pes.integration.athena;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pes.integration.athena.AthenaInitEngine;
import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.exceptions.IHubException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class AthenaInitEngineTest {

    @Mock
    private BaseInitEngine baseInitEngine;

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @InjectMocks
    private AthenaInitEngine athenaInitEngine;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInit_Success() throws IHubException {
        // Act
        athenaInitEngine.init();

        // Assert
        verify(baseInitEngine, times(1)).initializeConfig(anyString(), anyBoolean());
        verify(athenaApiCaller, times(1)).initializeObject();
    }
}