package com.pes.integration.athena.factory;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.pes.integration.enums.HandlerType;
import com.pes.integration.handlers.BaseHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;
import java.util.Map;

class AthenaHandlerFactoryServiceTest {

    private AthenaHandlerFactoryService athenaHandlerFactoryService;

    @Mock
    private BaseHandler mockHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        Map<String, BaseHandler> handlerMap = new HashMap<>();
        handlerMap.put("testKey", mockHandler);
        athenaHandlerFactoryService = new AthenaHandlerFactoryService();
    }

    @Test
    void testCreate_Null() {
        // Arrange
        HandlerType handlerType = mock(HandlerType.class);
        when(handlerType.getKey()).thenReturn("nonExistentKey");

        // Act
        BaseHandler result = athenaHandlerFactoryService.create(handlerType, new Object(), new Object());

        // Assert
        assertNull(result);
    }
}