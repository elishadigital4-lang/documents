package com.pes.integration.athena.component;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.constant.DocASAPConstants.Key.LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATION_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AthenaConfigCacheTest {

    @Mock
    private AthenaApiCaller athenaApiCaller;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private EPMFilter epmFilter;

    @InjectMocks
    private AthenaConfigCache athenaConfigCache;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAllowedLocationListHandlesExceptionWithReflection() throws Exception {
        AthenaConfigCache cache = new AthenaConfigCache();

        // Use reflection to inject a mock EPMFilter
        EPMFilter mockFilter = mock(EPMFilter.class);
        when(mockFilter.getAllowedLocations(anyString())).thenThrow(new RuntimeException("Test Exception"));

        java.lang.reflect.Field epmFilterField = AthenaConfigCache.class.getDeclaredField("epmFilter");
        epmFilterField.setAccessible(true);
        epmFilterField.set(cache, mockFilter);

        // Call the private method using reflection
        java.lang.reflect.Method method = AthenaConfigCache.class.getDeclaredMethod("getAllowedLocationList", String.class);
        method.setAccessible(true);
        Object result = method.invoke(cache, "deploymentId");

        assertNull(result);
    }

    @Test
    void getLocationIdsListAssignsClientLocationsWhenAllowedLocationsIsEmpty() throws IHubException {
        String deploymentId = "deployment123";
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        // clientLocations is not empty, allowedLocations is empty
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("loc1,loc2");
        when(epmFilter.getAllowedLocations(deploymentId)).thenReturn(null);

        String result = athenaConfigCache.getLocationIdsList(inputObject);

        assertEquals("loc1,loc2,", result);
    }

    @Test
    void getLocationIdsListReturnsCorrectLocationIds() throws IHubException {
        String deploymentId = "deployment123";
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        List<String> clientLocations = Arrays.asList("loc1", "loc2");
        List<String> allowedLocations = Arrays.asList("loc1", "loc3");

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("loc1, loc2");
        when(epmFilter.getAllowedLocations(deploymentId)).thenReturn(allowedLocations);

        String result = athenaConfigCache.getLocationIdsList(inputObject);

        assertEquals("loc1,", result);
    }

    @Test
    void getLocationIdsListHandlesEmptyClientLocations() throws IHubException {
        String deploymentId = "deployment123";
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        List<String> allowedLocations = Arrays.asList("loc1", "loc3");

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("");
        when(epmFilter.getAllowedLocations(deploymentId)).thenReturn(allowedLocations);

        String result = athenaConfigCache.getLocationIdsList(inputObject);

        assertEquals("loc1,loc3,", result);
    }

    @Test
    void getLocationIdsListHandlesEmptyAllowedLocations() throws IHubException {
        String deploymentId = "deployment123";
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        List<String> clientLocations = Arrays.asList("loc1", "loc2");

        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(null);
        when(epmFilter.getAllowedLocations(deploymentId)).thenReturn(null);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(LOCATIONS, new JSONArray().put(new JSONObject().put(LOCATION_ID, "loc1"))
                .put(new JSONObject().put(LOCATION_ID, "loc2")));
        when(athenaApiCaller.call(any(),any(),any())).thenReturn(jsonObject);
        String result = athenaConfigCache.getLocationIdsList(inputObject);

        assertEquals("loc1,loc2,", result);
    }

    @Test
    void getAppointmentTypeListReturnsCorrectMap() {
        String practiceId = "practice123";
        Map<String, String> expectedApptTypeMap = new HashMap<>();
        expectedApptTypeMap.put("type1", "description1");
        expectedApptTypeMap.put("type2", "description2");

        athenaConfigCache.setAppointmentTypeList(practiceId, expectedApptTypeMap);

        Map<String, String> actualApptTypeMap = athenaConfigCache.getAppointmentTypeList(practiceId);

        assertEquals(expectedApptTypeMap, actualApptTypeMap);
    }
    @Test
    void setAppointmentTypeListStoresCorrectly() {
        String practiceId = "practice123";
        Map<String, String> apptTypeMap = new HashMap<>();
        apptTypeMap.put("type1", "description1");
        apptTypeMap.put("type2", "description2");

        athenaConfigCache.setAppointmentTypeList(practiceId, apptTypeMap);

        Map<String, String> storedApptTypeMap = athenaConfigCache.getAppointmentTypeList(practiceId);

        assertEquals(apptTypeMap, storedApptTypeMap);
    }

    @Test
    void setVisitReasonArrayMapStoresCorrectly() {
        String deploymentId = "deployment123";
        JSONArray visitReasonArray = new JSONArray();
        visitReasonArray.put("reason1");
        visitReasonArray.put("reason2");

        athenaConfigCache.setVisitReasonArrayMap(deploymentId, visitReasonArray);

        JSONArray storedVisitReasonArray = athenaConfigCache.getVisitReasonArray(deploymentId);

        assertEquals(visitReasonArray, storedVisitReasonArray);
    }

    @Test
    void getVisitReasonArrayReturnsCorrectArray() {
        String deploymentId = "deployment123";
        JSONArray expectedVisitReasonArray = new JSONArray();
        expectedVisitReasonArray.put("reason1");
        expectedVisitReasonArray.put("reason2");

        athenaConfigCache.setVisitReasonArrayMap(deploymentId, expectedVisitReasonArray);

        JSONArray actualVisitReasonArray = athenaConfigCache.getVisitReasonArray(deploymentId);

        assertEquals(expectedVisitReasonArray.toString(), actualVisitReasonArray.toString());
    }
    @Test
    void getPracticeLocationMapReturnsCorrectArray() {
        String practiceId = "practice123";
        JSONArray expectedPracticeLocationArray = new JSONArray();
        expectedPracticeLocationArray.put("location1");
        expectedPracticeLocationArray.put("location2");

        athenaConfigCache.setPracticeLocationMap(practiceId, expectedPracticeLocationArray);

        JSONArray actualPracticeLocationArray = athenaConfigCache.getPracticeLocationMap(practiceId);

        assertEquals(expectedPracticeLocationArray.toString(), actualPracticeLocationArray.toString());
    }

    @Test
    void setPracticeLocationMapStoresCorrectly() {
        String practiceId = "practice123";
        JSONArray practiceLocationArray = new JSONArray();
        practiceLocationArray.put("location1");
        practiceLocationArray.put("location2");

        athenaConfigCache.setPracticeLocationMap(practiceId, practiceLocationArray);

        JSONArray storedPracticeLocationArray = athenaConfigCache.getPracticeLocationMap(practiceId);

        assertEquals(practiceLocationArray.toString(), storedPracticeLocationArray.toString());
    }

    @Test
    void getFilterDataMapReturnsCorrectData() {
        String deploymentId = "deployment123";
        JSONObject expectedFilterData = new JSONObject();
        expectedFilterData.put("key1", "value1");
        expectedFilterData.put("key2", "value2");

        athenaConfigCache.setFilterDataMap(deploymentId, expectedFilterData);

        JSONObject actualFilterData = athenaConfigCache.getFilterDataMap(deploymentId);

        assertEquals(expectedFilterData.toString(), actualFilterData.toString());
    }

    @Test
    void setFilterDataMapStoresCorrectly() {
        String deploymentId = "deployment123";
        JSONObject filterData = new JSONObject();
        filterData.put("key1", "value1");
        filterData.put("key2", "value2");

        athenaConfigCache.setFilterDataMap(deploymentId, filterData);

        JSONObject storedFilterData = athenaConfigCache.getFilterDataMap(deploymentId);

        assertEquals(filterData.toString(), storedFilterData.toString());
    }
}