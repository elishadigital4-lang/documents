package com.pes.integration.athena.component;

import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Method;

import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.*;
import static com.pes.integration.constant.UtilitiesConstants.FALSE;
import static com.pes.integration.constant.UtilitiesConstants.TRUE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;

class PatientNotificationPreferencesTest {

    @InjectMocks
    private PatientNotificationPreferences patientNotificationPreferences;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsTrueForEnabledEmail() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", "ENABLED");
        patientInfo.put("VoiceNotificationStatus", "INVALID");
        patientInfo.put("TextNotificationStatus", "INVALID");

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);

        input.put(EMAIL_NOTIFICATION_STATUS, ENABLED);
        input.put(VOICE_NOTIFICATION_STATUS, "INVALID");
        input.put(TEXT_NOTIFICATION_STATUS, "INVALID");
        assertTrue(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsTrueForDisabledEmail() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", DISABLED);
        patientInfo.put("VoiceNotificationStatus", "INVALID");
        patientInfo.put("TextNotificationStatus", "INVALID");

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);
        assertTrue(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsTrueForEnabledPhone() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", "INVALID");
        patientInfo.put("VoiceNotificationStatus", ENABLED);
        patientInfo.put("TextNotificationStatus", "INVALID");

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);
        assertTrue(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsTrueForDisabledPhone() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", "INVALID");
        patientInfo.put("VoiceNotificationStatus", DISABLED);
        patientInfo.put("TextNotificationStatus", "INVALID");

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);
        assertTrue(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsTrueForEnabledText() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", "INVALID");
        patientInfo.put("VoiceNotificationStatus", "INVALID");
        patientInfo.put("TextNotificationStatus", ENABLED);

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);
        assertTrue(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsTrueForDisabledText() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", "INVALID");
        patientInfo.put("VoiceNotificationStatus", "INVALID");
        patientInfo.put("TextNotificationStatus", DISABLED);

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);
        assertTrue(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsFalseForEmptyPreferences() {
        JSONObject input = new JSONObject();

        assertFalse(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void arePatientNotificationPreferencesPresentReturnsFalseForInvalidPreferences() {
        JSONObject input = new JSONObject();
        input.put(EMAIL_NOTIFICATION_STATUS, "INVALID");
        input.put(VOICE_NOTIFICATION_STATUS, "INVALID");
        input.put(TEXT_NOTIFICATION_STATUS, "INVALID");

        assertFalse(patientNotificationPreferences.arePatientNotificationPreferencesPresent(input));
    }

    @Test
    void getPatientNotificationPreferencesSetsTempValuesForEnabledPreferences() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", ENABLED);
        patientInfo.put("VoiceNotificationStatus", ENABLED);
        patientInfo.put("TextNotificationStatus", ENABLED);

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);

        JSONObject result = (JSONObject) patientNotificationPreferences.getPatientNotificationPreferences(input);

        assertEquals(TRUE, getValue(result, TEMP_APPOINTMENT_EMAIL));
        assertEquals(TRUE, getValue(result, TEMP_APPOINTMENT_PHONE));
        assertEquals(TRUE, getValue(result, TEMP_APPOINTMENT_SMS));
    }

    @Test
    void getPatientNotificationPreferencesSetsTempValuesForDisabledPreferences() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", DISABLED);
        patientInfo.put("VoiceNotificationStatus", DISABLED);
        patientInfo.put("TextNotificationStatus", DISABLED);

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);

        JSONObject result = (JSONObject) patientNotificationPreferences.getPatientNotificationPreferences(input);

        assertEquals(FALSE, getValue(result, TEMP_APPOINTMENT_EMAIL));
        assertEquals(FALSE, getValue(result, TEMP_APPOINTMENT_PHONE));
        assertEquals(FALSE, getValue(result, TEMP_APPOINTMENT_SMS));
    }

    @Test
    void getPatientNotificationPreferencesIgnoresInvalidPreferences() {
        JSONObject input = new JSONObject();
        input.put(EMAIL_NOTIFICATION_STATUS, "INVALID");
        input.put(VOICE_NOTIFICATION_STATUS, "INVALID");
        input.put(TEXT_NOTIFICATION_STATUS, "INVALID");

        JSONObject result = (JSONObject) patientNotificationPreferences.getPatientNotificationPreferences(input);

        assertFalse(result.has(TEMP_APPOINTMENT_EMAIL));
        assertFalse(result.has(TEMP_APPOINTMENT_PHONE));
        assertFalse(result.has(TEMP_APPOINTMENT_SMS));
    }

    @Test
    void setPatientNotificationPreferencesSetsEnabledValues() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", TRUE);
        patientInfo.put("VoiceNotificationStatus", TRUE);
        patientInfo.put("TextNotificationStatus", TRUE);

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);

        patientNotificationPreferences.setPatientNotificationPreferences(input);

        assertEquals(ENABLED, getValue(input, EMAIL_NOTIFICATION_STATUS));
        assertEquals(ENABLED, getValue(input, VOICE_NOTIFICATION_STATUS));
        assertEquals(ENABLED, getValue(input, TEXT_NOTIFICATION_STATUS));
    }

    @Test
    void setPatientNotificationPreferencesSetsDisabledValues() {
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", FALSE);
        patientInfo.put("VoiceNotificationStatus", FALSE);
        patientInfo.put("TextNotificationStatus", FALSE);

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);

        patientNotificationPreferences.setPatientNotificationPreferences(input);

        assertEquals(DISABLED, getValue(input, EMAIL_NOTIFICATION_STATUS));
        assertEquals(DISABLED, getValue(input, VOICE_NOTIFICATION_STATUS));
        assertEquals(DISABLED, getValue(input, TEXT_NOTIFICATION_STATUS));
    }

    @Test
    void setPatientNotificationPreferencesIgnoresInvalidValues() {
        JSONObject input = new JSONObject();
        input.put(EMAIL_NOTIFICATION_STATUS, "INVALID");
        input.put(VOICE_NOTIFICATION_STATUS, "INVALID");
        input.put(TEXT_NOTIFICATION_STATUS, "INVALID");

        patientNotificationPreferences.setPatientNotificationPreferences(input);

        assertEquals("INVALID", input.getString(EMAIL_NOTIFICATION_STATUS));
        assertEquals("INVALID", input.getString(VOICE_NOTIFICATION_STATUS));
        assertEquals("INVALID", input.getString(TEXT_NOTIFICATION_STATUS));
    }

    @Test
    void setPatientNotificationPreferencesHandlesEmptyPreferences() {
        JSONObject input = new JSONObject();

        patientNotificationPreferences.setPatientNotificationPreferences(input);

        assertFalse(input.has(EMAIL_NOTIFICATION_STATUS));
        assertFalse(input.has(VOICE_NOTIFICATION_STATUS));
        assertFalse(input.has(TEXT_NOTIFICATION_STATUS));
    }

    @Test
    void  setPatientNotificationPreferencesUpdatePatient(){
        JSONObject input = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("EmailNotificationStatus", ENABLED);
        patientInfo.put("VoiceNotificationStatus", ENABLED);
        patientInfo.put("TextNotificationStatus", ENABLED);

        JSONObject demographicData = new JSONObject();
        demographicData.put("PatientInformation", new JSONArray().put(patientInfo));

        input.put("DemographicData", demographicData);

        JSONObject result = new JSONObject();
        patientNotificationPreferences.setPatientNotificationPreferencesUpdatePatient(input, result);

        assertEquals(TRUE, getValue(result, TEMP_APPOINTMENT_EMAIL));
        assertEquals(TRUE, getValue(result, TEMP_APPOINTMENT_PHONE));
        assertEquals(TRUE, getValue(result, TEMP_APPOINTMENT_SMS));
    }

    @Test
    void returnsTrueForEnabledEmail() throws Exception {
        Object input = new Object();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> getValue(input, EMAIL_NOTIFICATION_STATUS)).thenReturn(null);
            jsonUtilsMock.when(() -> getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn(null);
            jsonUtilsMock.when(() -> getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn(null);
            nullCheckerMock.when(() -> isEmpty(ENABLED)).thenReturn(false);
            nullCheckerMock.when(() -> isEmpty(anyString())).thenReturn(true);

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("arePatientNotificationPreferencesPresent", Object.class);
            method.setAccessible(true);
            boolean result = (boolean) method.invoke(patientNotificationPreferences, input);
            assertTrue(true);
        }
    }

    @Test
    void setPatientNotificationPreferencesUpdatePatient_handlesIHubException() throws Exception {
        JSONObject source = new JSONObject();
        JSONObject destination = new JSONObject();

        try (MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class)) {
            jsonUtilsMock.when(() -> JsonUtils.copyKey(eq("temp"), any(), any()))
                    .thenThrow(new IHubException(null, "error"));

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("setPatientNotificationPreferencesUpdatePatient", Object.class, Object.class);
            method.setAccessible(true);

            // Should not throw, just log error
            method.invoke(patientNotificationPreferences, source, destination);

            jsonUtilsMock.verify(() -> JsonUtils.copyKey("temp", source, destination));
        }
    }

    @Test
    void handlesExceptionInSetValue() throws Exception {
        Object input = new JSONObject();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, EMAIL_NOTIFICATION_STATUS)).thenReturn(ENABLED);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn(ENABLED);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn(ENABLED);
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);

            jsonUtilsMock.when(() -> JsonUtils.setValue(any(), any(), any())).thenThrow(new RuntimeException("error"));

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("getPatientNotificationPreferences", Object.class);
            method.setAccessible(true);

            assertDoesNotThrow(() -> method.invoke(patientNotificationPreferences, input));
        }
    }

    @Test
    void setsEnabledValues() throws Exception {
        Object input = new JSONObject();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, EMAIL_NOTIFICATION_STATUS)).thenReturn(TRUE);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn(TRUE);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn(TRUE);
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);

            jsonUtilsMock.when(() -> JsonUtils.setValue(input, EMAIL_NOTIFICATION_STATUS, ENABLED)).thenAnswer(inv -> null);
            jsonUtilsMock.when(() -> JsonUtils.setValue(input, VOICE_NOTIFICATION_STATUS, ENABLED)).thenAnswer(inv -> null);
            jsonUtilsMock.when(() -> JsonUtils.setValue(input, TEXT_NOTIFICATION_STATUS, ENABLED)).thenAnswer(inv -> null);

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("setPatientNotificationPreferences", Object.class);
            method.setAccessible(true);
            method.invoke(patientNotificationPreferences, input);

            jsonUtilsMock.verify(() -> JsonUtils.setValue(input, EMAIL_NOTIFICATION_STATUS, ENABLED));
            jsonUtilsMock.verify(() -> JsonUtils.setValue(input, VOICE_NOTIFICATION_STATUS, ENABLED));
            jsonUtilsMock.verify(() -> JsonUtils.setValue(input, TEXT_NOTIFICATION_STATUS, ENABLED));
        }
    }

    @Test
    void setsDisabledValues() throws Exception {
        Object input = new JSONObject();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, EMAIL_NOTIFICATION_STATUS)).thenReturn(FALSE);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn(FALSE);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn(FALSE);
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);

            jsonUtilsMock.when(() -> JsonUtils.setValue(input, EMAIL_NOTIFICATION_STATUS, DISABLED)).thenAnswer(inv -> null);
            jsonUtilsMock.when(() -> JsonUtils.setValue(input, VOICE_NOTIFICATION_STATUS, DISABLED)).thenAnswer(inv -> null);
            jsonUtilsMock.when(() -> JsonUtils.setValue(input, TEXT_NOTIFICATION_STATUS, DISABLED)).thenAnswer(inv -> null);

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("setPatientNotificationPreferences", Object.class);
            method.setAccessible(true);
            method.invoke(patientNotificationPreferences, input);

            jsonUtilsMock.verify(() -> JsonUtils.setValue(input, EMAIL_NOTIFICATION_STATUS, DISABLED));
            jsonUtilsMock.verify(() -> JsonUtils.setValue(input, VOICE_NOTIFICATION_STATUS, DISABLED));
            jsonUtilsMock.verify(() -> JsonUtils.setValue(input, TEXT_NOTIFICATION_STATUS, DISABLED));
        }
    }

    @Test
    void ignoresInvalidValues() throws Exception {
        Object input = new JSONObject();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, EMAIL_NOTIFICATION_STATUS)).thenReturn("INVALID");
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn("INVALID");
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn("INVALID");
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("setPatientNotificationPreferences", Object.class);
            method.setAccessible(true);
            method.invoke(patientNotificationPreferences, input);

            jsonUtilsMock.verify(() -> JsonUtils.setValue(any(), any(), any()), Mockito.never());
        }
    }

    @Test
    void ignoresEmptyValues() throws Exception {
        Object input = new JSONObject();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, EMAIL_NOTIFICATION_STATUS)).thenReturn(null);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn(null);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn(null);
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(true);

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("setPatientNotificationPreferences", Object.class);
            method.setAccessible(true);
            method.invoke(patientNotificationPreferences, input);

            jsonUtilsMock.verify(() -> JsonUtils.setValue(any(), any(), any()), Mockito.never());
        }
    }

    @Test
    void handlesExceptionInSetValues() throws Exception {
        Object input = new JSONObject();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, EMAIL_NOTIFICATION_STATUS)).thenReturn(TRUE);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn(TRUE);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn(TRUE);
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);

            jsonUtilsMock.when(() -> JsonUtils.setValue(any(), any(), any())).thenThrow(new RuntimeException("error"));

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("setPatientNotificationPreferences", Object.class);
            method.setAccessible(true);

            assertDoesNotThrow(() -> method.invoke(patientNotificationPreferences, input));
        }
    }

    @Test
    void handlesExceptionsInSetValues() throws Exception {
        Object input = new JSONObject();
        try (
                MockedStatic<JsonUtils> jsonUtilsMock = Mockito.mockStatic(JsonUtils.class);
                MockedStatic<com.pes.integration.utils.NullChecker> nullCheckerMock = Mockito.mockStatic(com.pes.integration.utils.NullChecker.class)
        ) {
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, EMAIL_NOTIFICATION_STATUS)).thenThrow(new RuntimeException("error"));
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, VOICE_NOTIFICATION_STATUS)).thenReturn(TRUE);
            jsonUtilsMock.when(() -> JsonUtils.getValue(input, TEXT_NOTIFICATION_STATUS)).thenReturn(TRUE);
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);

            jsonUtilsMock.when(() -> JsonUtils.setValue(any(), any(), any())).thenAnswer(invocationOnMock -> null);

            Method method = PatientNotificationPreferences.class.getDeclaredMethod("setPatientNotificationPreferences", Object.class);
            method.setAccessible(true);

            assertDoesNotThrow(() -> method.invoke(patientNotificationPreferences, input));
        }
    }
}