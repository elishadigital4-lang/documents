package com.pes.integration.athena.component;

import com.pes.integration.athena.dto.Token;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;
import static org.springframework.http.MediaType.APPLICATION_JSON;

class AthenaClientCallerTest {

    @Mock
    WebClient.RequestBodyUriSpec requestBodyUriSpec;
    @Mock
    WebClient.RequestHeadersSpec requestHeadersSpec;
    @Mock
    WebClient.RequestHeadersSpec requestHeadersSpec1;
    @Mock
    WebClient.ResponseSpec responseSpec;
    @InjectMocks
    private AthenaClientCaller athenaClientCaller;
    private WebClient webClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        webClient = mock(WebClient.class);
        athenaClientCaller.webClient = webClient;
    }

    @Test
    void getDataReturnsSuccessResponse() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String httpMethod = "POST";
            String url = "http://example.com/data";
            String body = "requestBody";
            String token = "validToken";
            String expectedResponse = "responseBody";

            when(webClient.method(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.contentType(APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec1);
            when(requestHeadersSpec1.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just(expectedResponse));

            String result = athenaClientCaller.getData(httpMethod, url, body, token);

            assertEquals(expectedResponse, result);
        }
    }

    @Test
    void generateTokenReturnsValidToken() {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            Token expectedToken = new Token();
            expectedToken.setExpiresIn("3600");
            expectedToken.setAccessToken("token");


            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.just(expectedToken));

            Token result = athenaClientCaller.generateToken(url, headers);

            assertEquals(expectedToken, result);
        }
    }

    @Test
    void generateTokenHandlesErrorResponse() {

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            String errorBody = "Error while calling athena token api with  Error message:: Invalid request";


            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.error(new RuntimeException(errorBody)));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> athenaClientCaller.generateToken(url, headers));

            Assertions.assertEquals(errorBody, exception.getCause().getMessage());
        }
    }

    @Test
    void getDataReturnsValidResponse() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        String expectedResponse = "responseBody";
        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any()).body(Mono.class, String.class)).thenReturn(requestHeadersSpec1);
        when(requestHeadersSpec1.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("data"));

        Assertions.assertThrows(NullPointerException.class, () -> athenaClientCaller.getData(httpMethod, url, body, token));

    }

    @Test
    void generateToken_onStatusError_throwsIHubException() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            String errorBody = "Simulated error body";

            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

            // Simulate onStatus error
            when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
                java.util.function.Predicate<HttpStatusCode> statusPredicate = invocation.getArgument(0);
                java.util.function.Function<org.springframework.web.reactive.function.client.ClientResponse, Mono<? extends Throwable>> errorFunction = invocation.getArgument(1);

                // Simulate a client response with error status
                ClientResponse clientResponse = mock(ClientResponse.class);
                when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
                when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);

                // Call the error function to simulate error handling
                errorFunction.apply(clientResponse);

                return responseSpec;
            });

            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.error(new IHubException(com.pes.integration.enums.StatusCodes.EPM_INTERNAL_ERROR, errorBody, "")));

            IHubException ex = assertThrows(IHubException.class, () -> {
                try {
                    athenaClientCaller.generateToken(url, headers);
                } catch (RuntimeException e) {
                    if (e.getCause() instanceof IHubException) {
                        throw (IHubException) e.getCause();
                    }
                    throw e;
                }
            });
            assertEquals(errorBody, ex.getMessage());
        }
    }

    @Test
    void getData_onStatusError_throwsIHubException() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientSuccessCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String httpMethod = "POST";
            String url = "http://example.com/data";
            String body = "requestBody";
            String token = "validToken";
            String errorBody = "Simulated error body";

            when(webClient.method(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.contentType(APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec1);
            when(requestHeadersSpec1.retrieve()).thenReturn(responseSpec);

            when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
                java.util.function.Predicate<HttpStatusCode> statusPredicate = invocation.getArgument(0);
                java.util.function.Function<org.springframework.web.reactive.function.client.ClientResponse, Mono<? extends Throwable>> errorFunction = invocation.getArgument(1);

                ClientResponse clientResponse = mock(ClientResponse.class);
                when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
                when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);

                errorFunction.apply(clientResponse);

                return responseSpec;
            });

            when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(com.pes.integration.enums.StatusCodes.EPM_INTERNAL_ERROR, errorBody, "")));

            IHubException ex = assertThrows(IHubException.class, () -> {
                try {
                    athenaClientCaller.getData(httpMethod, url, body, token);
                } catch (RuntimeException e) {
                    if (e.getCause() instanceof IHubException) {
                        throw (IHubException) e.getCause();
                    }
                    throw e;
                }
            });
            assertEquals(errorBody, ex.getMessage());
        }
    }

    @Test
    void getData_onErrorMap_throwsIHubException() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientSuccessCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String httpMethod = "POST";
            String url = "http://example.com/data";
            String body = "requestBody";
            String token = "validToken";
            String errorMsg = "Some error";

            when(webClient.method(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.contentType(APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec1);
            when(requestHeadersSpec1.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new RuntimeException(errorMsg)));

            IHubException ex = assertThrows(IHubException.class, () -> {
                try {
                    athenaClientCaller.getData(httpMethod, url, body, token);
                } catch (RuntimeException e) {
                    if (e.getCause() instanceof IHubException) {
                        throw (IHubException) e.getCause();
                    }
                    throw e;
                }
            });
            assertEquals(errorMsg, ex.getMessage());
        }
    }

    @Test
    void getData_success_callsSuccessMetricsAndLogs() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientSuccessCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String httpMethod = "POST";
            String url = "http://example.com/data";
            String body = "requestBody";
            String token = "validToken";
            String expectedResponse = "responseBody";

            when(webClient.method(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.contentType(APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec1);
            when(requestHeadersSpec1.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just(expectedResponse));

            String result = athenaClientCaller.getData(httpMethod, url, body, token);

            assertEquals(expectedResponse, result);
        }
    }


}