package com.pes.integration.athena.component;

import static com.pes.integration.athena.constant.AthenaConstants.CLIENT_CREDENTIALS;
import static com.pes.integration.athena.constant.AthenaConstants.GRANT_TYPE;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.MetricsUtil.metricClientErrorCount;
import static com.pes.integration.utils.MetricsUtil.metricClientSuccessCount;
import static com.pes.integration.utils.MetricsUtil.metricClientRequestCount;
import static org.springframework.http.HttpMethod.valueOf;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.BodyInserters.fromFormData;

import com.pes.integration.athena.dto.Token;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Component
public class AthenaClientCaller {

    @Autowired
    WebClient webClient;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;
    public static final List<String> IGNORABLE_ERRORS = Arrays.asList("An unknown API path was called", "That appointment time was already booked", "Invalid departmentid or departmentid/patientid combination", "Unable to add patient");
    @Observed(name = "integration.generateToken", contextualName = "integration")
    public Token generateToken(String url, HttpHeaders headers) {
        metricClientRequestCount(engineName, appDescription, "Generate Token: "+ url);
        return webClient.post()
                .uri(url)
                .accept(APPLICATION_JSON)
                .headers(h -> h.addAll(headers))
                .body(fromFormData(GRANT_TYPE, CLIENT_CREDENTIALS)
                        .with("scope", "athena/service/Athenanet.MDP.*"))
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    "Error status code while calling athena token api is Status code:: {} and errorBody:: {}"
                                    , clientResponse.statusCode(), errorBody);
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody, ""));
                        }))
                .bodyToMono(Token.class)
                .onErrorMap(ex -> {
                    log.error(
                            "Error while calling athena token api with  Error message:: {} ", ex.getMessage());
                    return new IHubException(StatusCodes.EPM_INTERNAL_ERROR, ex.getMessage(),"");})
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, "Successfully fetched token for Athena");
                    log.info("Successfully fetched token for Athena ");
                }).block();
    }

    @Observed(name = "integration.getApiData", contextualName = "integration")
    public String getData(String httpMethod, String url, String body, String token) {
        metricClientRequestCount(engineName, appDescription, httpMethod+" - "+ url);
        return webClient.method(valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_FORM_URLENCODED)
                .headers(header ->
                        header.setBearerAuth(token))
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    "Error status code while calling athena api is Status code:: {} and errorBody:: {}",
                                    clientResponse.statusCode(), errorBody);
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody, ""));

                        }))
                .bodyToMono(String.class)
                .onErrorMap(ex -> {
                    log.error(
                            "Error while calling athena api with  Error message:: {} ", ex.getMessage());
                    return new IHubException(StatusCodes.EPM_INTERNAL_ERROR, ex.getMessage(),"");})
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                    log.info("Successfully fetched data for athena Api for url {} ", sanitizeForLog(url));
                }).block();
    }
}