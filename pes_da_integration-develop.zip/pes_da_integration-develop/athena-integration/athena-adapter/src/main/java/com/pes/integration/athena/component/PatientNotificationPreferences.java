package com.pes.integration.athena.component;

import static com.pes.integration.constant.DocASAPConstants.Key.DISABLED;
import static com.pes.integration.constant.DocASAPConstants.Key.EMAIL_NOTIFICATION_STATUS;
import static com.pes.integration.constant.DocASAPConstants.Key.ENABLED;
import static com.pes.integration.constant.DocASAPConstants.Key.TEXT_NOTIFICATION_STATUS;
import static com.pes.integration.constant.DocASAPConstants.Key.VOICE_NOTIFICATION_STATUS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP_APPOINTMENT_EMAIL;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP_APPOINTMENT_PHONE;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP_APPOINTMENT_SMS;
import static com.pes.integration.constant.EpmConstant.ERROR_LOG;
import static com.pes.integration.constant.UtilitiesConstants.FALSE;
import static com.pes.integration.constant.UtilitiesConstants.TRUE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.NullChecker.isEmpty;

import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PatientNotificationPreferences {


  public boolean arePatientNotificationPreferencesPresent(Object updatePatientObject) {
    boolean updateNotificationPrefs = false;
    String contactAppointmentEmail = (String) getValue(updatePatientObject,
        EMAIL_NOTIFICATION_STATUS);
    String contactAppointmentPhone = (String) getValue(updatePatientObject,
        VOICE_NOTIFICATION_STATUS);
    String contactAppointmentText = (String) getValue(updatePatientObject,
        TEXT_NOTIFICATION_STATUS);
    try {
      if (!isEmpty(contactAppointmentEmail) && (contactAppointmentEmail.equalsIgnoreCase(ENABLED) || contactAppointmentEmail.equalsIgnoreCase(DISABLED))) {
          updateNotificationPrefs = true;
      }
      if (!isEmpty(contactAppointmentPhone) && (contactAppointmentPhone.equalsIgnoreCase(ENABLED) || contactAppointmentPhone.equalsIgnoreCase(DISABLED))) {
          updateNotificationPrefs = true;
      }
      if (!isEmpty(contactAppointmentText) && (contactAppointmentText.equalsIgnoreCase(ENABLED) || contactAppointmentText.equalsIgnoreCase(DISABLED))) {
        updateNotificationPrefs = true;
      }
    } catch (Exception e) {
      log.error(ERROR_LOG, e.getMessage());
    }
    return updateNotificationPrefs;
  }

  public Object getPatientNotificationPreferences(Object input) {
    if (arePatientNotificationPreferencesPresent(input)) {
      String contactAppointmentEmail = (String) getValue(input, EMAIL_NOTIFICATION_STATUS);
      String contactAppointmentPhone = (String) getValue(input, VOICE_NOTIFICATION_STATUS);
      String contactAppointmentText = (String) getValue(input, TEXT_NOTIFICATION_STATUS);
      try {
        if (!isEmpty(contactAppointmentEmail)) {
          if (contactAppointmentEmail.equalsIgnoreCase(ENABLED)) {
            setValue(input, TEMP_APPOINTMENT_EMAIL, TRUE);
          }
          if (contactAppointmentEmail.equalsIgnoreCase(DISABLED)) {
            setValue(input, TEMP_APPOINTMENT_EMAIL, FALSE);
          }
        }
        if (!isEmpty(contactAppointmentPhone)) {
          if (contactAppointmentPhone.equalsIgnoreCase(ENABLED)) {
            setValue(input, TEMP_APPOINTMENT_PHONE, TRUE);
          }
          if (contactAppointmentPhone.equalsIgnoreCase(DISABLED)) {
            setValue(input, TEMP_APPOINTMENT_PHONE, FALSE);
          }
        }
        if (!isEmpty(contactAppointmentText)) {
          if (contactAppointmentText.equalsIgnoreCase(ENABLED)) {
            setValue(input, TEMP_APPOINTMENT_SMS, TRUE);
          }
          if (contactAppointmentText.equalsIgnoreCase(DISABLED)) {
            setValue(input, TEMP_APPOINTMENT_SMS, FALSE);
          }
        }
      } catch (Exception e) {
        log.error(ERROR_LOG, e.getMessage());
      }
    }
    return input;
  }


  public void setPatientNotificationPreferences(Object input) {
    String contactAppointmentEmail = null;
    String contactAppointmentPhone = null;
    String contactAppointmentText = null;
    try {
      contactAppointmentEmail = (String) getValue(input, EMAIL_NOTIFICATION_STATUS);
      contactAppointmentPhone = (String) getValue(input, VOICE_NOTIFICATION_STATUS);
      contactAppointmentText = (String) getValue(input, TEXT_NOTIFICATION_STATUS);
    } catch (Exception e) {
      log.error(ERROR_LOG, e.getMessage());
    }
    try {
      if (!isEmpty(contactAppointmentEmail)) {
        if (contactAppointmentEmail.equalsIgnoreCase(TRUE)) {
          setValue(input, EMAIL_NOTIFICATION_STATUS, ENABLED);
        }
        if (contactAppointmentEmail.equalsIgnoreCase(FALSE)) {
          setValue(input, EMAIL_NOTIFICATION_STATUS, DISABLED);
        }
      }
      if (!isEmpty(contactAppointmentPhone)) {
        if (contactAppointmentPhone.equalsIgnoreCase(TRUE)) {
          setValue(input, VOICE_NOTIFICATION_STATUS, ENABLED);
        }
        if (contactAppointmentPhone.equalsIgnoreCase(FALSE)) {
          setValue(input, VOICE_NOTIFICATION_STATUS, DISABLED);
        }
      }

      if (!isEmpty(contactAppointmentText)) {
        if (contactAppointmentText.equalsIgnoreCase(TRUE)) {
          setValue(input, TEXT_NOTIFICATION_STATUS, ENABLED);
        }
        if (contactAppointmentText.equalsIgnoreCase(FALSE)) {

          setValue(input, TEXT_NOTIFICATION_STATUS, DISABLED);
        }
      }
    } catch (Exception e) {
      log.error(ERROR_LOG, e.getMessage());
    }
  }

  public void setPatientNotificationPreferencesUpdatePatient(Object source, Object destination) {
    getPatientNotificationPreferences(source);
    try {
      JsonUtils.copyKey("temp", source, destination);
    } catch (IHubException e) {
      log.error(ERROR_LOG, e.getMessage());
    }
  }
}
