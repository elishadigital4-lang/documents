package com.pes.integration.athena.constant;

/**
 * Constants class to keep all constants specific to AthenaHealthEngine. It may include constants
 * related to ATHENA specific mapping files.
 */
public class AthenaEngineConstants {

  public static final String EPM_NAME_PREFIX = "ah";
  public static final String ATHENA_CONFIG = "athenaprop";
  public static final String E2D_MESSAGE_CONTROL_ID_PREFIX = "athena";
  public static final String EPM_TYPE = "athenahealth";
  public static final String EPM_CONFIG_GROUPS = "RunBaselineSync,Generic Configurations,Athena Properties,RunE2DSync,Filter Service Config,Environment Config";
  public static final String VERSION = "version";
  public static final String CLIENT_ID = "clientid";
  public static final String CLIENT_SECRET = "clientsecret";
  public static final String RETRY_COUNT = "retrycount";
  public static final String ZERO_BRACKET = "[0]";
  public static final String URL = "url";
  public static final String METHOD = "method";
  public static final String FORWARD_SLASH = "/";

  public static final String REQUEST_MAPPING_KEY_NAME = "ah_req_map";
  public static final String RESPONSE_MAPPING_KEY_NAME = "ah_res_map";
  public static final String REQUEST_CONFIG_KEY_NAME = "ah_req_conf";
  public static final String RESPONSE_CODES_MAPPING_KEY_NAME = "ah_res_codes";
  public static final int BASELINE_START_DAYS_DEFAULT = 0;
  public static final int BASELINE_END_DAYS_DEFAULT = 30;
  public static final int BASELINE_CHUNK_SIZE_DEFAULT = 1;
  public static final String BASELINE_START_DAYS_KEY = "baselinestart";
  public static final String BASELINE_END_DAYS_KEY = "baselineend";
  public static final String BASELINE_CHUNK_SIZE_KEY = "baseline_chunk_size";
  public static final String DEFAULT_CANCEL_REASON = "defcanreason";
  public static final Object TRUE = "true";
  public static final String ACKNOWLEDGE_TYPE = "ackType";
  public static final String EQUAL_TO = "=";
  public static final String AMPERSAND = "&";
  public static final String PRACTICE_ID = "practiceid";
  public static final String CLIENT_LOCATIONS = "clientlocations";
  public static final String NO_SHOW_ID = "noshowid";
  public static final String INSURANCE_LOGIC = "inslogic";
  public static final String ADD_INSURANCES_AT_TOP = "add_to_top";
  public static final String ADD_INSURANCES_AT_BOTTOM = "add_to_bottom";
  public static final String GENERIC_APPT_TYPE = "genapptype";
  public static final String SPLIT_BY_PROVIDER = "split_by_prov";
  public static final String SPLIT_BY_LOCATION = "split_by_loc";
  public static final int MAX_INSURANCES_ALLOWED = 3;
  public static final long RETRY_DELAY_VALUE_IN_MS = 100;
  public static final String SPACE = " ";
  public static final String CONSENT_TO_EMAIL = "consenttoemail";
  public static final String CONSENT_TO_TEXT = "consenttotext";
  public static final String WEB_SCHEDULABLE_FLAG = "webschedulable";
  public static final String USE_LOCAL_PROVIDER = "uselocalprovider";
  public static final String REASON_MAP_EXISTS = "isreasonmapexist";
  public static final String LIMIT = "limit";
  public static final String RUN_REALTIME_BY_FILTER = "realt_by_fil";
  public static final String DATE_FORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
  public static final String Y = "Y";
  public static final String ASSIGNMENT_BENEFITS_CONSENT = "SchedulingData.Schedule[0].AssignmentBenefitsConsent";
  public static final String RELEASE_BILLING_INFORMATION_CONSENT = "SchedulingData.Schedule[0].ReleaseBillingInformationConsent";
  public static final String PRIVACY_POLICY_CONSENT = "SchedulingData.Schedule[0].PrivacyPolicyConsent";
  public static final String PATIENT_CONSENT = "SchedulingData.Schedule[0].PatientConsent";
  public static final String PATIENT_CONSENT_TIMESTAMP = "SchedulingData.Schedule[0].PatientConsentTimestamp";
  public static final String PATIENT_CONSENT_EXPIRATION_TIMESTAMP = "SchedulingData.Schedule[0].PatientConsentExpirationTimestamp";
  public static final String CONTACT_CONSENT = "SchedulingData.Schedule[0].ContactConsent";
  public static final String TEXT_CONSENT = "SchedulingData.Schedule[0].TextConsent";
  public static final String CALL_CONSENT = "SchedulingData.Schedule[0].CallConsent";
  public static final String CUSTOM_FIELDS = "SchedulingData.Schedule[0].CustomFields";
  public static final String CUSTOM_FIELD_ID = "CustomFieldId";
  public static final String OPTION_ID = "CustomFieldValue";
  public static final String CUSTOM_FIELD_ID_EPM = "customfieldid";
  public static final String OPTION_ID_EPM = "optionid";
  public static final String BASE_URL = "base_url";
  public static final String TOKEN_URL = "token_url";
  public static final String OAUTH_VERSION = "oauth_ver";
  public static final String API_ERROR_MSG = "Error returned when calling the API";

  public static final String DEPARTMENT_ID = "SchedulingData.Provider[0].LocationId";
  public static final String SHOW_PATIENT_DETAIL = "showPatDetail";
  public static final String BS_LIMIT = "bs_limit";
  public static final String PULL_BY_DEPT_CHUNK = "pullByDeptChunk";
  public static final String DEPT_CHUNK_SIZE = "dept_chunk_size";
  public static final String GUARANTOR_RELATIONS = "guarRelation";

  private AthenaEngineConstants() {
  }
}
