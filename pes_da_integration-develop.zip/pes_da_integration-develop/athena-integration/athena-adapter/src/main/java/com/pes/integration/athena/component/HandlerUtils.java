package com.pes.integration.athena.component;

import static com.pes.integration.athena.api.ApiName.GET_LOCATIONS;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.athena.constant.AthenaEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.athena.constant.AthenaEngineConstants.GENERIC_APPT_TYPE;
import static com.pes.integration.athena.constant.AthenaEngineConstants.LIMIT;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.CharacterConstants.COMMA;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.EXT_LOCATION_IDS;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PROVIDER_LIST;
import static com.pes.integration.constant.EpmConstant.ERROR_LOG;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.TRUE;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_LOADING_CONFIG;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.join;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.FilterDataService;
import com.pes.integration.utils.NullChecker;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * This class is responsible for carrying out common operations specific to all Athena Handlers
 *
 */

@Slf4j
@Service
public class HandlerUtils {

  @Autowired
  DataCacheManager dataCacheManager;

  @Autowired
  AthenaConfigCache athenaConfigCache;

  @Autowired
  FilterDataService filterDataService;

  @Autowired
  AthenaApiCaller athenaApiCaller;

  private String getLocationIdsList(JSONArray locationIds) {
    String locationIdStr = EMPTY;
    if (!isEmpty(locationIds)) {
      locationIdStr = join(locationIds, COMMA);
    }
    log.info("locationIdStr {} ", locationIdStr);
    return locationIdStr;
  }

  public void addPracticeId(String deploymentId, Object inputObject) throws IHubException {
    if (isEmpty(deploymentId)) {
      return;
    }
    try {
      String practiceId = dataCacheManager.getStoredProvidersConfig(
              EPM_NAME_PREFIX, deploymentId, ATHENA_CONFIG, AthenaEngineConstants.PRACTICE_ID, false)
          .toString();
      setValue(inputObject, TempKey.PRACTICE_ID, practiceId);
    } catch (IHubException bee) {
      throw bee;
    } catch (Exception e) {
      log.error("Error in adding practiceId {} ", e.getMessage());
      throw new IHubException(ERROR_LOADING_CONFIG.getErrorCode(), "deploymentPracticeMapping");
    }
  }

  public List<String> getGenericApptTypeDBConfig(String deploymentId) {
    List<String> genAptTypesWithSpAptTypes = new ArrayList<>();
    try {
      String genApptTypesStr = (String) dataCacheManager.getStoredProvidersConfig(
          EPM_NAME_PREFIX, deploymentId, ATHENA_CONFIG, GENERIC_APPT_TYPE, false);
      if (!NullChecker.isEmpty(genApptTypesStr)) {
        genAptTypesWithSpAptTypes = Arrays.asList(genApptTypesStr.split(","));
      }
    } catch (Exception e) {
      log.error("Error in getGenericApptTypeDBConfig {} ", e.getMessage());
    }
    return genAptTypesWithSpAptTypes;
  }

  public JSONArray getFilterData(String deploymentId, String filter) throws IHubException {
    if (NullChecker.isEmpty(deploymentId)) {
      return null;
    }
    JSONObject filterListJson;
    JSONArray filterJsonArray = null;
    try {
      Object filterListObj = dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX,
          deploymentId, FILTER_CONFIG, filter, false);
      if (!NullChecker.isEmpty(filterListObj)) {
        filterListJson = (JSONObject) filterListObj;
        if (filterListJson.has(filter)) {
          filterJsonArray = filterListJson.getJSONArray(filter);
        }
      }
    } catch (IHubException bee) {
      log.error("Error in fetching {} for {} ", filter, deploymentId);
      throw bee;
    } catch (Exception e) {
      log.error(ERROR_LOG, e.getMessage());
      throw new IHubException(UtilityErrors.ERROR_LOADING_CONFIG.getErrorCode(),
          "deploymentPracticeMapping");
    }
    return filterJsonArray;
  }

  // used in baseline flow
  public JSONArray getLocationList(Object inputObject) throws IHubException {
    String practiceId = (String) JsonUtils.getValue(inputObject, TempKey.PRACTICE_ID);
    if (NullChecker.isEmpty(practiceId)) {
      String deploymentId = (String) JsonUtils.getValue(inputObject, DEPLOYMENT_ID);
      addPracticeId(deploymentId, inputObject);
      practiceId = (String) JsonUtils.getValue(inputObject, TempKey.PRACTICE_ID);
    }
    JSONArray locationArray = athenaConfigCache.getPracticeLocationMap(practiceId);
    if (NullChecker.isEmpty(locationArray)) {
      JsonUtils.setValue(inputObject, PROVIDER_LIST, TRUE);
      JSONObject locationObject = athenaApiCaller.call(GET_LOCATIONS.getKey(), inputObject, "");
      //store location id's list for future use
      JSONArray locationObjectsArray = (JSONArray) JsonUtils.getValue(locationObject, LOCATIONS);
      athenaConfigCache.setPracticeLocationMap(practiceId, locationObjectsArray);
      locationArray = athenaConfigCache.getPracticeLocationMap(practiceId);
    }
    return locationArray;
  }

  public void getLimit(String deploymentId, Object inputObject)
      throws IHubException {
    Object limit = null;
    limit = getLimitFromOrg(deploymentId, limit);
    limit = getLimitFromComponent(limit);
    try {
      limit = dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
          ATHENA_CONFIG, LIMIT, false);
    } catch (Exception e) {
      //do nothing
    }
    try {
      if (NullChecker.isEmpty(limit)) {
        limit = dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, ATHENA_CONFIG,
            LIMIT, false);
      }
    } catch (Exception e) {
      log.error(ERROR_LOG, e.getMessage());
    }
    if (!NullChecker.isEmpty(limit) && !limit.toString().trim().isEmpty()) {
      JsonUtils.setValue(inputObject, TempKey.LIMIT, limit);
    }
  }

  private Object getLimitFromOrg(String deploymentId, Object limit) {
    try {
      limit = dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
          ATHENA_CONFIG, LIMIT, false);
    } catch (Exception e) {
      log.error(ERROR_LOG, e.getMessage());
      // do nothing
    }
    return limit;
  }

  private Object getLimitFromComponent(Object limit) {
    try {
      if (NullChecker.isEmpty(limit)) {
        limit = dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, ATHENA_CONFIG,
            LIMIT, false);
      }
    } catch (Exception e) {
      log.error(ERROR_LOG, e.getMessage());
    }
    return limit;
  }

  public boolean getUseLocalProviderId(String deploymentId) {
    try {
      String useLocalProviderId =
          (String)
              dataCacheManager.getStoredProvidersConfig(
                  EPM_NAME_PREFIX,
                  deploymentId,
                  ATHENA_CONFIG,
                  AthenaEngineConstants.USE_LOCAL_PROVIDER, false);
      return "true".equals(useLocalProviderId);
    } catch (IHubException e) {
      return false;
    }
  }

  public String addLocationIdList(String deploymentId, Object inputObject) throws IHubException {
    JSONArray locationIds;
    String locationIdList = "";
    if (shouldStoreFilterLocationInCache(deploymentId)) {
      log.info("shouldStoreFilterLocationInCache {} ", true);
      JSONObject filterData = athenaConfigCache.getFilterDataMap(deploymentId);
      if (NullChecker.isEmpty(filterData)) {
        log.info("filter data found for deployment id {} ", deploymentId);
        filterData = (JSONObject) getFilterData(deploymentId);
        athenaConfigCache.setFilterDataMap(deploymentId, filterData);
      }
      if (!NullChecker.isEmpty(filterData) && filterData.has(EXT_LOCATION_IDS)) {
        locationIds = filterData.getJSONArray(EXT_LOCATION_IDS);
        locationIdList = getLocationIdsList(locationIds);
      }
      log.info("{} filterData {} ", deploymentId, filterData);
    } else {
      locationIdList = athenaConfigCache.getLocationIdsList((JSONObject) inputObject);
    }
    JsonUtils.setValue(inputObject, APPT_LOCATION_ID, locationIdList);
    return locationIdList;
  }

  public boolean shouldStoreFilterLocationInCache(String deploymentId) {
    try {
      String realtimeByFilter = (String) dataCacheManager.getStoredProvidersConfig(
          BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
          ATHENA_CONFIG, AthenaEngineConstants.RUN_REALTIME_BY_FILTER, false);
      return realtimeByFilter.equalsIgnoreCase(UtilitiesConstants.TRUE);
    } catch (IHubException e) {
      log.error(ERROR_LOG, e.getMessage());
      return false;
    }
  }

  private Object getFilterData(String deploymentId) throws IHubException {
    return filterDataService.getFilterDataFromDocASAP(deploymentId);
  }

  public String getScheduleAbleAppointmentTypes(String genApptTypeId,
      Map<String, String> apptTypeMap) {
    StringBuilder scheduleAbleApptTypesStr = new StringBuilder(BLANK);
    if (apptTypeMap != null) {
      String scheduleAbleDuration = apptTypeMap.get(genApptTypeId);
      Set<String> apptTypeKeySet = apptTypeMap.keySet();
      for (String apptTypeId : apptTypeKeySet) {
        String apptDuration = apptTypeMap.get(apptTypeId);
        if (!NullChecker.isEmpty(apptDuration)
            && !NullChecker.isEmpty(scheduleAbleDuration)
            && !NullChecker.isEmpty(apptTypeId)
            && (Integer.parseInt(apptDuration) % Integer.parseInt(scheduleAbleDuration)) == 0) {
          scheduleAbleApptTypesStr.append(apptTypeId).append("^");
        }
      }
      if (!NullChecker.isEmpty(scheduleAbleApptTypesStr.toString())) {
        scheduleAbleApptTypesStr = new StringBuilder(
            scheduleAbleApptTypesStr.substring(0, scheduleAbleApptTypesStr.length() - 1));
      }
    }
    return scheduleAbleApptTypesStr.toString();
  }
}
