package com.pes.integration.athena.factory;

import com.pes.integration.enums.HandlerType;
import com.pes.integration.factory.BaseHandlerFactory;
import com.pes.integration.handlers.BaseHandler;
import java.util.HashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AthenaHandlerFactoryService extends BaseHandlerFactory {

  private final Map<String, BaseHandler> handlerMap = new HashMap<>();

  @Override
  public BaseHandler create(HandlerType handlerType, Object inputObject, Object outputObject) {
    return handlerMap.get(handlerType.getKey());
  }
}
