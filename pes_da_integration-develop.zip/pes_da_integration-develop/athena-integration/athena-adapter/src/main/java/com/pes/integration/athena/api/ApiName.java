package com.pes.integration.athena.api;

import static java.util.Arrays.stream;

/**
 * ENUM class to define different type of API names to be called.
 */
public enum ApiName {

  NEW_APPOINTMENT("new_appointment"),
  CANCEL_APPOINTMENT("cancel_appointment"),
  OPEN_APPOINTMENTS("open_appointments"),
  CHANGED_APPOINTMENTS("changed_appointments"),
  CHANGED_APPOINTMENTS_SUBSCRIPTION("changed_appointments_subscription"),
  RESCHEDULE_APPOINTMENT("reschedule_appointment"),
  CHANGED_PATIENTS("changed_patients"),
  GET_PATIENTS("get_patients"),
  GET_PATIENT_INSURANCE("get_patient_insurance"),
  GET_PATIENT_DEMOGRAPHICS("get_patient_demographics"),
  SET_PATIENT_INSURANCE("set_patient_insurance"),
  UPDATE_PATIENT_INSURANCE("update_patient_insurance"),
  DELETE_PATIENT_INSURANCE("delete_patient_insurance"),
  NEW_PATIENT("new_patient"),
  GET_LOCATIONS("get_locations"),
  GET_PRACTICES("get_practices"),
  GET_PROVIDERS("get_providers"),
  GET_INSURANCE_TYPES("get_insurance_types"),
  GET_INSURANCE_PACKAGES("get_insurance_packages"),
  GET_APPOINTMENT_TYPES("get_appointment_types"),
  UPDATE_PATIENT("update_patient"),
  BOOKED_APPOINTMENTS("booked_appointments"),
  FREEZE_APPOINTMENT("freeze_appointment"),
  GET_APPOINTMENT_CANCEL_REASONS("get_appointment_cancel_reasons"),
  GET_PATIENT_VISIT_REASONS("get_patient_visit_reasons"),
  VERIFY_PATIENT_PRIVACY_INFORMATION("verify_patient_privacy_information"),
  ADD_CUSTOM_FIELDS("add_custom_fields"),
  UPDATE_APPOINTMENT_CHECKIN("update_appointment_checkin"),

  CHECK_IF_PATIENT_REGISTERED("check_if_patient_registered"),
  REGISTER_PATIENT_DPPT("register_patient_with_department"),
  CHECK_IF_PATIENT_INSURED("is_patient_insured"),
  GET_PAYMENTS("get_payments");

  String key;

  ApiName(String key) {
    this.key = key;
  }

  public String getKey() {
    return key;
  }

  public ApiName getEnum(String apiName) {
    return stream(values()).filter(api -> api.getKey().equals(apiName)).findFirst().orElse(null);
  }
}
