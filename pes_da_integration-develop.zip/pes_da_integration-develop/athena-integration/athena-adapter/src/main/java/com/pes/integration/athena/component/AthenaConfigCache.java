package com.pes.integration.athena.component;

import static com.pes.integration.athena.api.ApiName.GET_LOCATIONS;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.athena.constant.AthenaEngineConstants.CLIENT_LOCATIONS;
import static com.pes.integration.athena.constant.AthenaEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATION_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AthenaConfigCache {

  @Autowired
  AthenaApiCaller athenaApiCaller;

  Map<String, String> locationIdsMap = new HashMap<>();
  Map<String, Map<String, String>> practiceApptTypeMap = new HashMap<>();
  Map<String, JSONArray> visitReasonMap = new HashMap<>();
  Map<String, JSONArray> practiceLocationMap = new HashMap<>();
  Map<String, JSONObject> filterDataMap = new HashMap<>();

  @Autowired
  DataCacheManager dataCacheManager;

  @Autowired
  EPMFilter epmFilter;


  public String getLocationIdsList(JSONObject inputObject) throws IHubException {
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    if (!locationIdsMap.containsKey(deploymentId)) {
      List<String> allowedClientLocations;
      String deploymentLocationIds = BLANK;
      List<String> clientLocations = getClientLocationIds(deploymentId);
      List<String> allowedLocations = getAllowedLocationList(deploymentId);

      if (!NullChecker.isEmpty(clientLocations)) {
        if (!NullChecker.isEmpty(allowedLocations)) {
          allowedClientLocations = new ArrayList<>();
          for (String clientLocationId : clientLocations) {
            if (allowedLocations.contains(clientLocationId)) {
              allowedClientLocations.add(clientLocationId);
            }
          }
        } else {
          allowedClientLocations = clientLocations;
        }
      } else {
        allowedClientLocations = allowedLocations;
      }
      deploymentLocationIds = getDeploymentLocationIds(deploymentId, inputObject,
          allowedClientLocations, deploymentLocationIds);
      locationIdsMap.put(deploymentId, deploymentLocationIds);
    }
    return locationIdsMap.get(deploymentId);
  }

  private String getDeploymentLocationIds(String deploymentId, JSONObject inputObject,
      List<String> allowedClientLocations, String deploymentLocationIds) throws IHubException {
    if (!NullChecker.isEmpty(allowedClientLocations)) {
      StringBuilder deploymentLocationIdsBuilder = new StringBuilder(deploymentLocationIds);
      for (String locationId : allowedClientLocations) {
        deploymentLocationIdsBuilder.append(locationId).append(",");
      }
      deploymentLocationIds = deploymentLocationIdsBuilder.toString();
    } else {
      log.info("getLocationsFromEpm() call for deployment id {} ", deploymentId);
      JSONObject outputObject;
      outputObject = athenaApiCaller.call(GET_LOCATIONS.getKey(), inputObject, "");
      Object locationsObject = JsonUtils.getValue(outputObject, LOCATIONS);
      if (locationsObject != null) {
        JSONArray locationsArray = (JSONArray) locationsObject;
        StringBuilder deploymentLocationIdsBuilder = new StringBuilder(deploymentLocationIds);
        for (int i = 0; i < locationsArray.length(); i++) {
          JSONObject locationObject = locationsArray.getJSONObject(i);
          Object locationId = JsonUtils.getValue(locationObject, LOCATION_ID);
          if (locationId != null) {
            deploymentLocationIdsBuilder.append(locationId).append(",");
          }
        }
        deploymentLocationIds = deploymentLocationIdsBuilder.toString();
      }
    }
    return deploymentLocationIds;
  }

  private List<String> getAllowedLocationList(String deploymentId) {
    List<String> allowedLocations;
    try {
      allowedLocations = epmFilter.getAllowedLocations(deploymentId);
    } catch (Exception e) {
      log.info("Allowed locations not defined. " + e.getMessage());
      allowedLocations = null;
    }
    return allowedLocations;
  }

  private List<String> getClientLocationIds(String deploymentId) {
    List<String> clientLocations = null;
    try {
      String clientLocationString = (String) dataCacheManager.getStoredProvidersConfig(
          EPM_NAME_PREFIX, deploymentId, ATHENA_CONFIG, CLIENT_LOCATIONS, false);
      clientLocationString = clientLocationString.replace(" ", "");
      if (!clientLocationString.equals(BLANK)) {
        clientLocations = Arrays.asList(clientLocationString.split(","));
      }
    } catch (Exception e) {
      log.info("Client locations not defined. " + e.getMessage());
    }
    return clientLocations;
  }

  public Map<String, String> getAppointmentTypeList(String practiceId) {
    return practiceApptTypeMap.get(practiceId);
  }

  public void setAppointmentTypeList(String practiceId, Map<String, String> appttypeMap) {
    practiceApptTypeMap.put(practiceId, appttypeMap);
  }

  public void setVisitReasonArrayMap(String deploymentId, JSONArray visistReasonArray) {
    visitReasonMap.put(deploymentId, visistReasonArray);
  }

  public JSONArray getVisitReasonArray(String deploymentId) {
    return visitReasonMap.get(deploymentId);
  }

  public JSONArray getPracticeLocationMap(String practiceId) {
    return practiceLocationMap.get(practiceId);
  }

  public void setPracticeLocationMap(String practiceId, JSONArray practiceLocationArray) {
    this.practiceLocationMap.put(practiceId, practiceLocationArray);
  }


  public JSONObject getFilterDataMap(String deploymentId) {
    return filterDataMap.get(deploymentId);
  }

  public void setFilterDataMap(String deploymentId, JSONObject filterData) {
    this.filterDataMap.put(deploymentId, filterData);
  }
}