package com.pes.integration.athena;

import static com.pes.integration.athena.constant.AthenaConstants.BASE_URL;
import static com.pes.integration.athena.constant.AthenaConstants.DATE_FORMAT;
import static com.pes.integration.athena.constant.AthenaConstants.DATE_TIME_FORMAT;
import static com.pes.integration.athena.constant.AthenaConstants.TIME_FORMAT;
import static com.pes.integration.athena.constant.AthenaConstants.TRUE;
import static com.pes.integration.athena.constant.AthenaEngineConstants.ATHENA_CONFIG;
import static com.pes.integration.athena.constant.AthenaEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.athena.constant.AthenaEngineConstants.REQUEST_CONFIG_KEY_NAME;
import static com.pes.integration.athena.constant.AthenaEngineConstants.REQUEST_MAPPING_KEY_NAME;
import static com.pes.integration.athena.constant.AthenaEngineConstants.RESPONSE_CODES_MAPPING_KEY_NAME;
import static com.pes.integration.athena.constant.AthenaEngineConstants.RESPONSE_MAPPING_KEY_NAME;
import static com.pes.integration.athena.constant.AthenaEngineConstants.RETRY_COUNT;
import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.UtilitiesConstants.ENVIRONMENT_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;

import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.athena.api.AthenaApiCaller;
import com.pes.integration.exceptions.IHubException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AthenaInitEngine {

  @Autowired
  BaseInitEngine baseInitEngine;

  @Autowired
  AthenaApiCaller athenaApiCaller;

  public void init() throws IHubException {
    String[] configTypes = {GENERIC_CONFIG, ATHENA_CONFIG,
        ENVIRONMENT_CONFIG, FILTER_CONFIG};

    initialiseEPMConstants(DATE_FORMAT,
        DATE_TIME_FORMAT,
        TIME_FORMAT,
        BASE_URL,
        TRUE,
        EPM_NAME_PREFIX,
        ATHENA_CONFIG,
        RETRY_COUNT,
        REQUEST_MAPPING_KEY_NAME,
        RESPONSE_MAPPING_KEY_NAME,
        REQUEST_CONFIG_KEY_NAME,
        RESPONSE_CODES_MAPPING_KEY_NAME,
        configTypes);
    baseInitEngine.initializeConfig(EPM_NAME_PREFIX, false);
    athenaApiCaller.initializeObject();
  }
}