package com.pes.integration.athena.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.athena.component.AthenaClientCaller;
import com.pes.integration.athena.constant.AthenaConstants;
import com.pes.integration.athena.constant.AthenaEngineConstants;
import com.pes.integration.athena.dto.Token;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.entity.ApiMethod;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.StringTokenizer;

import static com.pes.integration.athena.constant.AthenaConstants.*;
import static com.pes.integration.athena.constant.AthenaEngineConstants.*;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EngineConstants.METHOD;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.COLON;
import static com.pes.integration.entity.ApiMethod.*;
import static com.pes.integration.exceptions.UtilityErrors.*;
import static com.pes.integration.jsonmapper.JsonUtils.mergeJsonArrays;
import static java.lang.Integer.parseInt;
import static java.net.URLEncoder.encode;
import static java.util.Base64.getEncoder;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;
import static org.springframework.web.util.UriComponentsBuilder.fromHttpUrl;

@Slf4j
@Service
public class AthenaApiCaller extends BaseApiCaller {

  @Autowired
  AthenaClientCaller athenaClientCaller;

  @Autowired
  DataCacheManager cacheManager;

  @Autowired
  ObjectMapper mapper;

  @Autowired
  RedisService redisService;

  private String version;
  private String key;
  private String secret;
  private String baseUrl;
  private String tokenUrl;
  private String oauthVersion;


  public void initializeObject() throws IHubException {
    requestConfig = (JSONObject) cacheManager.getStoredComponentConfig(
        EPM_NAME_PREFIX, ATHENA_CONFIG,
        REQUEST_CONFIG_KEY_NAME, false);
    requestMapping = (JSONObject) cacheManager.getStoredComponentConfig(
        EPM_NAME_PREFIX, ATHENA_CONFIG,
        REQUEST_MAPPING_KEY_NAME, false);
    responseMapping = (JSONObject) cacheManager.getStoredComponentConfig(
        EPM_NAME_PREFIX, ATHENA_CONFIG,
        RESPONSE_MAPPING_KEY_NAME, false);
    version = (String) cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX,
        ATHENA_CONFIG, VERSION, false);
    key = (String) cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX,
        ATHENA_CONFIG, CLIENT_ID, false);
    secret = (String) cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX,
        ATHENA_CONFIG, CLIENT_SECRET, false);
    baseUrl = (String) cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX,
        ATHENA_CONFIG, AthenaEngineConstants.BASE_URL, false);
    tokenUrl = (String) cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX,
        ATHENA_CONFIG, TOKEN_URL, false);
    oauthVersion = (String) cacheManager.getStoredComponentConfig(
        EPM_NAME_PREFIX, ATHENA_CONFIG,
        OAUTH_VERSION, false);
  }

  @Override
  protected Object callApi(JSONObject apiConfig, JSONObject requestObject)
      throws IHubException {
    String response = null;
    String methodString = apiConfig.getString(METHOD);
    ApiMethod method = getApiMethod(methodString);
    Map<String, String> maps;
    try {
      maps = mapper.readValue(requestObject.toString(), Map.class);
    } catch (JsonProcessingException e) {
      throw new IHubException(ERROR_IN_REQUEST.getErrorCode(), "Error in requestObject parsing ");
    }
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
    parameters.setAll(maps);
    String url = buildUrl(apiConfig.getString("url"), maps);
    String newUrl = new StringBuilder(baseUrl).append(version).append(url).toString();
    try {
      if (method.equals(GET) || method.equals(DELETE)) {
        String apiUrl = fromHttpUrl(newUrl).queryParams(parameters).build()
            .toString();
        parameters.clear();
        long startTime = System.currentTimeMillis();// Record the start time
        response = athenaClientCaller.getData(method.getKey(), apiUrl, EMPTY, getToken());

        Object json = new JSONTokener(response).nextValue();
        if (json instanceof JSONArray) {
          return new JSONArray(json.toString());
        }
        JSONObject responseJson = new JSONObject(response);
        JSONObject tempJson = responseJson;
        while(true){
          if(tempJson.has(AthenaConstants.NEXT)){
            String nextUrl = new StringBuilder(baseUrl).append(version).append(tempJson.getString(AthenaConstants.NEXT).replace(V1, BLANK)).toString();
             nextUrl = java.net.URLDecoder.decode(nextUrl, StandardCharsets.UTF_8);
             tempJson = new JSONObject(athenaClientCaller.getData(method.getKey(), nextUrl, EMPTY, getToken()));
            responseJson = mergeJsonArrays(responseJson, tempJson);
          }
          else{
            break;
          }
        }
        response = responseJson.toString();
        long endTime = System.currentTimeMillis(); // Record the end time
        double executionTimeSeconds = (endTime - startTime) / 1000.0;
        String formattedExecutionTime = String.format("%.2f", executionTimeSeconds);
        log.info("Execution Time For Athena_Client_Caller Get_Data: {} seconds", formattedExecutionTime);

      } else {
        long startTime = System.currentTimeMillis();// Record the start time
        response = athenaClientCaller.getData(method.getKey(), newUrl, encodeUrl(maps), getToken());

        long endTime = System.currentTimeMillis(); // Record the end time
        double executionTimeSeconds = (endTime - startTime) / 1000.0;
        String formattedExecutionTime = String.format("%.2f", executionTimeSeconds);
        log.info("Execution Time For Athena_Client_Caller Get_Data: {} seconds", formattedExecutionTime);
      }
    }

    catch (Exception e) {
      String errorMessage = new StringBuilder("Error occurred while calling client api - ").append(escapeJava(newUrl))
              .append(" with error message ").append(e.getMessage()).toString();
      log.error(errorMessage); 
      throw new IHubException(e, StatusCodes.EPM_INTERNAL_ERROR, e.getMessage(), "");
    }
    response = createCustomResponse(response);
    Object json = new JSONTokener(response).nextValue();
    if (json instanceof JSONArray) {
      return new JSONArray(json.toString());
    }
    return new JSONObject(json.toString());
  }

  @Override
  protected void getMappingConfig(String deploymentId) throws IHubException {
    //Below Method is not applicable in case of athena org
  }

  protected String encodeUrl(Map<?, ?> parameters) throws IHubException {
    StringBuilder encodedUrl = new StringBuilder();
    String url;
    try {
      parameters.keySet().forEach(keyObj -> {
        String encodedKey = EMPTY;
        String encodedValue = EMPTY;
        try {
          encodedKey = encode(keyObj.toString(), UTF_8);
          encodedValue = encode(parameters.get(keyObj).toString(), UTF_8);
        } catch (UnsupportedEncodingException e) {
          log.error("Error while encoding {} ", e.getMessage());
        }
        encodedUrl.append(encodedKey).append(EQUAL_TO).append(encodedValue).append(AMPERSAND);
      });
      url = encodedUrl.substring(0, encodedUrl.length() - 1);
    } catch (Exception e) {
      log.error("Error {} ", e.getMessage());
      throw new IHubException(ERROR_IN_REQUEST.getErrorCode(), e.getMessage());
    }
    return url;
  }

  protected String buildUrl(String url, Map<String, String> parameters) {
    StringTokenizer tokenizer = new StringTokenizer(url, FORWARD_SLASH);
    StringBuilder newUrl = new StringBuilder();
    while (tokenizer.hasMoreTokens()) {
      String urlPart = tokenizer.nextToken();
      if (urlPart.startsWith(COLON)) {
        urlPart = parameters.get(urlPart);
        if (urlPart != null) {
          parameters.remove(urlPart);
        }
      }
      newUrl.append(FORWARD_SLASH).append(urlPart);
    }
    return newUrl.toString();
  }

  private String getToken() {
    String token = redisService.get("athena_token");
    if (StringUtils.isEmpty(token)) {
      return generateToken();
    }
    return token;
  }

  /*
   * Generate the token and update redis with ttl
   */
  private String generateToken() {
    String tokenUri = new StringBuilder(baseUrl).append(oauthVersion).append(tokenUrl).toString();
    Token token = athenaClientCaller.generateToken(tokenUri, getHttpHeaders());
    redisService.saveWithTtl("athena_token", token.getAccessToken(),
        parseInt(token.getExpiryToString()));
    return token.getAccessToken();
  }

  private HttpHeaders getHttpHeaders() {
    String authString = new StringBuilder(key).append(COLON).append(secret)
        .toString();
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(APPLICATION_FORM_URLENCODED);
    headers.set("Authorization", "Basic " + getEncoder().encodeToString(authString.getBytes()));
    headers.set("X-B3-TRACEID", MDC.get("X-B3-TraceId"));
    return headers;
  }

  @Override
  protected JSONObject customizeResponseMapping(JSONObject apiResponseMapping,
                                                String apiName, Object inputObject) {
    try {
      if (apiName.equals("open_appointments")) {
        boolean isOrgConfigTrue = "true".equalsIgnoreCase(cacheManager.getConfiguration(EPM_NAME_PREFIX, ((JSONObject) inputObject).optString("deploymentId"), ATHENA_CONFIG, REASON_MAP_EXIST));
        if (isOrgConfigTrue) {
          apiResponseMapping.remove(APPT_TYPE_ID);
          apiResponseMapping.put(REASON_ID_ARRAY, APPT_REASON_ID_ARRAY);
        } else if (apiResponseMapping.has(REASON_ID_ARRAY)) {
          apiResponseMapping.put(APPT_TYPE_ID, APPT_REASON_ID_KEY);
          apiResponseMapping.remove(REASON_ID_ARRAY);
        }
      }
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return apiResponseMapping;
  }
}