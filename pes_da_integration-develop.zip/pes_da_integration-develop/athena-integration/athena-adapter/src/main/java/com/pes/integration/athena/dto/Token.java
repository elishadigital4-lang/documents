package com.pes.integration.athena.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Token {

  @JsonProperty("access_token")
  private String accessToken;

  @JsonProperty("expires_in")
  private Object expiresIn;

  public String getExpiryToString(){
    return this.expiresIn.toString();
  }
}
