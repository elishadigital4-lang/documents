package com.pes.integration.athena.constant;

import java.util.Map;

/**
 * Constants that are specific to AthenaAPI, always try to minimize this list. Any change in the
 * AthenaHealth might need to be reflected here.
 *
 * @author ajay.gond
 */
public class AthenaConstants {

  public static final String APPOINTMENT_TYPE_CANCELED = "x";
  public static final String APPOINTMENT_TYPE_FUTURE = "f";
  public static final String APPOINTMENT_TYPE_OPEN = "o";
  public static final String DATE_FORMAT = "MM/dd/yyyy";
  public static final String DATE_TIME_FORMAT = "MM/dd/yyyy HH:mm:ss";
  public static final String NEXT = "next";
  public static final String V1 = "/v1";
  public static final String DEFAULT_CANCEL_REASON_ID = "41";
  public static final String TIME_FORMAT = "HH:mm";
  public static final Object TRUE = "true";
  public static final String BASE_URL = "https://api.athenahealth.com";
  public static final String GRANT_TYPE = "grant_type";
  public static final String CLIENT_CREDENTIALS = "client_credentials";
  public static final String UTF_8 = "UTF-8";
  public static final String AUTHORIZATION = "Authorization";
  public static final String BEARER = "Bearer ";
  public static final Map<String, String> AUTH_PREFIXES;
  public static final String ATHENA_PRACTICE_ID = "practiceid";

  public static final String IGNORE_SHCED_PERMISSION = "ignore_schedulable_permission";

  public static final String SLOT_ID_KEY = "slotId";

  public static final String GENERIC_APPT_TYPE = "genapptype";

  public static final String ATHENA_DATE_FORMAT = "MM/dd/yyyy";

  public static final String TEMP_PRACTICE_ID = "temp.practice_id";

  public static final String WEB_SCHEDILABLE_FLAG = "webschedulable";

  public static final String REASON_ID = "reason_id";
  public static final String APPOINTMENTTYPEID = "appointmenttypeid";
  public static final String REASONID = "reasonId";
  public static final String PROVIDERID = "providerId";
  public static final String THREAD_SIZE="threadSize";

  public static final String REASON_MAP_EXIST="isreasonmapexist";

  public static final String PRACTICE_ID = "practiceId";

  public static final String DEPLOYMENTID = "deploymentId";

  public static final String PRACTICEID = ":practiceid";
  public static final String PATIENTID = ":patientid";
  public static final String PATIENT_PATH = "/:practiceid/patients";
  public static final String DEPARTMENT_ID = "departmentid";
  public static final String ERROR = "error";

  public static final String EXCEPTION = "EXCEPTION:: deploymentId:";
  public static final String TOTAL = "totalcount";
  public static final String NOT_REGISTERED_MSG = "The specified patient does not exist in that department.";
  public static final String REG_PATIENT_IN_DEPARTMENT = "Registerpatientindepartment";
  public static final String LOOKUP_DEPARTMENT_ID = "Lookupdepartmentid";
  public static final String SHOULD_IGNORE_SCHEDULABLE_PERMISSION = "true";
  public static final String INFO_PRACTICE_ID = "1";
  public static final String AUTH_TYPE = "Basic ";
  public static final String PATIENT = "Patient ";

  public static final String PRACTICE_ID1 = "practice_id";

  static {
    AUTH_PREFIXES = Map.of("v1", "/oauth2", "preview1", "/oauthpreview", "openpreview1",
        "/oauthopenpreview");
  }

  private AthenaConstants() {
  }
}
