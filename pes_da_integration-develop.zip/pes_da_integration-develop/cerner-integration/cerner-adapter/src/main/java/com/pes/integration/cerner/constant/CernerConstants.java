package com.pes.integration.cerner.constant;

public class CernerConstants {
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_TIME_FORMAT = "MM/dd/yyyy HH:mm:ss";
    public static final String DATE_TIME_Z_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String DATE_TIME_R4_Z_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String APPOINTMENT_DURATION = "Duration";
    public static final String EXTERNAL_APPT_ID = "ExternalApptId";
    public static final String REFERENCE = "Reference";
    public static final String START_TIME = "temp.start_time";
    public static final String NEXT = "next";
    public static final String TIME_FORMAT = "HH:mm";
    public static final Object TRUE = "true";
    public static final String BASE_URL = "base_url";
    public static final String PROVIDERS = "providers";
    public static final String AUTH = "/protocols/oauth2/profiles/smart-v1/token";
    public static final String GRANT_TYPE = "grant_type";
    public static final String CLIENT_CREDENTIALS = "client_credentials";
    public static final String ENCODING = "UTF-8";

    public static final String MALE = "male";
    public static final String FEMALE = "female";
    public static final String GENDER_M = "M";
    public static final String GENDER_F = "F";

    public static final String HOME_PHONE_TYPE_VALUE = "home";
    public static final String WORK_PHONE_TYPE_VALUE = "work";
    public static final String CELL_PHONE_TYPE_VALUE = "mobile";

    public static final String PHONE = "phone";
    public static final String TIME_ZONE = "timezone";
    public static final String EXT_REASON_ID_TYPE = "reasonIdType";

    public static final String  REASON_ID_LIST ="reasonIdList";
    public static final String PROVIDER_ID = "ProviderId";
    public static final String LOCATION_ID = "LocationId";
    public static final String PIPE = "|";

    private CernerConstants(){
    }
}
