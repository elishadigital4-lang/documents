package com.pes.integration.cerner.component;

import static com.pes.integration.cerner.constant.CernerEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.UtilitiesConstants.EPM_FILTERS;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.LOCATION_ID;

import com.pes.integration.config.data.DataCacheManager;
import java.util.ArrayList;
import java.util.List;

import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EPMFilter {

    @Autowired
    DataCacheManager dataCacheManager;

    public List<String> getAllowedLocations(String deploymentId) {
        List<String> allowedLocations = new ArrayList<>();
        try {
            JSONArray filterArray = (JSONArray) dataCacheManager.getStoredProvidersConfig(
                    EPM_NAME_PREFIX, deploymentId, GENERIC_CONFIG, EPM_FILTERS, false);
            for (int i = 0; i < filterArray.length(); i++) {
                JSONObject filterObject = filterArray.getJSONObject(i);
                if (filterObject.has(LOCATION_ID)) {
                    allowedLocations.add(filterObject.getString(LOCATION_ID));
                }
            }
        } catch (Exception e) {
            log.error("Error {} ", e.getMessage());
            //Allow all in case of exception.
        }
        return allowedLocations;
    }


    private static boolean getAllowedProviders(JSONArray provFilterArray, String providerId){
        for(int i=0;i<provFilterArray.length();i++){
            JSONObject filterObject = provFilterArray.getJSONObject(i);

            String allowedProviderId = BLANK;

            if(filterObject.has(UtilitiesConstants.PROVIDER_ID)){
                allowedProviderId = filterObject.getString(UtilitiesConstants.PROVIDER_ID);
            }
            if (!allowedProviderId.equals(BLANK) && allowedProviderId.equals(providerId)) {
                return true;
            }
        }
        return false;
    }
    private static boolean getAllowedLocationProviders(JSONArray locProvfilterArray, String locationId, String providerId){
        for(int i=0;i<locProvfilterArray.length();i++){
            JSONObject filterObject = locProvfilterArray.getJSONObject(i);

            String allowedProviderId = BLANK;
            String allowedLocationId = BLANK;

            if(filterObject.has(UtilitiesConstants.PROVIDER_ID)){
                allowedProviderId = filterObject.getString(UtilitiesConstants.PROVIDER_ID);
            }
            if(filterObject.has(UtilitiesConstants.LOCATION_ID)){
                allowedLocationId = filterObject.getString(UtilitiesConstants.LOCATION_ID);
            }
            if (!allowedProviderId.equals(BLANK)
                    && allowedProviderId.equals(providerId)
                    && !allowedLocationId.equals(BLANK)
                    && allowedLocationId.equals(locationId)) {
                return true;
            }
        }
        return false;
    }
    public boolean isAllowed(String deploymentId, String locationId, String providerId){
        boolean isAllowed = false;
        JSONObject filterJson = null;
        JSONArray provFilterArray = null;
        JSONArray locFilterArray = null;
        JSONArray locProvfilterArray = null;
        try{
            Object filterObj = null;
            try {
                filterObj =  dataCacheManager.getStoredProvidersConfig(   EPM_NAME_PREFIX,deploymentId, UtilitiesConstants.FILTER_CONFIG, false);
            } catch (IHubException e) {
                //Allow all in case of exception.
            }
            if(!NullChecker.isEmpty(filterObj)){
                filterJson = (JSONObject)filterObj;
                if (filterJson.has(Key.LOCATION_PROVIDER_FILTER)) {
                    JSONObject locProvfilterJson = filterJson.getJSONObject(Key.LOCATION_PROVIDER_FILTER);
                    locProvfilterArray = locProvfilterJson.getJSONArray(Key.LOCATION_PROVIDER_FILTER);
                    isAllowed = getAllowedLocationProviders(locProvfilterArray, locationId, providerId);
                }
                if (!isAllowed && filterJson.has(Key.PROVIDER_FILTER)) {
                    JSONObject provfilterJson = filterJson.getJSONObject(Key.PROVIDER_FILTER);
                    provFilterArray = provfilterJson.getJSONArray(Key.PROVIDER_FILTER);
                    isAllowed = getAllowedProviders(provFilterArray, providerId);
                }
                if (!isAllowed && filterJson.has(Key.LOCATION_FILTER)) {
                    JSONObject locfilterJson = filterJson.getJSONObject(Key.LOCATION_FILTER);
                    locFilterArray = locfilterJson.getJSONArray(Key.LOCATION_FILTER);
                    isAllowed = getAllowedLocations(locFilterArray, locationId);
                }
            } else{
                isAllowed = true;
            }

            if(NullChecker.isEmpty(locProvfilterArray) && NullChecker.isEmpty(provFilterArray) && NullChecker.isEmpty(locFilterArray)){
                isAllowed = true;
            }

        }catch(Exception e){
            isAllowed = true;
            //Allow all in case of exception.
        }
        return isAllowed;
    }

    private static boolean getAllowedLocations(JSONArray locFilterArray, String locationId){
        for(int i=0;i<locFilterArray.length();i++){
            JSONObject filterObject = locFilterArray.getJSONObject(i);

            String allowedLocationId = BLANK;

            if(filterObject.has(UtilitiesConstants.LOCATION_ID)){
                allowedLocationId = filterObject.getString(UtilitiesConstants.LOCATION_ID);
            }
            if (!allowedLocationId.equals(BLANK) && allowedLocationId.equals(locationId)) {
                return true;
            }
        }
        return false;
    }
}