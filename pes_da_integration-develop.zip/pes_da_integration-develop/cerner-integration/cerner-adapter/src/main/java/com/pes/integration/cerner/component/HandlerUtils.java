package com.pes.integration.cerner.component;


import static com.pes.integration.cerner.constant.CernerConstants.PHONE;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants.*;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.FilterDataService;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * This class is responsible for carrying out common operations specific to all Cerner Handlers
 *
 * @author prak.rai
 */

@Slf4j
@Service
public class HandlerUtils {

    @Autowired
    DataCacheManager dataCacheManager;

    @Autowired
    FilterDataService filterDataService;

    @Autowired
    CernerApiCaller cernerApiCaller;

    public static Object updateE2DPhones(Object outputObject) throws IHubException{
        Object phoneTypeOb = JsonUtils.getValue(outputObject, "DemographicData.PatientInformation[0]");
        if(!NullChecker.isEmpty(phoneTypeOb) && ((JSONObject)phoneTypeOb).has("Phones")){
            JSONArray phoneArray = ((JSONObject)phoneTypeOb).getJSONArray("Phones");
            JSONArray emailArray = new JSONArray();
            //reading email as phoneNumber because cerner returning phone number and email under same tag
            fetchPhoneNumber(phoneArray, outputObject, emailArray);
            setValue(outputObject, "DemographicData.PatientInformation[0].Phones", null);
            if(emailArray.length()>1)
                setValue(outputObject, "DemographicData.PatientInformation[0].EmailList", emailArray);

        }
        return outputObject;
    }

    private static void fetchPhoneNumber(JSONArray phoneArray, Object outputObject, JSONArray emailArray) throws IHubException {
        if(!NullChecker.isEmpty(phoneArray)){
            for(Object phone: phoneArray){
                Object phoneType = JsonUtils.getValue(phone, "PhoneType");
                Object phoneNumber = JsonUtils.getValue(phone, "Number");
                Object system = JsonUtils.getValue(phone, "System");
                if(system.equals(PHONE) && phoneType.equals(CernerConstants.CELL_PHONE_TYPE_VALUE)){
                    JsonUtils.setValue(outputObject, Key.MOBILE_PHONE, phoneNumber);
                } else if(system.equals(PHONE) && phoneType.equals(CernerConstants.WORK_PHONE_TYPE_VALUE)){
                    JsonUtils.setValue(outputObject, Key.WORK_PHONE, phoneNumber);
                } else if(system.equals(PHONE) && phoneType.equals(CernerConstants.HOME_PHONE_TYPE_VALUE)){
                    JsonUtils.setValue(outputObject, Key.HOME_PHONE, phoneNumber);
                }
                if(system.equals("email") && phoneType.equals(CernerConstants.HOME_PHONE_TYPE_VALUE) ){
                    JsonUtils.setValue(outputObject, Key.EMAIL, phoneNumber);
                    emailArray.put(phoneNumber);
                }
            }
        }
    }

    public static String getId(String idUrl){
        int index = idUrl.lastIndexOf('/');
        return idUrl.substring(index+1);
    }

    public String getCernerTimeZone(){
        String timeZoneStr = null;
        try{
            timeZoneStr = (String)dataCacheManager.getStoredComponentConfig(CernerEngineConstants.EPM_NAME_PREFIX, CernerEngineConstants.CERNER_CONFIG, CernerConstants.TIME_ZONE,false);
        }catch (Exception e) {
            log.error(e.getMessage());
        }
        return timeZoneStr;
    }

    public String getClientTimeZone(String deploymentId){
        String timeZoneStr = null;
        try{
            timeZoneStr = (String)dataCacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CernerEngineConstants.CERNER_CONFIG, CernerConstants.TIME_ZONE,false);
        }catch (Exception e) {
            log.error("timezone is not set for "+deploymentId +e);
        }
        return timeZoneStr;
    }

    public String getAppointmentTypeId(String deploymentId){
        String reasonIdType = null;
        try{
            reasonIdType = (String)dataCacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CernerEngineConstants.CERNER_CONFIG, CernerConstants.EXT_REASON_ID_TYPE,false);
        }catch (Exception e) {
            log.error("Error in reading AppointmentTypeId value for deploymentId: "+deploymentId);
        }
        return reasonIdType;
    }

    public static String convertDateFormat(String originalDate, String oldFormat, String newFormat, String cernerTimeZone, String clientTimeZone) throws ParseException {
        DateFormat originalFormat = new SimpleDateFormat(oldFormat, Locale.ENGLISH);
        originalFormat.setTimeZone(TimeZone.getTimeZone(cernerTimeZone));

        DateFormat targetFormat = new SimpleDateFormat(newFormat);
        targetFormat.setTimeZone(TimeZone.getTimeZone(clientTimeZone));

        String formattedDate = null;
        Date date = originalFormat.parse(originalDate);
        formattedDate = targetFormat.format(date);  // 20120821
        return formattedDate;
    }
}
