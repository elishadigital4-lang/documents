package com.pes.integration.cerner.api;

import static java.util.Arrays.stream;

/**
 * ENUM class to define different type of API names to be called.
 */
public enum ApiName {

  GET_PATIENT("patient_search"),
  NEW_PATIENT("new_patient"),
  GET_PATIENT_DEMOGRAPHICS("get_patient_demographics"),
  UPDATE_PATIENT("update_patient"),
  NEW_APPOINTMENT("new_appointment"),
  CANCEL_APPOINTMENT("cancel_appointment"),
  RESCHEDULE_APPOINTMENT("reschedule_appointment"),
  OPEN_APPOINTMENTS("open_appointments"),
  BOOKED_APPOINTMENTS("booked_appointments"),
  CHANGED_APPOINTMENTS("changed_appointments"),
  GET_APPOINTMENT("get_appointment"),
  GET_PRACTICES("get_practices");
  String key;

  ApiName(String key) {
    this.key = key;
  }

  public String getKey() {
    return key;
  }

  public ApiName getEnum(String apiName) {
    return stream(values()).filter(api -> api.getKey().equals(apiName)).findFirst().orElse(null);
  }
}
