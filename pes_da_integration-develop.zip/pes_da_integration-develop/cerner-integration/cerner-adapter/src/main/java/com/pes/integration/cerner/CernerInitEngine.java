package com.pes.integration.cerner;

import static com.pes.integration.cerner.constant.CernerConstants.BASE_URL;
import static com.pes.integration.cerner.constant.CernerConstants.DATE_FORMAT;
import static com.pes.integration.cerner.constant.CernerConstants.DATE_TIME_FORMAT;
import static com.pes.integration.cerner.constant.CernerConstants.TIME_FORMAT;
import static com.pes.integration.cerner.constant.CernerConstants.TRUE;
import static com.pes.integration.cerner.constant.CernerEngineConstants.CERNER_CONFIG;
import static com.pes.integration.cerner.constant.CernerEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.cerner.constant.CernerEngineConstants.REQUEST_CONFIG_KEY_NAME;
import static com.pes.integration.cerner.constant.CernerEngineConstants.REQUEST_MAPPING_KEY_NAME;
import static com.pes.integration.cerner.constant.CernerEngineConstants.RESPONSE_CODES_MAPPING_KEY_NAME;
import static com.pes.integration.cerner.constant.CernerEngineConstants.RESPONSE_MAPPING_KEY_NAME;
import static com.pes.integration.cerner.constant.CernerEngineConstants.RETRY_COUNT;
import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.UtilitiesConstants.ENVIRONMENT_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;

import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.exceptions.IHubException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CernerInitEngine {

    @Autowired
    BaseInitEngine baseInitEngine;

    @Autowired
    CernerApiCaller cernerApiCaller;

    public void init() throws IHubException {
        String[] configTypes = {GENERIC_CONFIG, CERNER_CONFIG,
                ENVIRONMENT_CONFIG, FILTER_CONFIG};

        initialiseEPMConstants(DATE_FORMAT,
                DATE_TIME_FORMAT,
                TIME_FORMAT,
                BASE_URL,
                TRUE,
                EPM_NAME_PREFIX,
                CERNER_CONFIG,
                RETRY_COUNT,
                REQUEST_MAPPING_KEY_NAME,
                RESPONSE_MAPPING_KEY_NAME,
                REQUEST_CONFIG_KEY_NAME,
                RESPONSE_CODES_MAPPING_KEY_NAME,
                configTypes);
        baseInitEngine.initializeConfig(EPM_NAME_PREFIX, false);
    }
}