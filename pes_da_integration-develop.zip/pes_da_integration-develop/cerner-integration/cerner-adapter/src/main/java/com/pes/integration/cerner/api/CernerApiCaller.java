package com.pes.integration.cerner.api;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.cerner.component.CernerClientCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.cerner.dto.Token;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.entity.ApiMethod;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;
import static com.pes.integration.cerner.constant.CernerEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.Key.REASON_ID_ARRAY;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.COLON;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.METHOD;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.URL;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.util.Base64.getEncoder;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;
@Slf4j
@Service
public class CernerApiCaller extends BaseApiCaller {
    private static Map<String, CernerApi> apiMap = new HashMap<>();
    @Autowired
    CernerClientCaller cernerClientCaller;
    @Autowired
    DataCacheManager cacheManager;
    @Autowired
    ObjectMapper mapper;
    @Autowired
    RedisService redisService;
    private CernerApi getCernerApi(String deploymentId) throws IHubException {
        CernerApi cernerApi = apiMap.getOrDefault(deploymentId, null);
        if (Objects.isNull(cernerApi)) {
            return apiCaller(deploymentId);
        }
        return cernerApi;
    }
    public CernerApi apiCaller(String deploymentId) throws IHubException {
        Object clientId = null;
        String key;
        String secret;
        String baseUrl;
        String tokenUrl;
        try {
            clientId =  cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, CERNER_CONFIG, CLIENT_ID,false);
        }catch(IHubException e) {
            log.info("org level configuration not exist for deploymentId "+ deploymentId);
        }
        if (!isEmpty(clientId)) {
            key = (String) clientId;
            secret = (String) cacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CernerEngineConstants.CERNER_CONFIG, CernerEngineConstants.CLIENT_SECRET,false);
            tokenUrl = (String) cacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CernerEngineConstants.CERNER_CONFIG, CernerEngineConstants.TOKEN_URL,false);
            baseUrl = (String) cacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CernerEngineConstants.CERNER_CONFIG, CernerConstants.BASE_URL,false);
        }
        else {
            key = (String) cacheManager.getStoredComponentConfig(CernerEngineConstants.EPM_NAME_PREFIX, CernerEngineConstants.CERNER_CONFIG, CernerEngineConstants.CLIENT_ID,false);
            secret = (String) cacheManager.getStoredComponentConfig(CernerEngineConstants.EPM_NAME_PREFIX, CernerEngineConstants.CERNER_CONFIG, CernerEngineConstants.CLIENT_SECRET,false);
            tokenUrl = (String) cacheManager.getStoredComponentConfig(CernerEngineConstants.EPM_NAME_PREFIX, CernerEngineConstants.CERNER_CONFIG, CernerEngineConstants.TOKEN_URL,false);
            baseUrl = (String) cacheManager.getStoredComponentConfig(CernerEngineConstants.EPM_NAME_PREFIX, CernerEngineConstants.CERNER_CONFIG, CernerConstants.BASE_URL,false);
        }
        String fhirTenantId = (String) cacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CernerEngineConstants.CERNER_CONFIG, CernerEngineConstants.FHIR_TENANT_ID,false);
        baseUrl = baseUrl + fhirTenantId;
        CernerApi cernerApi = new CernerApi(key, secret, deploymentId, baseUrl, tokenUrl, clientId, fhirTenantId);
        apiMap.put(deploymentId, cernerApi);
        return cernerApi;
    }
    protected void getMappingConfig(String deploymentId) throws IHubException{
        /*not required*/
    }
    @Override
    protected JSONObject customizeResponseMapping(JSONObject apiResponseMapping, String apiName, Object inputObject) {
        return null;
    }
    @Override
    protected Object callApi(JSONObject apiConfig, JSONObject requestObject) throws IHubException {
        final String deploymentId = getValue(requestObject, DEPLOYMENT_ID).toString();
        requestObject.remove(DocASAPConstants.Key.DEPLOYMENT_ID);
        CernerApi cernerApi = getCernerApi(deploymentId);
        String url = apiConfig.getString(URL);
        String method = apiConfig.getString(METHOD);
        String readHeader = apiConfig.has("header") ? apiConfig.getString("header") : null;
        Map<String, String> parameters = JsonUtils.getMapFromJson(requestObject);
        url = buildUrl(url, parameters,cernerApi);
        Object responseObject;
        try {
            responseObject = executeApiCall(requestObject, method, url, deploymentId, cernerApi, readHeader);
            if (method.equalsIgnoreCase(ApiMethod.GET.getKey()) && responseObject instanceof String) {
                String responseString = (String) responseObject;
                JSONObject responseJson = new JSONObject(responseString);
                JSONObject tempJson = responseJson;
                // Below code handles the data pagination.
                while (true) {
                    String nextUrl = getNextUrl(tempJson);
                    if (!NullChecker.isEmpty(nextUrl)) {
                        String nextPageResponseString = cernerClientCaller.getData(method, nextUrl, requestObject.toString(), getToken(deploymentId,cernerApi), getHeaders(requestObject,readHeader),readHeader);
                        JSONObject nextPageResponseJson = new JSONObject(nextPageResponseString);
                        responseJson = JsonUtils.mergeJsonArrays(responseJson, nextPageResponseJson);
                        tempJson = nextPageResponseJson;
                    } else {
                        break;
                    }
                }
                responseObject = responseJson;
            } else if (method.equalsIgnoreCase(ApiMethod.GET.getKey()) && !(responseObject instanceof JSONObject)) {
                JSONObject errorJson = new JSONObject();
                errorJson.accumulate("detail", responseObject);
                responseObject = errorJson;
                log.info("responseObject:: {}", responseObject);
            }

        } catch (Exception e) {
            String errorMessage = new StringBuilder("Error occurred while calling client api - ").append(escapeJava(url))
                    .append(" with error message ").append(e.getCause().getMessage()).toString();
            log.error(errorMessage);
            throw new IHubException(e, ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
                    errorMessage);
        }
        return responseObject;
    }

    private Object executeApiCall(JSONObject requestObject, String method, String url, String deploymentId, CernerApi cernerApi, String readHeader) throws Exception {
        Object responseObject = null;
        if(method.equals("PATCH")){
            if(requestObject.has("patchCancelRequest")){
                JSONArray patchCancelRequest = requestObject.getJSONArray("patchCancelRequest");
                if(!patchCancelRequest.isEmpty()){
                    JSONObject patchCancelRequestObject = patchCancelRequest.getJSONObject(0);
                    responseObject = cernerClientCaller.getData(method, url, patchCancelRequest.toString(), getToken(deploymentId, cernerApi), getHeaders(patchCancelRequestObject, readHeader), readHeader);
                } else {
                    throw new IllegalArgumentException("patchCancelRequest is empty");
                }
            } else {
                throw new IllegalArgumentException("patchCancelRequest is not present in the request object");
            }
        } else {
            responseObject = cernerClientCaller.getData(method, url, requestObject.toString(), getToken(deploymentId, cernerApi), getHeaders(requestObject, readHeader), readHeader);
        }
        if(responseObject==null){
            responseObject=new JSONObject();
        }
        if(responseObject.toString().contains("Error") || responseObject.toString().contains("conflict")){
            throw new IllegalArgumentException(responseObject.toString());
        }
        if(responseObject instanceof JSONArray){
            responseObject = new JSONArray(responseObject.toString());
        } else {
            responseObject = new JSONObject(responseObject.toString());

        }
        return responseObject;
    }

    private String getNextUrl(JSONObject responseObject) {
        String nextUrl = "";
        if (responseObject.has("link")) {
            JSONArray link = responseObject.getJSONArray("link");
            for (Object linkObj : link) {
                JSONObject linkJson = (JSONObject) linkObj;
                if (linkJson.has("relation")) {
                    String next = linkJson.getString("relation");
                    if (CernerConstants.NEXT.equalsIgnoreCase(next)) {
                        nextUrl = ((JSONObject) linkObj).getString(URL);
                    }
                }
            }
        }
        return nextUrl;
    }

    private String buildUrl(String endPoint, Map<String, String> parameters,CernerApi cernerApi) {
        endPoint = replacePathParameters(endPoint, parameters);
        endPoint = appendQueryParameters(endPoint, parameters);
        return String.format("%s%s", cernerApi.getBaseUrl(), endPoint);
    }

    private static String replacePathParameters(String endPoint, Map<String, String> parameters) {
        if (endPoint.contains(":")) {
            StringTokenizer tokenizer = new StringTokenizer(endPoint, "/");
            String newUrl = "";
            while (tokenizer.hasMoreTokens()) {
                String urlPart = tokenizer.nextToken();
                if (urlPart.startsWith(":")) {
                    urlPart = parameters.get(urlPart);
                    if (urlPart != null) {
                        parameters.remove(urlPart);
                    }
                }
                newUrl += "/" + urlPart;
            }
            endPoint = newUrl;
        }
        return endPoint;
    }

    private static String appendQueryParameters(String endPoint, Map<String, String> parameters) {
        if (endPoint.contains("?")) {
            int index = endPoint.indexOf('?');
            String url = endPoint.substring(0, index);
            Object[] keyArray = parameters.keySet().toArray();
            StringBuilder sb = new StringBuilder();
            appendParameters(endPoint, parameters, keyArray, sb);
            endPoint = url + sb.toString();
        }
        return endPoint;
    }

    private static void appendParameters(String endPoint, Map<String, String> parameters, Object[] keyArray, StringBuilder sb) {
        for (int i = 0; i < keyArray.length; i++) {
            String key = keyArray[i].toString();
            if (endPoint.contains(key)) {
                String value = parameters.get(key);
                if (key.contains("_") && !key.equals("_count"))
                    key = key.replace('_', '.');

                if (i == 0) {
                    sb.append(String.format("?%s=%s", key, value));
                } else if (sb.toString().length() == 0) {
                    sb.append(String.format("?%s=%s", key, value));
                } else
                    sb.append(String.format("&%s=%s", key, value));
            }
        }
    }


    private String getToken(String deploymentId,CernerApi cernerApi) {
        String token = redisService.get("cerner_token_"+deploymentId);
        if (StringUtils.isEmpty(token)) {
            return generateToken(deploymentId,cernerApi);
        }
        return token;
    }
    /*
     * Generate the token and update redis with ttl
     */
    private String generateToken(String deploymentId,CernerApi cernerApi) {
        String tokenUri = new StringBuilder(cernerApi.getTokenUrl()).append(cernerApi.getFhirTenantId()).append(CernerConstants.AUTH).toString();
        Token token = cernerClientCaller.generateToken(tokenUri, getHttpHeaders(cernerApi));
        redisService.saveWithTtl("cerner_token_"+deploymentId, token.getAccessToken(),
                parseInt(String.valueOf(token.getExpiresIn())));
        return token.getAccessToken();
    }
    private HttpHeaders getHttpHeaders(CernerApi cernerApi) {
        String authString = new StringBuilder(cernerApi.getKey()).append(COLON).append(cernerApi.getSecret())
                .toString();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.set("Authorization", "Basic " + getEncoder().encodeToString(authString.getBytes()));
        headers.set("X-B3-TRACEID", MDC.get("X-B3-TraceId"));
        return headers;
    }
    private HttpHeaders getHeaders(JSONObject requestObject,String readHeader) {
        HttpHeaders headers = new HttpHeaders();
        String value = (String) requestObject.opt("value");
        if(!isEmpty(value) && value.equals("cancelled")){
            headers.set("Content-Type", "application/json-patch+json");
            headers.set("Accept", "application/json-patch+json");
            headers.set("If-Match", "W/\"0\"");
        } else {
            headers.set("Content-Type", "application/json+fhir");
        }
        return headers;
    }
}