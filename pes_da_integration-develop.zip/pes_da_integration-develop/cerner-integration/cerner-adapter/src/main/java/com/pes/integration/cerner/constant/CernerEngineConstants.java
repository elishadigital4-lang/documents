package com.pes.integration.cerner.constant;

public class CernerEngineConstants {
    public static final String EPM_NAME_PREFIX = "cn";
    public static final String CERNER_CONFIG = "cernerprop";
    public static final String RETRY_COUNT = "retrycount";
    public static final String FORWARD_SLASH = "/";
    public static final String COLON = ":";
    public static final String REQUEST_CONFIG_KEY_NAME = "cn_req_conf";
    public static final String REQUEST_MAPPING_KEY_NAME = "cn_req_map";
    public static final String RESPONSE_CODES_MAPPING_KEY_NAME = "cn_res_codes";
    public static final String RESPONSE_MAPPING_KEY_NAME = "cn_res_map";

    public static final String CLIENT_ID = "clientId";
    public static final String CLIENT_SECRET = "clientSecret";
    public static final String FHIR_TENANT_ID = "fhirTenantId";
    public static final String TOKEN_URL = "token_url";
    public static final String EQUAL_TO = "=";
    public static final String AMPERSAND = "&";
    public static final String PATIENT_ORG_IDENTIFIER = "orgIdentifier";
    public static final String REFERENCE = "Reference";
    public static final String SLOT_ID = "SchedulingData.Schedule[0].SlotId";
    public static final String NUMBER = "Number";
    public static final String PHONE_TYPE = "PhoneType";
    public static final String SYSTEM = "System";
    public static final String LOCATION_ORG = "loc-org";
    public static final String DEFAULT_ORG = "def-org";
    public static final String COUNT = "count";
    public static final String ADDRESS = "DemographicData.PatientInformation[0].Addr";
    public static final String ADDRESS_TYPE = "AddressType";
    private CernerEngineConstants() {
    }
}
