package com.pes.integration.cerner.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CernerApi {

    String key;
    String secret;
    String deploymentId;
    String baseUrl;
    String tokenUrl;
    Object clientId;
    String  fhirTenantId;
}
