package com.pes.integration.cerner.component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.cerner.dto.Token;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static com.pes.integration.cerner.constant.CernerConstants.CLIENT_CREDENTIALS;
import static com.pes.integration.cerner.constant.CernerConstants.GRANT_TYPE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.MetricsUtil.*;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.springframework.http.HttpMethod.valueOf;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.BodyInserters.fromFormData;

@Slf4j
@Component
public class CernerClientCaller {

    @Autowired
    WebClient webClient;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;
    public static final List<String> IGNORABLE_ERRORS = Arrays.asList("Unprocessable entity", "Invalid request");

    @Observed(name = "integration.generateToken", contextualName = "integration")
    public Token generateToken(String url, HttpHeaders headers) {
        metricClientRequestCount(engineName, appDescription, url);
        return webClient.post()
                .uri(url)
                .accept(APPLICATION_JSON)
                .headers(h -> h.addAll(headers))
                .body(fromFormData(GRANT_TYPE, CLIENT_CREDENTIALS)
                        .with("scope", "system/Patient.read,system/Patient.write,system/Slot.read,system/Appointment.write,system/Appointment.read"))
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
                        .flatMap(errorBody -> {
                            log.error(
                                    "Error status code while calling cerner token api is Status code:: {} and errorBody:: {}"
                                    , clientResponse.statusCode(), errorBody);
                            metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                            return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(),
                                    errorBody));
                        }))
                .bodyToMono(Token.class)
                .doOnError(ex -> {
                    log.error(
                            "Error while calling cerner token api with Error message:: {} ", ex.getMessage());
                })
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, url);
                    log.info("Successfully fetched token for Cerner ");
                }).block();
    }

    @Observed(name = "integration.getApiData", contextualName = "integration")
    public String getData(String httpMethod, String url, String bodyy, String token, HttpHeaders headers, String readHeader) {
        String deploymentId = MDC.get(DEPLOYMENT_ID) != null ? MDC.get(DEPLOYMENT_ID) : EMPTY;
        String shortenUrl = getShortenUrl(url);
        metricClientRequestCountWithDeploymentId(engineName, appDescription, deploymentId,httpMethod+" - "+ shortenUrl);
        if (httpMethod.equalsIgnoreCase("GET")) {
            bodyy = "";
        }
        return webClient.method(valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .headers(header ->
                        header.setBearerAuth(token)
                )
                .headers(h -> h.addAll(headers))
                .body(Mono.just(bodyy), String.class)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        ObjectMapper objectMapper = new ObjectMapper();
                        Mono<String> bodyMono = response.bodyToMono(String.class);
                        if (readHeader != null && readHeader.equalsIgnoreCase("true")) {
                            HttpHeaders headerss = response.headers().asHttpHeaders();
                            Map<String, List<String>> headerMap = headerss;
                            String headerJson = null;
                            try {
                                headerJson = objectMapper.writeValueAsString(headerMap);
                            } catch (JsonProcessingException e) {
                                throw new RuntimeException(e);
                            }
                            return bodyMono.just(headerJson);
                        } else {
                            return bodyMono;
                        }
                    } else {
                        Mono.just("Error: " + response.statusCode());
                        return response.bodyToMono(String.class)
                                .flatMap(errorBody -> {
                                    recordErrorMetrics(response, errorBody, deploymentId, shortenUrl);
                                    log.error(
                                            "Error status code while calling cerner api is Status code:: {} and errorBody:: {}",
                                            response.statusCode(), errorBody);
                                    return Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,errorBody));
                                });
                    }
                })
                .onErrorMap(ex -> {
                    log.error(
                            "Error while calling cerner api with  Error message:: {} ", ex.getMessage());
                    return new IHubException(StatusCodes.EPM_INTERNAL_ERROR, ex.getMessage(),ex.getMessage());
                })
                .doOnSuccess(response -> {
                            metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                            log.info("Successfully fetched data for cerner Api for url {} ", sanitizeForLog(url));
                        }
                ).block();
    }

    private void recordErrorMetrics(ClientResponse response, String errorBody, String deploymentId, String shortenUrl) {
        if (response.statusCode().is4xxClientError()) {
            metricClientError4XXCountWithDeploymentId(engineName, appDescription, deploymentId, errorBody, String.valueOf(response.statusCode().value()), shortenUrl);
        } else if (response.statusCode().is5xxServerError()) {
            metricClientError5XXCountWithDeploymentId(engineName, appDescription, deploymentId, errorBody, String.valueOf(response.statusCode().value()), shortenUrl);
        } else {
            String errorMessage = errorBody != null ? errorBody : "Unknown error occurred";
            metricNetworkErrorCountWithDeploymentId(engineName, appDescription, deploymentId, errorMessage, String.valueOf(response.statusCode().value()), shortenUrl);
        }
    }

    public String getShortenUrl(String url) {
        if (url != null && url.contains("?")){
            return url.substring(0, url.indexOf("?"));
        }
        return url;
    }
}