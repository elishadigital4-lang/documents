package com.pes.integration.cerner.component;


import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.FilterDataService;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.MessageControlIdGenerator;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;

/**
 * This class is responsible for carrying out common operations specific to all Cerner Handlers
 *
 * @author prak.rai
 */

@Slf4j
@Service
public class HandlerHelper {

    @Autowired
    CernerApiCaller cernerApiCaller;

    public String getActivePatient(String patientId, Object inputObject,String deploymentId) throws IHubException {
        JSONObject patientObject = new JSONObject();
        setValue(patientObject, DocASAPConstants.TempKey.PATIENT_ID, patientId);
        JSONObject responseObject = new JSONObject();
        String newPatientId = "";
        try {
            responseObject= cernerApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), patientObject, "getActivePatient");
            if(responseObject.has("Active") && !responseObject.getBoolean("Active")){
                JSONArray patient = responseObject.getJSONArray("ActivePatient");
                for (Object patientObj: patient) {
                    JSONObject patientJson = (JSONObject)patientObj;
                    if (patientJson.has("Type") && "replace".equalsIgnoreCase(patientJson.getString("Type"))) {
                        newPatientId = patientJson.getString("Id");
                        newPatientId = newPatientId.substring(8);
                        log.info("newPatientId "+newPatientId);
                        JsonUtils.setValue(inputObject, Key.PATIENT_ID, "Patient/"+newPatientId);
                    }
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return newPatientId;
    }

    public void buildMergePatientMsg(String newPatientId, String oldPatientId, Object inputObject) throws IHubException {
        setValue(inputObject, Key.PATIENT_ID, newPatientId);
        setValue(inputObject, Key.PRIOR_PATIENT_ID, oldPatientId);
        setValue(inputObject, "SchedulingData", null);
        String messageControlId = MessageControlIdGenerator.generateMessageControlId();
        setValue(inputObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, messageControlId);
        setValue(inputObject, UtilitiesConstants.JsonConstants.MESSAGE_TYPE, HandlerType.MERGE_PATIENTS.getKey());
    }
}
