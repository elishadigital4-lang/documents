package com.pes.integration.cerner.api;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class CernerApiTest {
    @InjectMocks
    private CernerApi cernerApi;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    public void testNoArgsConstructor() {
        CernerApi cernerApi = new CernerApi();
        assertNotNull(cernerApi);
    }

    @Test
    public void testAllArgsConstructor() {
        CernerApi cernerApi = new CernerApi("key", "secret", "deploymentId", "baseUrl", "tokenUrl", "clientId", "fhirTenantId");
        assertEquals("key", cernerApi.getKey());
        assertEquals("secret", cernerApi.getSecret());
        assertEquals("deploymentId", cernerApi.getDeploymentId());
        assertEquals("baseUrl", cernerApi.getBaseUrl());
        assertEquals("tokenUrl", cernerApi.getTokenUrl());
        assertEquals("clientId", cernerApi.getClientId());
        assertEquals("fhirTenantId", cernerApi.getFhirTenantId());
    }

    @Test
    public void testSettersAndGetters() {
        CernerApi cernerApi = new CernerApi();
        cernerApi.setKey("key");
        cernerApi.setSecret("secret");
        cernerApi.setDeploymentId("deploymentId");
        cernerApi.setBaseUrl("baseUrl");
        cernerApi.setTokenUrl("tokenUrl");
        cernerApi.setClientId("clientId");
        cernerApi.setFhirTenantId("fhirTenantId");

        assertEquals("key", cernerApi.getKey());
        assertEquals("secret", cernerApi.getSecret());
        assertEquals("deploymentId", cernerApi.getDeploymentId());
        assertEquals("baseUrl", cernerApi.getBaseUrl());
        assertEquals("tokenUrl", cernerApi.getTokenUrl());
        assertEquals("clientId", cernerApi.getClientId());
        assertEquals("fhirTenantId", cernerApi.getFhirTenantId());
    }
}
