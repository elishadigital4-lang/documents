package com.pes.integration.cerner.api;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ApiNameTest {
    @Test
    public void testGetKey() {
        assertEquals("patient_search", ApiName.GET_PATIENT.getKey());
        assertEquals("new_patient", ApiName.NEW_PATIENT.getKey());
        assertEquals("get_patient_demographics", ApiName.GET_PATIENT_DEMOGRAPHICS.getKey());
        assertEquals("update_patient", ApiName.UPDATE_PATIENT.getKey());
        assertEquals("new_appointment", ApiName.NEW_APPOINTMENT.getKey());
        assertEquals("cancel_appointment", ApiName.CANCEL_APPOINTMENT.getKey());
        assertEquals("reschedule_appointment", ApiName.RESCHEDULE_APPOINTMENT.getKey());
        assertEquals("open_appointments", ApiName.OPEN_APPOINTMENTS.getKey());
        assertEquals("booked_appointments", ApiName.BOOKED_APPOINTMENTS.getKey());
        assertEquals("changed_appointments", ApiName.CHANGED_APPOINTMENTS.getKey());
        assertEquals("get_appointment", ApiName.GET_APPOINTMENT.getKey());
        assertEquals("get_practices", ApiName.GET_PRACTICES.getKey());
    }

    @Test
    public void testGetEnum() {
        assertEquals(ApiName.GET_PATIENT, ApiName.GET_PATIENT.getEnum("patient_search"));
        assertEquals(ApiName.NEW_PATIENT, ApiName.NEW_PATIENT.getEnum("new_patient"));
        assertEquals(ApiName.GET_PATIENT_DEMOGRAPHICS, ApiName.GET_PATIENT_DEMOGRAPHICS.getEnum("get_patient_demographics"));
        assertEquals(ApiName.UPDATE_PATIENT, ApiName.UPDATE_PATIENT.getEnum("update_patient"));
        assertEquals(ApiName.NEW_APPOINTMENT, ApiName.NEW_APPOINTMENT.getEnum("new_appointment"));
        assertEquals(ApiName.CANCEL_APPOINTMENT, ApiName.CANCEL_APPOINTMENT.getEnum("cancel_appointment"));
        assertEquals(ApiName.RESCHEDULE_APPOINTMENT, ApiName.RESCHEDULE_APPOINTMENT.getEnum("reschedule_appointment"));
        assertEquals(ApiName.OPEN_APPOINTMENTS, ApiName.OPEN_APPOINTMENTS.getEnum("open_appointments"));
        assertEquals(ApiName.BOOKED_APPOINTMENTS, ApiName.BOOKED_APPOINTMENTS.getEnum("booked_appointments"));
        assertEquals(ApiName.CHANGED_APPOINTMENTS, ApiName.CHANGED_APPOINTMENTS.getEnum("changed_appointments"));
        assertEquals(ApiName.GET_APPOINTMENT, ApiName.GET_APPOINTMENT.getEnum("get_appointment"));
        assertEquals(ApiName.GET_PRACTICES, ApiName.GET_PRACTICES.getEnum("get_practices"));
        assertNull(ApiName.GET_PATIENT.getEnum("non_existent_key"));
    }

    @Test
    public void testConstructor() {
        ApiName apiName = ApiName.GET_PATIENT;
        assertEquals("patient_search", apiName.getKey());
    }

}
