package com.pes.integration.cerner.component;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.json.JSONArray;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Test;

import static com.pes.integration.TestUtils.TestUtils.getData;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class HandlerHelperTest {
    @Mock
    private CernerApiCaller cernerApiCaller;
    @InjectMocks
    private HandlerHelper handlerHelper;
    private String deploymentId;
    private String patientId;
    private Object inputObject;

    @BeforeEach
    public void setUp() {
        deploymentId = "74415^0001";
        patientId = "pat456";
        inputObject = new JSONObject();
    }

    @Test
    public void testGetActivePatient_ActivePatient() throws Exception {
        JSONObject inputObject = getData("getPatientDemographics.json");
        JSONObject responseObject = new JSONObject();
        responseObject.put("Active", false);
        JSONArray activePatients = new JSONArray();
        JSONObject patientJson = new JSONObject();
        patientJson.put("Type", "replace");
        patientJson.put("Id", "12345678newId");
        activePatients.put(patientJson);
        responseObject.put("ActivePatient", activePatients);

        when(cernerApiCaller.call(eq(deploymentId), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()),any(JSONObject.class), eq("getActivePatient"))).thenReturn(responseObject);

        String newPatientId = handlerHelper.getActivePatient(patientId, inputObject, deploymentId);

        assertEquals("newId", newPatientId);
        assertEquals("Patient/newId", getValue(inputObject, DocASAPConstants.Key.PATIENT_ID));
    }

    @Test
    public void testGetActivePatient_NoActivePatient() throws Exception {
        JSONObject responseObject = new JSONObject();
        responseObject.put("Active", true);

        when(cernerApiCaller.call(eq(deploymentId), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()),any(JSONObject.class), eq("getActivePatient"))).thenReturn(responseObject);

        String newPatientId = handlerHelper.getActivePatient(patientId, inputObject, deploymentId);

        assertEquals("", newPatientId);
    }
    @Test
    public void testGetActivePatient_NoType() throws Exception {
        JSONObject inputObject = getData("getPatientDemographics.json");
        JSONObject responseObject = new JSONObject();
        responseObject.put("Active", false);
        JSONArray activePatients = new JSONArray();
        JSONObject patientJson = new JSONObject();
        patientJson.put("Id", "12345678newId");
        activePatients.put(patientJson);
        responseObject.put("ActivePatient", activePatients);
        when(cernerApiCaller.call(eq(deploymentId), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()),any(JSONObject.class), eq("getActivePatient"))).thenReturn(responseObject);

        String newPatientId = handlerHelper.getActivePatient(patientId, inputObject, deploymentId);

        assertEquals("", newPatientId);
    }

    @Test
    public void testGetActivePatient_Exception() throws Exception {
        when(cernerApiCaller.call(eq(deploymentId), any(), any(), any())).thenThrow(new RuntimeException("Error"));

        String newPatientId = handlerHelper.getActivePatient(patientId, inputObject, deploymentId);

        assertEquals("", newPatientId);
    }

    @Test
    public void testBuildMergePatientMsg() throws IHubException {
        String newPatientId = "newPatientId";
        String oldPatientId = "oldPatientId";
        inputObject= getData("getPatientDemographics.json");

        handlerHelper.buildMergePatientMsg(newPatientId, oldPatientId, inputObject);

        assertEquals(newPatientId, getValue(inputObject, DocASAPConstants.Key.PATIENT_ID));
        assertEquals(oldPatientId, getValue(inputObject, DocASAPConstants.Key.PRIOR_PATIENT_ID));
        assertNull(((JSONObject) inputObject).opt("SchedulingData"));
        assertNotNull(getValue(inputObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID));
        assertEquals(HandlerType.MERGE_PATIENTS.getKey(), getValue(inputObject, UtilitiesConstants.JsonConstants.MESSAGE_TYPE));
    }
}
