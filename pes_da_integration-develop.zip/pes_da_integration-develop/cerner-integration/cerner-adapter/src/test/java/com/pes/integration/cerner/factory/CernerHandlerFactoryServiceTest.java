package com.pes.integration.cerner.factory;

import com.pes.integration.enums.HandlerType;
import com.pes.integration.handlers.BaseHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CernerHandlerFactoryServiceTest {
    @Mock
    private Map<String, BaseHandler> handlerMap;

    @InjectMocks
    private CernerHandlerFactoryService cernerHandlerFactoryService;

    @BeforeEach
    void setUp() {
        handlerMap = new HashMap<>();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateHandler() {
        HandlerType handlerType = HandlerType.NEW_PATIENT;
        BaseHandler baseHandler = mock(BaseHandler.class);

        lenient().when(handlerMap.get(eq("NewPatient"))).thenReturn(baseHandler);
        BaseHandler actualHandler = cernerHandlerFactoryService.create(handlerType, new Object(), new Object());
        assertNull(actualHandler);
    }
    @Test
    void testCreate_NullHandlerType_ThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () ->
                cernerHandlerFactoryService.create(null, new Object(), new Object())
        );
    }
}
