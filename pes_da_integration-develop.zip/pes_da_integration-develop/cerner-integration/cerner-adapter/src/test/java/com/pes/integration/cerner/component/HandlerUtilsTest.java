package com.pes.integration.cerner.component;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.FilterDataService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.text.ParseException;
import java.util.Optional;

import static com.pes.integration.cerner.constant.CernerConstants.PHONE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class HandlerUtilsTest {
    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private FilterDataService filterDataService;

    @Mock
    private CernerApiCaller cernerApiCaller;

    @InjectMocks
    private HandlerUtils handlerUtils;
    @Test
    public void testUpdateE2DPhones_PhoneTypeObjNull() throws IHubException {
        Object outputObject = new JSONObject();
        Object result = HandlerUtils.updateE2DPhones(outputObject);
        assertEquals(outputObject, result);
    }

    @Test
    public void testUpdateE2DPhones_PhoneTypeObjEmpty() throws IHubException {
        Object outputObject = new JSONObject();
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", new JSONObject());
        Object result = HandlerUtils.updateE2DPhones(outputObject);
        assertEquals(outputObject, result);
    }

    @Test
    public void testUpdateE2DPhones_HasPhones() throws IHubException {
        Object outputObject = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("Phones", new JSONArray());
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", patientInfo);
        Object result = HandlerUtils.updateE2DPhones(outputObject);
        assertEquals(outputObject, result);
    }

    @Test
    public void testUpdateE2DPhones_PhoneArrayEmpty() throws IHubException {
        Object outputObject = new JSONObject();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("Phones", new JSONArray());
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", patientInfo);
        Object result = HandlerUtils.updateE2DPhones(outputObject);
        assertEquals(outputObject, result);
    }

    @Test
    public void testUpdateE2DPhones_SystemEqualsPhone() throws IHubException {
        Object outputObject = new JSONObject();
        JSONObject phone = new JSONObject();
        phone.put("PhoneType", CernerConstants.CELL_PHONE_TYPE_VALUE);
        phone.put("Number", "1234567890");
        phone.put("System", PHONE);
        JSONArray phoneArray = new JSONArray();
        phoneArray.put(phone);
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("Phones", phoneArray);
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", patientInfo);
        Object result = HandlerUtils.updateE2DPhones(outputObject);
        assertEquals("1234567890", JsonUtils.getValue(result, DocASAPConstants.Key.MOBILE_PHONE));
    }

    @Test
    public void testUpdateE2DPhones_SystemNotEqualsPhone() throws IHubException {
        Object outputObject = new JSONObject();
        JSONObject phone = new JSONObject();
        phone.put("PhoneType", CernerConstants.CELL_PHONE_TYPE_VALUE);
        phone.put("Number", "1234567890");
        phone.put("System", "EMAIL");
        JSONArray phoneArray = new JSONArray();
        phoneArray.put(phone);
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("Phones", phoneArray);
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", patientInfo);
        Object result = HandlerUtils.updateE2DPhones(outputObject);
        assertNull(JsonUtils.getValue(outputObject, DocASAPConstants.Key.MOBILE_PHONE));
    }

    @Test
    public void testUpdateE2DPhones_PhoneTypes() throws IHubException {
        Object outputObject = new JSONObject();
        JSONArray phoneArray = new JSONArray();

        JSONObject cellPhone = new JSONObject();
        cellPhone.put("PhoneType", CernerConstants.CELL_PHONE_TYPE_VALUE);
        cellPhone.put("Number", "1234567890");
        cellPhone.put("System", PHONE);
        phoneArray.put(cellPhone);

        JSONObject workPhone = new JSONObject();
        workPhone.put("PhoneType", CernerConstants.WORK_PHONE_TYPE_VALUE);
        workPhone.put("Number", "0987654321");
        workPhone.put("System", PHONE);
        phoneArray.put(workPhone);

        JSONObject homePhone = new JSONObject();
        homePhone.put("PhoneType", CernerConstants.HOME_PHONE_TYPE_VALUE);
        homePhone.put("Number", "1122334455");
        homePhone.put("System", PHONE);
        phoneArray.put(homePhone);

        JSONObject patientInfo = new JSONObject();
        patientInfo.put("Phones", phoneArray);
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", patientInfo);
        Object result = HandlerUtils.updateE2DPhones(outputObject);

        assertEquals("1234567890", JsonUtils.getValue(result, DocASAPConstants.Key.MOBILE_PHONE));
        assertEquals("0987654321", JsonUtils.getValue(result, DocASAPConstants.Key.WORK_PHONE));
        assertEquals("1122334455", JsonUtils.getValue(result, DocASAPConstants.Key.HOME_PHONE));
    }

    @Test
    public void testUpdateE2DPhones_EmailArrayLengthGreaterThanOne() throws IHubException, IHubException {
        Object outputObject = new JSONObject();
        JSONArray phoneArray = new JSONArray();

        JSONObject email1 = new JSONObject();
        email1.put("PhoneType", CernerConstants.HOME_PHONE_TYPE_VALUE);
        email1.put("Number", "email1@example.com");
        email1.put("System", "email");
        phoneArray.put(email1);

        JSONObject email2 = new JSONObject();
        email2.put("PhoneType", CernerConstants.HOME_PHONE_TYPE_VALUE);
        email2.put("Number", "email2@example.com");
        email2.put("System", "email");
        phoneArray.put(email2);

        JSONObject patientInfo = new JSONObject();
        patientInfo.put("Phones", phoneArray);
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", patientInfo);
        Object result = HandlerUtils.updateE2DPhones(outputObject);

        assertEquals("email2@example.com", JsonUtils.getValue(outputObject, DocASAPConstants.Key.EMAIL));
        JSONArray emailList = (JSONArray) JsonUtils.getValue(outputObject, "DemographicData.PatientInformation[0].EmailList");
        assertNotNull(emailList);
        assertEquals(2, emailList.length());
    }

    @Test
    public void testUpdateE2DPhones_EmailArrayLengthNotGreaterThanOne() throws IHubException {
        Object outputObject = new JSONObject();
        JSONArray phoneArray = new JSONArray();

        JSONObject email = new JSONObject();
        email.put("PhoneType", CernerConstants.HOME_PHONE_TYPE_VALUE);
        email.put("Number", "email@example.com");
        email.put("System", "email");
        phoneArray.put(email);

        JSONObject patientInfo = new JSONObject();
        patientInfo.put("Phones", phoneArray);
        JsonUtils.setValue(outputObject, "DemographicData.PatientInformation[0]", patientInfo);
        Object result = HandlerUtils.updateE2DPhones(outputObject);

        assertEquals("email@example.com", JsonUtils.getValue(outputObject, DocASAPConstants.Key.EMAIL));
        assertNull(JsonUtils.getValue(outputObject, "DemographicData.PatientInformation[0].EmailList"));
    }


    @Test
    public void testGetId_ValidUrl() {
        String idUrl = "http://example.com/resource/12345";
        String expected = "12345";
        String actual = HandlerUtils.getId(idUrl);
        assertEquals(expected, actual);
    }

    @Test
    public void testGetCernerTimeZone_Valid() throws Exception {
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("America/New_York");

        String timeZone = handlerUtils.getCernerTimeZone();
        assertEquals("America/New_York", timeZone);
    }

    @Test
    public void testGetCernerTimeZone_Exception() throws Exception {
        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        String timeZone = handlerUtils.getCernerTimeZone();
        assertNull(timeZone);
    }

    @Test
    public void testGetClientTimeZone_Valid() throws Exception {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("America/Los_Angeles");

        String timeZone = handlerUtils.getClientTimeZone("deploymentId");
        assertEquals("America/Los_Angeles", timeZone);
    }

    @Test
    public void testGetClientTimeZone_Exception() throws Exception {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        String timeZone = handlerUtils.getClientTimeZone("deploymentId");
        assertNull(timeZone);
    }

    @Test
    public void testGetAppointmentTypeId_Valid() throws Exception {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("appointmentTypeId");
        String appointmentTypeId = handlerUtils.getAppointmentTypeId("deploymentId");
        assertEquals("appointmentTypeId", appointmentTypeId);
    }

    @Test
    public void testGetAppointmentTypeId_Exception() throws Exception {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Error"));

        String appointmentTypeId = handlerUtils.getAppointmentTypeId("deploymentId");
        assertNull(appointmentTypeId);
    }

    @Test
    public void testConvertDateFormat_Valid() throws ParseException {
        String originalDate = "2023-10-01";
        String oldFormat = "yyyy-MM-dd";
        String newFormat = "MM/dd/yyyy";
        String cernerTimeZone = "UTC";
        String clientTimeZone = "America/New_York";

        String expected = "09/30/2023";
        String actual = HandlerUtils.convertDateFormat(originalDate, oldFormat, newFormat, cernerTimeZone, clientTimeZone);
        assertEquals(expected, actual);
    }

    @Test
    public void testConvertDateFormat_ParseException() {
        String originalDate = "invalid-date";
        String oldFormat = "yyyy-MM-dd";
        String newFormat = "MM/dd/yyyy";
        String cernerTimeZone = "UTC";
        String clientTimeZone = "America/New_York";

        assertThrows(ParseException.class, () -> {
            HandlerUtils.convertDateFormat(originalDate, oldFormat, newFormat, cernerTimeZone, clientTimeZone);
        });
    }
}
