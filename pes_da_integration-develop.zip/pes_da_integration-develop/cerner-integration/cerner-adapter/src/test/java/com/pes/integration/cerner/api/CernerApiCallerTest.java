package com.pes.integration.cerner.api;

import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.cerner.component.CernerClientCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.cerner.dto.Token;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.pes.integration.cerner.constant.CernerEngineConstants.*;
import static java.util.Base64.getEncoder;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;

@ExtendWith(MockitoExtension.class)
class CernerApiCallerTest {
    @InjectMocks
    private CernerApiCaller cernerApiCaller;
    @Mock
    CernerClientCaller cernerClientCaller;

    @Mock
    DataCacheManager cacheManager;

    @Mock
    RedisService redisService;

    private static final Map<String, CernerApi> apiMap = new HashMap<>();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetCernerApiNullCernerApi() throws Exception {
        String deploymentId = "74415^0001";
        Field apiMapField = CernerApiCaller.class.getDeclaredField("apiMap");
        apiMapField.setAccessible(true);
        Map<String, CernerApi> apiMap = new HashMap<>();
        apiMap.put(deploymentId, null);
        apiMapField.set(null, apiMap);

        when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq("74415^0001"), eq(CERNER_CONFIG),
                eq(CLIENT_ID), eq(false))).thenReturn("clientId");
        when(cacheManager.getStoredProvidersConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq("74415^0001"),
                eq(CernerEngineConstants.CERNER_CONFIG), eq(CernerEngineConstants.CLIENT_SECRET), eq(false))).thenReturn("secret");
        when(cacheManager.getStoredProvidersConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq("74415^0001"),
                eq(CernerEngineConstants.CERNER_CONFIG), eq(CernerEngineConstants.TOKEN_URL), eq(false))).thenReturn("tokenURL");
        when(cacheManager.getStoredProvidersConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq("74415^0001"),
                eq(CernerEngineConstants.CERNER_CONFIG), eq(CernerConstants.BASE_URL), eq(false))).thenReturn("baseURL");
        when(cacheManager.getStoredProvidersConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq("74415^0001"),
                eq(CernerEngineConstants.CERNER_CONFIG), eq(CernerEngineConstants.FHIR_TENANT_ID), eq(false))).thenReturn("fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("getCernerApi", String.class);
        method.setAccessible(true);
        CernerApi result = (CernerApi) method.invoke(cernerApiCaller, deploymentId);

        assertEquals(apiMap.getOrDefault(deploymentId, null), result);
    }

    @Test
    void testGetCernerApi_NotNullCernerApi() throws Exception {
        String deploymentId = "74415^0001";

        CernerApi expectedApi = new CernerApi("clientId", "secret", deploymentId, "baseURLfhirTenantId", "tokenURL", "clientId", "fhirTenantId");

        Field apiMapField = CernerApiCaller.class.getDeclaredField("apiMap");
        apiMapField.setAccessible(true);
        Map<String, CernerApi> apiMap = new HashMap<>();
        apiMap.put(deploymentId, expectedApi);
        apiMapField.set(null, apiMap);

        Method method = CernerApiCaller.class.getDeclaredMethod("getCernerApi", String.class);
        method.setAccessible(true);
        CernerApi result = (CernerApi) method.invoke(cernerApiCaller, deploymentId);

        assertEquals(expectedApi, result);
    }

    @Test
    void testApiCaller_ValidDeploymentId() throws IHubException {
        String deploymentId = "74415^0001";
        when(cacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn("clientId", "secret", "tokenUrl", "baseUrl", "fhirTenantId");

        CernerApi result = cernerApiCaller.apiCaller(deploymentId);

        assertNotNull(result);
        assertEquals("clientId", result.getKey());
        assertEquals("secret", result.getSecret());
        assertEquals("baseUrlfhirTenantId", result.getBaseUrl());
        assertEquals("tokenUrl", result.getTokenUrl());
    }

    @Test
    void testApiCaller_EmptyClientId() throws IHubException, NoSuchFieldException, IllegalAccessException {
        String deploymentId = "74415^0001";

        Field apiMapField = CernerApiCaller.class.getDeclaredField("apiMap");
        apiMapField.setAccessible(true);
        Map<String, CernerApi> apiMap = new HashMap<>();
        apiMap.put(deploymentId, null);
        apiMapField.set(null, apiMap);

        when(cacheManager.getStoredProvidersConfig(eq(EPM_NAME_PREFIX), eq("74415^0001"), eq(CERNER_CONFIG),
                eq(CLIENT_ID), eq(false))).thenReturn(null);
        when(cacheManager.getStoredComponentConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq(CernerEngineConstants.CERNER_CONFIG),
                eq(CernerEngineConstants.CLIENT_ID), eq(false))).thenReturn("key");
        when(cacheManager.getStoredComponentConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq(CernerEngineConstants.CERNER_CONFIG),
                eq(CernerEngineConstants.CLIENT_SECRET), eq(false))).thenReturn("secret");
        when(cacheManager.getStoredComponentConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq(CernerEngineConstants.CERNER_CONFIG),
                eq(CernerEngineConstants.TOKEN_URL), eq(false))).thenReturn("tokenURL");
        when(cacheManager.getStoredComponentConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq(CernerEngineConstants.CERNER_CONFIG),
                eq(CernerConstants.BASE_URL), eq(false))).thenReturn("baseURL");
        when(cacheManager.getStoredProvidersConfig(eq(CernerEngineConstants.EPM_NAME_PREFIX), eq("74415^0001"),
                eq(CernerEngineConstants.CERNER_CONFIG), eq(CernerEngineConstants.FHIR_TENANT_ID), eq(false))).thenReturn("fhirTenantId");


        CernerApi result = cernerApiCaller.apiCaller(deploymentId);

        assertNotNull(result);
        assertEquals("key", result.getKey());
        assertEquals("secret", result.getSecret());
        assertEquals("baseURLfhirTenantId", result.getBaseUrl());
        assertEquals("tokenURL", result.getTokenUrl());
        assertEquals(apiMap.getOrDefault(deploymentId, null), result);
    }

    @Test
    void testApiCaller_Exception() throws IHubException {
        String deploymentId = "xyz";
        when(cacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("500"), "Error"));

        assertThrows(IHubException.class, () -> cernerApiCaller.apiCaller(deploymentId));
    }

    @Test
    void testGetMappingConfig() throws Exception {
        String deploymentId = "74415^0001";

        JSONObject requestConfigMock = new JSONObject();
        requestConfigMock.put("key", "value");
        lenient().when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(CERNER_CONFIG), eq(REQUEST_CONFIG_KEY_NAME), eq(false)))
                .thenReturn(requestConfigMock);

        JSONObject requestMappingMock = new JSONObject();
        requestMappingMock.put("key", "value");
        lenient().when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(CERNER_CONFIG), eq(REQUEST_MAPPING_KEY_NAME), eq(false)))
                .thenReturn(requestMappingMock);

        JSONObject responseMappingMock = new JSONObject();
        responseMappingMock.put("key", "value");
        lenient().when(cacheManager.getStoredComponentConfig(eq(EPM_NAME_PREFIX), eq(CERNER_CONFIG), eq(RESPONSE_MAPPING_KEY_NAME), eq(false)))
                .thenReturn(responseMappingMock);

        Method method = CernerApiCaller.class.getDeclaredMethod("getMappingConfig", String.class);
        method.setAccessible(true);
        method.invoke(cernerApiCaller, deploymentId);

        Field requestConfigField = BaseApiCaller.class.getDeclaredField("requestConfig");
        requestConfigField.setAccessible(true);
        JSONObject requestConfig = (JSONObject) requestConfigField.get(cernerApiCaller);
        assertNull(requestConfig);

        Field requestMappingField = BaseApiCaller.class.getDeclaredField("requestMapping");
        requestMappingField.setAccessible(true);
        JSONObject requestMapping = (JSONObject) requestMappingField.get(cernerApiCaller);
        assertNull(requestMapping);

        Field responseMappingField = BaseApiCaller.class.getDeclaredField("responseMapping");
        responseMappingField.setAccessible(true);
        JSONObject responseMapping = (JSONObject) responseMappingField.get(cernerApiCaller);
        assertNull(responseMapping);
    }

    @Test
    void testCustomizeResponseMapping() throws Exception {
        JSONObject apiResponseMapping = new JSONObject();
        String apiName = "testApi";
        Object inputObject = new Object();

        Method method = CernerApiCaller.class.getDeclaredMethod("customizeResponseMapping", JSONObject.class, String.class, Object.class);
        method.setAccessible(true);
        JSONObject result = (JSONObject) method.invoke(cernerApiCaller, apiResponseMapping, apiName, inputObject);

        assertNull(result);
    }

    @Test
    void testCallApi() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put("method", "GET");
        apiConfig.put("url", "http://example.com");
        JSONObject requestObject = new JSONObject();
        requestObject.put("deployment_id", "74415^0001");
        CernerApi cernerApi = new CernerApi();
        cernerApi.setTokenUrl("http://tokenurl");
        cernerApi.setFhirTenantId("fhirTenantId");
        apiMap.put("74415^0001", cernerApi);
        Method method = CernerApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);
        lenient().when(cacheManager.getStoredProvidersConfig(any(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("test");
        Token token = new Token();
        token.setAccessToken("token");
        when(cernerClientCaller.generateToken(any(), any())).thenReturn(token);
        doNothing().when(redisService).saveWithTtl(any(), any(),
                anyInt());
        Object result = method.invoke(cernerApiCaller, apiConfig, requestObject);

        assertNotNull(result);
    }

    @Test
    void testCallApiWithPagination() throws Exception {
        String deploymentId = "74415^0001";
        String method = "GET";
        String url = "http://baseurl/resource";
        String token = "mockAccessToken";
        String responseString = "{\"link\":[{\"relation\":\"next\",\"url\":\"http://baseurl/resource?page=2\"}],\"data\":[{\"id\":\"1\"}]}";
        String nextPageResponseString = "{\"data\":[{\"id\":\"2\"}]}";

        JSONObject apiConfig = new JSONObject();
        apiConfig.put("url", url);
        apiConfig.put("method", method);

        JSONObject requestObject = new JSONObject();
        requestObject.put("version", "1.0");
        requestObject.put("deployment_id", deploymentId);
        when(redisService.get("cerner_token_" + deploymentId)).thenReturn(token);
        lenient().when(cernerClientCaller.getData(eq(method), eq(url), anyString(), eq(token), any(HttpHeaders.class), anyString()))
                .thenReturn(responseString);
        lenient().when(cernerClientCaller.getData(eq(method), eq("http://baseurl/resource?page=2"), anyString(), eq(token), any(HttpHeaders.class), anyString()))
                .thenReturn(nextPageResponseString);

        Method methodToTest = CernerApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        methodToTest.setAccessible(true);
        JSONObject result = (JSONObject) methodToTest.invoke(cernerApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertFalse(result.has("data"));
    }

    @Test
    void testCallApiWithNonJsonResponse() throws Exception {
        String deploymentId = "74415^0001";
        String method = "GET";
        String url = "http://baseurl/resource";
        String token = "mockAccessToken";
        String responseString = "Non-JSON response";

        JSONObject apiConfig = new JSONObject();
        apiConfig.put("url", url);
        apiConfig.put("method", method);

        JSONObject requestObject = new JSONObject();
        requestObject.put("version", "1.0");
        requestObject.put("deployment_id", deploymentId);
        when(redisService.get("cerner_token_" + deploymentId)).thenReturn(token);
        lenient().when(cernerClientCaller.getData(eq(method), eq(url), anyString(), eq(token), any(HttpHeaders.class), anyString()))
                .thenReturn(responseString);

        Method methodToTest = CernerApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        methodToTest.setAccessible(true);
        JSONObject result = (JSONObject) methodToTest.invoke(cernerApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertFalse(result.has("detail"));
    }

    @Test
    void buildUrl_withCountKey_doesNotReplaceUnderscore() throws Exception {
        String endPoint = "/api/resource?param_count=value";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("param_count", "value");
        CernerApi cernerApi = new CernerApi("key", "secret", "74415^0001", "http://example.com", "http://tokenurl", "clientId", "fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("buildUrl", String.class, Map.class, CernerApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, endPoint, parameters, cernerApi);

        assertNotNull(result);
        assertEquals("http://example.com/api/resource?param.count=value", result);
    }

    @Test
    void buildUrl_withMultipleParameters_appendsCorrectly() throws Exception {
        String endPoint = "/api/resource?param1=value1&param2=value2";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("param1", "value1");
        parameters.put("param2", "value2");
        CernerApi cernerApi = new CernerApi("key", "secret", "74415^0001", "http://example.com", "http://tokenurl", "clientId", "fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("buildUrl", String.class, Map.class, CernerApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, endPoint, parameters, cernerApi);

        assertNotNull(result);
        assertEquals("http://example.com/api/resource?param1=value1&param2=value2", result);
    }

    @Test
    void buildUrl_withNoParameters_returnsOriginalUrl() throws Exception {
        String endPoint = "/api/resource";
        Map<String, String> parameters = new HashMap<>();
        CernerApi cernerApi = new CernerApi("key", "secret", "74415^0001", "http://example.com", "http://tokenurl", "clientId", "fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("buildUrl", String.class, Map.class, CernerApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, endPoint, parameters, cernerApi);

        assertNotNull(result);
        assertEquals("http://example.com/api/resource", result);
    }

    @Test
    void testGetNextUrl_HasLinkAndRelationNext() throws Exception {
        JSONObject responseObject = new JSONObject();
        JSONArray linkArray = new JSONArray();
        JSONObject linkJson = new JSONObject();
        linkJson.put("relation", CernerConstants.NEXT);
        linkJson.put("url", "http://example.com/next");
        linkArray.put(linkJson);
        responseObject.put("link", linkArray);

        Method method = CernerApiCaller.class.getDeclaredMethod("getNextUrl", JSONObject.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, responseObject);

        assertEquals("http://example.com/next", result);
    }

    @Test
    void testGetNextUrl_NoLink() throws Exception {
        JSONObject responseObject = new JSONObject();

        Method method = CernerApiCaller.class.getDeclaredMethod("getNextUrl", JSONObject.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, responseObject);

        assertEquals("", result);
    }

    @Test
    void testGetNextUrl_LinkNoRelation() throws Exception {
        JSONObject responseObject = new JSONObject();
        JSONArray linkArray = new JSONArray();
        JSONObject linkJson = new JSONObject();
        linkJson.put("url", "http://example.com/next");
        linkArray.put(linkJson);
        responseObject.put("link", linkArray);

        Method method = CernerApiCaller.class.getDeclaredMethod("getNextUrl", JSONObject.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, responseObject);

        assertEquals("", result);
    }

    @Test
    void testGetNextUrl_LinkRelationNotNext() throws Exception {
        JSONObject responseObject = new JSONObject();
        JSONArray linkArray = new JSONArray();
        JSONObject linkJson = new JSONObject();
        linkJson.put("relation", "prev");
        linkJson.put("url", "http://example.com/prev");
        linkArray.put(linkJson);
        responseObject.put("link", linkArray);

        Method method = CernerApiCaller.class.getDeclaredMethod("getNextUrl", JSONObject.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, responseObject);

        assertEquals("", result);
    }

    @Test
    void testBuildUrl2() throws Exception {
        String endPoint = "/api/:param1/resource";
        Map<String, String> parameters = new HashMap<>();
        parameters.put(":param1", "value1");
        CernerApi cernerApi = new CernerApi("key", "secret", "74415^0001", "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("buildUrl", String.class, Map.class, CernerApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, endPoint, parameters, cernerApi);

        assertNotNull(result);
        assertEquals("http://baseurl/api/value1/resource", result);
    }

    @Test
    void testBuildUrl2with() throws Exception {
        String endPoint = "/api/:param1/resource";
        Map<String, String> parameters = new HashMap<>();
        parameters.put(":param1", "value?");
        CernerApi cernerApi = new CernerApi("key", "secret", "74415^0001", "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("buildUrl", String.class, Map.class, CernerApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, endPoint, parameters, cernerApi);

        assertNotNull(result);
        assertEquals("http://baseurl/api/value", result);
    }

    @Test
    void testGetToken() throws Exception {
        String deploymentId = "74415^0001";
        CernerApi cernerApi = new CernerApi("key", "secret", deploymentId, "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("getToken", String.class, CernerApi.class);
        method.setAccessible(true);
        Token token = new Token();
        token.setAccessToken("token");
        when(cernerClientCaller.generateToken(any(), any())).thenReturn(token);
        doNothing().when(redisService).saveWithTtl(eq("cerner_token_" + deploymentId), any(),
                anyInt());
        String result = (String) method.invoke(cernerApiCaller, deploymentId, cernerApi);

        assertNotNull(result);
        assertEquals("token", result);
    }

    @Test
    void testGetTokenEmptyToken() throws Exception {
        String deploymentId = "74415^0001";
        CernerApi cernerApi = new CernerApi("key", "secret", deploymentId, "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");

        Token mockToken = new Token();
        mockToken.setAccessToken("mockAccessToken");
        mockToken.setExpiresIn(3600);
        mockToken.setTokenType("Bearer");
        mockToken.setScope("scope");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.set("Authorization", "Basic " + getEncoder().encodeToString("key:secret".getBytes()));
        headers.set("X-B3-TRACEID", MDC.get("X-B3-TraceId"));

        doReturn(mockToken).when(cernerClientCaller).generateToken(eq("http://tokenurlfhirTenantId/protocols/oauth2/profiles/smart-v1/token"), eq(headers));
//        when(redisService.get("cerner_token_" + deploymentId)).thenReturn(null);

        Method method = CernerApiCaller.class.getDeclaredMethod("getToken", String.class, CernerApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, deploymentId, cernerApi);

        assertNotNull(result);
        assertEquals("mockAccessToken", result);
    }

    @Test
    void testGenerateToken() throws Exception {
        String deploymentId = "74415^0001";
        CernerApi cernerApi = new CernerApi("key", "secret", deploymentId, "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");

        Token mockToken = new Token();
        mockToken.setAccessToken("mockAccessToken");
        mockToken.setExpiresIn(3600);
        mockToken.setTokenType("Bearer");
        mockToken.setScope("scope");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.set("Authorization", "Basic " + getEncoder().encodeToString("key:secret".getBytes()));
        headers.set("X-B3-TRACEID", MDC.get("X-B3-TraceId"));
        doReturn(mockToken).when(cernerClientCaller).generateToken(eq("http://tokenurlfhirTenantId/protocols/oauth2/profiles/smart-v1/token"), eq(headers));

        Method method = CernerApiCaller.class.getDeclaredMethod("generateToken", String.class, CernerApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(cernerApiCaller, deploymentId, cernerApi);

        assertNotNull(result);
        assertEquals("mockAccessToken", result);
    }

    @Test
    void testGetHttpHeaders() throws Exception {
        CernerApi cernerApi = new CernerApi("key", "secret", "74415^0001", "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");

        Method method = CernerApiCaller.class.getDeclaredMethod("getHttpHeaders", CernerApi.class);
        method.setAccessible(true);
        HttpHeaders result = (HttpHeaders) method.invoke(cernerApiCaller, cernerApi);

        assertNotNull(result);
        assertEquals("application/x-www-form-urlencoded", Objects.requireNonNull(result.getContentType()).toString());
    }

    @Test
    void testGetHeaders() throws Exception {
        JSONObject requestObject = new JSONObject();
        requestObject.put("value", "cancelled");
        String readHeader = "true";

        Method method = CernerApiCaller.class.getDeclaredMethod("getHeaders", JSONObject.class, String.class);
        method.setAccessible(true);
        HttpHeaders result = (HttpHeaders) method.invoke(cernerApiCaller, requestObject, readHeader);

        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals("application/json-patch+json", Objects.requireNonNull(result.getContentType()).toString());
        assertEquals("W/\"0\"", result.getFirst("If-Match"));
    }

    @Test
    void testGetHeadersEmptyVersion() throws Exception {
        JSONObject requestObject = new JSONObject();
        String readHeader = "true";

        Method method = CernerApiCaller.class.getDeclaredMethod("getHeaders", JSONObject.class, String.class);
        method.setAccessible(true);
        HttpHeaders result = (HttpHeaders) method.invoke(cernerApiCaller, requestObject, readHeader);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("application/json+fhir", Objects.requireNonNull(result.getContentType()).toString());
    }

    @Test
    void executeApiCall_patchMethod_withValidPatchCancelRequest_callsGetData() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put("method", "PATCH");
        apiConfig.put("url", "http://example.com");
        JSONObject requestObject = new JSONObject();
        requestObject.put("deployment_id", "74415^0001");
        CernerApi cernerApi = new CernerApi();
        cernerApi.setTokenUrl("http://tokenurl");
        cernerApi.setFhirTenantId("fhirTenantId");
        apiMap.put("74415^0001", cernerApi);
        JSONArray patchCancelRequest = new JSONArray();
        JSONObject patchCancelRequestObject = new JSONObject();
        patchCancelRequestObject.put("field", "value");
        patchCancelRequest.put(patchCancelRequestObject);
        requestObject.put("patchCancelRequest", patchCancelRequest);
        Method method = CernerApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);
        lenient().when(cacheManager.getStoredProvidersConfig(any(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("test");
        Token token = new Token();
        token.setAccessToken("token");
        when(cernerClientCaller.generateToken(any(), any())).thenReturn(token);
        doNothing().when(redisService).saveWithTtl(any(), any(),
                anyInt());
        Object result = method.invoke(cernerApiCaller, apiConfig, requestObject);

        assertNotNull(result);
    }

    @Test
    void executeApiCall_patchMethod_withEmptyPatchCancelRequest_throwsException() throws Exception {
        JSONObject requestObject = new JSONObject();
        JSONArray patchCancelRequest = new JSONArray();
        requestObject.put("patchCancelRequest", patchCancelRequest);

        String method = "PATCH";
        String url = "http://example.com";
        String deploymentId = "74415^0001";
        CernerApi cernerApi = new CernerApi("key", "secret", deploymentId, "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");
        String readHeader = "true";

        Method executeApiCallMethod = CernerApiCaller.class.getDeclaredMethod("executeApiCall", JSONObject.class, String.class, String.class, String.class, CernerApi.class, String.class);
        executeApiCallMethod.setAccessible(true);

        Exception exception = assertThrows(InvocationTargetException.class, () -> executeApiCallMethod.invoke(cernerApiCaller, requestObject, method, url, deploymentId, cernerApi, readHeader));
        assertInstanceOf(IllegalArgumentException.class, exception.getCause());
        assertEquals("patchCancelRequest is empty", exception.getCause().getMessage());
    }

    @Test
    void executeApiCall_patchMethod_withoutPatchCancelRequest_throwsException() throws Exception {
        JSONObject requestObject = new JSONObject();
        String method = "PATCH";
        String url = "http://example.com";
        String deploymentId = "74415^0001";
        CernerApi cernerApi = new CernerApi("key", "secret", deploymentId, "http://baseurl", "http://tokenurl", "clientId", "fhirTenantId");
        String readHeader = "true";

        Method executeApiCallMethod = CernerApiCaller.class.getDeclaredMethod("executeApiCall", JSONObject.class, String.class, String.class, String.class, CernerApi.class, String.class);
        executeApiCallMethod.setAccessible(true);

        Exception exception = assertThrows(InvocationTargetException.class, () -> executeApiCallMethod.invoke(cernerApiCaller, requestObject, method, url, deploymentId, cernerApi, readHeader));
        assertInstanceOf(IllegalArgumentException.class, exception.getCause());
        assertEquals("patchCancelRequest is not present in the request object", exception.getCause().getMessage());
    }
}
