package com.pes.integration.cerner.component;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.List;

import static com.pes.integration.constant.CharacterConstants.BLANK;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class EPMFilterTest {
    @InjectMocks
    private EPMFilter epmFilter;
    @Mock
    private DataCacheManager dataCacheManager;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllowedLocations_HasLocationId() throws Exception {
        JSONArray filterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        filterArray.put(filterObject);

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterArray);

        List<String> result = epmFilter.getAllowedLocations("deployment1");

        assertTrue(result.contains("location1"));
    }

    @Test
    void testGetAllowedLocationsDoesNotHaveLocationId() throws Exception {
        JSONArray filterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterArray.put(filterObject);

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterArray);

        List<String> result = epmFilter.getAllowedLocations("deployment1");

        assertTrue(result.isEmpty());
    }

    @Test
    void testGetAllowedLocations_ExceptionScenario() throws Exception {
        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenThrow(new RuntimeException("Exception"));

        List<String> result = epmFilter.getAllowedLocations("deployment1");

        assertTrue(result.isEmpty());
    }
    @Test
    void testGetAllowedProviders_HasProviderId_AndEquals() throws Exception {
        JSONArray provFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        provFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedProviders", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, provFilterArray, "provider1");

        assertTrue(result);
    }

    @Test
    void testGetAllowedProviders_HasProviderId_AndNotEquals() throws Exception {
        JSONArray provFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        provFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedProviders", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, provFilterArray, "provider2");

        assertFalse(result);
    }

    @Test
    void testGetAllowedProviders_DoesNotHaveProviderId() throws Exception {
        JSONArray provFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        provFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedProviders", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, provFilterArray, "provider1");

        assertFalse(result);
    }

    @Test
    void testGetAllowedProviders_AllowedProviderIdEqualsBlank() throws Exception {
        JSONArray provFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, BLANK);
        provFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedProviders", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, provFilterArray, "provider1");

        assertFalse(result);
    }
    @Test
    void testGetAllowedLocationProviders_HasProviderIdAndLocationId_AndEquals() throws Exception {
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locProvFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locProvFilterArray, "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testGetAllowedLocationProviders_HasProviderIdAndLocationId_AndNotEquals() throws Exception {
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locProvFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locProvFilterArray, "location2", "provider2");

        assertFalse(result);
    }

    @Test
    void testGetAllowedLocationProviders_HasProviderIdAndNotLocationId() throws Exception {
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        locProvFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locProvFilterArray, "location1", "provider1");

        assertFalse(result);
    }

    @Test
    void testGetAllowedLocationProviders_HasLocationIdAndNotProviderId() throws Exception {
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locProvFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locProvFilterArray, "location1", "provider1");

        assertFalse(result);
    }

    @Test
    void testGetAllowedLocationProviders_AllowedProviderIdEqualsBlank() throws Exception {
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, BLANK);
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locProvFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locProvFilterArray, "location1", "provider1");

        assertFalse(result);
    }

    @Test
    void testGetAllowedLocationProviders_AllowedLocationIdEqualsBlank() throws Exception {
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        filterObject.put(UtilitiesConstants.LOCATION_ID, BLANK);
        locProvFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocationProviders", JSONArray.class, String.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locProvFilterArray, "location1", "provider1");

        assertFalse(result);
    }
    @Test
    void testIsAllowed_IHubException() throws Exception {
        Mockito.doThrow(new IHubException(new IHubErrorCode("500"), "Exception")).when(dataCacheManager).getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean());

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_NullFilterObj() throws Exception {
        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(null);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_EmptyFilterObj() throws Exception {
        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(new JSONObject());

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_HasLocationProviderFilter() throws Exception {
        JSONObject filterJson = new JSONObject();
        JSONArray locProvFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        locProvFilterArray.put(filterObject);
        filterJson.put(DocASAPConstants.Key.LOCATION_PROVIDER_FILTER, locProvFilterArray);

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterJson);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_HasProviderFilter() throws Exception {
        JSONObject filterJson = new JSONObject();
        JSONArray provFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.PROVIDER_ID, "provider1");
        provFilterArray.put(filterObject);
        filterJson.put(DocASAPConstants.Key.PROVIDER_FILTER, provFilterArray);

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterJson);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_HasLocationFilter() throws Exception {
        JSONObject filterJson = new JSONObject();
        JSONArray locFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locFilterArray.put(filterObject);
        filterJson.put(DocASAPConstants.Key.LOCATION_FILTER, locFilterArray);

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterJson);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_NoFilters() throws Exception {
        JSONObject filterJson = new JSONObject();

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterJson);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_EmptyLocProvFilterArray() throws Exception {
        JSONObject filterJson = new JSONObject();
        filterJson.put(DocASAPConstants.Key.LOCATION_PROVIDER_FILTER, new JSONArray());

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterJson);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_EmptyProvFilterArray() throws Exception {
        JSONObject filterJson = new JSONObject();
        filterJson.put(DocASAPConstants.Key.PROVIDER_FILTER, new JSONArray());

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterJson);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_EmptyLocFilterArray() throws Exception {
        JSONObject filterJson = new JSONObject();
        filterJson.put(DocASAPConstants.Key.LOCATION_FILTER, new JSONArray());

        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(filterJson);

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }

    @Test
    void testIsAllowed_ExceptionalScenario() throws Exception {
        Mockito.when(dataCacheManager.getStoredProvidersConfig(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenThrow(new RuntimeException("Exception"));

        boolean result = epmFilter.isAllowed("deployment1", "location1", "provider1");

        assertTrue(result);
    }
    @Test
    void testGetAllowedLocations_HasLocationId_AndEquals() throws Exception {
        JSONArray locFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocations", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locFilterArray, "location1");

        assertTrue(result);
    }

    @Test
    void testGetAllowedLocations_HasLocationId_AndNotEquals() throws Exception {
        JSONArray locFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, "location1");
        locFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocations", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locFilterArray, "location2");

        assertFalse(result);
    }

    @Test
    void testGetAllowedLocations_DoesNotHaveLocationId() throws Exception {
        JSONArray locFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        locFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocations", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locFilterArray, "location1");

        assertFalse(result);
    }

    @Test
    void testGetAllowedLocations_AllowedLocationIdEqualsBlank() throws Exception {
        JSONArray locFilterArray = new JSONArray();
        JSONObject filterObject = new JSONObject();
        filterObject.put(UtilitiesConstants.LOCATION_ID, BLANK);
        locFilterArray.put(filterObject);

        Method method = EPMFilter.class.getDeclaredMethod("getAllowedLocations", JSONArray.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(epmFilter, locFilterArray, "location1");

        assertFalse(result);
    }
}
