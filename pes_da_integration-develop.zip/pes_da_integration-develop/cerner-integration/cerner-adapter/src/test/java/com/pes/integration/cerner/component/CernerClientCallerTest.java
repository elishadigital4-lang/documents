package com.pes.integration.cerner.component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.cerner.dto.Token;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.reactive.ClientHttpResponse;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static com.pes.integration.constant.UtilitiesConstants.GET;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@ExtendWith(MockitoExtension.class)
public class CernerClientCallerTest {

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    WebClient.RequestHeadersSpec requestHeadersSpec1;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private ClientHttpResponse clientHttpResponse;

    @InjectMocks
    private CernerClientCaller cernerClientCaller;

    @BeforeEach
    void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
        webClient = mock(WebClient.class);
        cernerClientCaller.webClient = webClient;

        Field engineNameField = CernerClientCaller.class.getDeclaredField("engineName");
        engineNameField.setAccessible(true);
        engineNameField.set(cernerClientCaller, "TestEngine");

        Field appDescriptionField = CernerClientCaller.class.getDeclaredField("appDescription");
        appDescriptionField.setAccessible(true);
        appDescriptionField.set(cernerClientCaller, "TestApp");
    }

    @Test
    void generateTokenReturnsValidToken() {
        String url = "http://example.com/token";
        HttpHeaders headers = new HttpHeaders();
        Token expectedToken = new Token();
        expectedToken.setExpiresIn(3600);
        expectedToken.setAccessToken("token");


        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.just(expectedToken));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            Token result = cernerClientCaller.generateToken(url, headers);

            assertEquals(expectedToken, result);
        }
    }

    @Test
    void generateTokenHandlesErrorResponse() {

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            String errorBody = "Invalid request";


            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.error(new RuntimeException(errorBody)));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> cernerClientCaller.generateToken(url, headers));

            Assertions.assertEquals(errorBody, exception.getMessage());
        }
    }

    @Test
    void testGenerateToken_Error() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            String url = "http://example.com/token";
            HttpHeaders headers = new HttpHeaders();
            String errorBody = "400 Bad Request";

            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(Token.class)).thenReturn(Mono.error(new WebClientResponseException(400,
                    "Bad Request", null, null, null)));

            Exception exception = assertThrows(RuntimeException.class, () -> cernerClientCaller.generateToken(url, headers));

            Assertions.assertEquals(errorBody, exception.getMessage());
        }
    }

    @Test
    void getDataReturnsNullPointerException() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        String expectedResponse = "responseBody";
        lenient().when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.body(any(), eq(String.class))).thenAnswer(reqBody ->requestHeadersSpec);
        lenient().when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        ClientResponse clientResponse = mock(ClientResponse.class);
        Mono<ClientResponse> clientResponseMono = Mono.just(clientResponse);
        //when(requestBodyUriSpec.exchangeToMono(any())).thenReturn(clientResponseMono);
        //when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
        //when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just("responseBody"));

        Assertions.assertThrows(NullPointerException.class, () -> cernerClientCaller.getData(httpMethod, url, body, token, new HttpHeaders(), "false"));

    }

    @Test
    void getDataHandlesErrorResponse() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";

        assertThrows(NullPointerException.class, () -> cernerClientCaller.getData(httpMethod, url, body, token, new HttpHeaders(), "false"));
    }

    @Test
    void getDataReturnsSuccessResponse() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        HttpHeaders headers = new HttpHeaders();
        String expectedResponse = "responseBody";

        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);

        ClientResponse clientResponse = mock(ClientResponse.class);
        when(requestHeadersSpec.exchangeToMono(any())).thenAnswer(invocation -> {
            return ((java.util.function.Function<ClientResponse, Mono<String>>) invocation.getArgument(0)).apply(clientResponse);
        });
        when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
        when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(expectedResponse));

        String result = cernerClientCaller.getData(httpMethod, url, body, token, headers, "false");
        assertEquals(expectedResponse, result);
    }


    @Test
    void getDataReturnsErrorResponse_4xx() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        HttpHeaders headers = new HttpHeaders();
        String errorBody = "Bad Request";

        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);

        ClientResponse clientResponse = mock(ClientResponse.class);
        when(requestHeadersSpec.exchangeToMono(any())).thenAnswer(invocation -> {
            return ((java.util.function.Function<ClientResponse, Mono<String>>) invocation.getArgument(0)).apply(clientResponse);
        });
        when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));

        Exception ex = assertThrows(RuntimeException.class, () -> cernerClientCaller.getData(httpMethod, url, body, token, headers, "false"));
        assertEquals(IHubException.class, ex.getCause().getClass());
        assertEquals(errorBody, ex.getCause().getMessage());
    }

    @Test
    void getDataReturnsErrorResponse_5xx() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        HttpHeaders headers = new HttpHeaders();
        String errorBody = "Internal Server Error";

        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);

        ClientResponse clientResponse = mock(ClientResponse.class);
        when(requestHeadersSpec.exchangeToMono(any())).thenAnswer(invocation -> {
            return ((java.util.function.Function<ClientResponse, Mono<String>>) invocation.getArgument(0)).apply(clientResponse);
        });
        when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));

        Exception ex = assertThrows(RuntimeException.class, () -> cernerClientCaller.getData(httpMethod, url, body, token, headers, "false"));
        assertEquals(IHubException.class, ex.getCause().getClass());
        assertEquals(errorBody, ex.getCause().getMessage());
    }

    @Test
    void getDataReturnsErrorResponse_OtherStatus() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        HttpHeaders headers = new HttpHeaders();
        String errorBody = "Unknown Error";

        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);

        ClientResponse clientResponse = mock(ClientResponse.class);
        when(requestHeadersSpec.exchangeToMono(any())).thenAnswer(invocation -> {
            return ((java.util.function.Function<ClientResponse, Mono<String>>) invocation.getArgument(0)).apply(clientResponse);
        });
        when(clientResponse.statusCode()).thenReturn(HttpStatus.CONTINUE);
        when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));

        Exception ex = assertThrows(RuntimeException.class, () -> cernerClientCaller.getData(httpMethod, url, body, token, headers, "false"));
        assertEquals(IHubException.class, ex.getCause().getClass());
        assertEquals(errorBody, ex.getCause().getMessage());
    }

    @Test
    void getShortenUrl_withQuery() {
        String url = "http://test.com/api?param=value";
        String result = cernerClientCaller.getShortenUrl(url);
        assertEquals("http://test.com/api", result);
    }

    @Test
    void getShortenUrl_noQuery() {
        String url = "http://test.com/api";
        String result = cernerClientCaller.getShortenUrl(url);
        assertEquals(url, result);
    }

    @Test
    void recordErrorMetrics_4xx() throws Exception {
        Method method = CernerClientCaller.class.getDeclaredMethod("recordErrorMetrics", ClientResponse.class, String.class, String.class, String.class);
        method.setAccessible(true);
        ClientResponse response = mock(ClientResponse.class);
        when(response.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
        method.invoke(cernerClientCaller, response, "error", "depId", "shortUrl");
        // No exception means success
    }

    @Test
    void recordErrorMetrics_5xx() throws Exception {
        Method method = CernerClientCaller.class.getDeclaredMethod("recordErrorMetrics", ClientResponse.class, String.class, String.class, String.class);
        method.setAccessible(true);
        ClientResponse response = mock(ClientResponse.class);
        when(response.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        method.invoke(cernerClientCaller, response, "error", "depId", "shortUrl");
    }

    @Test
    void recordErrorMetrics_other() throws Exception {
        Method method = CernerClientCaller.class.getDeclaredMethod("recordErrorMetrics", ClientResponse.class, String.class, String.class, String.class);
        method.setAccessible(true);
        ClientResponse response = mock(ClientResponse.class);
        when(response.statusCode()).thenReturn(HttpStatus.CONTINUE);
        method.invoke(cernerClientCaller, response, null, "depId", "shortUrl");
    }

    @Test
    void getData_ReadHeaderTrue_Success() throws JsonProcessingException {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        HttpHeaders headers = new HttpHeaders();
        String readHeader = "true";
        ClientResponse clientResponse = mock(ClientResponse.class);

        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);

        when(requestHeadersSpec.exchangeToMono(any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<String>> handler = invocation.getArgument(0);
            when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.add("X-Test", "value");
            ClientResponse.Headers headersMock = mock(ClientResponse.Headers.class);
            when(headersMock.asHttpHeaders()).thenReturn(responseHeaders);
            when(clientResponse.headers()).thenReturn(headersMock);
            when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just("body"));
            return handler.apply(clientResponse);
        });

        cernerClientCaller.webClient = webClient;

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientSuccessCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String result = cernerClientCaller.getData(httpMethod, url, body, token, headers, readHeader);
            assertNotNull(result);
            assertTrue(result.contains("X-Test"));
        }
    }


    // 3. readHeader is not "true"
    @Test
    void getData_ReadHeaderNotTrue_ReturnsBody() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        HttpHeaders headers = new HttpHeaders();
        String readHeader = "false";

        ClientResponse clientResponse = mock(ClientResponse.class);

        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);

        when(requestHeadersSpec.exchangeToMono(any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<String>> handler = invocation.getArgument(0);
            when(clientResponse.statusCode()).thenReturn(HttpStatus.OK);
            when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just("body"));
            return handler.apply(clientResponse);
        });

        cernerClientCaller.webClient = webClient;

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientSuccessCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String result = cernerClientCaller.getData(httpMethod, url, body, token, headers, readHeader);
            assertEquals("body", result);
        }
    }

    // 4. Response status is not 2xx (error path)
    @Test
    void getData_ErrorStatus_ThrowsIHubException() {
        String httpMethod = "POST";
        String url = "http://example.com/data";
        String body = "requestBody";
        String token = "validToken";
        HttpHeaders headers = new HttpHeaders();
        String readHeader = null;

        ClientResponse clientResponse = mock(ClientResponse.class);

        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenReturn(requestHeadersSpec);

        when(requestHeadersSpec.exchangeToMono(any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<String>> handler = invocation.getArgument(0);
            when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
            when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just("errorBody"));
            return handler.apply(clientResponse);
        });

        cernerClientCaller.webClient = webClient;

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            Throwable ex = assertThrows(Throwable.class, () -> cernerClientCaller.getData(httpMethod, url, body, token, headers, readHeader));
            Throwable cause = ex.getCause();
            assertNotNull(cause);
            assertTrue(cause instanceof IHubException);
            assertTrue(cause.getMessage().contains("errorBody"));
        }
    }
}
