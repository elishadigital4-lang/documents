package com.pes.integration.cerner.consumer;

import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SendSyncDataConsumerTest {

    @Mock
    SyncDataConsumerService syncDataConsumerService;

    SendSyncDataConsumer sendSyncDataConsumer;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.initMocks(this);

        this.sendSyncDataConsumer = spy(new SendSyncDataConsumer());

        Field syncDataConsumerServiceField = SendSyncDataConsumer.class.getDeclaredField("syncDataConsumerService");
        syncDataConsumerServiceField.setAccessible(true);
        syncDataConsumerServiceField.set(this.sendSyncDataConsumer, syncDataConsumerService);
    }

    @Test
    public void testConsumeSendSyncDataMessage()
    {
        Mockito.doNothing().when(this.syncDataConsumerService).processSendSyncData("");

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            this.sendSyncDataConsumer.consumeSendSyncDataMessage("");

            Mockito.verify(this.syncDataConsumerService, times(1)).processSendSyncData("");

        }
    }

    @Test
    public void testListen() {
        Mockito.doNothing().when(this.syncDataConsumerService).processSendSyncData("");
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);


            this.sendSyncDataConsumer.listen("", "");

            Mockito.verify(this.syncDataConsumerService, times(1)).processSendSyncData("");
        }
    }

}
