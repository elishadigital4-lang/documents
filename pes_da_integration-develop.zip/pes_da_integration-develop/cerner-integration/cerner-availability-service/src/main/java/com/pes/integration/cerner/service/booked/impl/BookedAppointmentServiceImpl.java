package com.pes.integration.cerner.service.booked.impl;

import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.cerner.task.BookedAppointmentSupplier;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_FRAGMENT_FAILED;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.adapter.Utils.trackBookedFragmentError;
import static com.pes.integration.cerner.constant.CernerEngineConstants.CERNER_CONFIG;
import static com.pes.integration.cerner.constant.CernerEngineConstants.COUNT;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.util.Collections.emptyMap;

@Slf4j
@Qualifier(BOOKED_APPOINTMENT)
@Service
public class BookedAppointmentServiceImpl extends AppointmentService {

  @Value("${application.data.path}")
  private String dataLocation;

  @Autowired
  private CernerApiCaller cernerApiCaller;

  @Autowired
  private FileUploader fileUploader;

  @Autowired
  private EventTracker trackEvents;

  @Autowired
  DataCacheManager dataCacheManager;

  private static final int TOTAL_BOOKED_CALLS = 1;
  private static final String REQUEST_RECEIVED =
          "Booked Appointment request has been received with input %s";

  @Override
  public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
    return null;
  }

  @Override
  public JSONArray getAvailability(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap,
                                   String epmPrefix) throws JsonProcessingException, IHubException {
    if (availabilityRequest.getIndex().equals(valueOf(FIRST_INDEX))) {
      trackEvents.trackEvent(availabilityRequest, BOOKED_APPOINTMENT_PROCESSING_STARTED,
              format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
              getFragmentsDetails(availabilityRequest));
    }
    fetchBookedAppointments(providerLocationMap.get(PROVIDER_ID_LIST), availabilityRequest, epmPrefix);
    return null;
  }

  private void fetchBookedAppointments(JSONArray locationJsonArray,
                                       AvailabilityRequest availabilityRequest,String epmPrefix) throws IHubException {
    JSONObject inputObject = getInputObject(availabilityRequest.getStartDate(), availabilityRequest.getEndDate(),
            locationJsonArray, epmPrefix, availabilityRequest.getDeploymentId());
    try {
      new BookedAppointmentSupplier(cernerApiCaller, inputObject, fileUploader, trackEvents,
              availabilityRequest).processBookedAppointment();
    } catch (InvalidIdException e) {
      log.error(e.getMessage());
      trackBookedFragmentError(availabilityRequest, trackEvents, e.getMessage());
    } catch (EpmApiCallerException ee) {
      String message = "Error in getting the booked appointment slot " + ee.getMessage();
      log.error(message);
      trackBookedFragmentError(availabilityRequest, trackEvents, message);
    }
  }

  private JSONObject getInputObject(String startDate, String endDate, JSONArray providerJsonArray,
                                    String epmPrefix, String deploymentId) throws IHubException {
    JSONObject inputObject = new JSONObject();
    inputObject.put(STARTDATE, startDate);
    inputObject.put(ENDDATE, endDate);
    inputObject.put(APPOINTMENT_PATH, dataLocation);
    inputObject.put(CernerConstants.PROVIDERS, providerJsonArray.toString());
    inputObject.put("count", dataCacheManager.getConfiguration(epmPrefix, deploymentId, CERNER_CONFIG, COUNT));
    return inputObject;
  }

  private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest) {
    Map<String, Object> providerDetails = new HashMap<>();
    providerDetails.put(TOTAL_FRAGMENTS, valueOf(TOTAL_BOOKED_CALLS));
    providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
    return providerDetails;
  }
}
