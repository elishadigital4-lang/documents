package com.pes.integration.cerner.util;

import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.Map;


public class CernerUtil {

  private CernerUtil() {}

  public static void trackEventToNifi(EventTracker trackEvents,
      AvailabilityRequest availabilityRequest, DataflowStatus dataflowStatus, String totalFragments,
      String fragmentId, Map<String, Object> payload) throws JsonProcessingException {
    NifiTrackingEvent nifiEvent = NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
        .messageControlId(availabilityRequest.getMessageControlId())
        .appointmentType(availabilityRequest.getAppointmentType())
        .sliceId(availabilityRequest.getSliceId())
        .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
        .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices()).payload(payload)
        .flow(availabilityRequest.getFlow())
        .build();
    trackEvents.trackEventToNifi(nifiEvent);
  }
}
