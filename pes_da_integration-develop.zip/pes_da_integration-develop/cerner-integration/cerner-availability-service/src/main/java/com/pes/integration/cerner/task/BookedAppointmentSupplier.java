package com.pes.integration.cerner.task;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.SlotDTO;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.cerner.constant.CernerConstants.*;
import static com.pes.integration.cerner.util.CernerUtil.trackEventToNifi;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.cerner.constant.CernerConstants.DATE_TIME_FORMAT;
import static com.pes.integration.cerner.constant.CernerConstants.APPOINTMENT_DURATION;
import static com.pes.integration.cerner.constant.CernerConstants.DATE_TIME_Z_FORMAT;
import static com.pes.integration.cerner.constant.CernerConstants.EXTERNAL_APPT_ID;
import static com.pes.integration.cerner.constant.CernerConstants.PROVIDERS;
import static com.pes.integration.cerner.constant.CernerConstants.REFERENCE;
import static com.pes.integration.cerner.constant.CernerConstants.START_TIME;
import static com.pes.integration.constant.EpmConstant.DATE_FORMAT;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.EpmConstant.LOCATION_ID;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.enums.DataflowStatus.PULL_BOOKED_APPOINTMENT_FRAGMENT;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static java.util.Collections.emptyMap;
import static java.util.Objects.nonNull;
import static java.lang.String.valueOf;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class BookedAppointmentSupplier {

  private String startDate;
  private String endDate;
  private String providers;
  private String nextUrlCount;
  private String dataLocation;
  private EventTracker trackEvents;
  private FileUploader fileUploader;
  private CernerApiCaller cernerApiCaller;
  private AvailabilityRequest availabilityRequest;
  private Map<String, String> contextMap = getCopyOfContextMap();
  private final String ERROR_MSG = "Error while building the request ";

  public BookedAppointmentSupplier( CernerApiCaller cernerApiCaller,
                                   JSONObject inputObject, FileUploader fileUploader, EventTracker trackEvents,
                                   AvailabilityRequest availabilityRequest) {
    this.cernerApiCaller = cernerApiCaller;
    this.fileUploader = fileUploader;
    this.trackEvents = trackEvents;
    this.availabilityRequest = availabilityRequest;
    this.startDate = inputObject.getString(STARTDATE);
    this.endDate = inputObject.getString(ENDDATE);
    this.providers = inputObject.getString(PROVIDERS);
    this.nextUrlCount = inputObject.optString("count");
    this.dataLocation = inputObject.getString(APPOINTMENT_PATH);
  }

  public void processBookedAppointment() {
    setContext(contextMap);
    Map<String, File> appointmentDataFiles = new HashMap<>();
    try {
      JSONObject bookedApptOutput = getBookedAppointment();
      uploadBookedFiles(appointmentDataFiles, bookedApptOutput);
      trackEventToNifi(trackEvents, availabilityRequest, PULL_BOOKED_APPOINTMENT_FRAGMENT,
              valueOf(ONE), EMPTY, emptyMap());
    } catch (JsonProcessingException e) {
      log.error("error while tracking the request {}", e.getMessage());
      throw new EpmApiCallerException("error while tracking the request");
    } catch (IHubException e) {
      log.error("error while tracking the request {}", e.getMessage());
      throw new IllegalArgumentException("Error while tracking the request "+ e.getMessage());
    } finally {
       deleteFiles(appointmentDataFiles);
    }
  }

  private void uploadBookedFiles(Map<String, File> appointmentDataFiles,
                                 JSONObject bookedApptOutput) {
    appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
            prepareBookedFile(bookedApptOutput, availabilityRequest));
    fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
            availabilityRequest.getAppointmentType(), availabilityRequest.getSliceId(),
            appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
  }

  private File prepareBookedFile(JSONObject apptresponse, AvailabilityRequest availabilityRequest) {
    return prepareFile(apptresponse.toString(),
            dataLocation + availabilityRequest.getMessageControlId() + SLASH
                    + availabilityRequest.getSliceId(),
            SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
  }

  private JSONObject getBookedAppointment() throws IHubException {
    JSONArray bookedAppointmentsArray = new JSONArray();
    JSONObject responseObject = bookedAppointments();
    log.info("Booked api called ");
    if (nonNull(responseObject)) {
      bookedAppointmentsArray.putAll(extractBookedSlots(responseObject));
    }
    return getBookedAppointmentObject(bookedAppointmentsArray);
  }

  private JSONObject getBookedAppointmentObject(JSONArray bookedAppointmentsArray) {
    JSONObject bookedApptObj = new JSONObject();
    bookedApptObj.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
    bookedApptObj.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
    bookedApptObj.put(TOTAL_COUNT, bookedAppointmentsArray.length());
    bookedApptObj.put(DATA, bookedAppointmentsArray);
    return bookedApptObj;
  }

  private JSONObject bookedAppointments() throws IHubException {
    JSONObject bookedAppointments=new JSONObject();
    JSONObject cernerRequestObject = buildRequest();
    String slotTypes = getValue(cernerRequestObject, "SchedulingData.Provider[0].ProviderId").toString();
    String[] slotTypesArray = slotTypes.split(",");
    int slotTypesArrayLengthLimit = 200;
    if (slotTypesArray.length > slotTypesArrayLengthLimit) {
      log.info("slotTypes array length is more than {}",slotTypesArrayLengthLimit);
      List<String> slotTypesList = splitSlotTypes(slotTypesArray, slotTypesArrayLengthLimit);
      for(int i=0; i<slotTypesList.size(); i++) {
        log.info("slotTypesList size for call no:{} {}",i,slotTypesList.size());
        log.info("slotTypesList list for call no:{} {}",i,slotTypesList.get(i));
        setValue(cernerRequestObject, "SchedulingData.Provider[0].ProviderId", slotTypesList.get(i));
        JSONObject tempopenappointments =
                cernerApiCaller.call(availabilityRequest.getDeploymentId(), ApiName.BOOKED_APPOINTMENTS.getKey(), cernerRequestObject, "");

        if (!tempopenappointments.isEmpty() && bookedAppointments.isEmpty()) {
          bookedAppointments = tempopenappointments;
        }

        else if (!tempopenappointments.isEmpty()) {
          List<Object> previousSlots = bookedAppointments.getJSONArray("BookedAppointments").toList();
          List<Object> presentSlots = tempopenappointments.getJSONArray("BookedAppointments").toList();
          previousSlots.addAll(presentSlots);

          JSONArray finalSlots = new JSONArray(previousSlots);
          bookedAppointments.put("BookedAppointments", finalSlots);
          log.info("bookedappointments size for call no:{} {}",i,bookedAppointments.getJSONArray("BookedAppointments").length());
        }
      }
    }else {
      bookedAppointments =
              cernerApiCaller.call(availabilityRequest.getDeploymentId(), ApiName.BOOKED_APPOINTMENTS.getKey(), cernerRequestObject, "");
    }
    return bookedAppointments;
  }

  private List<String> splitSlotTypes(String[] slotTypesArray, int slotTypesArrayLengthLimit)
  {
    List<String> slotTypesList = new ArrayList<>();
    String slotTypesString = "";
    for(int i=0; i< slotTypesArray.length ;i++) {
      if(i>0 && i%slotTypesArrayLengthLimit == 0) {
        slotTypesList.add(slotTypesString);
        slotTypesString = "";
      }

      if (slotTypesString.equals("")) {
        slotTypesString=slotTypesArray[i];
      } else {
        slotTypesString+=","+(slotTypesArray[i]);
      }

      if ((i == slotTypesArray.length-1) && !slotTypesString.equals("")) {
        slotTypesList.add(slotTypesString);
        slotTypesString = "";
      }
    }

    return slotTypesList;
  }

  private JSONObject buildRequest() {
    JSONObject input = new JSONObject();
    String providerData = fetchProviderData(new JSONArray(providers));
    try {
      setValue(input, "SchedulingData.Provider[0].ProviderId", providerData);
      setValue(input, "Count", "5");
      setValue(input, "temp.start_date", "ge" + this.startDate + "&date=le" + this.endDate);
      setValue(input, "Count", nextUrlCount);
    } catch (IHubException e) {
      log.error(ERROR_MSG + "{}", e.getMessage());
      throw new IllegalArgumentException(ERROR_MSG + e.getMessage());
    }
    return input;
  }

  private String fetchProviderData(JSONArray providerJsonArray) {
    StringBuilder providerIdStr = new StringBuilder();
    for (Object providerId : providerJsonArray) {
      providerId = "Practitioner/" + providerId;
      if (providerIdStr.toString().isEmpty()) {
        providerIdStr = providerIdStr.append(providerId);
      } else {
        providerIdStr = providerIdStr.append("," + providerId);
      }
    }
    return providerIdStr.toString();
  }

  private JSONArray extractBookedSlots(JSONObject outputObject) {
    List<SlotDTO> res = new ArrayList<>();
    JSONArray bookedAppointmentsArray = outputObject.optJSONArray("BookedAppointments");
    if (bookedAppointmentsArray == null || bookedAppointmentsArray.length() == 0) {
      return new JSONArray(res);
    }
    bookedAppointmentsArray.forEach(bookedAppointment -> {
      res.add(transformBookedAppointment(bookedAppointment.toString()));
    });
    return new JSONArray(res);
  }

  private SlotDTO transformBookedAppointment(String bookedAppointment) {
    JSONObject appointmentObject = new JSONObject(bookedAppointment);
    String dateTimeString = getValue(appointmentObject, START_TIME).toString();
    String daDate = "";
    String daTime = "";
    try {
      daDate = convertDateFormat(dateTimeString.trim(), DATE_TIME_Z_FORMAT, DATE_TIME_FORMAT);
      daTime = convertDateFormat(dateTimeString, DATE_TIME_Z_FORMAT, DOCASAP_TIME_FORMAT);
    } catch (ParseException e) {
      log.error("error while parsing in transformBookedAppointment {}", e.getMessage());
      throw new IllegalArgumentException(ERROR_MSG +e.getMessage());
    }

    String duration = getValue(appointmentObject, APPOINTMENT_DURATION).toString();
    setLocationProvider(appointmentObject);
    String slotId = (String) getValue(appointmentObject, EXTERNAL_APPT_ID);
    String providerId = getValue(appointmentObject, PROVIDER_ID).toString();
    String locationId = getValue(appointmentObject, LOCATION_ID).toString();
    SlotDTO slotDto = SlotDTO.builder().slotId(slotId).duration(duration).durationUnit(MINUTES)
            .reasonId("").providerId(providerId.trim()).locationId(locationId.trim()).build();
    slotDto.setDate(daDate);
    slotDto.setStartTime(daTime);
    return slotDto;
  }

  private void setLocationProvider(JSONObject appointmentObject) {
    JSONArray referenceArray = (JSONArray) getValue(appointmentObject, REFERENCE);
    for (Object reference : referenceArray) {
      String referenceStr = reference.toString();
      String referenceId =
              referenceStr.substring(referenceStr.indexOf('/') + 1, referenceStr.length());
      try {
        if (referenceStr.contains("Practitioner")) {
          setValue(appointmentObject, CernerConstants.PROVIDER_ID, referenceId);
        } else if (referenceStr.contains("Location")) {
          setValue(appointmentObject, CernerConstants.LOCATION_ID, referenceId);
        }
      } catch (IHubException e) {
        log.error("error while setting location provider {}", e.getMessage());
        throw new IllegalArgumentException(ERROR_MSG + e.getMessage());
      }
    }
  }
}
