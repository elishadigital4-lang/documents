package com.pes.integration.cerner.consumer;

import com.pes.integration.component.EventTracker;
import com.pes.integration.constant.EpmConstant;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.awspring.cloud.sqs.annotation.SqsListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.constant.EpmConstant.MESSAGE_CONTROL_ID;
import static com.pes.integration.constant.EpmConstant.OPEN_APPOINTMENT;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_SLICE_PROCESSING_FAILED;
import static java.util.Collections.emptyMap;
import static org.slf4j.MDC.put;

@Service
@Slf4j
public class OpenAppointmentConsumer {

  @Autowired
  @Qualifier(OPEN_APPOINTMENT)
  private AppointmentService openAppointmentService;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private EventTracker trackEvents;

  @SqsListener(value = "${application.queue.openAppt.process}",maxConcurrentMessages = "1",maxMessagesPerPoll = "1")
  public void consume(String request) throws JsonProcessingException {
      AvailabilityRequest availabilityRequest = null;
      log.info("Open Appointment data request received is {}", request);
      try {
        availabilityRequest = objectMapper.readValue(request, AvailabilityRequest.class);
        log.info("Starting processing for slice {} and msid : {}",availabilityRequest.getSliceId(),availabilityRequest.getMessageControlId());
        validateInput(availabilityRequest);
        openAppointmentService.getAppointments(availabilityRequest, CernerEngineConstants.EPM_NAME_PREFIX);
        log.info("Completed processing for slice {} and msid : {}",availabilityRequest.getSliceId(),availabilityRequest.getMessageControlId());
      } catch (JsonProcessingException jpe) {
        String message = "Error while parsing the request " + availabilityRequest + jpe.getMessage();
        log.error(message);
        trackOpenSliceError(availabilityRequest, trackEvents, message);
      } catch (Exception ex) {
        String message = "Error in processing the data , Details: " + ex.getMessage();
        log.error(message);
        trackOpenSliceError(availabilityRequest, trackEvents, message);
      }
  }
}
