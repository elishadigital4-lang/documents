package com.pes.integration.cerner.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.service.AppointmentService;
import io.awspring.cloud.sqs.annotation.SqsListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import static com.pes.integration.adapter.Utils.trackBookedSliceError;
import static com.pes.integration.adapter.Utils.validateInput;
import static com.pes.integration.constant.EpmConstant.BOOKED_APPOINTMENT;

@Service
@Slf4j
public class BookedAppointmentConsumer {

  @Autowired
  @Qualifier(BOOKED_APPOINTMENT)
  private AppointmentService bookedAppointmentService;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private EventTracker trackEvents;

  @SqsListener(value = "${application.queue.bookedAppt.process}",maxConcurrentMessages = "1",maxMessagesPerPoll = "1")
  public void consume(String request) throws JsonProcessingException {
    AvailabilityRequest availabilityRequest = null;
    log.info("Booked Appointment data request received is {}", request);
    try {
      availabilityRequest = objectMapper.readValue(request, AvailabilityRequest.class);
      validateInput(availabilityRequest);
      bookedAppointmentService.getAppointments(availabilityRequest, CernerEngineConstants.EPM_NAME_PREFIX);
    } catch (JsonProcessingException jpe) {
      String message = "Error while parsing the request " + availabilityRequest + jpe.getMessage();
      log.error(message);
      trackBookedSliceError(availabilityRequest, trackEvents, message);
    } catch (Exception ex) {
      String message = "Error in processing the Booked Appointment data , Details: ";

      Throwable cause = ex.getCause();
      if (cause !=null) {
        message += cause.getMessage();
      } else {
        message += "No Cause is available for the exception";
      }

      log.error(message);
      trackBookedSliceError(availabilityRequest, trackEvents, message);
    }
  }
  
  public void setObjectMapper(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

}
