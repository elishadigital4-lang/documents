package com.pes.integration.cerner.task;

import static com.pes.integration.adapter.Utils.trackOpenFragmentError;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.upload.FileUploader;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Supplier;

import static com.pes.integration.cerner.constant.CernerConstants.DATE_TIME_Z_FORMAT;
import static com.pes.integration.cerner.constant.CernerConstants.PIPE;
import static com.pes.integration.cerner.util.CernerUtil.trackEventToNifi;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.FRAGMENT_ID_KEY;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_FRAGMENT_FAILED;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.DateUtils.getTimeDiff;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext;
import static com.pes.integration.adapter.Utils.createNifiErrorPayload;
import static com.pes.integration.adapter.Utils.getOpenDataFlowNifiStatus;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static java.lang.String.format;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static java.lang.String.valueOf;

@Slf4j
public class OpenAppointmentSupplier implements Supplier<Void> {

  private static final String ERROR_PROCESSING_DATA =
          "Error in processing the data for open appointment slot, Details:- Start Date : %s,  End Date: %s, ProviderId: %s, Error: %s  ";

  private String startDate;
  private String endDate;
  private String providerId;
  private String dataLocation;
  private CernerApiCaller cernerApiCaller;
  private EventTracker trackEvents;
  private FileUploader fileUploader;
  private JSONObject requestPrameters;
  private AvailabilityRequest availabilityRequest;
  private Map<String, String> contextMap = MDC.getCopyOfContextMap();

  public OpenAppointmentSupplier(CernerApiCaller cernerApiCaller,
                                 FileUploader fileUploader, EventTracker trackEvents, JSONObject requestPrameters,
                                 AvailabilityRequest availabilityRequest) {
    this.cernerApiCaller = cernerApiCaller;
    this.fileUploader = fileUploader;
    this.trackEvents = trackEvents;
    this.availabilityRequest = availabilityRequest;
    this.startDate = requestPrameters.getString(STARTDATE);
    this.endDate = requestPrameters.getString(ENDDATE);
    this.providerId = requestPrameters.getString(PROVIDER);
    this.requestPrameters = requestPrameters;
    this.dataLocation = requestPrameters.optString(APPOINTMENT_PATH);
  }

  @Override
  public Void get() {
    setContext(contextMap);
    Map<String, File> appointmentDataFiles = new HashMap<>();
    try {
      JSONObject openApptOutput = getOpenAppointments();
      uploadFiles(appointmentDataFiles, openApptOutput, providerId);
      trackEventToNifi(trackEvents, availabilityRequest,
              getOpenDataFlowNifiStatus(availabilityRequest), MDC.get(TOTAL_FRAGMENTS), providerId,
              createNifiErrorPayload(getNifiPayload()));
    } catch (JsonProcessingException jpe) {
      log.error("error  while tracking the request {}", jpe.getMessage());
    } catch (EpmApiCallerException ee) {
      log.error("Error in getting the open slotId " + ee.getMessage());
    } finally {
      deleteFiles(appointmentDataFiles);
    }
    return null;
  }

  private void uploadFiles(Map<String, File> appointmentDataFiles, JSONObject openApptOutput,
      String id) {
    appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
            prepareOpenAppointmentFile(openApptOutput, availabilityRequest, id));
    if (isEmpty(id)) {
      fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
              availabilityRequest.getAppointmentType(), availabilityRequest.getSliceId(),
              appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    } else {
      fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
              availabilityRequest.getAppointmentType(), availabilityRequest.getSliceId() + SLASH + id,
              appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    }
  }

  private File prepareOpenAppointmentFile(JSONObject apptresponse,
                                          AvailabilityRequest availabilityRequest, String id) {
    return prepareFile(apptresponse.toString(),
            dataLocation + availabilityRequest.getMessageControlId() + SLASH
                    + availabilityRequest.getSliceId() + SLASH + availabilityRequest.getAppointmentType()
                    + SLASH + id,
            SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
  }

  private List<String> splitSlotTypes(String[] slotTypesArray, int slotTypesArrayLengthLimit)
  {
    List<String> slotTypesList = new ArrayList<>();
    String slotTypesString = "";
    for(int i=0; i< slotTypesArray.length ;i++) {
      if(i>0 && i%slotTypesArrayLengthLimit == 0) {
        slotTypesList.add(slotTypesString);
        slotTypesString = "";
      }

      if (slotTypesString.equals("")) {
        slotTypesString=slotTypesArray[i];
      } else {
        slotTypesString+=","+(slotTypesArray[i]);
      }

      if ((i == slotTypesArray.length-1) && !slotTypesString.equals("")) {
        slotTypesList.add(slotTypesString);
        slotTypesString = "";
      }
    }

    return slotTypesList;
  }

  private JSONObject getOpenAppointments() throws JsonProcessingException {
    JSONArray openAppointmentsArray = new JSONArray();
    JSONObject openApptOutput = new JSONObject();
    try {
      JSONObject inputObject = getinputObject();
      JSONObject openappointments = new JSONObject();
      String slotTypes = getValue(inputObject, "temp.slot-type").toString();
      String[] slotTypesArray = slotTypes.split(",");
      int slotTypesArrayLengthLimit = 75;

      if (slotTypesArray.length > slotTypesArrayLengthLimit) {
        log.info("slotTypes array length is more than {}",slotTypesArrayLengthLimit);
        List<String> slotTypesList = splitSlotTypes(slotTypesArray, slotTypesArrayLengthLimit);
        for(int i=0; i<slotTypesList.size(); i++) {
          log.info("slotTypesList size for call no:{} {}",i,slotTypesList.size());
          log.info("slotTypesList list for call no:{} {}",i,slotTypesList.get(i));
          setValue(inputObject, "temp.slot-type", slotTypesList.get(i));
          JSONObject tempopenappointments = cernerApiCaller.call(availabilityRequest.getDeploymentId(),
                  ApiName.OPEN_APPOINTMENTS.getKey(), inputObject, "");

          if (!tempopenappointments.isEmpty() && openappointments.isEmpty()) {
            openappointments = tempopenappointments;
          }

          else if (!tempopenappointments.isEmpty()) {
            List<Object> previousSlots = openappointments.getJSONArray("OpenAppointments").toList();
            List<Object> presentSlots = tempopenappointments.getJSONArray("OpenAppointments").toList();
            previousSlots.addAll(presentSlots);

            JSONArray finalSlots = new JSONArray(previousSlots);
            openappointments.put("OpenAppointments", finalSlots);
            log.info("openappointments size for call no:{} {}",i,openappointments.getJSONArray("OpenAppointments").length());
          }
        }
      } else {
        openappointments = cernerApiCaller.call(availabilityRequest.getDeploymentId(),
                ApiName.OPEN_APPOINTMENTS.getKey(), inputObject, "");
      }

      log.info("Open api called ");
      if (!openappointments.isEmpty()) {
        openAppointmentsArray = extractOpenSlotsFromResponse(openappointments);
      }
      openApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
      openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
      openApptOutput.put(TOTAL_COUNT, openAppointmentsArray.length());
      openApptOutput.put(DATA, openAppointmentsArray);
    } catch (InvalidIdException | NullPointerException ide) {
      String exceptionDetails =
              format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ide.getMessage());
      log.error(exceptionDetails);
      trackOpenFragmentError(availabilityRequest, trackEvents, providerId, exceptionDetails);
      throw new EpmApiCallerException(exceptionDetails);
    } catch (Exception ee) {
      String exceptionDetails =
              format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ee.getMessage());
      log.error(exceptionDetails);
      trackOpenFragmentError(availabilityRequest, trackEvents, providerId, exceptionDetails);
      throw new EpmApiCallerException(exceptionDetails);
    }
    return openApptOutput;
  }

  private JSONArray extractOpenSlotsFromResponse(JSONObject outputObject) {
    JSONArray appointmentsArray = outputObject.optJSONArray("OpenAppointments");
    JSONArray openAppointmentsArray = new JSONArray();
    appointmentsArray.forEach(appointmentObject -> openAppointmentsArray
            .put(transformObject((JSONObject) appointmentObject)));
    return openAppointmentsArray;
  }

  private JSONObject transformObject(JSONObject appointmentObject) {
    JSONObject openAppointment = new JSONObject();
    String startDateTime = (String) getValue(appointmentObject, "temp.start_time");
    String endDateTime = (String) getValue(appointmentObject, "temp.end_time");
    String daDate = "";
    String startTime = "";
    String endTime = "";

    try {
      daDate =
              convertDateFormat(startDateTime.trim(), DATE_TIME_Z_FORMAT, DATE_TIME_FORMAT);
      startTime = convertDateFormatCerner(startDateTime.trim(), DATE_TIME_Z_FORMAT,
              DOCASAP_TIME_FORMAT, requestPrameters.optString("cernerTimeZone"),
              requestPrameters.optString("clientTimeZone"));
      endTime = convertDateFormatCerner(endDateTime.trim(), DATE_TIME_Z_FORMAT,
              DOCASAP_TIME_FORMAT, requestPrameters.optString("cernerTimeZone"),
              requestPrameters.optString("clientTimeZone"));
    } catch (ParseException e) {
      log.error("error while parsing in transformObject {}", e.getMessage());
      throw new IllegalArgumentException("Error  while parsing in transformObject "+e.getMessage());
    }

    openAppointment.put("slotId", appointmentObject.optString("SlotId"));
    openAppointment.put(PROVIDER_ID_KEY, providerId);
    openAppointment.put(LOCATION_ID_KEY, appointmentObject.optString("LocationId").substring(9));
    openAppointment.put("reasonId", getReasonId(appointmentObject));
    openAppointment.put("scheduleId", appointmentObject.optString("ScheduleId"));
    openAppointment.put(START_TIME, startTime);
    openAppointment.put("endTime", endTime);
    openAppointment.put(DATE_KEY, daDate);
    openAppointment.put(DURATION, valueOf(getTimeDiff(endTime, startTime, DOCASAP_TIME_FORMAT)));
    openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
    return openAppointment;
  }

  private String getReasonId(JSONObject appointmentObject) {
    String resonId = EMPTY;
    for (Object object : appointmentObject.getJSONArray("ApptReason")) {
      JSONObject reasonObject = new JSONObject(object.toString());
      if ((reasonObject.optString("Code")+PIPE).equals(requestPrameters.optString("reasonIdType"))) {
        resonId = reasonObject.optString("ApptReasonId");
        break;
      }
    }
    return resonId;
  }

  private JSONObject getinputObject() {
    JSONObject input = new JSONObject();
    try {
      setValue(input, "SchedulingData.Provider[0].ProviderId", "Practitioner/" + providerId);
      setValue(input, "temp.start_date",
              "ge" + availabilityRequest.getStartDate() + "&start=lt" + availabilityRequest.getEndDate());
      setValue(input, "temp.slot-type", requestPrameters.optString("slotType"));
      setValue(input, "Count", requestPrameters.optString("count"));
    } catch (IHubException e) {
      log.error("error while building input object {}", e.getMessage());
      throw new IllegalArgumentException("Error  while parsing in transformObject "+e.getMessage());
    }
    return input;
  }

  private JSONObject getNifiPayload() {
    JSONObject nifiObject = new JSONObject();
    nifiObject.put(STARTDATE, startDate);
    nifiObject.put(ENDDATE, endDate);
    nifiObject.put(FRAGMENT_ID_KEY, providerId);
    return nifiObject;
  }

  @SneakyThrows
  private static String convertDateFormatCerner(String originalDate, String oldFormat,
                                                String newFormat, String cernerTimeZone, String clientTimeZone) {
    DateFormat originalFormat = new SimpleDateFormat(oldFormat, Locale.ENGLISH);
    originalFormat.setTimeZone(TimeZone.getTimeZone(cernerTimeZone));

    DateFormat targetFormat = new SimpleDateFormat(newFormat);
    targetFormat.setTimeZone(TimeZone.getTimeZone(clientTimeZone));

    String formattedDate = null;
    Date date = originalFormat.parse(originalDate);
    formattedDate = targetFormat.format(date); // 20120821
    return formattedDate;
  }
}
