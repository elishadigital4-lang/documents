package com.pes.integration.cerner.service.open.impl;

import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.cerner.task.OpenAppointmentSupplier;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;

import static com.pes.integration.cerner.constant.CernerConstants.REASON_ID_LIST;
import static com.pes.integration.cerner.constant.CernerEngineConstants.CERNER_CONFIG;
import static com.pes.integration.cerner.constant.CernerEngineConstants.COUNT;
import static com.pes.integration.constant.CharacterConstants.COMMA;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.constant.UtilitiesConstants.ORG_CONFIG;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.Thread.currentThread;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static java.util.Objects.nonNull;
import static java.util.stream.Collectors.toList;
import static org.slf4j.MDC.put;

@Slf4j
@Qualifier(OPEN_APPOINTMENT)
@Service
public class OpenAppointmentServiceImpl extends AppointmentService {

  @Value("${configuration.api.threadsize}")
  private String threadSize;

  @Value("${application.data.path}")
  private String dataLocation;

  @Autowired
  private FileUploader fileUploader;

  @Autowired
  private EventTracker trackEvents;

  @Autowired
  private CernerApiCaller cernerApiCaller;

  @Autowired
  DataCacheManager dataCacheManager;

  @Override
  public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
    return null;
  }

  @Override
  public JSONArray getAvailability(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap,
                                   String epmPrefix) throws JsonProcessingException, IHubException {
    if (availabilityRequest.getIndex().equals(valueOf(FIRST_INDEX))) {
      trackEvents.trackEvent(availabilityRequest, OPEN_APPOINTMENT_PROCESSING_STARTED,
          format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
          getFragmentsDetails(availabilityRequest, providerLocationMap));
    }
    fetchOpenAppointments(providerLocationMap, availabilityRequest, epmPrefix);
    return null;
  }

  private void fetchOpenAppointments(Map<String, JSONArray> providerLocationMap,
                                     AvailabilityRequest availabilityRequest, String epmPrefix) throws IHubException {
    JSONArray providerList = new JSONArray();
    String deploymentId = availabilityRequest.getDeploymentId();
    String apptTypeIdList = dataCacheManager.getConfiguration(epmPrefix, deploymentId, UtilitiesConstants.FILTER_CONFIG,
            "appt_type_filter");
    String configuredPoolSize = dataCacheManager.getConfiguration(epmPrefix, deploymentId, CERNER_CONFIG, MAX_POOL_SIZE);
    String maxPoolSize = !isEmpty(configuredPoolSize) ? configuredPoolSize : threadSize;

    if (nonNull(availabilityRequest.getEntityId())) {
      JSONArray providers = new JSONArray(availabilityRequest.getEntityId().toString());
      providerList.putAll(providers);
      maxPoolSize = valueOf(ONE);
    } else {
      providerList = providerLocationMap.get(PROVIDER_ID_LIST);
      maxPoolSize = !isEmpty(configuredPoolSize) ? configuredPoolSize : threadSize;
    }
    JSONObject inputObject = getInputObject(availabilityRequest.getStartDate(), availabilityRequest.getEndDate(),
            providerLocationMap, epmPrefix, deploymentId);
    if (providerList != null && apptTypeIdList != null) {
      ExecutorService executorService = newFixedThreadPool(parseInt(maxPoolSize));
      List<CompletableFuture<Void>> openApptFutureList = new ArrayList<>();
      try {
        providerList.forEach(provider -> {
            inputObject.put("provider", provider.toString());
            openApptFutureList.add(CompletableFuture
                    .supplyAsync(new OpenAppointmentSupplier(cernerApiCaller, fileUploader,
                            trackEvents, inputObject, availabilityRequest), executorService));
        });
        CompletableFuture<Void> openApptAllFutures = CompletableFuture
            .allOf(openApptFutureList.toArray(new CompletableFuture[openApptFutureList.size()]));
        CompletableFuture<List<Void>> openApptAllCompletableFuture =
                openApptAllFutures.thenApply(future -> openApptFutureList.stream()
                    .map(CompletableFuture<Void>::join).collect(toList()));
        CompletableFuture<List<Void>> openApptCompletableFuture =
            openApptAllCompletableFuture.toCompletableFuture();
        openApptCompletableFuture.get();
      } catch (ExecutionException ee) {
        log.error("Error in getting the slotId " + ee);
        throw new EpmApiCallerException("Error in getting the slot " + ee.getMessage());
      } catch (InterruptedException ie) {
        log.error("Error in getting the slotId " + ie);
        currentThread().interrupt();
      } finally {
        executorService.shutdown();
      }
    }
  }

  private JSONObject getInputObject(String startDate, String endDate, Map<String, JSONArray> providerLocationMap,
                                    String epmPrefix, String deploymentId) throws IHubException {
    JSONObject inputObject = new JSONObject();
    inputObject.put(STARTDATE, startDate);
    inputObject.put(ENDDATE, endDate);
    inputObject.put(APPOINTMENT_PATH, dataLocation);
    inputObject.put("cernerTimeZone", dataCacheManager.getStoredComponentConfig(epmPrefix, CERNER_CONFIG, "timezone", false));
    inputObject.put("clientTimeZone", dataCacheManager.getStoredProvidersConfig(epmPrefix, deploymentId, CERNER_CONFIG, "timezone", false));
    String reasonIdType = dataCacheManager.getConfiguration(epmPrefix, deploymentId, CERNER_CONFIG, "reasonIdType");
    inputObject.put("reasonIdType", reasonIdType);
    if (dataCacheManager.getConfiguration(epmPrefix, deploymentId, UtilitiesConstants.GENERIC_CONFIG, PULL_FILTER).equals("true")) {
      inputObject.put("slotType", getSlotType(reasonIdType, providerLocationMap));
    } else {
      inputObject.put("slotType", dataCacheManager.getConfiguration(epmPrefix, deploymentId, UtilitiesConstants.FILTER_CONFIG, "appt_type_filter"));
    }
    inputObject.put("count", dataCacheManager.getConfiguration(epmPrefix, deploymentId, CERNER_CONFIG, COUNT));
    return inputObject;
  }

  private String getSlotType(String reasonIdType, Map<String, JSONArray> providerLocationMap) {
    StringBuilder slotType = new StringBuilder();
    JSONArray reasonIdList = providerLocationMap.get(REASON_ID_LIST);
    reasonIdList
        .forEach(reason -> slotType.append(reasonIdType).append(reason.toString()).append(COMMA));
    return slotType.substring(0, slotType.length() - 1);
  }

  private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest,
      Map<String, JSONArray> providerLocationMap) {
    Map<String, Object> providerDetails = new HashMap<>();
    providerDetails.put(TOTAL_FRAGMENTS, providerLocationMap.get(PROVIDER_ID_LIST).length());
    providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
    put(TOTAL_FRAGMENTS, String.valueOf(providerLocationMap.get(PROVIDER_ID_LIST).length()));
    put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
    return providerDetails;
  }
}
