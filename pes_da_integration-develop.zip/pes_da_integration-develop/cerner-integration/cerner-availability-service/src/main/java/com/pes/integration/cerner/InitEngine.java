package com.pes.integration.cerner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.cerner.consumer.BookedAppointmentConsumer;
import com.pes.integration.cerner.consumer.OpenAppointmentConsumer;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.RefreshBaseInitEngine;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class InitEngine implements RefreshBaseInitEngine {

    @Autowired
    CernerInitEngine cernerInitEngine;

    @PostConstruct
    public void init() throws IHubException {
        cernerInitEngine.init();
    }
}