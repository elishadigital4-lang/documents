package com.pes.integration.cerner.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.adapter.Utils;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.AppointmentService;
import org.json.JSONArray;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class BookedAppointmentConsumerTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private AvailabilityRequest availabilityRequest;

    @InjectMocks
    private BookedAppointmentConsumer bookedAppointmentConsumer;

    @Mock
    private AppointmentService bookedAppointmentService;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);

        this.availabilityRequest = spy(new AvailabilityRequest());
        this.bookedAppointmentConsumer = spy(new BookedAppointmentConsumer());
        this.bookedAppointmentService = mock(AppointmentService.class);

        this.objectMapper = mock(ObjectMapper.class);

        Field objectMapperField = BookedAppointmentConsumer.class.getDeclaredField("objectMapper");
        objectMapperField.setAccessible(true);
        objectMapperField.set(this.bookedAppointmentConsumer, this.objectMapper);

        Field bookedAppointmentServiceField = BookedAppointmentConsumer.class.getDeclaredField("bookedAppointmentService");
        bookedAppointmentServiceField.setAccessible(true);
        bookedAppointmentServiceField.set(this.bookedAppointmentConsumer, bookedAppointmentService);

        Field trackEventsField = BookedAppointmentConsumer.class.getDeclaredField("trackEvents");
        trackEventsField.setAccessible(true);
        trackEventsField.set(this.bookedAppointmentConsumer, this.trackEvents);
    }

    @Test
    public void testConsume() throws JsonProcessingException, IHubException, NoSuchMethodException {

        Mockito.when(this.objectMapper.readValue("", AvailabilityRequest.class))
                .thenReturn(this.availabilityRequest);

        Method getMessageControlIdMethod = AvailabilityRequest.class.getDeclaredMethod("getMessageControlId");
        getMessageControlIdMethod.setAccessible(true);
        lenient().when(availabilityRequest.getMessageControlId()).thenReturn("testMessageControlId");
        Mockito.when(this.bookedAppointmentService.getAppointments(this.availabilityRequest,
                CernerEngineConstants.EPM_NAME_PREFIX)).thenReturn(new JSONArray());


        try (MockedStatic<Utils> utilsMockedStatic =  mockStatic(Utils.class)) {
            utilsMockedStatic.when(() -> Utils.validateInput(this.availabilityRequest)).thenAnswer(invocation -> null);
            bookedAppointmentConsumer.consume("");
            utilsMockedStatic.verify(() -> Utils.validateInput(this.availabilityRequest), times(1));
        }

        Mockito.verify(this.objectMapper, times(1))
                .readValue("", AvailabilityRequest.class);

        Mockito.verify(this.bookedAppointmentService, times(1))
                .getAppointments(availabilityRequest, CernerEngineConstants.EPM_NAME_PREFIX);
    }

    @Test
    public void testConsumeThrowsJsonProcessingException() throws JsonProcessingException {
        String exceptionMessage = "this is JsonProcessingException";
        JsonProcessingException jsonProcessingException = mock(JsonProcessingException.class);
        Mockito.when(jsonProcessingException.getMessage()).thenReturn(exceptionMessage);

        Mockito.when(this.objectMapper.
                readValue("", AvailabilityRequest.class)).thenThrow(jsonProcessingException);

        try (MockedStatic<Utils> utilsMockedStatic =  mockStatic(Utils.class)) {
            utilsMockedStatic.when(() -> Utils.trackBookedSliceError(null, trackEvents,
                    "Error while parsing the request null"+exceptionMessage)).thenAnswer(invocation -> null);
            bookedAppointmentConsumer.consume("");
            utilsMockedStatic.verify(() -> Utils.trackBookedSliceError(null, trackEvents,
                    "Error while parsing the request null"+exceptionMessage), times(1));
        }
    }

    @Test
    public void testConsumeThrowsExceptionWithCause() throws JsonProcessingException, IHubException {
        String throwableMessage = "this is throwable";
        Throwable throwable = mock(Throwable.class);
        Mockito.when(throwable.getMessage()).thenReturn(throwableMessage);

        IHubException exception = mock(IHubException.class);
        Mockito.when(exception.getCause()).thenReturn(throwable);

        Mockito.when(this.objectMapper.readValue("", AvailabilityRequest.class))
                .thenReturn(this.availabilityRequest);

        lenient().when(availabilityRequest.getMessageControlId()).thenReturn("testMessageControlId");
        Mockito.when(this.bookedAppointmentService.getAppointments(this.availabilityRequest,
                CernerEngineConstants.EPM_NAME_PREFIX)).thenThrow(exception);

        try (MockedStatic<Utils> utilsMockedStatic =  mockStatic(Utils.class)) {
            utilsMockedStatic.when(() -> Utils.validateInput(this.availabilityRequest)).thenAnswer(invocation -> null);
            utilsMockedStatic.when(() -> Utils.trackBookedSliceError(this.availabilityRequest, trackEvents,
                    "Error in processing the Booked Appointment data , Details: "+throwableMessage))
                    .thenAnswer(invocation -> null);
            bookedAppointmentConsumer.consume("");
            utilsMockedStatic.verify(() -> Utils.trackBookedSliceError(this.availabilityRequest, trackEvents,
                    "Error in processing the Booked Appointment data , Details: "+throwableMessage),
                    times(1));
        }

    }

    @Test
    public void testConsumeThrowsExceptionWithNoCause() throws JsonProcessingException, IHubException {
        IHubException exception = mock(IHubException.class);
        Mockito.when(exception.getCause()).thenReturn(null);

        Mockito.when(this.objectMapper.readValue("", AvailabilityRequest.class))
                .thenReturn(this.availabilityRequest);

        lenient().when(availabilityRequest.getMessageControlId()).thenReturn("testMessageControlId");
        Mockito.when(this.bookedAppointmentService.getAppointments(this.availabilityRequest,
                CernerEngineConstants.EPM_NAME_PREFIX)).thenThrow(exception);

        try (MockedStatic<Utils> utilsMockedStatic =  mockStatic(Utils.class)) {
            utilsMockedStatic.when(() -> Utils.validateInput(this.availabilityRequest)).thenAnswer(invocation -> null);
            utilsMockedStatic.when(() -> Utils.trackBookedSliceError(this.availabilityRequest, trackEvents,
                            "Error in processing the Booked Appointment data , Details: No Cause is available for the exception"))
                    .thenAnswer(invocation -> null);
            bookedAppointmentConsumer.consume("");
            utilsMockedStatic.verify(() -> Utils.trackBookedSliceError(this.availabilityRequest, trackEvents,
                            "Error in processing the Booked Appointment data , Details: No Cause is available for the exception"),
                    times(1));
        }
    }

    @Test
    public void testSetObjectMapper()
    {
        bookedAppointmentConsumer.setObjectMapper(this.objectMapper);
    }
}
