package com.pes.integration.cerner.service.booked.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.task.BookedAppointmentSupplier;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.cerner.constant.CernerEngineConstants.*;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_PROCESSING_STARTED;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookedAppointmentServiceImplTest {

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private BookedAppointmentSupplier bookedAppointmentSupplier;

    @Mock
    private CernerApiCaller cernerApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    Map<String, File> appointmentDataFiles;

    JSONObject bookedApptOutput;

    @Mock
    private AvailabilityRequest availabilityRequest;

    @InjectMocks
    private BookedAppointmentServiceImpl bookedAppointmentServiceImpl;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        MockitoAnnotations.openMocks(this);
        this.appointmentDataFiles = new HashMap<>();
        this.bookedApptOutput = new JSONObject();

        this.bookedAppointmentSupplier = mock(BookedAppointmentSupplier.class);
        this.availabilityRequest = mock(AvailabilityRequest.class);
        this.bookedAppointmentServiceImpl = spy(new BookedAppointmentServiceImpl());
        Field objectMapperField =AppointmentService.class.getDeclaredField("objectMapper");
        objectMapperField.setAccessible(true);
        objectMapperField.set(this.bookedAppointmentServiceImpl, objectMapper);

        Field trackEventsField =BookedAppointmentServiceImpl.class.getDeclaredField("trackEvents");
        trackEventsField.setAccessible(true);
        trackEventsField.set(this.bookedAppointmentServiceImpl, this.trackEvents);

        Field dataLocationField =BookedAppointmentServiceImpl.class.getDeclaredField("dataLocation");
        dataLocationField.setAccessible(true);
        dataLocationField.set(this.bookedAppointmentServiceImpl, "");

        Field cernerApiCallerField =BookedAppointmentServiceImpl.class.getDeclaredField("cernerApiCaller");
        cernerApiCallerField.setAccessible(true);
        cernerApiCallerField.set(this.bookedAppointmentServiceImpl, this.cernerApiCaller);

        Field fileUploaderField =BookedAppointmentServiceImpl.class.getDeclaredField("fileUploader");
        fileUploaderField.setAccessible(true);
        fileUploaderField.set(this.bookedAppointmentServiceImpl, this.fileUploader);
    }

    @Test
    public void testGetAvailability() throws Exception {
        lenient().when(availabilityRequest.getIndex()).thenReturn("1");
        Mockito.when(this.objectMapper.writeValueAsString(availabilityRequest)).thenReturn("availabilityRequest");
        Map<String, Object> providerDetails = new HashMap<>();
        providerDetails.put(TOTAL_FRAGMENTS, "1");
        providerDetails.put(TOTAL_SLICES, "10");

        Mockito.when(availabilityRequest.getTotalSlices()).thenReturn("10");

       Mockito.doNothing().when(this.trackEvents).trackEvent(availabilityRequest, BOOKED_APPOINTMENT_PROCESSING_STARTED,
                "Booked Appointment request has been received with input availabilityRequest", providerDetails);

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray locationJsonArray = new JSONArray();
        providerLocationMap.put(PROVIDER_ID_LIST, locationJsonArray);

        String startDate = "2024-10-09";
        String endDate = "2024-11-09";
        String epmPrefix = "cn";
        String deploymentId = "74415^001";

        Mockito.when(availabilityRequest.getStartDate()).thenReturn(startDate);
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn(deploymentId);
        Mockito.when(availabilityRequest.getEndDate()).thenReturn(endDate);

        Field dataCacheManagerField =BookedAppointmentServiceImpl.class.getDeclaredField("dataCacheManager");
        dataCacheManagerField.set(this.bookedAppointmentServiceImpl, this.dataCacheManager);

        Mockito.when(this.dataCacheManager.getConfiguration(epmPrefix, deploymentId, CERNER_CONFIG, COUNT))
                .thenReturn("10");


        JSONArray result = bookedAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, epmPrefix);

        Assertions.assertNull(result);
    }
    @Test
    public void testGetAvailabilityIndex() throws Exception {
        Mockito.when(availabilityRequest.getIndex()).thenReturn("2");
        Map<String, Object> providerDetails = new HashMap<>();
        providerDetails.put(TOTAL_FRAGMENTS, "1");
        providerDetails.put(TOTAL_SLICES, "10");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray locationJsonArray = new JSONArray();
        providerLocationMap.put(PROVIDER_ID_LIST, locationJsonArray);

        String startDate = "2024-10-09";
        String endDate = "2024-11-09";
        String epmPrefix = "cn";
        String deploymentId = "74415^001";

        Mockito.when(availabilityRequest.getStartDate()).thenReturn(startDate);
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn(deploymentId);
        Mockito.when(availabilityRequest.getEndDate()).thenReturn(endDate);

        Field dataCacheManagerField =BookedAppointmentServiceImpl.class.getDeclaredField("dataCacheManager");
        dataCacheManagerField.set(this.bookedAppointmentServiceImpl, this.dataCacheManager);

        Mockito.when(this.dataCacheManager.getConfiguration(epmPrefix, deploymentId, CERNER_CONFIG, COUNT))
                .thenReturn("10");

        JSONArray result = bookedAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, epmPrefix);

        Assertions.assertNull(result);
    }
    @Test
    public void testFetchBookedAppointments_InvalidIdException() throws Exception {
        JSONArray locationJsonArray = new JSONArray();
        String epmPrefix = "cn";
        Mockito.when(availabilityRequest.getStartDate()).thenReturn("2024-10-09");
        Mockito.when(availabilityRequest.getEndDate()).thenReturn("2024-11-09");
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^001");

        Method method = BookedAppointmentServiceImpl.class.getDeclaredMethod("fetchBookedAppointments", JSONArray.class, AvailabilityRequest.class, String.class);
        method.setAccessible(true);

        Field dataCacheManagerField =BookedAppointmentServiceImpl.class.getDeclaredField("dataCacheManager");
        dataCacheManagerField.set(this.bookedAppointmentServiceImpl, this.dataCacheManager);
        Mockito.when(this.dataCacheManager.getConfiguration(epmPrefix, "74415^001", CERNER_CONFIG, COUNT))
                .thenReturn("10");
        Mockito.doThrow(new InvalidIdException("Invalid ID")).when(cernerApiCaller).call(eq("74415^001"),eq(ApiName.BOOKED_APPOINTMENTS.getKey()),eq(new JSONObject()), eq(""));

        assertThrows(Exception.class, () -> {
            method.invoke(bookedAppointmentServiceImpl, locationJsonArray, availabilityRequest, epmPrefix);
        });
    }

    @Test
    public void testGetRealTimeAvailability()
    {
        RealTimeRequest realTimeRequest = mock(RealTimeRequest.class);
        JSONObject result = bookedAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest);

        Assertions.assertNull(result);
    }
}
