package com.pes.integration.cerner.task;

import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.util.CernerUtil;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

import static com.pes.integration.constant.EpmConstant.TOTAL_FRAGMENTS;
import static com.pes.integration.enums.DataflowStatus.PULL_OPEN_APPOINTMENT_FRAGMENT;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OpenAppointmentSupplierTest {

    @Mock
    private CernerApiCaller cernerApiCaller;

    @Mock
    private FileUploader fileUploader;

    private EventTracker trackEvents;

    private String startDate;

    private String endDate;

    private String providerId;

    private String dataLocation;

    Map<String, File> appointmentDataFiles;

    JSONObject openApptOutput;

    @Mock
    private AvailabilityRequest availabilityRequest;

    private OpenAppointmentSupplier openAppointmentSupplier;

    @BeforeEach
    public void setUp()
    {
        MockitoAnnotations.openMocks(this);
        JSONObject inputObject = new JSONObject();
        this.trackEvents = mock(EventTracker.class);
        this.availabilityRequest = mock(AvailabilityRequest.class);

        startDate = "2024-10-09";
        endDate = "2024-11-09";
        providerId = "1234";

        inputObject.put("startDate", startDate);
        inputObject.put("endDate", endDate);
        inputObject.put("provider", providerId);
        inputObject.put("appointmentPath", "src/test/resources/");
        inputObject.put("count", "100");
        inputObject.put("slotType",Arrays.toString(IntStream.rangeClosed(1, 80).toArray()));

        this.appointmentDataFiles = new HashMap<>();
        this.openApptOutput = new JSONObject();

        this.openAppointmentSupplier = spy(new OpenAppointmentSupplier(cernerApiCaller, fileUploader,
                trackEvents, inputObject, availabilityRequest));
    }

    @Test
    public void testGet() throws Exception {
        JSONObject openAppointment = new JSONObject("{\"temp\": {\"start_time\": \"2024-10-09T10:20:00.000Z\", " +
                "\"end_time\": \"2024-10-09T11:20:00.000Z\"}, \"Duration\": \"60\", \"ExternalApptId\":\"1234\", " +
                "\"ProviderId\": \"4567\", \"LocationId\":\"786576543787989765987654\", \"ScheduleId\":\"89765987654\", " +
                "\"Reference\": [\"Practitioner/1\"], \"ApptReason\": [ {\"Code\": \"12345\",\"ApptReasonId\": \"656789\"}]}");
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^0001");
        Mockito.when(cernerApiCaller.call(anyString(), anyString(), any(), anyString()))
                .thenReturn(new JSONObject().put("OpenAppointments", new JSONArray().put(openAppointment)));

        Mockito.when(availabilityRequest.getAppointmentType()).thenReturn("testAppointmentType");
        Mockito.when(availabilityRequest.getMessageControlId()).thenReturn("testMessageControlId");
        Mockito.when(availabilityRequest.getSliceId()).thenReturn("testSliceId");
        Mockito.when(availabilityRequest.getIndex()).thenReturn("index10");
        Map<String, Object> openDataFiles = new HashMap<>();
        openDataFiles.put("endDate", "2024-11-09");
        openDataFiles.put("fragmentId", "1234");
        openDataFiles.put("startDate", "2024-10-09");

        try (MockedStatic<CernerUtil> cernerUtilMockedStatic =  mockStatic(CernerUtil.class)) {
            try (MockedStatic<MDC> mdcMockedStatic =  mockStatic(MDC.class)) {
                mdcMockedStatic.when(() -> MDC.get(TOTAL_FRAGMENTS)).thenReturn("2");
                cernerUtilMockedStatic.when(() -> CernerUtil.trackEventToNifi(this.trackEvents, this.availabilityRequest,
                                PULL_OPEN_APPOINTMENT_FRAGMENT, "2", "1234", openDataFiles))
                        .thenAnswer(invocation -> null);
                openAppointmentSupplier.get();
                cernerUtilMockedStatic.verify(() -> CernerUtil.trackEventToNifi(this.trackEvents, this.availabilityRequest,
                                PULL_OPEN_APPOINTMENT_FRAGMENT, "2", "1234", openDataFiles),
                        times(1));
                mdcMockedStatic.verify(() -> MDC.get(TOTAL_FRAGMENTS), times(1));
            }
        }
    }

    @Test
    public void testGetThrowsException() throws Exception {
        JSONObject openAppointment = new JSONObject("{\"temp\": {\"start_time\": \"2024-10-09T10:20:00.000Z\", " +
                "\"end_time\": \"2024-10-09T11:20:00.000Z\"}, \"Duration\": \"60\", \"ExternalApptId\":\"1234\", " +
                "\"ProviderId\": \"4567\", \"LocationId\":\"786576543787989765987654\", \"ScheduleId\":\"89765987654\", " +
                "\"Reference\": [\"Practitioner/1\"], \"ApptReason\": [ {\"Code\": \"12345\",\"ApptReasonId\": \"656789\"}]}");

        when(availabilityRequest.getDeploymentId()).thenReturn("74415^0001");
        when(cernerApiCaller.call(anyString(), anyString(), any(), anyString()))
                .thenThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), "Error while calling cerner api"));

        when(availabilityRequest.getIndex()).thenReturn("index10");

        Map<String, Object> openDataFiles = new HashMap<>();
        openDataFiles.put("endDate", "2024-11-09");
        openDataFiles.put("fragmentId", "1234");
        openDataFiles.put("startDate", "2024-10-09");

        openAppointmentSupplier.get();
    }
}



