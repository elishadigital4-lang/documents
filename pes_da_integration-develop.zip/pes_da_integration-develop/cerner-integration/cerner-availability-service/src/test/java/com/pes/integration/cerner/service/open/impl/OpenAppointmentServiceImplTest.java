package com.pes.integration.cerner.service.open.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.service.AppointmentService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static com.pes.integration.cerner.constant.CernerConstants.REASON_ID_LIST;
import static com.pes.integration.cerner.constant.CernerEngineConstants.CERNER_CONFIG;
import static com.pes.integration.cerner.constant.CernerEngineConstants.COUNT;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

@ExtendWith(MockitoExtension.class)
public class OpenAppointmentServiceImplTest {
    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private AvailabilityRequest availabilityRequest;

    @InjectMocks
    private OpenAppointmentServiceImpl openAppointmentServiceImpl;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        MockitoAnnotations.openMocks(this);

        Field objectMapperField =AppointmentService.class.getDeclaredField("objectMapper");
        objectMapperField.setAccessible(true);
        objectMapperField.set(this.openAppointmentServiceImpl, objectMapper);

        Field trackEventsField =OpenAppointmentServiceImpl.class.getDeclaredField("trackEvents");
        trackEventsField.setAccessible(true);
        trackEventsField.set(this.openAppointmentServiceImpl, this.trackEvents);
    }

    @Test
    public void testGetAvailability() throws Exception {
        Mockito.when(availabilityRequest.getEntityId()).thenReturn("[\"provider1\", \"provider2\", \"provider3\"]");
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^001");
        Mockito.when(availabilityRequest.getStartDate()).thenReturn("2025-01-09");
        Mockito.when(availabilityRequest.getEndDate()).thenReturn("2025-05-09");
        Mockito.when(availabilityRequest.getIndex()).thenReturn("1");
        Mockito.when(this.objectMapper.writeValueAsString(availabilityRequest)).thenReturn("availabilityRequest");
        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("provider1").put("provider2").put("provider3"));
        Map<String, Object> fragmentsSlices = new HashMap<>();
        fragmentsSlices.put("totalFragments", 3);
        fragmentsSlices.put("totalSlices", null);
        Mockito.doNothing().when(this.trackEvents).trackEvent(eq(availabilityRequest), eq(OPEN_APPOINTMENT_PROCESSING_STARTED),
                eq("Open Appointment request has been received with input availabilityRequest"), eq(fragmentsSlices));

        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(UtilitiesConstants.FILTER_CONFIG), eq("appt_type_filter")))
                .thenReturn("testApptTypeFilter");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(CERNER_CONFIG), eq(MAX_POOL_SIZE)))
                .thenReturn("4");
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("true");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");

        JSONArray result = openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "cn");
        assertNull(result);
    }

    @Test
    public void testFetchOpenAppointments() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", Map.class, AvailabilityRequest.class, String.class);
        method.setAccessible(true);

        Mockito.when(availabilityRequest.getEntityId()).thenReturn("[\"provider1\", \"provider2\", \"provider3\"]");
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^001");
        Mockito.when(availabilityRequest.getStartDate()).thenReturn("2025-01-09");
        Mockito.when(availabilityRequest.getEndDate()).thenReturn("2025-05-09");
        Mockito.when(availabilityRequest.getIndex()).thenReturn("1");


        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("provider1").put("provider2").put("provider3"));

        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(UtilitiesConstants.FILTER_CONFIG), eq("appt_type_filter")))
                .thenReturn("testApptTypeFilter");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(CERNER_CONFIG), eq(MAX_POOL_SIZE)))
                .thenReturn("4");
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("true");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");

        method.invoke(openAppointmentServiceImpl, providerLocationMap, availabilityRequest, "cn");
    }
    @Test
    public void testFetchOpenAppointmentsNullEntityID() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", Map.class, AvailabilityRequest.class, String.class);
        method.setAccessible(true);

        Mockito.when(availabilityRequest.getEntityId()).thenReturn(null);
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^001");
        Mockito.when(availabilityRequest.getStartDate()).thenReturn("2025-01-09");
        Mockito.when(availabilityRequest.getEndDate()).thenReturn("2025-05-09");
        Mockito.when(availabilityRequest.getIndex()).thenReturn("1");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("provider1").put("provider2").put("provider3"));

        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(UtilitiesConstants.FILTER_CONFIG), eq("appt_type_filter")))
                .thenReturn("testApptTypeFilter");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(CERNER_CONFIG), eq(MAX_POOL_SIZE)))
                .thenReturn("4");
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("true");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");

        method.invoke(openAppointmentServiceImpl, providerLocationMap, availabilityRequest, "cn");
    }
    @Test
    public void testFetchOpenAppointmentsExecutionException() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", Map.class, AvailabilityRequest.class, String.class);
        method.setAccessible(true);

        Mockito.when(availabilityRequest.getEntityId()).thenReturn("[\"provider1\", \"provider2\", \"provider3\"]");
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^001");
        Mockito.when(availabilityRequest.getStartDate()).thenReturn("2025-01-09");
        Mockito.when(availabilityRequest.getEndDate()).thenReturn("2025-05-09");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("provider1").put("provider2").put("provider3"));

        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(UtilitiesConstants.FILTER_CONFIG), eq("appt_type_filter")))
                .thenReturn("testApptTypeFilter");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(CERNER_CONFIG), eq(MAX_POOL_SIZE)))
                .thenReturn("4");
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("true");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");

        assertThrows(Exception.class, ()->method.invoke(openAppointmentServiceImpl, providerLocationMap, availabilityRequest, "cn"));

    }
    @Test
    public void testFetchOpenAppointmentsNullProviderListApptTypeIdList() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", Map.class, AvailabilityRequest.class, String.class);
        method.setAccessible(true);

        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^001");
        Mockito.when(availabilityRequest.getStartDate()).thenReturn("2025-01-09");
        Mockito.when(availabilityRequest.getEndDate()).thenReturn("2025-05-09");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, null);

        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(UtilitiesConstants.FILTER_CONFIG), eq("appt_type_filter")))
                .thenReturn(null);
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(CERNER_CONFIG), eq(MAX_POOL_SIZE)))
                .thenReturn("4");
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("true");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");

        method.invoke(openAppointmentServiceImpl, providerLocationMap, availabilityRequest, "cn");
    }
    @Test
    public void testFetchOpenAppointmentsInterruptedException() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("fetchOpenAppointments", Map.class, AvailabilityRequest.class, String.class);
        method.setAccessible(true);

        Mockito.when(availabilityRequest.getEntityId()).thenReturn("[\"provider1\", \"provider2\", \"provider3\"]");
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^001");
        Mockito.when(availabilityRequest.getStartDate()).thenReturn("2025-01-09");
        Mockito.when(availabilityRequest.getEndDate()).thenReturn("2025-05-09");
        Mockito.when(availabilityRequest.getIndex()).thenReturn("1");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("provider1").put("provider2").put("provider3"));

        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(UtilitiesConstants.FILTER_CONFIG), eq("appt_type_filter")))
                .thenReturn("testApptTypeFilter");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"), eq("74415^001"), eq(CERNER_CONFIG), eq(MAX_POOL_SIZE)))
                .thenReturn("4");
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("true");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");
       /* CompletableFuture openApptCompletableFuture  = mock(java.util.concurrent.CompletableFuture.class);
        Mockito.when(openApptCompletableFuture.get())
                .thenThrow(InterruptedException.class);*/

        method.invoke(openAppointmentServiceImpl, providerLocationMap, availabilityRequest, "cn");

    }

    @Test
    public void testGetInputObjectGenericConfig() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("getInputObject", String.class, String.class, Map.class, String.class, String.class);
        method.setAccessible(true);

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("1345").put("28765"));
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("true");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");

        JSONObject result = (JSONObject) method.invoke(openAppointmentServiceImpl, "2024-10-09", "2024-11-09", providerLocationMap, "cn", "74415^001");
        assertNotNull(result);
        assertEquals("testReasonIdType12,testReasonIdType23,testReasonIdType45,testReasonIdType56",
                getValue(result, "slotType").toString());
    }
    @Test
    public void testGetInputObjectFilterConfig() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("getInputObject", String.class, String.class, Map.class, String.class, String.class);
        method.setAccessible(true);

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("1345").put("28765"));
        Mockito.when(dataCacheManager.getStoredComponentConfig(eq("cn"),eq(CERNER_CONFIG),eq("timezone"), eq(false)))
                .thenReturn("CDT");
        Mockito.when(dataCacheManager.getStoredProvidersConfig(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("timezone"), eq(false)))
                .thenReturn("UTC");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq("reasonIdType")))
                .thenReturn("testReasonIdType");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.GENERIC_CONFIG),eq(PULL_FILTER)))
                .thenReturn("false");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(UtilitiesConstants.FILTER_CONFIG),eq("appt_type_filter")))
                .thenReturn("slots");
        Mockito.when(dataCacheManager.getConfiguration(eq("cn"),eq("74415^001"),eq(CERNER_CONFIG), eq(COUNT)))
                .thenReturn("10");

        JSONObject result = (JSONObject) method.invoke(openAppointmentServiceImpl, "2024-10-09", "2024-11-09", providerLocationMap, "cn", "74415^001");
        assertNotNull(result);
        assertEquals("slots",getValue(result, "slotType").toString());
    }

    @Test
    public void testGetSlotType() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("getSlotType", String.class, Map.class);
        method.setAccessible(true);

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);

        String result = (String) method.invoke(openAppointmentServiceImpl, "testReasonIdType", providerLocationMap);
        assertNotNull(result);
        assertEquals("testReasonIdType12,testReasonIdType23,testReasonIdType45,testReasonIdType56",result.toString());
    }

    @Test
    public void testGetFragmentsDetails() throws Exception {
        Method method = OpenAppointmentServiceImpl.class.getDeclaredMethod("getFragmentsDetails", AvailabilityRequest.class, Map.class);
        method.setAccessible(true);

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray reasonIdJsonArray = new JSONArray();
        reasonIdJsonArray.put(12).put(23).put(45).put(56);
        providerLocationMap.put(REASON_ID_LIST, reasonIdJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("1345").put("28765"));
        availabilityRequest.setTotalSlices("10");

        Map<String, Object> result = (Map<String, Object>) method.invoke(openAppointmentServiceImpl, availabilityRequest, providerLocationMap);
        assertNotNull(result);
        assertEquals("{totalFragments=2, totalSlices=null}",result.toString());
    }
    @Test
    public void testGetRealTimeAvailability()
    {
        RealTimeRequest realTimeRequest = mock(RealTimeRequest.class);
        JSONObject result = openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest);
        assertNull(result);
    }
}
