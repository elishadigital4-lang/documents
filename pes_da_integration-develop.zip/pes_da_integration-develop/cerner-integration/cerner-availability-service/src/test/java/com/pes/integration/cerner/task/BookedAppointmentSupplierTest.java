package com.pes.integration.cerner.task;

import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.util.CernerUtil;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.enums.DataflowStatus.PULL_BOOKED_APPOINTMENT_FRAGMENT;
import static java.lang.String.valueOf;
import static java.util.Collections.emptyMap;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookedAppointmentSupplierTest
{
    @Mock
    private CernerApiCaller cernerApiCaller;

    @Mock
    private FileUploader fileUploader;


    private String startDate;


    private String endDate;


    private String providers;
    private String nextUrlCount;

    private EventTracker trackEvents;

    Map<String, File> appointmentDataFiles;

    JSONObject bookedApptOutput;

    @Mock
    private AvailabilityRequest availabilityRequest;

    private BookedAppointmentSupplier bookedAppointmentSupplier;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
        JSONObject inputObject = new JSONObject();

        startDate = "2024-10-09";
        endDate = "2024-11-09";
        nextUrlCount = "100";
        providers = Arrays.toString(IntStream.rangeClosed(1, 210).toArray());

        this.appointmentDataFiles = new HashMap<>();
        this.bookedApptOutput = new JSONObject();

        inputObject.put("startDate", startDate);
        inputObject.put("endDate", endDate);
        inputObject.put("providers", providers);
        inputObject.put("count", nextUrlCount);
        inputObject.put("appointmentPath", "src/test/resources/");
        this.bookedAppointmentSupplier = spy(new BookedAppointmentSupplier(cernerApiCaller,  inputObject, fileUploader,
                trackEvents, availabilityRequest));

        Field trackEventsField =BookedAppointmentSupplier.class.getDeclaredField("trackEvents");
        trackEventsField.setAccessible(true);
        trackEventsField.set(this.bookedAppointmentSupplier, this.trackEvents);
    }

    @Test
    public void testProcessBookedAppointment() throws Exception {
        Mockito.when(availabilityRequest.getDeploymentId()).thenReturn("74415^0001");
        Mockito.when(cernerApiCaller.call(anyString(), anyString(), any(), anyString()))
                .thenReturn(new JSONObject().put("BookedAppointments", new JSONArray().put("{\"temp\": {\"start_time\": \"2024-10-09T10:20:00.000Z\"}, \"Duration\": \"60\", " +
                "\"ExternalApptId\":\"1234\", \"ProviderId\": \"4567\", \"LocationId\":\"7865\",  " +
                "\"Reference\": [\"Practitioner/1\"]}")));
        Mockito.when(availabilityRequest.getSliceId()).thenReturn("testSliceId");


        try (MockedStatic<CernerUtil> cernerUtilMockedStatic =  mockStatic(CernerUtil.class)) {
            cernerUtilMockedStatic.when(() -> CernerUtil.trackEventToNifi(this.trackEvents, this.availabilityRequest,
                    PULL_BOOKED_APPOINTMENT_FRAGMENT, valueOf(ONE), EMPTY, emptyMap())).thenAnswer(invocation -> null);
            bookedAppointmentSupplier.processBookedAppointment();
            cernerUtilMockedStatic.verify(() -> CernerUtil.trackEventToNifi(this.trackEvents, this.availabilityRequest,
                    PULL_BOOKED_APPOINTMENT_FRAGMENT, valueOf(ONE), EMPTY, emptyMap()), times(1));
        }
    }
}
