package com.pes.integration.cerner.handler;

import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.component.HandlerUtils;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;

import static com.pes.integration.cerner.api.ApiName.GET_PATIENT;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MatchPatientHandlerTest {

    @Mock
    protected DataCacheManager dataCacheManager;

    @Mock
    CernerApiCaller cernerApiCaller;

    @InjectMocks
    private MatchPatientHandler matchPatientHandler;

    String deploymentId;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        MockitoAnnotations.openMocks(this);
        this.matchPatientHandler = spy(new MatchPatientHandler());

        Field cernerApiCallerField =MatchPatientHandler.class.getDeclaredField("cernerApiCaller");
        cernerApiCallerField.setAccessible(true);
        cernerApiCallerField.set(this.matchPatientHandler, this.cernerApiCaller);

        Field deploymentIdField =MatchPatientHandler.class.getDeclaredField("deploymentId");
        deploymentIdField.setAccessible(true);
        deploymentIdField.set(this.matchPatientHandler, this.deploymentId);
    }

    @Test
    public void testGetPatients() throws IHubException
    {

        JSONObject inputObject = new JSONObject().put("deployment_id","74415^0001").put("flowName","d2e");
        JSONObject expectedOutputObject = new JSONObject();
        JSONObject outputObject = new JSONObject();

        Mockito.when(this.cernerApiCaller.call("74415^0001",GET_PATIENT.getKey(), inputObject,
                inputObject.optString("flowName"))).thenReturn(outputObject);

        JSONObject result = this.matchPatientHandler.getPatients(inputObject);

        Assertions.assertTrue(expectedOutputObject.similar(result));
    }

    @Test
    public void testGetPatientsThrowsException() throws IHubException
    {

        JSONObject inputObject = new JSONObject().put("deployment_id","74415^0001");
        JSONObject expectedOutputObject = new JSONObject().put("Error", "this is error");
        Mockito.doThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), "this is error"))
                .when(this.cernerApiCaller).call("74415^0001",GET_PATIENT.getKey(), inputObject,
                        inputObject.optString("flowName"));

        JSONObject result = this.matchPatientHandler.getPatients(inputObject);

        Assertions.assertTrue(expectedOutputObject.similar(result));
    }

    @Test
    public void testGetPatientDemographicsDetails() throws Exception {
        JSONArray patientsArray = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"AddressType\":\"home\",\"Zip\":\"12345-3456\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"false\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"AddressType\":\"home\",\"Zip\":\"45345-9876\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"true\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");
        JSONArray expectedJson = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"12345\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\",\"AddressType\":\"home\"}],\"MaritalStatus\":\"\",\"Active\":\"false\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");

        Field dataCacheManagerField = MatchPatientHandler.class.getDeclaredField("cacheManager");
        dataCacheManagerField.setAccessible(true);
        dataCacheManagerField.set(this.matchPatientHandler, this.dataCacheManager);

        Field deploymentIdField = MatchPatientHandler.class.getDeclaredField("deploymentId");
        deploymentIdField.setAccessible(true);
        deploymentIdField.set(this.matchPatientHandler, "74415^0001");

        Object returnValue = "true";

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX,
                "74415^0001", UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.INACTIVE_PAT_CONF,
                        false)).thenReturn(returnValue);

        JSONArray result = this.matchPatientHandler.getPatientDemographicsDetails(patientsArray);

        Assertions.assertTrue(expectedJson.similar(result));
    }

    @Test
    public void testGetPatientDemographicsDetailsThrowsException() throws Exception {
        JSONArray patientsArray = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"AddressType\":\"home\",\"Zip\":\"12345-3456\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"false\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"AddressType\":\"home\",\"Zip\":\"45345-9876\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"true\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");
        JSONArray expectedJson = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"12345\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\",\"AddressType\":\"home\"}],\"MaritalStatus\":\"\",\"Active\":\"false\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"45345\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\",\"AddressType\":\"home\"}],\"MaritalStatus\":\"\",\"Active\":\"true\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");

        Field dataCacheManagerField = MatchPatientHandler.class.getDeclaredField("cacheManager");
        dataCacheManagerField.setAccessible(true);
        dataCacheManagerField.set(this.matchPatientHandler, this.dataCacheManager);

        Field deploymentIdField = MatchPatientHandler.class.getDeclaredField("deploymentId");
        deploymentIdField.setAccessible(true);
        deploymentIdField.set(this.matchPatientHandler, "74415^0001");


        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX,
                "74415^0001", UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.INACTIVE_PAT_CONF,
                false)).thenThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), "this is error"));

        JSONArray result = this.matchPatientHandler.getPatientDemographicsDetails(patientsArray);

        Assertions.assertTrue(expectedJson.similar(result));
    }

    @Test
    public void testGetPatientDemographicsDetailsThrowsAnotherException() throws Exception {
        JSONArray patientsArray = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"AddressType\":\"home\",\"Zip\":\"12345-3456\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"false\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"AddressType\":\"home\",\"Zip\":\"45345-9876\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"true\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");
        JSONArray expectedJson = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"12345\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\",\"AddressType\":\"home\"}],\"MaritalStatus\":\"\",\"Active\":\"false\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");

        Field dataCacheManagerField = MatchPatientHandler.class.getDeclaredField("cacheManager");
        dataCacheManagerField.setAccessible(true);
        dataCacheManagerField.set(this.matchPatientHandler, this.dataCacheManager);

        Field deploymentIdField = MatchPatientHandler.class.getDeclaredField("deploymentId");
        deploymentIdField.setAccessible(true);
        deploymentIdField.set(this.matchPatientHandler, "74415^0001");

        Object returnValue = "true";

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX,
                "74415^0001", UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.INACTIVE_PAT_CONF,
                false)).thenReturn(returnValue);

        try (MockedStatic<HandlerUtils> utilsMockedStatic =  mockStatic(HandlerUtils.class)) {
            utilsMockedStatic.when(() -> HandlerUtils.updateE2DPhones(Mockito.any()))
                    .thenThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), "this is error"));
            JSONArray result = this.matchPatientHandler.getPatientDemographicsDetails(patientsArray);
            Assertions.assertTrue(expectedJson.similar(result));
            utilsMockedStatic.verify(() -> HandlerUtils.updateE2DPhones(Mockito.any()), times(2));
        }
    }

    @Test
    public void testGetPatientDemographicsDetailsGetAddress() throws Exception {
        JSONArray patientsArray = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Active\":\"false\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[],\"Active\":\"true\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"AddressType\":\"office\",\"Zip\":\"45345-9876\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"true\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"45345-9876\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}],\"Active\":\"true\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");
        JSONArray expectedJson = new JSONArray("[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"MaritalStatus\":\"\",\"Active\":\"false\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]");

        Field dataCacheManagerField = MatchPatientHandler.class.getDeclaredField("cacheManager");
        dataCacheManagerField.setAccessible(true);
        dataCacheManagerField.set(this.matchPatientHandler, this.dataCacheManager);

        Field deploymentIdField = MatchPatientHandler.class.getDeclaredField("deploymentId");
        deploymentIdField.setAccessible(true);
        deploymentIdField.set(this.matchPatientHandler, "74415^0001");

        Object returnValue = "true";

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX,
                "74415^0001", UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.INACTIVE_PAT_CONF,
                false)).thenReturn(returnValue);

        JSONArray result = this.matchPatientHandler.getPatientDemographicsDetails(patientsArray);

        Assertions.assertTrue(expectedJson.similar(result));
    }

    @Test
    public void testIsSingleMatch() throws Exception
    {
        Assertions.assertFalse(this.matchPatientHandler.isSingleMatch());
    }
}
