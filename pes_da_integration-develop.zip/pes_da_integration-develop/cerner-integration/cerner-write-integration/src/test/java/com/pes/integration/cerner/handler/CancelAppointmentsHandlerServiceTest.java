package com.pes.integration.cerner.handler;


import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CancelAppointmentsHandlerServiceTest
{
    @Mock
    CernerApiCaller cernerApiCaller;

    @InjectMocks
    private CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        this.cancelAppointmentsHandlerService = spy(new CancelAppointmentsHandlerService());

        Field cernerApiCallerField =CancelAppointmentsHandlerService.class.getDeclaredField("cernerApiCaller");
        cernerApiCallerField.setAccessible(true);
        cernerApiCallerField.set(this.cancelAppointmentsHandlerService, this.cernerApiCaller);

    }

    @Test
    public void testGetAppointmentDetail() throws Exception {
        CancelAppointmentsHandlerService service = new CancelAppointmentsHandlerService();
        CernerApiCaller mockCaller = Mockito.mock(CernerApiCaller.class);

        // Use reflection to inject the mock
        Field field = CancelAppointmentsHandlerService.class.getDeclaredField("cernerApiCaller");
        field.setAccessible(true);
        field.set(service, mockCaller);

        String appointmentId = "appt123";
        String deploymentId = "dep456";
        JSONObject responseJson = new JSONObject();
        responseJson.put("VersionId", "v1");

        Mockito.when(mockCaller.call(
                Mockito.eq(deploymentId),
                Mockito.eq(ApiName.GET_APPOINTMENT.getKey()),
                Mockito.any(JSONObject.class),
                Mockito.eq(Flow.CANCEL_APPOINTMENT.getKey())
        )).thenReturn(responseJson);

        java.lang.reflect.Method method = CancelAppointmentsHandlerService.class.getDeclaredMethod("getAppointmentDetail", String.class, String.class);
        method.setAccessible(true);
        String versionId = (String) method.invoke(service, appointmentId, deploymentId);
        Assertions.assertEquals("v1", versionId);        Assertions.assertEquals("v1", versionId);
    }

    @Test
    public void testCancelAppointment() throws IHubException {
        JSONObject inputObject = new JSONObject("{\"message_type\":\"CancelAppt\",\"deployment_id\":\"74468^0001\",\"message_control_id\":\"49042317\",\"ResponseMode\":\"\",\"AppId\":\"\",\"OrgInfo\":{\"OrgId\":67076,\"SiuWriteRemoteIp\":\"172.19.2.21\",\"SiuWritePort\":23456,\"AdtWriteProtocol\":\"0\",\"OrgCode\":\"PPWI\",\"OrgName\":\"Planned Parenthood of Wisconsin\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\"},\"SchedulingData\":{\"Schedule\":[{\"SlotId\":\"0\",\"TemplateId\":\"\",\"DAApptId\":\"DA11111\",\"ExternalApptId\":\"11111\",\"EventReasonId\":\"INJ10\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"ApptReason\":\",\",\"AppointmentDuration\":\"10\",\"AppointmentDurationUnits\":\"minutes\",\"AppointmentTimezone\":\"America/New_York\",\"ApptTimingStart\":\"202311110820\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentCheckIn\":0,\"VisitType\":\"office\"}],\"Provider\":[{\"LocationId\":\"\",\"ResourceType\":\"Thing\",\"ResourceId\":\"\",\"StartDateTime\":\"\"}],\"Channel\":\"PROHEALTH\"},\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"1111\",\"PatientLastName\":\"\",\"PatientFirstName\":\"\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"account number\":\"\",\"account type\":\"\"}],\"RelatedPerson\":[{\"PartyType\":\"Guarantor\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"FirstName\":\"PolicyHoldFSpouse\",\"MiddleName\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"DOB\":\"19591001\",\"Gender\":\"M\",\"Email\":\"PolicyHold21@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"PopulatePatientRefProv\":1,\"ApptRefProv\":\"PATIENT_REF_PROV\",\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\"}");
        JSONObject expectedResponse = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"123\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject result = this.cancelAppointmentsHandlerService.cancelAppointment(inputObject);

        assertNotNull(result);
    }

    @Test
    void testCancelAppointmentException() throws Exception {
        JSONObject input = new JSONObject();
        input.put("deployment_id", "dep1");
        input.put(DocASAPConstants.Key.APPOINTMENT_ID, "appt1");
        input.put(DocASAPConstants.Key.PATIENT_ID, "pat1");

        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = mockStatic(JsonUtils.class)) {
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.PATIENT_ID)))
                    .thenReturn("pat1");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(), eq(DocASAPConstants.Key.APPOINTMENT_ID)))
                    .thenReturn("appt1");
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID)))
                    .thenReturn("deploymentId");

            when(cernerApiCaller.call(anyString(), eq(ApiName.CANCEL_APPOINTMENT.getKey()), any(), eq(Flow.CANCEL_APPOINTMENT.getKey())))
                    .thenThrow(new IHubException(null, "API error"));

            assertThrows(IHubException.class, () -> cancelAppointmentsHandlerService.cancelAppointment(input));
        }
    }

    @Test
    void testPrivateGetAppointmentDetail() throws Exception {
        CancelAppointmentsHandlerService service = new CancelAppointmentsHandlerService();
        CernerApiCaller mockCaller = mock(CernerApiCaller.class);

        // Inject mock using reflection
        var field = CancelAppointmentsHandlerService.class.getDeclaredField("cernerApiCaller");
        field.setAccessible(true);
        field.set(service, mockCaller);

        JSONObject responseJson = new JSONObject();
        responseJson.put("VersionId", "v1");

        when(mockCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(responseJson);

        Method method = CancelAppointmentsHandlerService.class.getDeclaredMethod("getAppointmentDetail", String.class, String.class);
        method.setAccessible(true);
        String versionId = (String) method.invoke(service, "appt1", "dep1");
        assertEquals("v1", versionId);
    }

}
