package com.pes.integration.cerner.handler;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.component.HandlerHelper;
import com.pes.integration.cerner.component.HandlerUtils;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;

import static com.pes.integration.TestUtils.TestUtils.getData;
import static com.pes.integration.cerner.constant.CernerEngineConstants.CERNER_CONFIG;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_TIMING_START;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class NewAppointmentHandlerServiceTest {

    String componentId;

    @Mock
    CernerApiCaller cernerApiCaller;

    @Mock
    CernerApiCaller cernerApiCallerForHandlerHelper;

    @Mock
    HandlerUtils handlerUtils;

    @InjectMocks
    private NewAppointmentHandlerService newAppointmentHandlerService;

    @InjectMocks
    private HandlerHelper handlerHelper;

    @Mock
    DataCacheManager dataCacheManager1;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        this.newAppointmentHandlerService = spy(new NewAppointmentHandlerService());
        this.handlerHelper = spy(new HandlerHelper());

        Field cernerApiCallerField = NewAppointmentHandlerService.class.getDeclaredField("cernerApiCaller");
        cernerApiCallerField.setAccessible(true);
        cernerApiCallerField.set(this.newAppointmentHandlerService, this.cernerApiCaller);

        Field handlerUtilsField = NewAppointmentHandlerService.class.getDeclaredField("handlerUtils");
        handlerUtilsField.setAccessible(true);
        handlerUtilsField.set(this.newAppointmentHandlerService, this.handlerUtils);

        Field dataCacheManagerField = NewAppointmentHandlerService.class.getDeclaredField("dataCacheManager1");
        dataCacheManagerField.setAccessible(true);
        dataCacheManagerField.set(this.newAppointmentHandlerService, this.dataCacheManager1);
    }

    @Test
    void testCreateNewAppointment_ClearOutputObjectUsingReflection() throws Exception {
        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject();
        inputObject.put("message_type", "NewAppt");
        inputObject.put("deployment_id", deploymentId);

        JSONObject outputObject = new JSONObject();
        outputObject.put("temp", "value");

        // Use reflection to invoke clear on JSONObject
        java.lang.reflect.Method clearMethod = outputObject.getClass().getMethod("clear");
        clearMethod.invoke(outputObject);

        assertTrue(outputObject.isEmpty());
    }

    @Test
    public void testCreateNewAppointment() throws Exception
    {
        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"Method\":\"HL7\",\"message_type\":\"NewAppt\",\"deployment_id\":\"74415^0001\",\"message_control_id\":\"45678934507705\",\"ResponseMode\":\"Sync\",\"AppId\":\"\",\"SchedulingData\":{\"Schedule\":[{\"SlotId\":\"345-323-67787483\",\"TemplateId\":\"\",\"DAApptId\":\"DA1111109\",\"ExternalApptId\":\"\",\"EventReasonId\":\"INJ10\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"ApptReason\":\",\",\"AppointmentDuration\":\"10\",\"AppointmentDurationUnits\":\"minutes\",\"AppointmentTimezone\":\"America/New_York\",\"ApptTimingStart\":\"202311110820\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentCheckIn\":0,\"VisitType\":\"office\",\"ApptOffset\":\"\",\"ExternalTemplateId\":\"\",\"SiuDAAnchorAid\":\"\",\"ReferringProvider\":\"\",\"Status\":\"\",\"ApptState\":\"S12\"}],\"Provider\":[{\"LocationId\":\"2432228\",\"ResourceType\":\"Thing\",\"ResourceId\":\"2432228\",\"StartDateTime\":\"\",\"AltResourceId\":\"\",\"ResourceDesc\":\"\"}],\"Channel\":\"PROHEALTH\"},\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"1111\",\"PatientLastName\":\"Sync App 1\",\"PatientFirstName\":\"Sync App 1\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"19901010\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"account number\":\"\",\"account type\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"RelatedPerson\":[{\"PartyType\":\"Guarantor\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"FirstName\":\"PolicyHoldFSpouse\",\"MiddleName\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"DOB\":\"19591001\",\"Gender\":\"M\",\"Email\":\"PolicyHold21@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"PopulatePatientRefProv\":1,\"ApptRefProv\":\"PATIENT_REF_PROV\",\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\"}");

        Mockito.when(cernerApiCaller.call(deploymentId, ApiName.NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey()))
                .thenReturn(new JSONObject().put("temp", new JSONObject().put("error_message", "Unprocessable entity").put("appointmentIdURL", "www.appointment.com")));

        JSONObject appointmentObject = new JSONObject().put("temp", new JSONObject().put("start_time","202311110820")).put("SlotId", "234-543-8986-87965");
        JSONObject baselineOutput = new JSONObject().put("OpenAppointments", new JSONArray().put(appointmentObject));

        Mockito.when(cernerApiCaller.call(eq(deploymentId),eq(ApiName.OPEN_APPOINTMENTS.getKey()), any(), eq(CREATE_APPOINTMENT.getKey())))
                .thenReturn(baselineOutput);
        Mockito.when(dataCacheManager1.getConfiguration(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CERNER_CONFIG, "reasonIdType"))
                .thenReturn("https://fhir.cerner.com/12ef400e-c3a4-435a-9604-a3a16ffe67d5/codeSet/14249|");
        Mockito.when(this.handlerUtils.getAppointmentTypeId(deploymentId)).thenReturn("visitReason");
        Mockito.when(this.handlerUtils.getCernerTimeZone()).thenReturn("CDT");
        Mockito.when(this.handlerUtils.getClientTimeZone(deploymentId)).thenReturn("UTC");
        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Schedule\":[{}]},\"temp\":{\"error_message\":\"Unprocessable entity\",\"appointmentIdURL\":\"www.appointment.com\"}}");

        try (MockedStatic<HandlerUtils> utilsMockedStatic =  mockStatic(HandlerUtils.class)) {
            utilsMockedStatic.when(() -> HandlerUtils.convertDateFormat(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                    .thenReturn("0820");
            Method method = NewAppointmentHandlerService.class.getDeclaredMethod("createNewAppointment", Object.class);
            method.setAccessible(true);
            JSONObject result = (JSONObject) method.invoke(newAppointmentHandlerService, inputObject);
            assertTrue(expectedOutput.similar(result));
            utilsMockedStatic.verify(() -> HandlerUtils.convertDateFormat(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()), times(1));
        }
    }

    @Test
    public void testBuildAndSendMergePatientMsg() throws Exception {
        // Arrange
        String deploymentId = "74415^0001";
        String newPatientId = "newPatient123";
        String oldPatientId = "oldPatient456";
        JSONObject inputObject = new JSONObject();
        inputObject.put("message_control_id", "12345");
        inputObject.put("message_type", "NewAppt");

        HandlerHelper mockHandlerHelper = mock(HandlerHelper.class);
        doNothing().when(mockHandlerHelper).buildMergePatientMsg(newPatientId, oldPatientId, inputObject);

        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        ReflectionTestUtils.setField(service, "handlerUtils", mock(HandlerUtils.class));

        // Use reflection to access the private method
        Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                "buildAndSendMergePatientMsg", String.class, Object.class, String.class, String.class, HandlerHelper.class
        );
        method.setAccessible(true);

        // Act
        method.invoke(service, deploymentId, inputObject, newPatientId, oldPatientId, mockHandlerHelper);

        // Assert
        assertEquals("12345", inputObject.get("message_control_id"));
        assertEquals("NewAppt", inputObject.get("message_type"));
        verify(mockHandlerHelper, times(1)).buildMergePatientMsg(newPatientId, oldPatientId, inputObject);
    }

    @Test
    void testCreateNewAppointment_SlotIdPatternMatch() throws Exception {
        JSONObject input = getData("createAppointmentValidInput.json");
        String deploymentId = "74415^0001";
        JSONObject apiResponse = new JSONObject().put("temp", new JSONObject().put("appointmentIdURL", "url"));
        when(cernerApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(apiResponse);
        when(dataCacheManager1.getConfiguration(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CERNER_CONFIG, "reasonIdType"))
                .thenReturn("https://fhir.cerner.com/12ef400e-c3a4-435a-9604-a3a16ffe67d5/codeSet/14249|");
        Method m = NewAppointmentHandlerService.class.getDeclaredMethod("createNewAppointment", Object.class);
        m.setAccessible(true);
        JSONObject result = (JSONObject) m.invoke(newAppointmentHandlerService, input);

        assertTrue(result.has("temp"));
    }

    @Test
    void testCreateNewAppointment_SlotIdPatternNotMatch_SlotNotFound() throws Exception {
        JSONObject input = getData("createAppointmentInvalidSlotId.json");

        when(handlerUtils.getAppointmentTypeId(anyString())).thenReturn("type");
        when(handlerUtils.getCernerTimeZone()).thenReturn("TZ");
        when(handlerUtils.getClientTimeZone(anyString())).thenReturn("CTZ");

        JSONObject baselineOutput = new JSONObject().put("OpenAppointments", new JSONArray());
        when(cernerApiCaller.call(anyString(), eq(ApiName.OPEN_APPOINTMENTS.getKey()), any(), anyString()))
                .thenReturn(baselineOutput);

        Method m = NewAppointmentHandlerService.class.getDeclaredMethod("createNewAppointment", Object.class);
        m.setAccessible(true);

        InvocationTargetException ex = assertThrows(InvocationTargetException.class, () -> m.invoke(newAppointmentHandlerService, input));
        Throwable cause = ex.getCause();
        assertInstanceOf(IHubException.class, cause);
    }

    public static JSONObject getData(String fileName) {
        JSONObject respObject = null;
        try {
            String content = new String(Files.readAllBytes(Paths.get("src/test/resources/" + fileName)));
            respObject = new JSONObject(content);
        } catch (IOException e) {
            log.error(e.getMessage());
        }

        return respObject;
    }

    @Test
    void testBuildAndSendMergePatientMsg_Success() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "dep1";
        String newPatientId = "newPat";
        String oldPatientId = "oldPat";
        HandlerHelper handlerHelper = mock(HandlerHelper.class);

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
             MockedStatic<com.pes.integration.utils.LogUtil> logUtilMock = mockStatic(com.pes.integration.utils.LogUtil.class)) {

            jsonUtilsMock.when(() -> getValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID)))
                    .thenReturn("msgCtrlId");
            jsonUtilsMock.when(() -> setValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID), eq("msgCtrlId")))
                    .thenAnswer(invocation -> null);
            jsonUtilsMock.when(() -> setValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_TYPE), eq(HandlerType.NEW_APPOINTMENT.getKey())))
                    .thenAnswer(invocation -> null);

            doNothing().when(handlerHelper).buildMergePatientMsg(newPatientId, oldPatientId, inputObject);

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "buildAndSendMergePatientMsg", String.class, Object.class, String.class, String.class, HandlerHelper.class
            );
            method.setAccessible(true);
            method.invoke(service, deploymentId, inputObject, newPatientId, oldPatientId, handlerHelper);

            verify(handlerHelper, times(1)).buildMergePatientMsg(newPatientId, oldPatientId, inputObject);
            jsonUtilsMock.verify(() -> setValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID), eq("msgCtrlId")), times(1));
            jsonUtilsMock.verify(() -> setValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_TYPE), eq(HandlerType.NEW_APPOINTMENT.getKey())), times(1));
        }
    }

    @Test
    void testBuildAndSendMergePatientMsg_HandlerHelperThrowsException() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "dep1";
        String newPatientId = "newPat";
        String oldPatientId = "oldPat";
        HandlerHelper handlerHelper = mock(HandlerHelper.class);

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
             MockedStatic<com.pes.integration.utils.LogUtil> logUtilMock = mockStatic(com.pes.integration.utils.LogUtil.class)) {

            jsonUtilsMock.when(() -> getValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID)))
                    .thenReturn("msgCtrlId");
            jsonUtilsMock.when(() -> setValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID), eq("msgCtrlId")))
                    .thenAnswer(invocation -> null);
            jsonUtilsMock.when(() -> setValue(eq(inputObject), eq(UtilitiesConstants.JsonConstants.MESSAGE_TYPE), eq(HandlerType.NEW_APPOINTMENT.getKey())))
                    .thenAnswer(invocation -> null);

            doThrow(new IHubException(null, "error")).when(handlerHelper).buildMergePatientMsg(newPatientId, oldPatientId, inputObject);
            logUtilMock.when(() -> com.pes.integration.utils.LogUtil.sanitizeForLog(anyString())).thenReturn("sanitized");

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod(
                    "buildAndSendMergePatientMsg", String.class, Object.class, String.class, String.class, HandlerHelper.class
            );
            method.setAccessible(true);
            method.invoke(service, deploymentId, inputObject, newPatientId, oldPatientId, handlerHelper);

            assertTrue(true);
        }
    }


    @Test
    void testGetFormattedDateTime_Success() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String apptTime = "202401011200";
        String expectedDate = "2024-01-01T12:00:00Z";

        try (MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class)) {
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(
                    eq(apptTime),
                    eq(DocASAPConstants.DATE_TIME_FORMAT),
                    eq(CernerConstants.DATE_TIME_R4_Z_FORMAT)
            )).thenReturn(expectedDate);

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod("getFormattedDateTime", String.class);
            method.setAccessible(true);
            Object result = method.invoke(service, apptTime);

            Assertions.assertEquals(expectedDate, result);
            dateUtilsMock.verify(() -> DateUtils.convertDateFormat(
                    eq(apptTime),
                    eq(DocASAPConstants.DATE_TIME_FORMAT),
                    eq(CernerConstants.DATE_TIME_R4_Z_FORMAT)
            ), times(1));
        }
    }

    @Test
    void testGetFormattedDateTime_Exception() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String apptTime = "invalid";

        try (MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class)) {
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenThrow(new RuntimeException("error"));

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod("getFormattedDateTime", String.class);
            method.setAccessible(true);

            Exception ex = assertThrows(InvocationTargetException.class, () -> method.invoke(service, apptTime));
            assertTrue(ex.getCause() instanceof IHubException);
            Assertions.assertEquals(UtilityErrors.DATA_VALIDATION_ERROR.getErrorCode(), ((IHubException) ex.getCause()).getErrorCode());
        }
    }

    @Test
    void testGetReasonIdWithoutPipe_RemovesPipe() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        String input = null;
        String expected = "reasonId";

            Method method = NewAppointmentHandlerService.class.getDeclaredMethod("getReasonIdWithoutPipe", String.class);
            method.setAccessible(true);
            String result = (String) method.invoke(service, input);

            assertTrue(true);
    }

    @Test
    void testGetSlotId_ihubexception() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();

        // Prepare input
        JSONObject inputObject = new JSONObject();
        inputObject.put(APPOINTMENT_TIMING_START, "202401011200");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_END, "202401011230");
        inputObject.put(DocASAPConstants.Key.APPT_RESOURCE_ID, "provider1");
        inputObject.put(DocASAPConstants.Key.EVENT_REASON_ID, "reason1");
        inputObject.put(DocASAPConstants.Key.APPT_LOCATION_ID, "loc1");

        // Prepare baselineOutput with one matching slot
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(DocASAPConstants.TempKey.START_TIME, "2024-01-01T12:00:00Z");
        appointmentObject.put("SlotId", "slot123");
        JSONArray appointmentsArray = new JSONArray();
        appointmentsArray.put(appointmentObject);
        JSONObject baselineOutput = new JSONObject();
        baselineOutput.put(DocASAPConstants.Key.OPEN_APPOINTMENTS, appointmentsArray);

        // Mock statics and dependencies
        try (
                MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class);
                MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class);
                MockedStatic<HandlerUtils> handlerUtilsStatic = mockStatic(HandlerUtils.class)
        ) {
            // Date conversions
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(APPOINTMENT_TIMING_START))).thenReturn("202401011200");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(eq("202401011200"), eq(DocASAPConstants.DATE_TIME_FORMAT), eq(DocASAPConstants.TIME_FORMAT)))
                    .thenThrow(new RuntimeException("error"));
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(eq("202401011200"), eq(DocASAPConstants.DATE_TIME_FORMAT), eq(CernerConstants.DATE_TIME_R4_Z_FORMAT)))
                    .thenReturn("2024-01-01T12:00:00Z");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(eq("202401011230"), eq(DocASAPConstants.DATE_TIME_FORMAT), eq(CernerConstants.DATE_TIME_R4_Z_FORMAT)))
                    .thenReturn("2024-01-01T12:30:00Z");

            // JsonUtils.getValue
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("provider1");
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(DocASAPConstants.Key.EVENT_REASON_ID))).thenReturn("reason1");
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(DocASAPConstants.Key.APPT_LOCATION_ID))).thenReturn("loc1");
            jsonUtilsMock.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.OPEN_APPOINTMENTS))).thenReturn(appointmentsArray);
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(appointmentObject), eq(DocASAPConstants.TempKey.START_TIME))).thenReturn("2024-01-01T12:00:00Z");
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(appointmentObject), eq("SlotId"))).thenReturn("slot123");

            // JsonUtils.setValue
            jsonUtilsMock.when(() -> JsonUtils.setValue(any(JSONObject.class), anyString(), any())).thenAnswer(invocation -> null);

            // HandlerUtils.convertDateFormat
            handlerUtilsStatic.when(() -> HandlerUtils.convertDateFormat(
                    eq("2024-01-01T12:00:00Z"),
                    eq(CernerConstants.DATE_TIME_R4_Z_FORMAT),
                    eq(DocASAPConstants.TIME_FORMAT),
                    anyString(),
                    anyString()
            )).thenReturn("1200");

            // HandlerUtils.getAppointmentTypeId, getCernerTimeZone, getClientTimeZone
            HandlerUtils handlerUtilsMock = mock(HandlerUtils.class);
            lenient().when(handlerUtilsMock.getAppointmentTypeId(anyString())).thenReturn("typeId");
            lenient().when(handlerUtilsMock.getCernerTimeZone()).thenReturn("TZ");
            lenient().when(handlerUtilsMock.getClientTimeZone(anyString())).thenReturn("CTZ");

            // cernerApiCaller.call
            CernerApiCaller cernerApiCallerMock = mock(CernerApiCaller.class);
            lenient().when(cernerApiCallerMock.call(anyString(), anyString(), any(), anyString())).thenReturn(baselineOutput);

            // Inject mocks
            java.lang.reflect.Field handlerUtilsField = NewAppointmentHandlerService.class.getDeclaredField("handlerUtils");
            handlerUtilsField.setAccessible(true);
            handlerUtilsField.set(service, handlerUtilsMock);

            java.lang.reflect.Field cernerApiCallerField = NewAppointmentHandlerService.class.getDeclaredField("cernerApiCaller");
            cernerApiCallerField.setAccessible(true);
            cernerApiCallerField.set(service, cernerApiCallerMock);

            // Invoke private method
            Method method = NewAppointmentHandlerService.class.getDeclaredMethod("getSlotId", String.class, Object.class);
            method.setAccessible(true);
            assertThrows(Exception.class, () ->  method.invoke(service, "dep1", inputObject));
        }
    }

    @Test
    void testGetSlotId_exception() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();

        // Prepare input
        JSONObject inputObject = new JSONObject();
        inputObject.put(APPOINTMENT_TIMING_START, "202401011200");
        inputObject.put(DocASAPConstants.Key.APPOINTMENT_TIMING_END, "202401011230");
        inputObject.put(DocASAPConstants.Key.APPT_RESOURCE_ID, "provider1");
        inputObject.put(DocASAPConstants.Key.EVENT_REASON_ID, "reason1");
        inputObject.put(DocASAPConstants.Key.APPT_LOCATION_ID, "loc1");

        // Prepare baselineOutput with one matching slot
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(DocASAPConstants.TempKey.START_TIME, "2024-01-01T12:00:00Z");
        appointmentObject.put("SlotId", "slot123");
        JSONArray appointmentsArray = new JSONArray();
        appointmentsArray.put(appointmentObject);
        JSONObject baselineOutput = new JSONObject();
        baselineOutput.put(DocASAPConstants.Key.OPEN_APPOINTMENTS, appointmentsArray);

        // Mock statics and dependencies
        try (
                MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class);
                MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class);
                MockedStatic<HandlerUtils> handlerUtilsStatic = mockStatic(HandlerUtils.class)
        ) {
            // Date conversions
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(APPOINTMENT_TIMING_START))).thenReturn("202401011200");
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(DocASAPConstants.TempKey.START_TIME))).thenReturn("202401011200");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(eq("202401011200"), eq(DocASAPConstants.DATE_TIME_FORMAT), eq(DocASAPConstants.TIME_FORMAT)))
                    .thenReturn("2024-01-01T12:00:00Z");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(eq("202401011200"), eq(DocASAPConstants.DATE_TIME_FORMAT), eq(CernerConstants.DATE_TIME_R4_Z_FORMAT)))
                    .thenReturn("2024-01-01T12:00:00Z");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(eq("202401011230"), eq(DocASAPConstants.DATE_TIME_FORMAT), eq(CernerConstants.DATE_TIME_R4_Z_FORMAT)))
                    .thenReturn("2024-01-01T12:30:00Z");

            handlerUtilsStatic.when(() -> HandlerUtils.convertDateFormat(
                    eq("2024-01-01T12:00:00Z"),
                    eq(CernerConstants.DATE_TIME_R4_Z_FORMAT),
                    eq(DocASAPConstants.TIME_FORMAT),
                    anyString(),
                    anyString()
            )).thenThrow(new RuntimeException("error"));

            // JsonUtils.getValue
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(DocASAPConstants.Key.APPT_RESOURCE_ID))).thenReturn("provider1");
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(DocASAPConstants.Key.EVENT_REASON_ID))).thenReturn("reason1");
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(inputObject), eq(DocASAPConstants.Key.APPT_LOCATION_ID))).thenReturn("loc1");
            jsonUtilsMock.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.OPEN_APPOINTMENTS))).thenReturn(appointmentsArray);
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(appointmentObject), eq(DocASAPConstants.TempKey.START_TIME))).thenReturn("2024-01-01T12:00:00Z");
            jsonUtilsMock.when(() -> JsonUtils.getValue(eq(appointmentObject), eq("SlotId"))).thenReturn("slot123");

            // JsonUtils.setValue
            jsonUtilsMock.when(() -> JsonUtils.setValue(any(JSONObject.class), anyString(), any())).thenAnswer(invocation -> null);

            // HandlerUtils.convertDateFormat
            handlerUtilsStatic.when(() -> HandlerUtils.convertDateFormat(
                    eq("2024-01-01T12:00:00Z"),
                    eq(CernerConstants.DATE_TIME_R4_Z_FORMAT),
                    eq(DocASAPConstants.TIME_FORMAT),
                    eq("TZ"),
                    eq("CTZ")
            )).thenThrow(new ParseException("error", 0));

            // HandlerUtils.getAppointmentTypeId, getCernerTimeZone, getClientTimeZone
            HandlerUtils handlerUtilsMock = mock(HandlerUtils.class);
            lenient().when(handlerUtilsMock.getAppointmentTypeId(anyString())).thenReturn("typeId");
            lenient().when(handlerUtilsMock.getCernerTimeZone()).thenReturn("TZ");
            lenient().when(handlerUtilsMock.getClientTimeZone(anyString())).thenReturn("CTZ");

            // cernerApiCaller.call
            CernerApiCaller cernerApiCallerMock = mock(CernerApiCaller.class);
            when(cernerApiCallerMock.call(anyString(), anyString(), any(), anyString())).thenThrow(new RuntimeException("error"));

            // Inject mocks
            java.lang.reflect.Field handlerUtilsField = NewAppointmentHandlerService.class.getDeclaredField("handlerUtils");
            handlerUtilsField.setAccessible(true);
            handlerUtilsField.set(service, handlerUtilsMock);

            java.lang.reflect.Field cernerApiCallerField = NewAppointmentHandlerService.class.getDeclaredField("cernerApiCaller");
            cernerApiCallerField.setAccessible(true);
            cernerApiCallerField.set(service, cernerApiCallerMock);

            // Invoke private method
            Method method = NewAppointmentHandlerService.class.getDeclaredMethod("getSlotId", String.class, Object.class);
            method.setAccessible(true);
            method.invoke(service, "dep1", inputObject);

            assertTrue(true);
        }
    }

}
