package com.pes.integration.cerner.service;

import com.pes.integration.cerner.handler.CancelAppointmentsHandlerService;
import com.pes.integration.cerner.handler.NewAppointmentHandlerService;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.CANCEL_APPOINTMENT;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.enums.FlowStatus.CREATED;
import static com.pes.integration.enums.FlowStatus.FAILED;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

@ExtendWith(MockitoExtension.class)
public class ProcessAppointmentsServiceTest {

    @Mock
    DataTransactionService dataTransactionService;

    @Mock
    CancelAppointmentsHandlerService cancelAppointmentsHandlerService;

    @Mock
    NewAppointmentHandlerService newAppointmentHandlerService;

    @InjectMocks
    private ProcessAppointmentsService processAppointmentsService;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        this.processAppointmentsService = spy(new ProcessAppointmentsService());

        Field cancelAppointmentsHandlerServiceField = ProcessAppointmentsService.class
                .getDeclaredField("cancelAppointmentsHandlerService");
        cancelAppointmentsHandlerServiceField.setAccessible(true);
        cancelAppointmentsHandlerServiceField.set(this.processAppointmentsService, this.cancelAppointmentsHandlerService);

        Field newAppointmentHandlerServiceField = ProcessAppointmentsService.class
                .getDeclaredField("newAppointmentHandlerService");
        newAppointmentHandlerServiceField.setAccessible(true);
        newAppointmentHandlerServiceField.set(this.processAppointmentsService, this.newAppointmentHandlerService);

        Field dataTransactionServiceField = ProcessAppointmentsService.class
                .getDeclaredField("dataTransactionService");
        dataTransactionServiceField.setAccessible(true);
        dataTransactionServiceField.set(this.processAppointmentsService, this.dataTransactionService);
    }

    @Test
    public void testCreateAppointment() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject response = new JSONObject();

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CREATE_APPOINTMENT.getKey(), CREATED.getKey(),
                "iHub Create Appointment Request Message");

        Mockito.doReturn(response).when(this.newAppointmentHandlerService)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        JSONObject result = this.processAppointmentsService.createAppointment(input);

        Assertions.assertTrue(response.similar(result));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CREATE_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Create Appointment Request Message");

        Mockito.verify(this.newAppointmentHandlerService, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

    }

    @Test
    public void testCreateAppointmentThrowsException() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CREATE_APPOINTMENT.getKey(), CREATED.getKey(),
                "iHub Create Appointment Request Message");

        Mockito.doThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), ""))
                .when(this.newAppointmentHandlerService)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CREATE_APPOINTMENT.getKey(), FAILED.getKey(),
                "");

        Assertions.assertThrows(IHubException.class, () -> {
            this.processAppointmentsService.createAppointment(input);
        });

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CREATE_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Create Appointment Request Message");

        Mockito.verify(this.newAppointmentHandlerService, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CREATE_APPOINTMENT.getKey(), FAILED.getKey(), "");

    }

    @Test
    public void testCancelAppointment() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject response = new JSONObject();

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CANCEL_APPOINTMENT.getKey(), CREATED.getKey(),
                "iHub Cancel Appointment Request Message");

        Mockito.doReturn(response).when(this.cancelAppointmentsHandlerService)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        JSONObject result = this.processAppointmentsService.cancelAppointment(input);

        Assertions.assertTrue(response.similar(result));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CANCEL_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Cancel Appointment Request Message");

        Mockito.verify(this.cancelAppointmentsHandlerService, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

    }

    @Test
    public void testCancelAppointmentThrowsException() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CANCEL_APPOINTMENT.getKey(), CREATED.getKey(),
                "iHub Cancel Appointment Request Message");

        Mockito.doThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), ""))
                .when(this.cancelAppointmentsHandlerService)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CANCEL_APPOINTMENT.getKey(), FAILED.getKey(),
                "");

        Assertions.assertThrows(IHubException.class, () -> {
            this.processAppointmentsService.cancelAppointment(input);
        });

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CANCEL_APPOINTMENT.getKey(), CREATED.getKey(), "iHub Cancel Appointment Request Message");

        Mockito.verify(this.cancelAppointmentsHandlerService, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CANCEL_APPOINTMENT.getKey(), FAILED.getKey(), "");

    }
}
