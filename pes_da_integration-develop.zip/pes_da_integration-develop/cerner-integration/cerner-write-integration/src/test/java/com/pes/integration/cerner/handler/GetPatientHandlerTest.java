package com.pes.integration.cerner.handler;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.DateUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.text.ParseException;

import static com.pes.integration.cerner.api.ApiName.GET_PATIENT;
import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.enums.Flow.SEARCH_PATIENT;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GetPatientHandlerTest
{
    @Mock
    CernerApiCaller cernerApiCaller;

    private GetPatientHandler getPatientHandler;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        this.getPatientHandler = spy(new GetPatientHandler());

        Field cernerApiCallerField =GetPatientHandler.class.getDeclaredField("cernerApiCaller");
        cernerApiCallerField.setAccessible(true);
        cernerApiCallerField.set(this.getPatientHandler, this.cernerApiCaller);
    }

    @Test
    public void testDoExecute() throws IHubException, ParseException {
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JsonObject expectedOutputObject = JsonParser.parseString("{\"appointment_sync\":[{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Street2\":\"{Zip=, Street1=, State=CT, City=New Milford}\",\"Street1\":{\"Zip\":\"\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}}],\"ActiveStatus\":\"\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Street2\":\"{Zip=, Street1=, State=CT, City=New Milford}\",\"Street1\":{\"Zip\":\"\",\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\"}}],\"ActiveStatus\":\"\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}]}").getAsJsonObject();
        JSONObject outputObject = new JSONObject("{\"appointment_sync\":[{\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"},{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}]}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"},{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}]}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\"}]}}]}");

        Mockito.when(this.cernerApiCaller.call("74415^0001", GET_PATIENT.getKey(), inputObject,
                SEARCH_PATIENT.getKey())).thenReturn(outputObject);

        try (MockedStatic<DateUtils> dateUtilsMockedStatic =  mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat("1990809",
                    CernerConstants.DATE_FORMAT, DOCASAP_DATE_FORMAT)).thenReturn("1990809");
            JSONObject result =   getPatientHandler.doExecute(inputObject);
            Assertions.assertEquals(expectedOutputObject.toString(),result.toString());
            dateUtilsMockedStatic.verify(() -> DateUtils.convertDateFormat("1990809",
                            CernerConstants.DATE_FORMAT, DOCASAP_DATE_FORMAT), times(2));
        }
    }

    @Test
    public void testDoExecuteNullPatientArray() throws IHubException, ParseException {
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JSONObject outputObject = new JSONObject("{\"appointment_syncd\":[]}");

        Mockito.when(this.cernerApiCaller.call("74415^0001", GET_PATIENT.getKey(), inputObject,
                SEARCH_PATIENT.getKey())).thenReturn(outputObject);

        try (MockedStatic<DateUtils> dateUtilsMockedStatic =  mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat("1990809",
                    DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT)).thenReturn("1990809");
            JSONObject result =   getPatientHandler.doExecute(inputObject);
            Assertions.assertEquals(outputObject.toString(),result.toString());
            dateUtilsMockedStatic.verify(() -> DateUtils.convertDateFormat("1990809",
                    DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT), times(1));
        }
    }

    @Test
    public void testDoExecuteNullStreetArray() throws IHubException, ParseException {
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JSONObject outputObject = new JSONObject("{\"appointment_sync\":[{\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street\":[]}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street\":[]}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\"}]}}]}");

        Mockito.when(this.cernerApiCaller.call("74415^0001", GET_PATIENT.getKey(), inputObject,
                SEARCH_PATIENT.getKey())).thenReturn(outputObject);

        try (MockedStatic<DateUtils> dateUtilsMockedStatic =  mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat("1990809",
                    DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT)).thenReturn("1990809");
            JSONObject result =   getPatientHandler.doExecute(inputObject);
            Assertions.assertEquals(outputObject.toString(),result.toString());
            dateUtilsMockedStatic.verify(() -> DateUtils.convertDateFormat("1990809",
                    DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT), times(1));
        }
    }

    @Test
    public void testDoExecuteThrowsException() throws IHubException, ParseException {
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");

        try (MockedStatic<DateUtils> dateUtilsMockedStatic =  mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat("1990809",
                    DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT)).thenThrow(new ParseException("this is a parser error", 10));
            Assertions.assertThrows(IHubException.class, () -> {
                getPatientHandler.doExecute(inputObject);
            });
            dateUtilsMockedStatic.verify(() -> DateUtils.convertDateFormat("1990809",
                    DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT), times(1));
        }
    }

    @Test
    public void testDoExecuteThrowsAnotherException() throws IHubException, ParseException {
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");

        JSONObject outputObject = new JSONObject("{\"appointment_sync\":[{\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street\":[]}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\"}]}},{\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street\":[]}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\"}]}}]}");

        Mockito.when(this.cernerApiCaller.call("74415^0001", GET_PATIENT.getKey(), inputObject,
                SEARCH_PATIENT.getKey())).thenReturn(outputObject);

        try (MockedStatic<DateUtils> dateUtilsMockedStatic =  mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat("1990809",
                    CernerConstants.DATE_FORMAT, DOCASAP_DATE_FORMAT)).thenThrow(new ParseException("this is a parser error", 10));
                getPatientHandler.doExecute(inputObject);
            dateUtilsMockedStatic.verify(() -> DateUtils.convertDateFormat("1990809",
                    DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT), times(1));
        }
    }

}
