package com.pes.integration.cerner.consumer;


import com.pes.integration.service.AsyncConsumerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;

import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
public class CernerAsyncConsumerTest {

    String syncDataTopic;

    @Mock
    AsyncConsumerService asyncConsumerService;

    @InjectMocks
    CernerAsyncConsumer cernerAsyncConsumer;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        this.cernerAsyncConsumer = spy(new CernerAsyncConsumer());
        this.syncDataTopic = "";

        Field syncDataConsumerServiceField = CernerAsyncConsumer.class.getDeclaredField("asyncConsumerService");
        syncDataConsumerServiceField.set(this.cernerAsyncConsumer, asyncConsumerService);
        Field syncDataTopicField = CernerAsyncConsumer.class.getDeclaredField("syncDataTopic");
        syncDataTopicField.set(this.cernerAsyncConsumer, syncDataTopic);
    }

    @Test
    public void testConsumeSendSyncDataMessage()
    {
        Mockito.doNothing().when(this.asyncConsumerService).processAsyncMessage(this.syncDataTopic, "");

        this.cernerAsyncConsumer.consumeAsyncMessage("");

        Mockito.verify(this.asyncConsumerService, times(1)).processAsyncMessage("", "");
    }

    @Test
    public void testListen()
    {
        Mockito.doNothing().when(this.asyncConsumerService).processAsyncMessage("e2d", "");

        this.cernerAsyncConsumer.listen("d2e","");

        Mockito.verify(this.asyncConsumerService, times(1)).processAsyncMessage("e2d","");
    }
}
