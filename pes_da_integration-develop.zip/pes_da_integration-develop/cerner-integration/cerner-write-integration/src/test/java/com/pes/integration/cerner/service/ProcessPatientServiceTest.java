package com.pes.integration.cerner.service;

import com.pes.integration.cerner.handler.GetPatientHandler;
import com.pes.integration.cerner.handler.NewPatientHandlerService;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.Flow.SEARCH_PATIENT;
import static com.pes.integration.enums.FlowStatus.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

@ExtendWith(MockitoExtension.class)
public class ProcessPatientServiceTest
{
    @Mock
    NewPatientHandlerService newPatientHandlerService;

    @Mock
    GetPatientHandler getPatientHandler;

    @Mock
    DataTransactionService dataTransactionService;

    @InjectMocks
    private ProcessPatientService processPatientService;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {
        this.processPatientService = spy(new ProcessPatientService());

        Field newPatientHandlerServiceField = ProcessPatientService.class
                .getDeclaredField("newPatientHandlerService");
        newPatientHandlerServiceField.setAccessible(true);
        newPatientHandlerServiceField.set(this.processPatientService, this.newPatientHandlerService);

        Field getPatientHandlerField = ProcessPatientService.class.getDeclaredField("getPatientHandler");
        getPatientHandlerField.setAccessible(true);
        getPatientHandlerField.set(this.processPatientService, this.getPatientHandler);

        Field dataTransactionServiceField = ProcessPatientService.class.getDeclaredField("dataTransactionService");
        dataTransactionServiceField.setAccessible(true);
        dataTransactionServiceField.set(this.processPatientService, this.dataTransactionService);
    }

    @Test
    public void testCreatePatient() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject response = new JSONObject();

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CREATE_PATIENT.getKey(), CREATED.getKey(),
                "iHub Create Patient Request Message");

        Mockito.doReturn(response).when(this.newPatientHandlerService)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CREATE_PATIENT.getKey(), SUCCESS.getKey(),
                "iHub Create Patient Successful");

        JSONObject result = this.processPatientService.createPatient(input);

        Assertions.assertTrue(response.similar(result));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CREATE_PATIENT.getKey(), CREATED.getKey(), "iHub Create Patient Request Message");

        Mockito.verify(this.newPatientHandlerService, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CREATE_PATIENT.getKey(), SUCCESS.getKey(), "iHub Create Patient Successful");
    }

    @Test
    public void testCreatePatientThrowsException() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject response = new JSONObject();

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CREATE_PATIENT.getKey(), CREATED.getKey(),
                "iHub Create Patient Request Message");

        Mockito.doThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), ""))
                .when(this.newPatientHandlerService)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.doNothing().when(this.dataTransactionService).logData(input, CREATE_PATIENT.getKey(), FAILED.getKey(),
                "");

        Assertions.assertThrows(IHubException.class, () -> {
            JSONObject result = this.processPatientService.createPatient(input);
            Assertions.assertTrue(response.similar(result));
        });


        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CREATE_PATIENT.getKey(), CREATED.getKey(), "iHub Create Patient Request Message");

        Mockito.verify(this.newPatientHandlerService, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                CREATE_PATIENT.getKey(), FAILED.getKey(), "");
    }

    @Test
    public void testSearchPatient() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject response = new JSONObject().put("temp1","testing");
        JSONObject responseJson = new JSONObject().put(DATA, response);

        Mockito.doNothing().when(this.dataTransactionService).logData(input, SEARCH_PATIENT.getKey(), CREATED.getKey(),
                "iHub Search Patient Request Message");

        Mockito.doReturn(response).when(this.getPatientHandler)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        JSONObject result = this.processPatientService.searchPatient(input);

        Assertions.assertTrue(responseJson.similar(result));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                SEARCH_PATIENT.getKey(), CREATED.getKey(), "iHub Search Patient Request Message");

        Mockito.verify(this.getPatientHandler, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

    }

    @Test
    public void testSearchPatientHasTemp() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject tempObject = new JSONObject().put("testKey", "testValue");
        JSONObject response = new JSONObject().put("temp", tempObject);
        JSONObject expectedResponseJson = new JSONObject("{\"data\":{\"temp\":{\"temp\":\"Optional.empty\",\"testKey\":\"testValue\"}},\"Error\":[{\"temp\":\"Optional.empty\",\"testKey\":\"testValue\"}]}");

        Mockito.doNothing().when(this.dataTransactionService).logData(input, SEARCH_PATIENT.getKey(), CREATED.getKey(),
                "iHub Search Patient Request Message");

        Mockito.doReturn(response).when(this.getPatientHandler)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        JSONObject result = this.processPatientService.searchPatient(input);

        Assertions.assertEquals(expectedResponseJson.toString(), result.toString());

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                SEARCH_PATIENT.getKey(), CREATED.getKey(), "iHub Search Patient Request Message");

        Mockito.verify(this.getPatientHandler, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

    }

    @Test
    public void testSearchPatientThrowsException() throws IHubException {
        JSONObject input = new JSONObject("{\"data\":{\"appointment_sync\":[{\"SchedulingData\":{\"Schedule\":[{\"ApptReason\":\",\",\"AppointmentTimezone\":\"America/New_York\",\"EventReason\":\"Injection Immunization Blood Draw 10 min\",\"DAApptId\":\"DA11111\",\"ExApptId\":\"11111\",\"AppointmentDurationUnits\":\"minutes\",\"ApptTimingEnd\":\"202311110830\",\"AppointmentDuration\":\"10\",\"SlotId\":\"0\",\"ApptTimingStart\":\"202311110820\",\"VisitType\":\"office\",\"AppointmentCheckIn\":0,\"EventReasonId\":\"INJ10\",\"ExternalApptId\":\"11111\",\"TemplateId\":\"\"}],\"Channel\":\"PROHEALTH\",\"Provider\":[{\"StartDateTime\":\"\",\"ResourceId\":\"\",\"LocationId\":\"\",\"ResourceType\":\"Thing\"}]},\"PopulatePatientRefProv\":1,\"temp\":{\"version\":\"W/\\\"null\\\"\",\"participant\":{\"status\":\"accepted\"},\"status\":\"cancelled\",\"resourceType\":\"Appointment\"},\"DemographicData\":{\"PatientInformation\":[{\"EmployerId\":\"\",\"EmergencyContact\":\"\",\"PatientFirstName\":\"\",\"Email\":\"\",\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"Patient/1111\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Zip\":\"\",\"Street1\":\"\",\"State\":\"CT\",\"City\":\"New Milford\"}],\"ActiveStatus\":\"\",\"LanguagePreference\":\"English\",\"DOB\":\"\",\"Race\":\"\",\"EmergencyContactRelation\":\"\",\"StudentStatus\":\"\",\"account type\":\"\",\"VoiceNotificationStatus\":\"\",\"PopulateHomePhone\":0,\"NotificationStatus\":\"\",\"DAPatientId\":\"DA11410980\",\"PopulatePatientRefProv\":1,\"HomePhoneAreaCode\":\"\",\"Interpreter\":\"\",\"WorkPhone\":\"\",\"TextNotificationStatus\":\"\",\"PopulateCellPhone\":1,\"EthnicGroupId\":\"\",\"EmploymentStatus\":\"\",\"Nationality\":\"\",\"account number\":\"\",\"MaritalStatus\":\"\",\"PatientRefProv\":\"\",\"Suffix\":\"\",\"DeceasedDateTime\":\"\",\"HomePhone\":\"\",\"PrimaryPhoneIndicator\":\"\",\"MultipleBirthNumber\":\"\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"CellPhoneAreaCode\":\"\",\"EmployerName\":\"\"}],\"RelatedPerson\":[{\"Email\":\"Guarantor20@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"DOB\":\"19580131\",\"AddressSameAsPatient\":0,\"Relationship\":\"Mother\",\"CellPhone\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"MiddleName\":\"\",\"PartyType\":\"Guarantor\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}},{\"Email\":\"PolicyHold21@docasap.com\",\"WorkPhone\":\"\",\"HomePhone\":\"\",\"FirstName\":\"PolicyHoldFSpouse\",\"DOB\":\"19591001\",\"Relationship\":\"Other\",\"CellPhone\":\"\",\"LastName\":\"PolicyHoldlSpouse\",\"Gender\":\"M\",\"MiddleName\":\"\",\"PartyType\":\"Policyholder\",\"Addr\":{\"Zip\":\"19103\",\"Street1\":\"111 park ave\",\"State\":\"PA\",\"City\":\"Philadelphia\"}}]},\"is_new\":true,\"retry_message\":false,\"message_type\":\"CancelAppt\",\"message_received_time\":\"2023-10-30 08:44:03 CDT\",\"ApptRefProv\":\"PATIENT_REF_PROV\",\"OrgInfo\":{\"OrgId\":67076,\"OrgCode\":\"PPWI\",\"NgExternalOrgId\":1234567,\"EpmCode\":\"\",\"SiuWritePort\":23456,\"OrgName\":\"Planned Parenthood of Wisconsin\",\"SiuWriteRemoteIp\":\"172.19.2.21\",\"AdtWriteProtocol\":\"0\"},\"message_status\":\"recfromda\",\"AppId\":\"\",\"ResponseMode\":\"\",\"message_control_id\":\"49042317\",\"deployment_id\":\"74468^0001\"}]}}");

        JSONObject response = new JSONObject();

        Mockito.doNothing().when(this.dataTransactionService).logData(input, SEARCH_PATIENT.getKey(), CREATED.getKey(),
                "iHub Search Patient Request Message");

        Mockito.doThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), ""))
                .when(this.getPatientHandler)
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.doNothing().when(this.dataTransactionService).logData(input, SEARCH_PATIENT.getKey(), FAILED.getKey(),
                "");

        Assertions.assertThrows(IHubException.class, () -> {
            this.processPatientService.searchPatient(input);
        });

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                SEARCH_PATIENT.getKey(), CREATED.getKey(), "iHub Search Patient Request Message");

        Mockito.verify(this.getPatientHandler, Mockito.times(1))
                .doExecute(input.getJSONObject(DATA).getJSONArray(APPOINTMENT_SYNC).getJSONObject(0));

        Mockito.verify(this.dataTransactionService, Mockito.times(1)).logData(input,
                SEARCH_PATIENT.getKey(), FAILED.getKey(), "");
    }

    @Test
    public void testUpdatePatient() throws IHubException {
        JSONObject input = new JSONObject();
        Assertions.assertNull(this.processPatientService.updatePatient(input));
    }

    @Test
    public void testGetPatient() throws IHubException {
        JSONObject input = new JSONObject();
        Assertions.assertNull(this.processPatientService.getPatient(input));
    }
}
