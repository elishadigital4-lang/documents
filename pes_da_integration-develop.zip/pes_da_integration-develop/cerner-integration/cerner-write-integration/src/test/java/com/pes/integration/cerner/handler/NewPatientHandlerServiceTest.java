package com.pes.integration.cerner.handler;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.component.HandlerUtils;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

import static com.pes.integration.cerner.api.ApiName.NEW_PATIENT;
import static com.pes.integration.cerner.constant.CernerEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.GENDER;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class NewPatientHandlerServiceTest {

    @Mock
    CernerApiCaller cernerApiCaller;

    @Mock
    HandlerUtils handlerUtils;

    @Mock
    DataCacheManager dataCacheManager;

    @Mock
    MatchPatientHandler matchPatientHandler;

    @InjectMocks
    private NewPatientHandlerService newPatientHandlerService;

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException
    {

        this.newPatientHandlerService = spy(new NewPatientHandlerService());

        Field dataCacheManagerField = NewPatientHandlerService.class.getDeclaredField("cacheManager");
        dataCacheManagerField.setAccessible(true);
        dataCacheManagerField.set(this.newPatientHandlerService, this.dataCacheManager);


        Field cernerApiCallerField =NewPatientHandlerService.class.getDeclaredField("cernerApiCaller");
        cernerApiCallerField.setAccessible(true);
        cernerApiCallerField.set(this.newPatientHandlerService, this.cernerApiCaller);

        Field matchPatientHandlerField = NewPatientHandlerService.class.getDeclaredField("matchPatientHandler");
        matchPatientHandlerField.setAccessible(true);
        matchPatientHandlerField.set(this.newPatientHandlerService, this.matchPatientHandler);
    }

    @Test
    public void testCreateNewPatient() throws Exception {

        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"is_synchronous_flow\":\"true\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":1,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":1,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Channel\":\"EnI\",\"Provider\":[{\"ResourceId\":\"DBS\",\"LocationId\":\"401081\",\"ResourceType\":2}]},\"temp\":{\"patientIdURL\":\"this is url\"},\"DemographicData\":{\"PatientInformation\":[{\"ExternalPatientId\":\"this is url\",\"DAPatientId\":\"DA11410980\"}]},\"deployment_id\":\"74415^0001\"}");

        Mockito.when(this.matchPatientHandler.processMatchPatient(any(), any()))
                .thenReturn(inputObject);

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig( BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_LAYER_PRIORITY_CONFIG,false)).thenReturn("testPatMatchL");


        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false)).thenReturn("testPatMatchA");

        JSONObject locObject = new JSONObject().put("loc","401081").put("org","74415");
        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74415^0001",
                CERNER_CONFIG, PATIENT_ORG_IDENTIFIER,false))
                .thenReturn(new JSONObject().put("loc-org", new JSONArray().put(locObject)));

        Mockito.when(cernerApiCaller.call(deploymentId,NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey()))
                .thenReturn(new JSONObject().put("temp", new JSONObject().put("patientIdURL", "this is url")));

        JSONObject result = this.newPatientHandlerService.createNewPatient(inputObject);

        Assertions.assertEquals(expectedOutput.toString(), result.toString());
    }


    @Test
    public void testCreateNewPatientThrowsMultipleExceptions() throws Exception {

        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"is_synchronous_flow\":\"true\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":1,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":1,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Channel\":\"EnI\",\"Provider\":[{\"ResourceId\":\"DBS\",\"LocationId\":\"401081\",\"ResourceType\":2}]},\"temp\":{\"patientIdURL\":\"this is url\"},\"DemographicData\":{\"PatientInformation\":[{\"ExternalPatientId\":\"this is url\",\"DAPatientId\":\"DA11410980\"}]},\"deployment_id\":\"74415^0001\"}");

        Mockito.when(this.matchPatientHandler.processMatchPatient(any(), any()))
                .thenReturn(inputObject);

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig( BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_LAYER_PRIORITY_CONFIG,false))
                .thenThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class),
                        "Error while getting cache data"));

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false))
                .thenThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class),
                "Error while getting cache data"));

        JSONObject locObject = new JSONObject().put("loc","401081").put("org","74415");
        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74415^0001",
                        CERNER_CONFIG, PATIENT_ORG_IDENTIFIER,false))
                .thenReturn(new JSONObject().put("loc-org", new JSONArray().put(locObject)));

        Mockito.when(cernerApiCaller.call(deploymentId,NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey()))
                .thenReturn(new JSONObject().put("temp", new JSONObject().put("patientIdURL", "this is url")));

        JSONObject result = this.newPatientHandlerService.createNewPatient(inputObject);

        Assertions.assertEquals(expectedOutput.toString(), result.toString());
    }

    @Test
    public void testCreateNewPatientExternalPatientIdNull() throws Exception {

        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"is_synchronous_flow\":\"true\",\"error_code\":\"2001\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"0\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":1,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":1,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Channel\":\"EnI\",\"Provider\":[{\"ResourceId\":\"DBS\",\"LocationId\":\"401081\",\"ResourceType\":2}]},\"temp\":{\"error_message\":\"Multiple matching patients detected\"},\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\"}]},\"error_code\":\"2001\",\"deployment_id\":\"74415^0001\"}");

        Mockito.when(this.matchPatientHandler.processMatchPatient(any(), any()))
                .thenReturn(inputObject);

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig( BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_LAYER_PRIORITY_CONFIG,false)).thenReturn("testPatMatchL");


        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false)).thenReturn("testPatMatchA");

        JSONObject result = this.newPatientHandlerService.createNewPatient(inputObject);

        Assertions.assertEquals(expectedOutput.toString(), result.toString());
    }

    @Test
    public void testCreateNewPatientWithMultiplePatientErrorCode() throws Exception {

        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"is_synchronous_flow\":\"true\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":1,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":1,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Channel\":\"EnI\",\"Provider\":[{\"ResourceId\":\"DBS\",\"LocationId\":\"401081\",\"ResourceType\":2}]},\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\"}]}}");
        IHubException iHubException = new IHubException(new Exception(), new IHubErrorCode("2001"),
                "Error while getting cache data");
        iHubException.setStatusCode(StatusCodes.MULTIPLE_PATIENT);

        Mockito.when(this.matchPatientHandler.processMatchPatient(any(), any()))
                .thenThrow(iHubException);

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig( BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_LAYER_PRIORITY_CONFIG,false)).thenReturn("testPatMatchL");

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false)).thenReturn("testPatMatchA");

        JSONObject result = this.newPatientHandlerService.createNewPatient(inputObject);

        Assertions.assertEquals(expectedOutput.toString(), result.toString());
    }

    @Test
    public void testCreateNewPatientWithDifferentErrorCode() throws Exception {

        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"is_synchronous_flow\":\"true\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":1,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":1,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        IHubException iHubException = new IHubException(new Exception(), new IHubErrorCode("2004"),
                "Error while getting cache data");
        iHubException.setStatusCode(StatusCodes.NO_PATIENT_FOUND);

        Mockito.when(this.matchPatientHandler.processMatchPatient(any(), any()))
                .thenThrow(iHubException);

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig( BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_LAYER_PRIORITY_CONFIG,false)).thenReturn("testPatMatchL");

        Mockito.when(this.dataCacheManager.getStoredProvidersConfig(BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false)).thenReturn("testPatMatchA");

        Assertions.assertThrows(IHubException.class, () -> {
            this.newPatientHandlerService.createNewPatient(inputObject);
        });
    }

    @Test
    public void testCreateNewPatientEmptyOrgIdentifier() throws Exception {

        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"is_synchronous_flow\":\"true\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":1,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":1,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");

        // Mock the required organization location mapping
        JSONObject locObject = new JSONObject().put("loc", "401081").put("org", "74415");
        when(dataCacheManager.getStoredProvidersConfig(
                eq(BaseEPMConstants.EPM_NAME_PREFIX), eq(deploymentId),
                eq(CernerEngineConstants.CERNER_CONFIG), eq(CernerEngineConstants.PATIENT_ORG_IDENTIFIER), eq(false)))
                .thenReturn(new JSONObject().put("loc-org", new JSONArray().put(locObject)));

        // Act and Assert
        IHubException exception = Assertions.assertThrows(IHubException.class, () -> {
            newPatientHandlerService.createNewPatient(inputObject);
        });

        Assertions.assertEquals("Error while creating patient - the required org location mapping not found in ihubdb. Please reach out to L2 support to get the same verified/updated.", exception.getMessage());
    }

    @Test
    public void testGetPatientDemographics() throws IHubException
    {
        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"flowName\":\"D2E\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");

        JSONObject outputObject = new JSONObject("{\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"AddressType\":\"home\",\"Street\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}]}],\"HomePhone\":\"\",\"HomePhoneAreaCode\":\"\",\"CellPhone\":\"\",\"CellPhoneAreaCode\":\"\",\"WorkPhone\":\"\",\"WorkPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\"}]}}");
        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Channel\":\"EnI\",\"Provider\":[{\"ResourceId\":\"DBS\",\"LocationId\":\"401081\",\"ResourceType\":2}]},\"DemographicData\":{\"PatientInformation\":[{\"PatientFirstName\":\"Varun\",\"HomePhoneAreaCode\":\"\",\"Email\":\"\",\"WorkPhone\":\"\",\"PopulateCellPhone\":1,\"CellPhone\":\"\",\"PopulateWorkPhone\":0,\"ExternalPatientId\":\"\",\"Prefix\":\"\",\"Gender\":\"F\",\"WorkPhoneAreaCode\":\"\",\"Addr\":[{\"Street1\":\"{Zip=, Street1=, State=CT, City=New Milford}\",\"AddressType\":\"home\"}],\"ActiveStatus\":\"\",\"MaritalStatus\":\"\",\"Suffix\":\"\",\"HomePhone\":\"\",\"DOB\":\"1990809\",\"PatientMiddleName\":\"\",\"PatientLastName\":\"L\",\"CellPhoneAreaCode\":\"\",\"PopulateHomePhone\":0,\"DAPatientId\":\"DA11410980\"}]}}");

        Mockito.when(this.cernerApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject, inputObject.optString("flowName"))).thenReturn(outputObject);

        JSONObject result = this.newPatientHandlerService.getPatientDemographics(inputObject);

        Assertions.assertEquals(expectedOutput.toString(), result.toString());
    }


    @Test
    public void testGetPatientDemographicsThrowsException() throws IHubException
    {
        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"flowName\":\"D2E\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":0,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":0,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");

        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Channel\":\"EnI\",\"Provider\":[{\"ResourceId\":\"DBS\",\"LocationId\":\"401081\",\"ResourceType\":2}]}}");

        Mockito.when(this.cernerApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject,
                inputObject.optString("flowName")))
                .thenThrow(new IHubException(mock(Exception.class),mock(IHubErrorCode.class), "Error while calling cerner api"));


        JSONObject result = this.newPatientHandlerService.getPatientDemographics(inputObject);

        Assertions.assertEquals(expectedOutput.toString(), result.toString());
    }

    @Test
    public void testGetPatientInsuranceInfo() throws Exception {

        JSONObject result = this.newPatientHandlerService.getPatientInsuranceInfo(new JSONObject());

        Assertions.assertNull(result);
    }

    @Test
    void testGetStreetListSuccess() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONArray streetArray = new JSONArray();
        streetArray.put("Street1=123 Main St, City=Metropolis, State=NY, Zip=10001");
        JSONObject add = new JSONObject();
        JSONObject patientObject = new JSONObject();

        try (
                MockedStatic<NullChecker> nullCheckerMock = mockStatic(com.pes.integration.utils.NullChecker.class);
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)
        ) {
            nullCheckerMock.when(() -> com.pes.integration.utils.NullChecker.isEmpty(anyString())).thenReturn(false);

            // Mock setValue to actually set the value in the JSONObject
            jsonUtilsMock.when(() -> setValue(eq(add), eq("Street1"), any()))
                            .thenThrow(new RuntimeException("Street1 already set"));
            jsonUtilsMock.when(() -> setValue(eq(add), eq("Street"), eq(null)))
                    .thenAnswer(invocation -> {
                        add.put("Street", JSONObject.NULL);
                        return null;
                    });
            jsonUtilsMock.when(() -> setValue(eq(patientObject), eq(com.pes.integration.cerner.constant.CernerEngineConstants.ADDRESS), eq(null)))
                    .thenAnswer(invocation -> {
                        patientObject.put(com.pes.integration.cerner.constant.CernerEngineConstants.ADDRESS, JSONObject.NULL);
                        return null;
                    });

            Method method = NewPatientHandlerService.class.getDeclaredMethod("getStreetList", JSONArray.class, JSONObject.class, JSONObject.class);
            method.setAccessible(true);
            method.invoke(service, streetArray, add, patientObject);

            assertTrue(true);
        }
    }

    @Test
    void testGetAddressSuccess() throws Exception {
        NewPatientHandlerService service = spy(new NewPatientHandlerService());
        JSONObject patientObject = new JSONObject();
        JSONObject addressObj = new JSONObject();
        addressObj.put("AddressType", "home");
        addressObj.put("Street", new JSONArray().put("123 Main St"));
        JSONArray addressArray = new JSONArray().put(addressObj);

        try (
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class);
        ) {
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(eq(patientObject), anyString()))
                    .thenThrow(new RuntimeException("Mocked exception"));

            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.setValue(eq(patientObject), anyString(), any()))
                    .thenAnswer(invocation -> null);

            Method method = NewPatientHandlerService.class.getDeclaredMethod("getAddress", JSONObject.class);
            method.setAccessible(true);
            method.invoke(service, patientObject);

            assertTrue(true);
        }
    }


    @Test
    void testSetGenderThrowsException() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONObject input = new JSONObject();

        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            jsonUtilsMock.when(() -> getValue(eq(input), eq(GENDER))).thenThrow(new RuntimeException("error"));

            Method method = NewPatientHandlerService.class.getDeclaredMethod("setGender", JSONObject.class);
            method.setAccessible(true);

            assertThrows(Exception.class, () -> method.invoke(service, input));
        }
    }

    @Test
    void testCreatePatientException() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONObject input = new JSONObject();

        try (MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class)) {
            jsonUtilsMock.when(() -> getValue(any(), eq(DEPLOYMENT_ID))).thenThrow(new RuntimeException("error"));

            assertThrows(Exception.class, () -> newPatientHandlerService.createNewPatient(input));
        }
    }

    @Test
    void testCreatePatientNull() throws Exception {
        NewPatientHandlerService service = new NewPatientHandlerService();
        JSONObject input = new JSONObject();

        try (MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class)) {
            jsonUtilsMock.when(() -> getValue(any(), eq(DEPLOYMENT_ID))).thenReturn(null);

            assertThrows(Exception.class, () -> newPatientHandlerService.createNewPatient(input));
        }
    }

    @Test
    public void testCreateNewPatientID() throws Exception {

        String deploymentId = "74415^0001";
        JSONObject inputObject = new JSONObject("{\"deployment_id\":\"74415^0001\",\"is_synchronous_flow\":\"true\",\"message_control_id\":\"488914522344\",\"message_type\":\"NewPatient\",\"AppId\":\"\",\"DemographicData\":{\"PatientInformation\":[{\"DAPatientId\":\"DA11410980\",\"ExternalPatientId\":\"\",\"PatientLastName\":\"L\",\"PatientFirstName\":\"Varun\",\"PatientMiddleName\":\"\",\"Prefix\":\"\",\"Suffix\":\"\",\"DOB\":\"1990809\",\"Gender\":\"F\",\"Addr\":[{\"Street1\":\"\",\"City\":\"New Milford\",\"State\":\"CT\",\"Zip\":\"\"}],\"HomePhone\":\"3454567\",\"HomePhoneAreaCode\":\"454\",\"CellPhone\":\"8764567\",\"CellPhoneAreaCode\":\"456\",\"WorkPhone\":\"5674345\",\"WorkPhoneAreaCode\":\"342\",\"PopulateHomePhone\":1,\"PopulateCellPhone\":1,\"PopulateWorkPhone\":1,\"Email\":\"test@test.com\",\"MaritalStatus\":\"\",\"ActiveStatus\":\"\",\"EmergencyContact\":\"\",\"EmergencyContactRelation\":\"\",\"EthnicGroupId\":\"\",\"Race\":\"\",\"Nationality\":\"\",\"NotificationComments\":\"\",\"NotificationStatus\":\"\",\"TextNotificationStatus\":\"\",\"VoiceNotificationStatus\":\"\",\"PrimaryPhoneIndicator\":\"\",\"DeceasedDateTime\":\"\",\"MultipleBirthNumber\":\"\",\"LanguagePreference\":\"English\",\"PopulatePatientRefProv\":1,\"PatientRefProv\":\"\",\"PCP\":[{\"Type\":\"\",\"Id\":\"\",\"Name\":\"\"}],\"Interpreter\":\"\",\"EmployerName\":\"\",\"EmployerId\":\"\",\"EmploymentStatus\":\"\",\"StudentStatus\":\"\",\"AccountNumber\":\"\",\"AccountType\":\"\"}],\"InsuranceInformation\":[{\"InsPlanId\":\"31724\",\"GroupNumber\":\"\",\"SubscriberId\":\"\"}],\"relatedPerson\":[{\"PartyType\":\"Guarantor\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Mother\"},{\"PartyType\":\"Policyholder\",\"RelatedPersonId\":\"\",\"FirstName\":\"GuarantorInfoSpouse\",\"MiddleName\":\"\",\"LastName\":\"GuarantorInfolaSpouse\",\"DOB\":\"19580131\",\"Email\":\"Guarantor20@docasap.com\",\"HomePhone\":\"\",\"CellPhone\":\"\",\"WorkPhone\":\"\",\"AddressSameAsPatient\":0,\"Addr\":{\"Street1\":\"111 park ave\",\"City\":\"Philadelphia\",\"State\":\"PA\",\"Zip\":\"19103\"},\"Relationship\":\"Other\"}]},\"SchedulingData\":{\"Provider\":[{\"LocationId\":\"401081\",\"ResourceType\":2,\"ResourceId\":\"DBS\"}],\"Channel\":\"EnI\"},\"retry_message\":false,\"is_new\":true,\"message_status\":\"recfromda\",\"message_received_time\":\"2023-10-18 13:15:50 CDT\"}");
        JSONObject expectedOutput = new JSONObject("{\"SchedulingData\":{\"Channel\":\"EnI\",\"Provider\":[{\"ResourceId\":\"DBS\",\"LocationId\":\"401081\",\"ResourceType\":2}]},\"temp\":{\"patientIdURL\":\"this is url\"},\"DemographicData\":{\"PatientInformation\":[{\"ExternalPatientId\":\"this is url\",\"DAPatientId\":\"DA11410980\"}]},\"deployment_id\":\"74415^0001\"}");

        try(MockedStatic<JsonUtils> mockedStatic = mockStatic(JsonUtils.class)) {

            mockedStatic.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn(deploymentId);
            mockedStatic.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(DocASAPConstants.Key.APPOINTMENT_PATIENT_ID))).thenReturn("789632");
            mockedStatic.when(() -> JsonUtils.getValue(anyString(), eq(DocASAPConstants.Key.APPOINTMENT_PATIENT_ID))).thenReturn(null);



            Mockito.when(this.matchPatientHandler.processMatchPatient(any(), any()))
                    .thenReturn(inputObject);

            Mockito.when(this.dataCacheManager.getStoredProvidersConfig(BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                    GENERIC_CONFIG, PAT_MATCHING_LAYER_PRIORITY_CONFIG, false)).thenReturn("testPatMatchL");


            Mockito.when(this.dataCacheManager.getStoredProvidersConfig(BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                    GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false)).thenReturn("testPatMatchA");

            JSONObject locObject = new JSONObject().put("loc", "401081").put("org", "74415");
            lenient().when(this.dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74415^0001",
                            CERNER_CONFIG, PATIENT_ORG_IDENTIFIER, false))
                    .thenReturn(new JSONObject().put("loc-org", new JSONArray().put(locObject)));

            lenient().when(cernerApiCaller.call(deploymentId, NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey()))
                    .thenReturn(new JSONObject().put("temp", new JSONObject().put("patientIdURL", "this is url")));

            JSONObject result = this.newPatientHandlerService.createNewPatient(inputObject);

            assertTrue(true);
        }
    }


}
