package com.pes.integration.cerner;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.KafkaService;
import com.pes.integration.service.RefreshBaseInitEngine;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static com.pes.integration.cerner.constant.CernerEngineConstants.EPM_NAME_PREFIX;

@Component
public class InitEngine implements RefreshBaseInitEngine {

  @Value("${kafka.async.topic}")
  String asyncTopicName;

  @Value("${kafka.config.group.id}")
  String groupId;

  @Autowired
  CernerInitEngine cernerEngine;

  @Autowired
  KafkaService kafkaService;

  @Autowired
  DataCacheManager cacheManager;

  @PostConstruct
  public void init() throws IHubException {
    cernerEngine.init();
    kafkaService.createTopicAndListener(cacheManager.getRedisConfig(EPM_NAME_PREFIX).toString(),
        asyncTopicName, groupId);
  }
}
