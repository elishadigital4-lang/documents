package com.pes.integration.cerner.handler;


import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.component.HandlerUtils;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractMatchPatientHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import static com.pes.integration.cerner.api.ApiName.GET_PATIENT;
import static com.pes.integration.cerner.constant.CernerEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_DEPT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.PAT_MATCHING_USE_DEPT;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.util.Objects.isNull;

@Slf4j
@Service
public class MatchPatientHandler extends AbstractMatchPatientHandler {

    @Autowired
    protected DataCacheManager cacheManager;

    @Autowired
    CernerApiCaller cernerApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    String deploymentId;

    @Override
    public JSONObject getPatients(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        this.deploymentId=deploymentId;
        setValue(inputObject, DocASAPConstants.Key.PATIENT_ID, null);
        try {
            outputObject = cernerApiCaller.call(deploymentId,GET_PATIENT.getKey(), inputObject, inputObject.optString("flowName"));
        } catch (IHubException e) {
            log.error("Error {} ", e.getMessage());
            outputObject.put("Error", e.getMessage());
        }
        return outputObject;
    }


    @Override
    public JSONArray getPatientDemographicsDetails(JSONArray patientsArray) throws IHubException {

        JSONArray finalPatientsArray = new JSONArray();
        for (int i = 0; i < patientsArray.length(); i++) {
            JSONObject patientObject = patientsArray.getJSONObject(i);
            try {
                getAddress(patientObject);
                HandlerUtils.updateE2DPhones(patientObject);
            } catch (Exception e) {
                log.error(e.getMessage());
            }
            Object inactive = getValue(patientObject, "DemographicData.PatientInformation[0].Active");
            if (getMatchPatientInactiveConfig() && inactive.equals("true")) {
                log.info("patient is inactive");
            } else finalPatientsArray.put(patientObject);
        }
        return finalPatientsArray;
    }

    private JSONObject getAddress(JSONObject patientObject) throws IHubException {
        JSONArray addressArray = (JSONArray) getValue(patientObject, CernerEngineConstants.ADDRESS);
        if (!isEmpty(addressArray)) {
            for (Object address : addressArray) {
                if (!isNull(address) && !isEmpty(address)) {
                    JSONObject add = (JSONObject) address;
                    if (add.has(CernerEngineConstants.ADDRESS_TYPE)) {
                        String type = add.getString(CernerEngineConstants.ADDRESS_TYPE);
                        if ("home".equalsIgnoreCase(type)) {
                            getAddressZIP(add, patientObject);
                            break;
                        }
                    }
                }
            }
        }
        return patientObject;
    }

    private void getAddressZIP(JSONObject add, JSONObject patientObject) throws IHubException {
        Object zip = getValue(add, "Zip");
        if (!isEmpty(zip) && zip.toString().length() > 5) {
            zip = zip.toString().substring(0, 5);
            setValue(add, "Zip", zip);
        }
        setValue(patientObject, CernerEngineConstants.ADDRESS, null);
        setValue(patientObject, DocASAPConstants.Key.ADDRESS, add);
    }

    private boolean getMatchPatientInactiveConfig() throws IHubException{
        try {
            String config = (String)cacheManager.getStoredProvidersConfig(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, UtilitiesConstants.GENERIC_CONFIG, UtilitiesConstants.INACTIVE_PAT_CONF,false);
            return config.equalsIgnoreCase(UtilitiesConstants.TRUE) ? true : false;
        } catch (IHubException e) {
            return false;
        }
    }

    @Override
    public boolean isSingleMatch() throws IHubException {
        return false;
    }
}
