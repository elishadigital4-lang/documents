package com.pes.integration.cerner.handler;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.component.HandlerHelper;
import com.pes.integration.cerner.component.HandlerUtils;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.handlers.AbstractNewAppointmentHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.regex.Pattern;

import static com.pes.integration.cerner.constant.CernerEngineConstants.CERNER_CONFIG;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.NullChecker.isEmpty;

@Slf4j
@Service(value = "NewAppt")
public class NewAppointmentHandlerService extends AbstractNewAppointmentHandler {

  @Value("${epm.engine.component_id}")
  String componentId;

  @Autowired
  CernerApiCaller cernerApiCaller;

  @Autowired
  HandlerUtils handlerUtils;

  @Autowired
  DataCacheManager dataCacheManager1;

  /**
   * creates a new Appointment based on the EPM engine to be defined in the EPM engine. * * @throws
   * IHubException
   *
   * @param inputObject this is input object
   * @throws IHubException throws iHub exception
   */
  @Override
  @Observed(name = "integration.createNewAppointment", contextualName = "integration")
  protected JSONObject createNewAppointment(Object inputObject) throws IHubException {
    JSONObject outputObject = new JSONObject();
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    log.info("createAppointment for the deployment id {} " , deploymentId);
    JsonUtils.setValue(inputObject, "temp.resourceType", "Appointment");
    Object slotId = JsonUtils.getValue(inputObject, CernerEngineConstants.SLOT_ID);
    String newSlotId;
    boolean slotFound = true;
    if (!isEmpty(slotId)) {
      String pattern = ".*-.*-.*-.*";
      boolean isMatch = Pattern.matches(pattern, slotId.toString());
      if (!isMatch) {
        newSlotId = getSlotId(deploymentId,inputObject);
        if (!isEmpty(newSlotId))
          slotId = newSlotId;
        else {
          slotFound = false;
          setValue(outputObject, TempKey.ERROR_MESSAGE, "Could not find Cerner slot id");
          setValue(outputObject, Key.ERROR_CODE, StatusCodes.SLOT_NOT_AVAILABLE.getKey());
            log.info("Could not find Cerner slot id. {}", deploymentId);
        }
      }
    }

    String patientId = (String)JsonUtils.getValue(inputObject, Key.PATIENT_ID);
    String locationId = (String)JsonUtils.getValue(inputObject, Key.APPT_LOCATION_ID);
    if (slotFound) {
      prepareInputObject(inputObject, patientId, locationId, slotId, deploymentId);
      outputObject = cernerApiCaller.call(deploymentId, ApiName.NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
    }

    String error = (String)JsonUtils.getValue(outputObject, TempKey.ERROR_MESSAGE);
    if(!isEmpty(error) && error.contains("Unprocessable entity")) {
      HandlerHelper handlerHelper = new HandlerHelper();
      String newPatientId = handlerHelper.getActivePatient(patientId, inputObject,deploymentId);

      if(!isEmpty(newPatientId)) {
        (outputObject).clear();
        outputObject = cernerApiCaller.call(deploymentId,ApiName.NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
        buildAndSendMergePatientMsg(deploymentId,inputObject,newPatientId, patientId, handlerHelper);
        patientId = newPatientId;
      }
      log.debug(sanitizeForLog("inputObject: " + inputObject));
    } else if (!isEmpty(error) && error.contains("Could not find Cerner slot id")) {
      log.error(sanitizeForLog("Error in creating appointment: " + error));
      throw new IHubException(StatusCodes.SLOT_NOT_AVAILABLE, error, "");
    }
    Object appointmentIdUrl = JsonUtils.getValue(outputObject, "temp.appointmentIdURL");
    log.info(sanitizeForLog("External appointmentIdUrl: " + appointmentIdUrl + " for slotId: "+slotId));
    if(!NullChecker.isEmpty(appointmentIdUrl)){
      String appointmentId = HandlerUtils.getId(appointmentIdUrl.toString());
      setValue(inputObject, Key.APPOINTMENT_ID, appointmentId);
      setValue(outputObject, Key.APPOINTMENT_ID, appointmentId);
    }
    setValue(inputObject, Key.PATIENT_ID, patientId);
    return outputObject;
  }

  private void prepareInputObject(Object inputObject, String patientId, String locationId, Object slotId, String deploymentId) throws IHubException {
    setValue(inputObject, "temp.status", "proposed");
    JSONObject patientParticipant = new JSONObject();
    patientParticipant.put("actor", new JSONObject().put("reference", "Patient/" + patientId));
    patientParticipant.put("status", "needs-action");

    JSONObject locationParticipant = new JSONObject();
    locationParticipant.put("actor", new JSONObject().put("reference", "Location/" + locationId));
    locationParticipant.put("status", "needs-action");

    JSONArray participants = new JSONArray();
    participants.put(patientParticipant);
    participants.put(locationParticipant);

    setValue(inputObject, "temp.participant", participants);

    String apptStartTime = (String)JsonUtils.getValue(inputObject, Key.APPOINTMENT_TIMING_START);
    setValue(inputObject, Key.APPOINTMENT_TIMING_START, getFormattedDateTime(apptStartTime));
    String apptEndTime = (String)JsonUtils.getValue(inputObject, Key.APPOINTMENT_TIMING_END);
    setValue(inputObject, Key.APPOINTMENT_TIMING_END, getFormattedDateTime(apptEndTime));
    setValue(inputObject, CernerEngineConstants.SLOT_ID, "Slot/" + slotId);
    String reasonIdType = dataCacheManager1.getConfiguration(CernerEngineConstants.EPM_NAME_PREFIX, deploymentId, CERNER_CONFIG, "reasonIdType");
    setValue(inputObject, "temp.serviceType.coding.system", getReasonIdWithoutPipe(reasonIdType));
    setValue(inputObject, "temp.serviceType.coding.userSelected", true);
  }

  private String getReasonIdWithoutPipe(String reasonIdType) {
    if (reasonIdType != null && reasonIdType.endsWith(CharacterConstants.PIPE)) {
      return reasonIdType.substring(0, reasonIdType.length() - 1);
    }
      return reasonIdType;
  }

  private Object getFormattedDateTime(String apptTime) throws IHubException {
    String formattedDate;
    try{
      formattedDate = DateUtils.convertDateFormat(apptTime,DocASAPConstants.DATE_TIME_FORMAT, CernerConstants.DATE_TIME_R4_Z_FORMAT);
    }catch (Exception e) {
      throw new IHubException(UtilityErrors.DATA_VALIDATION_ERROR.getErrorCode(), "StartDate or EndDate were invalid or null.");
    }
      return formattedDate;
  }

  private void buildAndSendMergePatientMsg(String deploymentId,Object inputObject, String newPatientId, String oldPatientId, HandlerHelper handlerHelper) throws IHubException{
    String messageControlId = getValue(inputObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID).toString();

    try {
      handlerHelper.buildMergePatientMsg(newPatientId, oldPatientId, inputObject);
    } catch (IHubException e) {
      log.error(sanitizeForLog("Error in sending MergePatient for deploymentId "+deploymentId +" for External patientId "+newPatientId + "Old patientId "+oldPatientId));
    }
    setValue(inputObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, messageControlId);
    setValue(inputObject, UtilitiesConstants.JsonConstants.MESSAGE_TYPE, HandlerType.NEW_APPOINTMENT.getKey());
  }

  private String getSlotId(String deploymentId,Object inputObject) throws IHubException{
    log.info(deploymentId);
    String startDate = (String)getValue(inputObject, Key.APPOINTMENT_TIMING_START);
    String endDate = (String)getValue(inputObject, Key.APPOINTMENT_TIMING_END);
    String apptStartTime;
    try{
      apptStartTime = DateUtils.convertDateFormat(startDate,DocASAPConstants.DATE_TIME_FORMAT, DocASAPConstants.TIME_FORMAT);
      startDate = DateUtils.convertDateFormat(startDate,DocASAPConstants.DATE_TIME_FORMAT, CernerConstants.DATE_TIME_R4_Z_FORMAT);
      endDate = DateUtils.convertDateFormat(endDate,DocASAPConstants.DATE_TIME_FORMAT, CernerConstants.DATE_TIME_R4_Z_FORMAT);
    }catch (Exception e) {
      throw new IHubException(UtilityErrors.DATA_VALIDATION_ERROR.getErrorCode(), "StartDate or EndDate were invalid or null.");
    }
    String providerId = (String) JsonUtils.getValue(inputObject, Key.APPT_RESOURCE_ID);
    String apptTypeId = (String) JsonUtils.getValue(inputObject, Key.EVENT_REASON_ID);
    JSONObject baselineInput = new JSONObject();
    JSONObject baselineOutput = new JSONObject();
    JsonUtils.setValue(baselineInput, TempKey.START_DATE, "ge"+startDate+"&start=lt"+endDate);
    JsonUtils.setValue(baselineInput, Key.APPT_PROVIDER_ID, "Practitioner/"+providerId);
    String reasonIdType = handlerUtils.getAppointmentTypeId(deploymentId);

    setValue(baselineInput, "temp.slot-type", reasonIdType+apptTypeId);
    setValue(baselineInput, Key.APPT_LOCATION_ID, JsonUtils.getValue(inputObject, Key.APPT_LOCATION_ID));
    log.info(sanitizeForLog("baseline input "+baselineInput));
    try {
      baselineOutput = cernerApiCaller.call(deploymentId,ApiName.OPEN_APPOINTMENTS.getKey(), baselineInput, CREATE_APPOINTMENT.getKey());
    } catch (Exception e1) {
      log.error(e1.getMessage());
    }
    JSONArray appointmentsArray = (JSONArray) JsonUtils.getValue(baselineOutput, Key.OPEN_APPOINTMENTS);
    String slotId = "";
    if (appointmentsArray != null) {
      String cernerTimeZone = handlerUtils.getCernerTimeZone();
      String clientTimeZone = handlerUtils.getClientTimeZone(deploymentId);
      for (int i = 0; i < appointmentsArray.length(); i++) {

        JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
        String startDateTime = (String) JsonUtils.getValue(appointmentObject, TempKey.START_TIME);
        String slotStartTime = "";
        try {
          slotStartTime = HandlerUtils.convertDateFormat(startDateTime.trim(), CernerConstants.DATE_TIME_R4_Z_FORMAT,
                  DocASAPConstants.TIME_FORMAT, cernerTimeZone, clientTimeZone);
        } catch (ParseException e) {
          log.error(e.getMessage());
        }
        if(apptStartTime.equalsIgnoreCase(slotStartTime)) {
          slotId = (String) JsonUtils.getValue(appointmentObject, "SlotId");
          break;
        }
      }
    }
    return slotId;
  }
}
