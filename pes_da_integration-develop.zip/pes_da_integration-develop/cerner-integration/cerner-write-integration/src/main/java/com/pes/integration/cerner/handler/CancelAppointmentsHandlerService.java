package com.pes.integration.cerner.handler;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractCancelAppointmentsHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;

@Slf4j
@Service(value = "CancelAppt")
public class CancelAppointmentsHandlerService extends AbstractCancelAppointmentsHandler {

  @Autowired
  CernerApiCaller cernerApiCaller;

  @Override
  public JSONObject cancelAppointment(JSONObject inputObject) throws IHubException {
    JSONObject outputObject = new JSONObject();
    String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
    log.info("cancelAppointment for the deployment id {} " ,deploymentId);
    String appointmentId = (String)getValue(inputObject, DocASAPConstants.Key.APPOINTMENT_ID);
    setValue(inputObject, "SchedulingData.Schedule[0].ExApptId",  appointmentId);
    String patientId = (String) JsonUtils.getValue(inputObject, DocASAPConstants.Key.PATIENT_ID);
    JSONArray requestArray = new JSONArray();
    JSONObject requestObject = new JSONObject();
    requestObject.put("op","replace");
    requestObject.put("path","/status");
    requestObject.put("value","cancelled");
    requestArray.put(requestObject);
    setValue(inputObject, "temp.request", requestArray);
    String version = "0";
    log.info("versionId {}", version);

    version= "W/\""+version+"\"";
    setValue(inputObject, "temp.version", version);
    try{
      outputObject = cernerApiCaller.call(deploymentId, ApiName.CANCEL_APPOINTMENT.getKey(), inputObject, Flow.CANCEL_APPOINTMENT.getKey());
    }catch (IHubException e){
      setValue(inputObject, DocASAPConstants.Key.PATIENT_ID, patientId);
      log.error("Error while cancelling appointment", e);
      throw new IHubException(e, ERROR_IN_SERVICE_EXECUTION.getErrorCode(),
              e.getMessage());
    }
    JSONObject response  = new JSONObject();
    setValue(inputObject, DocASAPConstants.Key.PATIENT_ID, patientId);
    setValue(response, DocASAPConstants.Key.APPOINTMENT_OBJECT,inputObject);
    return response;
  }

  private String getAppointmentDetail(String appointmentId, String deploymentId) throws IHubException{
      JSONObject inputJson = new JSONObject();
    setValue(inputJson, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
    setValue(inputJson, DocASAPConstants.Key.APPOINTMENT_ID, appointmentId);
    JSONObject responseJson = (JSONObject) cernerApiCaller.call(deploymentId, ApiName.GET_APPOINTMENT.getKey(), inputJson, Flow.CANCEL_APPOINTMENT.getKey());

    return (String)getValue(responseJson, "VersionId");
  }
}
