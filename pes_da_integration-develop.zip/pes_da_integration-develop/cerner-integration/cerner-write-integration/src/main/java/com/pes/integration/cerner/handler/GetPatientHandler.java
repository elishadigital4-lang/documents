package com.pes.integration.cerner.handler;

import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.component.HandlerUtils;
import com.pes.integration.cerner.constant.CernerConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.utils.DateUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;

import static com.pes.integration.cerner.api.ApiName.GET_PATIENT;

import static com.pes.integration.constant.BaseEPMConstants.EPM_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.DOB;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.SEARCH_PATIENT;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.util.Objects.isNull;

@Slf4j
@Service
public class GetPatientHandler extends BaseHandler {

  @Autowired
  CernerApiCaller cernerApiCaller;


  @Override
  @Observed(name = "integration.cernerGetPatient", contextualName = "integration")
  public JSONObject doExecute(JSONObject inputObject) throws IHubException {
    JSONObject outputObject;
    try {
      validateDob(inputObject);
      String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
      outputObject = cernerApiCaller.call(deploymentId, GET_PATIENT.getKey(), inputObject,
              SEARCH_PATIENT.getKey());
    } catch (IHubException e) {
      log.error("Error {} ", e.getMessage());
      throw new IHubException(DATA_VALIDATION_ERROR.getErrorCode(), "DOB was invalid or null.");
    }
    JSONArray patientsArray = (JSONArray) getValue(outputObject, "appointment_sync");
    if (patientsArray != null) {
      for (Object paientObj : patientsArray) {

        try {
          HandlerUtils.updateE2DPhones(paientObj);
          String dob = (String) getValue(paientObj, Key.DOB);
          dob = DateUtils.convertDateFormat(dob, CernerConstants.DATE_FORMAT, DOCASAP_DATE_FORMAT);
          setValue(inputObject, Key.DOB, dob);
        } catch (Exception e1) {
          log.error(e1.getMessage());
        }
        JSONObject street = (JSONObject) getValue(paientObj, Key.ADDRESS);

        String st2 = fetchPatientAddress(street, paientObj);

        setValue(paientObj, "DemographicData.PatientInformation[0].Addr[0].Street2", st2);
        setValue(paientObj, "DemographicData.PatientInformation[0].Addr[0].Street", null);
      }

    }
    return outputObject;
  }

  private String fetchPatientAddress(JSONObject street, Object paientObj) {
    JSONArray streetArray = street.getJSONArray("Street");

    String st2 = "";
    if (!isEmpty(streetArray)) {
      try {
        List<Object> streetList = streetArray.toList();
        for (int i = 0; i < streetList.size(); i++) {
          Object st = streetList.get(i);
          if (i == 0) {
            setValue(paientObj, "DemographicData.PatientInformation[0].Addr[0].Street1", st);
          } else st2 = st2 + st;
        }
      } catch (Exception e) {
        log.error(e.getMessage());
      }
    } else log.info("Error in reading address");

    return st2;
  }

  private void validateDob(JSONObject inputObject) throws IHubException {
    try {
      String dob = getValue(inputObject, DOB).toString();
      dob = convertDateFormat(dob, DOCASAP_DATE_FORMAT, EPM_DATE_FORMAT);
      setValue(inputObject, DOB, dob);
    } catch (ParseException e) {
      log.error("Error {} .", e.getMessage());
      throw new IHubException(DATA_VALIDATION_ERROR.getErrorCode(), "DOB was invalid or null.");
    }
  }
}
