package com.pes.integration.cerner.handler;

import com.pes.integration.cerner.api.ApiName;
import com.pes.integration.cerner.api.CernerApiCaller;
import com.pes.integration.cerner.component.HandlerUtils;
import com.pes.integration.cerner.constant.CernerEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractNewPatientHandler;
import com.pes.integration.utils.PhoneNumberUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.pes.integration.cerner.api.ApiName.GET_PATIENT;
import static com.pes.integration.cerner.api.ApiName.NEW_PATIENT;
import static com.pes.integration.cerner.constant.CernerConstants.*;
import static com.pes.integration.cerner.constant.CernerEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.IS_SYNCRONOUS_FLOW;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEMOGRAPHIC_DATA;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.MESSAGE_TYPE;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.FlowStatus.FAILED;
import static com.pes.integration.enums.FlowStatus.IN_PROGRESS;
import static com.pes.integration.enums.StatusCodes.MULTIPLE_PATIENT;
import static com.pes.integration.exceptions.UtilityErrors.*;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;

@Slf4j
@Service(value = "NewPatient")
public class NewPatientHandlerService extends AbstractNewPatientHandler {

    @Autowired
    CernerApiCaller cernerApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    DataCacheManager cacheManager;

    @Autowired
    MatchPatientHandler matchPatientHandler;

    String orgIdentifierError="Error while creating patient - the required org location mapping not found in ihubdb. Please reach out to L2 support to get the same verified/updated.";

    @Override
    @Observed(name = "integration.CreateNewPatient", contextualName = "integration")
    public JSONObject createNewPatient(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        try {
            String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
            JSONObject matchPatientResponse = matchPatient(inputObject, deploymentId);
            Object patientId = getValue(matchPatientResponse, Key.APPOINTMENT_PATIENT_ID);
            Object error = getValue(matchPatientResponse, Key.ERROR_CODE);
            log.info(deploymentId+":: Matched PatientId: " + patientId + " :: "+error);
            PhoneNumberUtils.handlePhoneNumberFromFlag(inputObject);
            if ((isNull(patientId) || patientId.equals(0)) && !StatusCodes.MULTIPLE_PATIENT.getKey().equals(error)) {
                outputObject = checkPatientExists(inputObject, deploymentId, patientId);
            }else if(!isEmpty(error) && StatusCodes.MULTIPLE_PATIENT.getKey().equals(error)){
                setValue(outputObject, DocASAPConstants.TempKey.ERROR_MESSAGE, "Multiple matching patients detected");
                setValue(outputObject, Key.ERROR_CODE, StatusCodes.MULTIPLE_PATIENT.getKey());
                log.info("Found multiple matching patients.");
            }else if(!isEmpty(patientId)){
                log.info(deploymentId+" No API call");
                copyKey(JsonConstants.DEMOGRAPHIC_DATA, inputObject, outputObject);
                setValue(outputObject, Key.PATIENT_ID, patientId.toString());
            }
            setValue(outputObject, DEPLOYMENT_ID, deploymentId);
        } catch (IHubException e) {
            if (!isNull(e.getStatusCode()) && e.getStatusCode().equals(MULTIPLE_PATIENT)) {
                //intentionally empty
            } else {
                log.error(e.getMessage());
                throw e;
            }
        } catch (Exception e) {
            log.error("Error in createNewPatient "+e);
            if(e.getMessage().toString().toLowerCase().contains("null".toLowerCase()))
                throw new IHubException(e, UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), "Null Constraint Violation");
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), e.getMessage());
        }
        copyKey(Key.DA_PATIENT_ID, inputObject, outputObject);
        copyKey(SCHEDULING_DATA , inputObject, outputObject);
        return outputObject;
    }

    private JSONObject checkPatientExists(JSONObject inputObject, String deploymentId, Object patientId) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String apptLocationId = (String)getValue(inputObject, Key.APPT_LOCATION_ID);
        String orgIdentifier = getPatientOrgIndentifier(apptLocationId, deploymentId);
        if(!isEmpty(orgIdentifier)){
            setValue(inputObject, "temp.resourceType", "Patient");
            setValue(inputObject, "temp.identifier",  "Organization/"+orgIdentifier);
            setValue(inputObject, "temp.active", true);
            setValue(inputObject, "temp.name.use", "official");
            setValue(inputObject, "temp.address.use", "home");
            setGender(inputObject);
            String email = (String)getValue(inputObject, Key.EMAIL);
            handleEpmPhoneNoEmail(inputObject,HOME_PHONE_TYPE_VALUE,CELL_PHONE_TYPE_VALUE, WORK_PHONE_TYPE_VALUE, email);
            outputObject = cernerApiCaller.call(deploymentId,NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey());
            Object patientIdUrl = getValue(outputObject, "temp.patientIdURL");
            log.info("External patientIdUrl: " + patientIdUrl);
            if (!isEmpty(patientIdUrl)) {
                patientId = getExternalPatientId(patientIdUrl.toString());
                setValue(inputObject, Key.PATIENT_ID, patientId);
                setValue(outputObject, Key.PATIENT_ID, patientId);
            }
        }else {
            setValue(outputObject, DocASAPConstants.TempKey.ERROR_MESSAGE, orgIdentifierError);
            setValue(outputObject, Key.ERROR_CODE, StatusCodes.QUEUE_READ_ERROR.getKey());
            log.info("Error while creating patient - the required org location mapping not found in ihubdb for "+deploymentId+". Please reach out to L2 support to get the same verified/updated.");
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), orgIdentifierError);
        }

        return outputObject;
    }

    private String getExternalPatientId(String patientIdUrl){
        int index = patientIdUrl.lastIndexOf('/');
        return patientIdUrl.substring(index+1);
    }
    private void setGender(JSONObject inputObject) throws IHubException {
        try {
            String gender = String.valueOf(getValue(inputObject, GENDER));
            String resolvedGender = gender.equalsIgnoreCase(GENDER_F) ? FEMALE : gender;
            setValue(inputObject, GENDER, gender.equalsIgnoreCase(GENDER_M) ? MALE :
                    resolvedGender);
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new IHubException(DATA_VALIDATION_ERROR.getErrorCode(), "Gender was invalid or null.");
        }
    }

    private JSONObject getPatientOrgIndentifierConfig(String deploymentId) throws IHubException{
        JSONObject itentifier = null;
        try{
            itentifier = (JSONObject)cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, CERNER_CONFIG, PATIENT_ORG_IDENTIFIER,false);
        } catch(Exception e){
            log.info("Patient orgnization indentifier is not set for deployment ID: " + deploymentId);
        }
        return itentifier;
    }

    private String getPatientOrgIndentifier(String apptLocationId, String deploymentId) throws IHubException {
        JSONObject orgIndentifierJSON = getPatientOrgIndentifierConfig(deploymentId);
        String orgItentifier = "";
        try {
            if (orgIndentifierJSON != null && orgIndentifierJSON.has(LOCATION_ORG)
                    && !isEmpty(orgIndentifierJSON.getJSONArray(LOCATION_ORG))) {
                JSONArray locationOrgArray = orgIndentifierJSON.getJSONArray(LOCATION_ORG);
                if (!isEmpty(locationOrgArray)) {
                    for (Object locationOrg : locationOrgArray) {
                        String locationId = ((JSONObject) locationOrg).getString("loc");
                        if (apptLocationId.equalsIgnoreCase(locationId)) {
                            orgItentifier = ((JSONObject) locationOrg).getString("org");
                        }
                    }
                } else if (orgIndentifierJSON.has(DEFAULT_ORG)) {
                    orgItentifier = orgIndentifierJSON.getString(DEFAULT_ORG);
                }
            } else if (orgIndentifierJSON != null && orgIndentifierJSON.has(DEFAULT_ORG)) {
                orgItentifier = orgIndentifierJSON.getString(DEFAULT_ORG);
            }
        } catch(Exception e) {
            log.info(e.getMessage());
        }
        return orgItentifier;
    }

    public void handleEpmPhoneNoEmail(JSONObject inputObject,String homeType, String CellType, String workType, String email)throws IHubException{
        Object homePhoneNumber = getValue(inputObject, Key.HOME_PHONE);
        Object workPhoneNumber = getValue(inputObject, Key.WORK_PHONE);
        Object mobilePhoneNumber = getValue(inputObject, Key.MOBILE_PHONE);
        String phone = "phone";
        JSONArray phoneArray = new JSONArray();
        if(!isNull(homePhoneNumber)){
            JSONObject homeJson = new JSONObject();
            setValue(homeJson, CernerEngineConstants.NUMBER, homePhoneNumber);
            setValue(homeJson, CernerEngineConstants.PHONE_TYPE, homeType);
            setValue(homeJson, CernerEngineConstants.SYSTEM, phone);
            phoneArray.put(homeJson);
        }
        if(!isNull(workPhoneNumber)){
            JSONObject workJson = new JSONObject();
            setValue(workJson, CernerEngineConstants.NUMBER, workPhoneNumber);
            setValue(workJson, CernerEngineConstants.PHONE_TYPE, workType);
            setValue(workJson, CernerEngineConstants.SYSTEM, phone);
            phoneArray.put(workJson);
        }
        if(!isNull(mobilePhoneNumber)){
            JSONObject mobileJson = new JSONObject();
            setValue(mobileJson, CernerEngineConstants.NUMBER, mobilePhoneNumber);
            setValue(mobileJson, CernerEngineConstants.PHONE_TYPE, CellType);
            setValue(mobileJson, CernerEngineConstants.SYSTEM, phone);
            phoneArray.put(mobileJson);
        }
        if(!isNull(email)){
            JSONObject emailJson = new JSONObject();
            setValue(emailJson, CernerEngineConstants.NUMBER, email);
            setValue(emailJson, CernerEngineConstants.PHONE_TYPE, "home");
            setValue(emailJson, CernerEngineConstants.SYSTEM, "email");
            phoneArray.put(emailJson);
        }

        JSONObject patientInformation = (JSONObject)getValue(inputObject, "DemographicData.PatientInformation[0]");
        patientInformation.put("Phone", phoneArray);

    }



    private JSONObject matchPatient(JSONObject inputObject, String deploymentId)
            throws IHubException {
        JSONObject matchPatientObject = new JSONObject();
        matchPatientObject.put("patMatchingLayerPriConfStr",
                getPatMatchingLayerPriConfStr(deploymentId));
        matchPatientObject.put("patMatchingAlgoConfigStr", getPatMatchingAlgoConfigStr(deploymentId));
        return matchPatientHandler.processMatchPatient(getSearchPatientObject(inputObject),
                matchPatientObject);
    }

    private String getPatMatchingAlgoConfigStr(String deploymentId) {
        String patMatchingAlgoConfigStr = EMPTY;
        try {
            patMatchingAlgoConfigStr = (String) cacheManager.getStoredProvidersConfig(
                    BaseEPMConstants.EPM_NAME_PREFIX, deploymentId,
                    GENERIC_CONFIG, PAT_MATCHING_ALGO_CONFIG, false);
        } catch (Exception e) {
            log.error("Patient Matching Algo Config is not set for org: " + deploymentId
                    + ", default will be used");
        }
        return patMatchingAlgoConfigStr;
    }

    private String getPatMatchingLayerPriConfStr(String deploymentId) {
        String patMatchingLayerPriConfStr = null;
        try {
            patMatchingLayerPriConfStr = (String) cacheManager.getStoredProvidersConfig(
                    BaseEPMConstants.EPM_NAME_PREFIX, deploymentId, GENERIC_CONFIG,
                    PAT_MATCHING_LAYER_PRIORITY_CONFIG,
                    false);
        } catch (Exception e) {
            log.error(
                    "Patient matching layers priority configuration is not set for org: " + deploymentId);
        }
        return patMatchingLayerPriConfStr;
    }
    private JSONObject getSearchPatientObject(JSONObject inputObject) throws IHubException {
        JSONObject searchPatientJson = new JSONObject();
        copyKey(DEMOGRAPHIC_DATA, inputObject, searchPatientJson);
        copyKey(DEPLOYMENT_ID, inputObject, searchPatientJson);
        copyKey(MESSAGE_CONTROL_ID, inputObject, searchPatientJson);
        copyKey(MESSAGE_TYPE, inputObject, searchPatientJson);
        copyKey(IS_SYNCRONOUS_FLOW, inputObject, searchPatientJson);
        return searchPatientJson;
    }

    @Override
    public JSONObject getPatientInsuranceInfo(JSONObject inputObject) throws IHubException {
        return null;
    }

    @Override
    public JSONObject getPatientDemographics(JSONObject inputObject) throws IHubException {
        JSONObject responseObject=new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();

        try {
            responseObject = cernerApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject, inputObject.optString("flowName"));
            copyKey(Key.DA_PATIENT_ID, inputObject, responseObject);
            HandlerUtils.updateE2DPhones(responseObject);
            getAddress(responseObject);
        } catch (Exception e) {
            log.error("Error in getPatientDemographics "+e);
        }
        copyKey(SCHEDULING_DATA , inputObject, responseObject);
        return responseObject;
    }

    private void getAddress(JSONObject patientObject) throws IHubException {
        try {
            JSONArray addressArray = (JSONArray) getValue(patientObject, CernerEngineConstants.ADDRESS);
            for (Object address : addressArray) {
                if (!isNull(address) && !isEmpty(address)) {
                    JSONObject add = (JSONObject) address;
                    if (add.has(CernerEngineConstants.ADDRESS_TYPE)) {
                        String type = add.getString(CernerEngineConstants.ADDRESS_TYPE);
                        if ("home".equalsIgnoreCase(type)) {

                            JSONArray streetArray = add.getJSONArray("Street");
                            getStreetList(streetArray, add, patientObject);
                            setValue(patientObject, Key.ADDRESS, add);
                        }
                    }
                }
            }
        }catch(Exception e) {
            log.info(e.getMessage());
        }
    }

    private void getStreetList(JSONArray streetArray, JSONObject add, JSONObject patientObject) {
        if (!isEmpty(streetArray)) {
            try {
                List<Object> streetList = streetArray.toList();
                String street = "";
                for (int i = 0; i < streetList.size(); i++) {
                    Object st = streetList.get(i);
                    street = street + st + " ";
                }
                setValue(add, "Street1", street.trim());
                setValue(add, "Street", null);
                setValue(patientObject, CernerEngineConstants.ADDRESS, null);

            } catch (Exception e) {
                log.error("Error in reading address {}", e.getMessage());
            }
        }
    }
}