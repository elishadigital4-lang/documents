package com.pes.integration.epic;

import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.exceptions.IHubException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.*;

@Slf4j
@Component
public class EpicInitEngine {

    @Autowired
    BaseInitEngine baseInitEngine;

    @Autowired
    EpicApiCaller epicApiCaller;

    public void init() throws IHubException {
        String[] configTypes = {GENERIC_CONFIG, EPIC_CONFIG,
                ENVIRONMENT_CONFIG, FILTER_CONFIG};
        initialiseEPMConstants(DATE_FORMAT,
                DATE_TIME_FORMAT,
                TIME_FORMAT,
                BASE_URL,
                TRUE,
                EPM_NAME_PREFIX,
                EPIC_CONFIG,
                RETRY_COUNT,
                REQUEST_MAPPING_KEY_NAME,
                RESPONSE_MAPPING_KEY_NAME,
                REQUEST_CONFIG_KEY_NAME,
                RESPONSE_CODES_MAPPING_KEY_NAME,
                configTypes);
        baseInitEngine.initializeConfig(EPM_NAME_PREFIX, false);
        epicApiCaller.initializeObject();
    }
}