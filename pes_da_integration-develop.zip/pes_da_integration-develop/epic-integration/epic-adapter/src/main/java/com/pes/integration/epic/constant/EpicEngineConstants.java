package com.pes.integration.epic.constant;

public class EpicEngineConstants {

	public static final String EPM_NAME_PREFIX = "ep";
	public static final String EPIC_CONFIG = "epicprop";
	public static final String BLANK = "";
	public static final String RETRY_COUNT = "retrycount";
	public static final String URL = "url";
	public static final String METHOD = "method";
	public static final String NAME = "Name";
	public static final String REQUEST_MAPPING_FILE_NAME = "epic_request_mapping.json";
	public static final String RESPONSE_MAPPING_FILE_NAME = "epic_response_mapping.json";
	public static final String REQUEST_CONFIG_FILE_NAME = "ep_request_config.json";
	public static final String RESPONSE_CODES_MAPPING_FILE_NAME = "epic_response_codes_mapping.json";
	public static final String REQUEST_MAPPING_KEY_NAME = "ep_req_map";

	public static final String RESPONSE_MAPPING_KEY_NAME = "ep_res_map";
	public static final String REQUEST_CONFIG_KEY_NAME = "ep_req_conf";
	public static final String RESPONSE_CODES_MAPPING_KEY_NAME = "ep_res_codes";
	public static final String END_POINT = "epicendpoint";
	public static final String EPM_TYPE = "epic";
	public static final String EPM_CONFIG_GROUPS = "RunBaselineSync,Epic Properties,Filter Service Config";
	public static final String EPIC_CLIENT_ID = "Epic-Client-ID";
	public static final String EPIC_USER_ID = "Epic-UserID";
	public static final String EPIC_USER_ID_TYPE = "Epic-UserIDType";

	public static final String LOC_FILTER = "loc_filter";
	public static final String PROV_FILTER = "prov_filter";
	public static final String ORCHARDUSERID = "orcharduserid";
	public static final String ORCHARDPASSWORD = "orchardpassword";
	public static final String ORCHARDCLIENTID = "orchardclientid";
	public static final String EPICENDPOINT = "epicendpoint";
	public static final String RUN_BY_PROVIDER = "run_by_prov";
	public static final String PROVIDER_CHUNK_SIZE = "prov_chunk_size";
	public static final String ORCHARDCLIENTID_TYPE = "orchardclienttyp";
	public static final String  POLICYHOLDER_RELATION = "policyRelation";
	public static final String PATIENT_FLAG_STATUS_MESSAGE = "Failed to update PatientFlagStatus:";
	public static final String SMART_DATA_ELEMENT_MESSAGE = "Failed to update SmartDataElement:";
	public static final String SUMMARY_VALUE = "Set via a DocASAP";
	public static final String EPIC_CLIENT_ID_VERSION = "epic_client_vr";

	public static final String ACTOR = "actor";
	public static final String PARTICIPANT_ACTOR_IDS = "reference";
	public static final String PARTICIPANT_ACTOR_NAMES = "display";
	public static final String PATIENT = "Patient";
	public static final String PRACTITIONER = "Practitioner";
	public static final String LOCATION = "Location";
	public static final String PRACTIONER_ID = "PractitonerId";
	public static final String PRACTITIONER_FULLNAME = "PractitionerFullName";
	public static final String PATIENT_FULLNAME = "PatientFullName";
	public static final String LOCATION_ID = "LocationId";
	public static final String LOCATION_NAME = "LocationName";
	public static final String EXCEPTION_MESSAGE = "ExceptionMessage";
	public static final String MESSAGE = "Message";
	public static final String APPT_START_DATE = "ApptStartDate";
	public static final String APPT_END_DATE = "ApptEndDate";
	public static final String APPT_TIMING_START = "ApptTimingStart";
	public static final String APPT_STATUS = "ApptStatus";
	public static final String NUMBER= "Number";
	public static final String PHONE_TYPE= "PhoneType";
	public static final String SYSTEM= "system";
	public static final String USE= "use";
	public static final String VALUE= "value";
	public static final String USUAL= "usual";
	public static final String DA_PATIENT_ID= "DAPatientId";
	public static final String UID_SYSTEM = "system_uid";
	public static final String PAT_ID_TYPE = "pat_id_type";

	private EpicEngineConstants() {
	}
}
