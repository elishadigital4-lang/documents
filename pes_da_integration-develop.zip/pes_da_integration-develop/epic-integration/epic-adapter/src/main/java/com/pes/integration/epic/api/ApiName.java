package com.pes.integration.epic.api;

import java.util.Arrays;

/**
 * ENUM class to define different type of API names to be called.
 */
public enum ApiName {
  GET_APPOINTMENT_TYPES("ScheduleAppointmentTypesGet"),
  NEW_PATIENT("new_patient"),
  GET_PATIENT_DEMOGRAPHICS("get_patient_demographics"),
  GET_PATIENT_INSURANCE("get_patient_insurance"),
  UPDATE_PATIENT("update_patient"),
  CANCEL_APPOINTMENT("cancel_appointment"),
  BOOKED_APPOINTMENTS("booked_appointments"),
  OPEN_APPOINTMENTS("open_appointments"),
  NEW_APPOINTMENT("new_appointment"),
  NEW_APPOINTMENT_WITH_INSURANCE("new_appointment_with_insurance"),
  GET_PATIENT("patient_search"),
  GET_COVERAGE("get_coverage"),
  GET_LOCATIONS("get_locations"),
  GET_PROVIDERS("get_providers"),
  GET_PRACTITIONER("get_Practitioner"),
  GET_PROVIDER_SCHEDULE("get_provider_schedule"),
  GET_SCHEDULE_DAYS_FOR_PROVIDER("get_schedule_days_for_provider"),
  UPDATE_DEMOGRAPHICS("update_demographics"),
  GET_AGENT_PATIENT("fhir_patient_search"),
  GET_PATIENTS("patient_lookup"),
  UPDATE_PATIENT_PREFERENCE("update_patient_preference"),
  GET_PATIENT_IDENTIFIER("get_patients_identifier"),
  SET_EXTERNAL_CONNECTION_STATUS("set_external_connection_status"),
  GET_PAYMENTS("get_payments"),
  SUBMIT_INSURANCE("submit_insurance"),
  SET_PATIENT_FLAG("set_patient_flag"),
  SET_SMART_DATA_VALUES("set_smart_data"),
  SYNC_NEW_PATIENT("sync_new_patient"),
  GET_NEW_PATIENT_DETAILS("patient_read"),
  SEARCH_APPOINTMENTS("search_appointment");

  String key;

  ApiName(String key) {
    this.key = key;
  }

  public String getKey() {
    return key;
  }

  public ApiName getEnum(String apiName) {
    return Arrays.stream(values()).filter(api -> api.getKey().equals(apiName)).findFirst().get();
  }


}
