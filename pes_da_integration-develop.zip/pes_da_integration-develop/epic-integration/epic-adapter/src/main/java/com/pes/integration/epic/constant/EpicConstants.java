package com.pes.integration.epic.constant;

import static java.util.Arrays.asList;

import java.util.List;

public class EpicConstants {
	public static final String BASE_URL = "https://ic-fhirworks.epic.com/interconnect-fhir-username/api/epic";

	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_FORMAT1 = "MM/dd/yyyy";
	public static final String DATE_TIME_FORMAT = "MM/dd/yyyy HH:mm:ss";
	public static final String TIME_FORMAT = "HH:mm:ss";
	public static final String EPIC_ENDPOINT = "ep_endpoint";
	public static final String EPICCLIENT_ID = "ep_clientid";
	public static final String SLOTID = "slotId";
	public static final String TIME_FORMAT_AM_PM = "hh:mm a";
	public static final String DATE_TIME_UTC_Z_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final String DATE_TIME_ISO8601_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

	public static final String BOOKED_APPT = "BookedAppointments";
	public static final String BOOKED_APPT_DATE = "start_date";
	public static final String BOOKED_APPT_TIME = "start_time";
	public static final String BOOKED_APPT_DURATION = "Duration";
	public static final String ORCHARD_USR_ID = "orcharduserid";
	public static final String ORCHARD_USR_PSWD = "orchardpassword";
	public static final String NEXT = "next";
	public static final String ID_TYPE_VALUE = "idtypeval";
	public static final String PATIENT_ID_TYPE_VALUE = "patientidtypeval";
	public static final String EXTERNAL_APPT = "ExternalAppt";
	public static final String ID_TYPE = "IdType";
	public static final String TEMP = "temp";
	public static final String EXTERNAL_APPT_ID_TYPE_VALUE = "exapptidtypeval";
	public static final String ORCHARD_CLIENT_ID = "orchardclientid";
	public static final String ORCHARD_CLIENT_ID_TYPE = "orchardclienttyp";
	public static final String HOME_PHONE_TYPE_VALUE = "Home Phone";
	public static final String HOME_PHONE_TYPE_VALUE_AGENT = "home";
	public static final String COUNTRY_VALUE = "United States of America";

	public static final String LOCATIONS = "locations";
	public static final String BOOKED_APPT_PROVIDER = "Providers";
	public static final String BOOKED_APPT_LOCATION = "Locations";

	public static final String PATIENT_ID_TYPE = "DemographicData.PatientInformation[0].PatientIdType";
	public static final String EXTERNAL_APPT_ID_TYPE = "SchedulingData.Schedule[0].ExternalApptIdType";
	public static final String APPOINTMENT_DATE = "SchedulingData.Schedule[0].ApptDate";
	public static final String PROVIDER_ID_TYPE = "SchedulingData.Provider[0].ProviderIdType";
	public static final String LOCATION_ID_TYPE = "SchedulingData.Provider[0].LocationIdType";
	public static final String VISIT_TYPE_ID_TYPE = "SchedulingData.Schedule[0].VisitTypeIdType";
	public static final String HOME_PHONE_TYPE = "DemographicData.PatientInformation[2].HomePhoneType";
	public static final String WORK_PHONE_TYPE = "DemographicData.PatientInformation[1].WorkPhoneType";
	public static final String CELL_PHONE_TYPE = "DemographicData.PatientInformation[0].CellPhoneType";
	public static final String USER_ID = "temp.user_id";
	public static final String USER_ID_TYPE = "temp.user_id_type";
	public static final String COUNTRY = "DemographicData.PatientInformation[0].Addr[0].Country";
	public static final String TIME = "Time";
	public static final String START_TIME = "StartTime";
	public static final String PROVIDER_PATH = "SchedulingData.Provider";
	public static final String MALE = "Male";
	public static final String FEMALE = "Female";
	public static final String GENDER_M = "M";
	public static final String GENDER_F = "F";
	public static final String WORK_PHONE = "DemographicData.PatientInformation[1].WorkPhone";
	public static final String CELL_PHONE = "DemographicData.PatientInformation[0].CellPhone";
	public static final String WORK_PHONE_TYPE_VALUE = "Work Phone";
	public static final String CELL_PHONE_TYPE_VALUE = "Cell Phone";
	public static final String HOME_PHONE_TYPE_VALUE1 = "Home";
	public static final String MOBILE_PHONE_TYPE_VALUE = "Mobile";
	public static final String WORK_PHONE_TYPE_VALUE1 = "Work";
	public static final String PHONE_TYPE = "PhoneType";
	public static final String SYSTEM = "System";
	public static final String PHONE = "phone";
	public static final String PHONES_STRING = "Phones";
	public static final String EMAIL = "email";
	public static final String NAME = "Name";
	public static final String NAME_TYPE = "NameType";
	public static final String ADDRESS_TYPE = "AddressType";
	public static final String PATIENT_FIRST_NAME = "PatientFirstName";
	public static final String PATIENT_LAST_NAME = "PatientLastName";
	public static final String OFFICIAL = "official";


	public static final String SYSTEM_IDENTIFIER ="SystemIdentifier";
	public static final String PAYER_MEMBER_ID = "PayerMemberId";
	public static final String SUBSCRIBER_ID = "SubscriberId";
	public static final List<String> ID_TYPES = asList("EPIC", "FHIR STU3", "FHIR", "MRN");
	public static final String TYPE = "Type";
	public static final String NUMBER = "Number";
	public static final String INSURANCE_INFO = "DemographicData.PatientInformation[0].InsuranceInformation";
	public static final String INSURANCE_INFORMATION = "InsuranceInformation";
	public static final String ADDRESS = "DemographicData.PatientInformation[0].Addr";
	public static final String ADDRESS_ARRAY = "DemographicData.PatientInformation[0].Addr[0]";
	public static final String APPT_DATE = "SchedulingData.Schedule[0].ApptDate";
	public static final String PATIENTS = "DemographicData.PatientInformation[0]";
	public static final String NAMES ="DemographicData.PatientInformation[0].Name";
	public static final String PHONES = "DemographicData.PatientInformation[0].Phones";
	public static final String DEFAULT_CANCEL_REASON = "defcanreason";
	public static final String PROVIDER_ID_TYPE_ID = "provideridtype";
	public static final String EXTERNAL_PATIENT_ID_TYPE = "ExternalPatientIdType";
	public static final String EXTERNAL_PATIENT_ID = "ExternalPatientId";
	public static final String PATIENT_IDS = "DemographicData.PatientInformation[0].Ids";
	public static final String INSURANCE_ID_TYPE_ID = "insuranceidtype";
	public static final String KEY_INSURANCE_ID_TYPE = "DemographicData.InsuranceInformation[0].InsPlanIdType";
	public static final String KEY_PAYOR_ID_TYPE = "DemographicData.InsuranceInformation[0].InsPayorIdType";
	public static final String EXTERNAL_APPT_ID = "ExternalApptId";
	public static final String APPT_REASON = "ApptReason";
	public static final String ALLOW_DUPLICATE_PATIENT = "allow_dup_pat";
	public static final String PHONE_TYPE_ID = "phoneTypeId";
	public static final String STREET_1 = "DemographicData.PatientInformation[0].Addr[0].Street1";
	public static final String STREET_2 = "DemographicData.PatientInformation[0].Addr[0].Street2";
	public static final Object ONE = "1";
	public static final String CUSTOM_FIELDS = "SchedulingData.Schedule[0].CustomFields";
	public static final String CUSTOM_FIELD_ID = "CustomFieldId";
	public static final String CUSTOM_FIELD_VALUE = "CustomFieldValue";
	public static final String VALUES = "Values";
	public static final String SMART_DATA_ELEMENT = "smartdataelement";
	public static final String PATIENT_FLAG = "patientflag";
	// on demand over booking code changes
	public static final String APPOINTMENT_TYPE_MAP = "appointmentTypMap";
	public static final String APPOINTMENT_TYPE_LIST = "appointmentTypList";
	public static final String ON_DEMAND_USERID = "ondemandUserId";
	public static final String ON_DEMAND_PWD = "password";
	public static final String ON_DEMAND_API_USER_KEY = "onDemandAPIUser";
	public static final String ON_DEMAND_VISIT_TYPE_MAP = "ondemandvisittypemap";
	public static final String MINUS_TWO="-2";
	public static final String MINUS_THREE="-3";
	public static final String GROUP_NUMBER="DemographicData.InsuranceInformation[0].GroupNumber";
	public static final String COVERAGE="CoverageClass";
	public static final String APPOINTMENTS="Appointments";
	public static final String AGENT_FLOW="Agent_Flow";
	public static final String PATIENT_FLOW="Patient_Flow";
	public static final String APP_FLOW="AppFlow";
	public static final String EPIC_CLIENTID="epicClientId";
	public static final String IHUB_EPIC_APPID_MAP = "ihub_epic_appid_map";
	public static final String DOCASAP_EPM_APPID_MAP = "docasap_epm_appid_map";
	public static final String APP_ID = "AppId";
	public static final String PATIENT_ID = "PatientId";
	public static final String DEMO_DATA = "DemographicData";
	public static final String PAT_INFO = "PatientInformation";
	public static final String IDS = "Ids";
	public static final String PH = "Phone";
	public static final String CREATE_PATIENT_REQ="createPatientRequest";

	private EpicConstants() {
	}

}