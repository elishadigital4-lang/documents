package com.pes.integration.epic.api;

import static com.pes.integration.constant.BaseEPMConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.IS_SSL_ENABLED;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.KEY_STORE_FILE_PATH;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.KEY_STORE_PASSWORD;
import static com.pes.integration.constant.UtilitiesConstants.POSTPATIENTMADEPAYMENTS;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.epic.constant.EpicEngineConstants.REQUEST_CONFIG_KEY_NAME;
import static com.pes.integration.epic.constant.EpicEngineConstants.REQUEST_MAPPING_KEY_NAME;
import static com.pes.integration.epic.constant.EpicEngineConstants.RESPONSE_MAPPING_KEY_NAME;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static com.pes.integration.jsonmapper.JsonUtils.getMapFromJson;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static org.apache.commons.codec.binary.Base64.encodeBase64;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.epic.component.EpicClientCaller;
import com.pes.integration.epic.constant.EpicConstants;
import com.pes.integration.epic.constant.EpicEngineConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonFormatConverter;
import com.pes.integration.jsonmapper.JsonObjectTerser;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import io.micrometer.observation.annotation.Observed;

import java.util.*;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class EpicApiCaller extends BaseApiCaller {

    @Autowired
    EpicClientCaller epicClientCaller;

    @Autowired
    DataCacheManager cacheManager;

    private String authStringEnc = EMPTY;

    public void initializeObject() throws IHubException {
        requestConfig = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, EPIC_CONFIG,
                REQUEST_CONFIG_KEY_NAME, false);
        requestMapping = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, EPIC_CONFIG,
                REQUEST_MAPPING_KEY_NAME, false);
        responseMapping = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, EPIC_CONFIG,
                RESPONSE_MAPPING_KEY_NAME, false);
    }

    public void initializeAvailabilityObject(JSONObject configurationData) throws IHubException {
        this.configurationData=configurationData;
        requestConfig = new JSONObject(configurationData.optString(REQUEST_CONFIG_KEY_NAME));
        requestMapping = new JSONObject(configurationData.optString(REQUEST_MAPPING_KEY_NAME));
        responseMapping = new JSONObject(configurationData.optString(RESPONSE_MAPPING_KEY_NAME));

        String orchardUserId = (String) configurationData.optString(ORCHARDUSERID);
        String orchardPswd = (String) configurationData.optString(ORCHARDPASSWORD);
        if (StringUtils.isEmpty(authStringEnc)) {
            getAuthStringEnc(orchardUserId, orchardPswd);
        }
    }

    //@SneakyThrows
    @Override
    protected Object callApi(JSONObject apiConfig, JSONObject requestObject) throws IHubException {
        final String deploymentId = getValue(requestObject, DEPLOYMENT_ID).toString();
        EpicApi epicApi = apiCaller(deploymentId);
        requestObject.remove(DEPLOYMENT_ID);
        JSONObject input  = requestObject.optJSONObject("input");
        if(!Objects.isNull(input) && !input.isEmpty()){
            epicApi.setEpicClientId(input.getString("ep_clientid"));
            requestObject.remove("input");
        }
        String url = apiConfig.getString(EpicEngineConstants.URL);
        String method = apiConfig.getString(EpicEngineConstants.METHOD);
        Map<String, String> parameters = JsonUtils.getMapFromJson(requestObject);
        url = buildUrl(epicApi.getEndPoint(), url, parameters);
        setValue(requestObject, KEY_STORE_PASSWORD, getPropertyValue(deploymentId, KEY_STORE_PASSWORD));
        setValue(requestObject, IS_SSL_ENABLED, getPropertyValue(deploymentId, IS_SSL_ENABLED));
        setValue(requestObject, KEY_STORE_FILE_PATH,
                getPropertyValue(deploymentId, KEY_STORE_FILE_PATH));
        String readHeader = null;
        if (apiConfig.has("header")) {
            readHeader = apiConfig.getString("header");
        }
        Object responseObject = null;
        try {
            log.info("Client URL: {}", url);
            responseObject = epicClientCaller.getData(method, url,
                    requestObject.toString(), getHttpHeaders(deploymentId, requestObject, epicApi, parameters, url, readHeader));
            responseObject = new JSONObject(String.valueOf(responseObject));
            log.info("Successfully get data from epic client api");
            responseObject = checkNullResponse(responseObject);
        } catch (IHubException iHubException){
            JSONObject errorJson = new JSONObject();
            errorJson.accumulate(EpicEngineConstants.EXCEPTION_MESSAGE, "Error Occurred - "+iHubException.getMessage());
            errorJson.put("errorCode", iHubException.getStatusCode());
            errorJson.put("statusCodes", iHubException.getErrorCode().getCode());
            return  errorJson;
        }
        catch (Exception e) {
            JSONObject errorJson = new JSONObject();
            log.error("Error in calling Epic API {}", e.getMessage());
            errorJson.put("errorCode", UNABLE_TO_PROCESS_MESSAGE);
            errorJson.put("statusCode", StatusCodes.UNABLE_TO_PROCESS_MESSAGE.getKey());
            JSONObject jsonObject=new JSONObject();
            jsonObject.accumulate(EpicEngineConstants.MESSAGE,e.getMessage());
            jsonObject.accumulate(EpicEngineConstants.EXCEPTION_MESSAGE,errorJson.toString());
            responseObject = jsonObject;
            return responseObject;
        }
        return responseObject;
    }

    private static Object checkNullResponse(Object responseObject) {
        if (((JSONObject) responseObject).has("null")) {
            try {
                String epmFormatDataString = responseObject.toString();
                responseObject = new JSONObject(epmFormatDataString.replace("null", "HTTP-Header"));
            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
        return responseObject;
    }

    private String getOnDemandAuthStringEncoded(Object requestObject) {
        String onDemandAPIAuthStringEnc = null;
        try {
            JSONObject requestObjectJson = new JSONObject(requestObject.toString());
            onDemandAPIAuthStringEnc = (String) requestObjectJson.get(ON_DEMAND_API_USER_KEY);
        } catch (JSONException e) {
            log.error(e.getMessage());
        }
        return onDemandAPIAuthStringEnc;
    }

    private Object getPropertyValue(String deploymentId, String propertyKey) {
        try {
            return cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX,
                    deploymentId, EPIC_CONFIG, propertyKey, false);
        } catch (IHubException e) {
            log.info("Property key {} value is not set for:: {}", propertyKey, deploymentId);
        }
        return null;
    }

    private String buildUrl(String baseUrl, String url, Map<String, String> parameters) {
        String commentValue = null;
        int keepCommentLast = (url.contains(POSTPATIENTMADEPAYMENTS)) ? 1 : 0;
        if (url.contains("?")) {
            StringBuilder sb = new StringBuilder();
            commentValue = loopingThroughUrl(parameters.keySet().toArray(), url, parameters,
                    keepCommentLast, sb);
            if (!isEmpty(commentValue)) {
                sb.append("&").append(commentValue);
            }
            url = url.substring(0, url.indexOf("?") + 1) + sb.toString();
        }
        return String.format("%s/%s", baseUrl, url.contains(":") ? buildBaseUrl(url, parameters) : url);
    }

    private String buildBaseUrl(String endPoint, Map<String, String> parameters) {
        StringTokenizer tokenizer = new StringTokenizer(endPoint, "/");
        String newUrl = "";
        while (tokenizer.hasMoreTokens()) {
            String urlPart = tokenizer.nextToken();
            if (urlPart.startsWith(":")) {
                urlPart = parameters.get(urlPart);
                if (urlPart != null) {
                    parameters.remove(urlPart);
                }
            }
            newUrl = new StringBuilder(newUrl).append("/").append(urlPart).toString();
        }
        return newUrl;
    }

    private String loopingThroughUrl(Object[] keyArray, String url, Map<String, String> parameters,
                                     int keepCommentLast, StringBuilder sb) {
        int f = 0;
        String commentValue = null;
        for (int i = 0; i < keyArray.length; i++) {
            String key = keyArray[i].toString();
            if (url.contains(key)) {
                if (key.equals(UtilitiesConstants.COMMENT) && keepCommentLast == 1) {
                    commentValue = parameters.get(key);
                } else {
                    if (f == 1) {
                        sb.append("&");
                    }
                    sb.append(String.format("%s=%s", key, parameters.get(key)));
                    f = 1;
                }
            }
        }
        return commentValue;
    }

    @SneakyThrows
    private HttpHeaders getHttpHeaders(String deploymentId, JSONObject requestObject, EpicApi epicApi, Map<String, String> params, String apiName, String readHeader) {
        HttpHeaders headers = new HttpHeaders();
        String onDemandAPIAuthStringEnc = getOnDemandAuthStringEncoded(requestObject);
        if (readHeader != null && readHeader.equals("true")) {
            headers.add("readHeader", readHeader);
        }
        if (params.containsKey(EPIC_CLIENTID)) {
            headers.set(EPIC_CLIENT_ID, params.get(EPIC_CLIENTID));
            params.remove(EPIC_CLIENTID);
        } else {
            headers.set(EPIC_CLIENT_ID, epicApi.getEpicClientId());
            log.info("Selected normal Epic API client id");
        }
        if (apiName.contains("api/epic")) {
            headers.setBasicAuth(epicApi.getAuthStringEnc());
            log.info("Routing to normal Epic API call");
        } else if (!NullChecker.isEmpty(onDemandAPIAuthStringEnc)) {
            headers.setBasicAuth(onDemandAPIAuthStringEnc);
        } else if(apiName.contains("api/FHIR")){
            headers.set(EPIC_USER_ID, epicApi.getEpicClientUserId());
            headers.set(EPIC_USER_ID_TYPE, epicApi.getEpicClientUserIdType());
            headers.set("Accept", "application/json");
            headers.setBasicAuth(epicApi.getAuthStringEnc());
            log.info("Routing to Epic FHIR API call");
        }
        return headers;
    }

    @Override
    protected void getMappingConfig(String deploymentId){
        /*
         * not needed for this implementation
         */
    }

    @Override
    protected JSONObject customizeResponseMapping(JSONObject apiResponseMapping, String apiName, Object inputObject) {
        return null;
    }

    public EpicApi apiCaller(String deploymentId) throws IHubException {
        String orchardUserId = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, ORCHARD_USR_ID, false);
        String orchardClientUserId = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, ORCHARD_CLIENT_ID, false);
        String orchardClientUserIdType = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, ORCHARD_CLIENT_ID_TYPE, false);
        String orchardPswd = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, ORCHARD_USR_PSWD, false);
        String endPoint = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, END_POINT, false);
        String clientId = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, EPIC_CLIENT_ID, false);
        String authString = getAuthStringEnc(orchardUserId, orchardPswd);
        return new EpicApi(orchardUserId, orchardPswd, endPoint, authString, clientId, orchardClientUserId, orchardClientUserIdType);
    }

    private String getAuthStringEnc(String username, String password) {
        String authString = username + ":" + password;
        authStringEnc = new String(encodeBase64(authString.getBytes()));
        return authStringEnc;
    }
}
