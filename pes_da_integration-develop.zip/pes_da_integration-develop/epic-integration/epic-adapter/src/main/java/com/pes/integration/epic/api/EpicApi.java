package com.pes.integration.epic.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EpicApi {

    String username;
    String password;
    String endPoint;
    String authStringEnc;
    String epicClientId;
    String epicClientUserId;
    String epicClientUserIdType;
}
