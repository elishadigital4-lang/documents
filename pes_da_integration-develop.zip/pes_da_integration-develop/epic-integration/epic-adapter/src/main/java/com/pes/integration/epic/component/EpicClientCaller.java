package com.pes.integration.epic.component;

import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import io.micrometer.core.annotation.Timed;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.utils.MetricsUtil.metricClientRequestCountWithDeploymentId;
import static com.pes.integration.utils.MetricsUtil.metricClientError4XXCountWithDeploymentId;
import static com.pes.integration.utils.MetricsUtil.metricClientError5XXCountWithDeploymentId;
import static com.pes.integration.utils.MetricsUtil.metricClientSuccessCountWithDeploymentId;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.springframework.http.HttpMethod.valueOf;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Slf4j
@Component
public class EpicClientCaller {

  @Autowired
  WebClient webClient;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;

    @Value("${ignorable.patient.errors.list}")
    private List<String> ignorablePatientErrors;

    @Value("${shorten.error.string.list}")
    private List<String> shortenErrorsString;

    public static final List<String> IGNORABLE_ERRORS = Arrays.asList("No matching patients found", "MAKE-FAIL details: code:APTWARN ERROR", "MAKE-FAIL details: code:CADENCE: LOCK FAILED");
  @Observed(name = "integration.getEpicApiData", contextualName = "integration")
  @Timed(value = "epic.client.api.request.latency", description = "Time taken to process epic client APIs")
  public String getData(String httpMethod, String url, String body, HttpHeaders headers) throws IHubException{
      String deploymentId = MDC.get(DEPLOYMENT_ID) != null ? MDC.get(DEPLOYMENT_ID) : EMPTY;
      String shortenUrl = getShortenUrl(url);
      metricClientRequestCountWithDeploymentId(engineName, appDescription, deploymentId,httpMethod+" - "+ shortenUrl);
      return webClient.method(valueOf(httpMethod))
        .uri(url)
        .accept(APPLICATION_JSON)
        .contentType(APPLICATION_JSON)
        .headers(header -> header.addAll(headers))
        .body(Mono.just(body), String.class)
        .retrieve()
        .onStatus(HttpStatusCode::isError, clientResponse -> clientResponse.bodyToMono(String.class)
            .flatMap(errorBody -> {
                handleErrorResponse(httpMethod, clientResponse, errorBody, shortenUrl, deploymentId);
                return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(),
                  errorBody));
            }))
        .bodyToMono(String.class)
            .onErrorMap(ex -> {
                log.error(
                    "Error while calling epic api with  Error message:: {} ", ex.getMessage());
                return new IHubException(StatusCodes.EPM_INTERNAL_ERROR, ex.getMessage(),"");
            })
        .doOnSuccess(response -> {
            metricClientSuccessCountWithDeploymentId(engineName, appDescription, deploymentId,httpMethod+" - "+ shortenUrl);
            log.info("Successfully fetched data for epic Api for url {} ", sanitizeForLog(url));
        }).block();
  }

    public void handleErrorResponse(String httpMethod, ClientResponse clientResponse, String errorBody, String shortenUrl, String deploymentId) {
        //we are not incrementing client error metrics for ignorable errors
        if (errorBody != null) {
            if (ignorablePatientErrors.stream().noneMatch(errorBody::contains)) {
                boolean errorStringMatched = shortenErrorsString.stream().anyMatch(errorString -> {
                    if (errorBody.contains(errorString)) {
                        log.info("INFO - Error while calling epic api with status code:: {} and errorBody:: {}",
                                clientResponse.statusCode(), errorBody);
                        recordErrorMetrics(clientResponse, errorString, shortenUrl, deploymentId);
                        return true;
                    }
                    return false;
                });
                if (!errorStringMatched) {
                    log.error("Error while calling epic api with status code:: {} and errorBody:: {}",
                            clientResponse.statusCode(), errorBody);
                    recordErrorMetrics(clientResponse, errorBody, shortenUrl, deploymentId);
                }
            } else {
                metricClientSuccessCountWithDeploymentId(engineName, appDescription, deploymentId, httpMethod + " - " + shortenUrl);
            }
        } else {
            log.error("Error while calling Epic api with status code:: {} and errorBody:: {}",
                    clientResponse.statusCode(), "null");
            recordErrorMetrics(clientResponse, "null", shortenUrl, deploymentId);
        }
    }

    public String getShortenUrl(String url) {
        if (url != null && url.contains("?")){
            return url.substring(0, url.indexOf("?"));
        }
        return url;
    }

    public void recordErrorMetrics(ClientResponse clientResponse, String errorBody, String shortenUrl, String deploymentId) {
        if (clientResponse.statusCode().is4xxClientError()) {
            metricClientError4XXCountWithDeploymentId(engineName, appDescription, deploymentId, errorBody, String.valueOf(clientResponse.statusCode().value()), shortenUrl);
        } else if (clientResponse.statusCode().is5xxServerError()) {
            metricClientError5XXCountWithDeploymentId(engineName, appDescription, deploymentId, errorBody, String.valueOf(clientResponse.statusCode().value()), shortenUrl);
        }
    }
}