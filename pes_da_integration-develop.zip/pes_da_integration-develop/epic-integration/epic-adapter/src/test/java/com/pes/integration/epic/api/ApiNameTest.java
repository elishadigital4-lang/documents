package com.pes.integration.epic.api;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ApiNameTest {
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void getEnum_returnsCorrectEnumForValidKey() {
        ApiName result = ApiName.GET_APPOINTMENT_TYPES.getEnum("ScheduleAppointmentTypesGet");
        assertEquals(ApiName.GET_APPOINTMENT_TYPES, result);
    }

    @Test
    void getEnum_throwsExceptionForInvalidKey() {
        assertThrows(NoSuchElementException.class, () -> ApiName.GET_APPOINTMENT_TYPES.getEnum("invalid_key"));
    }

    @Test
    void getKey_returnsCorrectKey() {
        assertEquals("ScheduleAppointmentTypesGet", ApiName.GET_APPOINTMENT_TYPES.getKey());
    }

    @Test
    void getEnum_returnsCorrectEnumForAnotherValidKey() {
        ApiName result = ApiName.NEW_PATIENT.getEnum("new_patient");
        assertEquals(ApiName.NEW_PATIENT, result);
    }

    @Test
    void getEnum_handlesNullKey() {
        assertThrows(NoSuchElementException.class, () -> ApiName.GET_APPOINTMENT_TYPES.getEnum(null));
    }
}
