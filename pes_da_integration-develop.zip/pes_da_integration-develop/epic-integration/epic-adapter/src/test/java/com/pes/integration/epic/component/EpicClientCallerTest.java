package com.pes.integration.epic.component;

import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.function.Function;

import static com.pes.integration.constant.UtilitiesConstants.GET;
import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EpicClientCallerTest {
    @InjectMocks
    private EpicClientCaller epicClientCaller;
    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec<?> requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private ClientResponse clientResponse;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        setPrivateField(epicClientCaller, "ignorablePatientErrors", Arrays.asList("No matching patients found", "LOCK FAILED"));
        setPrivateField(epicClientCaller, "shortenErrorsString", Arrays.asList("Error1", "Error2"));
        setPrivateField(epicClientCaller, "engineName", "TestEngine");
        setPrivateField(epicClientCaller, "appDescription", "TestApp");
    }

    @Test
    void getData_returnsResponseBodyOnSuccess() throws IHubException {
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            String url = "http://example.com";
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", "Bearer token");
            when(webClient.method(HttpMethod.valueOf(GET))).thenAnswer(reqMethod -> requestBodyUriSpec);
            when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
            when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
            when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
            when(requestBodySpec.body(any(), eq(String.class))).thenAnswer(reqBody -> requestHeadersSpec);
            when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("response"));

            String result = epicClientCaller.getData("GET", url, "{}", headers);
            assertEquals("response", result);
        }
    }

    @Test
    void getData_throwsIHubExceptionOnClientError() {
        HttpHeaders headers = new HttpHeaders();
        String httpMethod = GET;
        String url = "http://example.com?";
        headers.add("Authorization", "Bearer token");
        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenAnswer(reqMethod -> requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenAnswer(reqBody ->requestHeadersSpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(eq(String.class))).thenReturn(Mono.error(new IHubException(new IHubErrorCode("400"), "Bad Request")));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            try {
                epicClientCaller.getData(httpMethod, url, "{}", headers);
            } catch (Exception e) {
                assertTrue(e.getMessage().contains("Bad Request"));
            }
        }

    }

    @Test
    void getData_logsErrorOnException() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer token");
        lenient().when(webClient.method(HttpMethod.valueOf(anyString()))).thenAnswer(reqMethod -> requestBodyUriSpec);

        assertThrows(RuntimeException.class, () -> epicClientCaller.getData("GET", "http://example.com", "{}", headers));
    }
    @Test
    void getDataExceptionOnErrorStatus() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer token");
        String url = "http://example.com";
        String httpMethod = GET;
        String errorBody = "Error occurred";

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(), eq(String.class))).thenAnswer(reqBody -> requestHeadersSpec);
        when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<Throwable>> errorFunction = invocation.getArgument(1);
            ClientResponse clientResponse = mock(ClientResponse.class);
            lenient().when(clientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorBody));
            lenient().when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);
            return Mono.error(new IHubException(INVALID_REQUEST.getErrorCode(),
                    errorBody));
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            Exception exception = assertThrows(Exception.class, () -> {
                epicClientCaller.getData(httpMethod, url, "{}", headers);
            });
        }
    }

    @Test
    void testHandleErrorResponse_IgnorableError() {
        String errorBody = "No matching patients found";

        try (MockedStatic<MetricsUtil> mockedMetrics = mockStatic(MetricsUtil.class)) {
            epicClientCaller.handleErrorResponse("GET", clientResponse, errorBody, "http://example.com", "deployment123");

            mockedMetrics.verify(() -> MetricsUtil.metricClientSuccessCountWithDeploymentId(
                    "TestEngine", "TestApp", "deployment123", "GET - http://example.com"), times(1));
        }
    }

    @Test
    void testHandleErrorResponse_ShortenedError() {
        String errorBody = "Error1 occurred";
        when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);

        try (MockedStatic<MetricsUtil> mockedMetrics = mockStatic(MetricsUtil.class)) {
            epicClientCaller.handleErrorResponse("POST", clientResponse, errorBody, "http://example.com", "deployment123");

            mockedMetrics.verify(() -> MetricsUtil.metricClientError4XXCountWithDeploymentId(
                    "TestEngine", "TestApp", "deployment123", "Error1", "400", "http://example.com"), times(1));
        }
    }

    @Test
    void testHandleErrorResponse_NonIgnorableError() {
        String errorBody = "Some other error";
        when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);

        try (MockedStatic<MetricsUtil> mockedMetrics = mockStatic(MetricsUtil.class)) {
            epicClientCaller.handleErrorResponse("PUT", clientResponse, errorBody, "http://example.com", "deployment123");

            mockedMetrics.verify(() -> MetricsUtil.metricClientError5XXCountWithDeploymentId(
                    "TestEngine", "TestApp", "deployment123", "Some other error", "500", "http://example.com"), times(1));
        }
    }

    @Test
    void testHandleErrorResponse_NullErrorBody() {
        when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);

        try (MockedStatic<MetricsUtil> mockedMetrics = mockStatic(MetricsUtil.class)) {
            epicClientCaller.handleErrorResponse("DELETE", clientResponse, null, "http://example.com", "deployment123");

            mockedMetrics.verify(() -> MetricsUtil.metricClientError5XXCountWithDeploymentId(
                    "TestEngine", "TestApp", "deployment123", "null", "500", "http://example.com"), times(1));
        }
    }

    @Test
    void testRecordErrorMetrics_4xxError() {
        when(clientResponse.statusCode()).thenReturn(HttpStatus.BAD_REQUEST);

        try (MockedStatic<MetricsUtil> mockedMetrics = mockStatic(MetricsUtil.class)) {
            epicClientCaller.recordErrorMetrics(clientResponse, "Error message", "http://example.com", "deployment123");

            mockedMetrics.verify(() -> MetricsUtil.metricClientError4XXCountWithDeploymentId(
                    "TestEngine", "TestApp", "deployment123", "Error message", "400", "http://example.com"), times(1));
        }
    }

    @Test
    void testRecordErrorMetrics_5xxError() {
        when(clientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);

        try (MockedStatic<MetricsUtil> mockedMetrics = mockStatic(MetricsUtil.class)) {
            epicClientCaller.recordErrorMetrics(clientResponse, "Error message", "http://example.com", "deployment123");

            mockedMetrics.verify(() -> MetricsUtil.metricClientError5XXCountWithDeploymentId(
                    "TestEngine", "TestApp", "deployment123", "Error message", "500", "http://example.com"), times(1));
        }
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}
