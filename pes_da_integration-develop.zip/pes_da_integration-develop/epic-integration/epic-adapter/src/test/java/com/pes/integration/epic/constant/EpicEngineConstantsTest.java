package com.pes.integration.epic.constant;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EpicEngineConstantsTest {
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void EPM_NAME_PREFIX_ShouldBe_ep() {
        assertEquals("ep", EpicEngineConstants.EPM_NAME_PREFIX);
    }

    @Test
    void EPIC_CONFIG_ShouldBe_epicprop() {
        assertEquals("epicprop", EpicEngineConstants.EPIC_CONFIG);
    }

    @Test
    void BLANK_ShouldBe_EmptyString() {
        assertEquals("", EpicEngineConstants.BLANK);
    }

    @Test
    void RETRY_COUNT_ShouldBe_retrycount() {
        assertEquals("retrycount", EpicEngineConstants.RETRY_COUNT);
    }

    @Test
    void URL_ShouldBe_url() {
        assertEquals("url", EpicEngineConstants.URL);
    }

    @Test
    void METHOD_ShouldBe_method() {
        assertEquals("method", EpicEngineConstants.METHOD);
    }

    @Test
    void NAME_ShouldBe_Name() {
        assertEquals("Name", EpicEngineConstants.NAME);
    }

    @Test
    void REQUEST_MAPPING_FILE_NAME_ShouldBe_epic_request_mapping_json() {
        assertEquals("epic_request_mapping.json", EpicEngineConstants.REQUEST_MAPPING_FILE_NAME);
    }

    @Test
    void RESPONSE_MAPPING_FILE_NAME_ShouldBe_epic_response_mapping_json() {
        assertEquals("epic_response_mapping.json", EpicEngineConstants.RESPONSE_MAPPING_FILE_NAME);
    }

    @Test
    void REQUEST_CONFIG_FILE_NAME_ShouldBe_ep_request_config_json() {
        assertEquals("ep_request_config.json", EpicEngineConstants.REQUEST_CONFIG_FILE_NAME);
    }

    @Test
    void RESPONSE_CODES_MAPPING_FILE_NAME_ShouldBe_epic_response_codes_mapping_json() {
        assertEquals("epic_response_codes_mapping.json", EpicEngineConstants.RESPONSE_CODES_MAPPING_FILE_NAME);
    }

    @Test
    void REQUEST_MAPPING_KEY_NAME_ShouldBe_ep_req_map() {
        assertEquals("ep_req_map", EpicEngineConstants.REQUEST_MAPPING_KEY_NAME);
    }

    @Test
    void RESPONSE_MAPPING_KEY_NAME_ShouldBe_ep_res_map() {
        assertEquals("ep_res_map", EpicEngineConstants.RESPONSE_MAPPING_KEY_NAME);
    }

    @Test
    void REQUEST_CONFIG_KEY_NAME_ShouldBe_ep_req_conf() {
        assertEquals("ep_req_conf", EpicEngineConstants.REQUEST_CONFIG_KEY_NAME);
    }

    @Test
    void RESPONSE_CODES_MAPPING_KEY_NAME_ShouldBe_ep_res_codes() {
        assertEquals("ep_res_codes", EpicEngineConstants.RESPONSE_CODES_MAPPING_KEY_NAME);
    }

    @Test
    void END_POINT_ShouldBe_epicendpoint() {
        assertEquals("epicendpoint", EpicEngineConstants.END_POINT);
    }

    @Test
    void EPM_TYPE_ShouldBe_epic() {
        assertEquals("epic", EpicEngineConstants.EPM_TYPE);
    }

    @Test
    void EPM_CONFIG_GROUPS_ShouldBe_RunBaselineSync_EpicProperties_FilterServiceConfig() {
        assertEquals("RunBaselineSync,Epic Properties,Filter Service Config", EpicEngineConstants.EPM_CONFIG_GROUPS);
    }

    @Test
    void EPIC_CLIENT_ID_ShouldBe_Epic_Client_ID() {
        assertEquals("Epic-Client-ID", EpicEngineConstants.EPIC_CLIENT_ID);
    }

    @Test
    void EPIC_USER_ID_ShouldBe_Epic_UserID() {
        assertEquals("Epic-UserID", EpicEngineConstants.EPIC_USER_ID);
    }

    @Test
    void EPIC_USER_ID_TYPE_ShouldBe_Epic_UserIDType() {
        assertEquals("Epic-UserIDType", EpicEngineConstants.EPIC_USER_ID_TYPE);
    }

    @Test
    void LOC_FILTER_ShouldBe_loc_filter() {
        assertEquals("loc_filter", EpicEngineConstants.LOC_FILTER);
    }

    @Test
    void PROV_FILTER_ShouldBe_prov_filter() {
        assertEquals("prov_filter", EpicEngineConstants.PROV_FILTER);
    }

    @Test
    void ORCHARDUSERID_ShouldBe_orcharduserid() {
        assertEquals("orcharduserid", EpicEngineConstants.ORCHARDUSERID);
    }

    @Test
    void ORCHARDPASSWORD_ShouldBe_orchardpassword() {
        assertEquals("orchardpassword", EpicEngineConstants.ORCHARDPASSWORD);
    }

    @Test
    void ORCHARDCLIENTID_ShouldBe_orchardclientid() {
        assertEquals("orchardclientid", EpicEngineConstants.ORCHARDCLIENTID);
    }

    @Test
    void EPICENDPOINT_ShouldBe_epicendpoint() {
        assertEquals("epicendpoint", EpicEngineConstants.EPICENDPOINT);
    }

    @Test
    void RUN_BY_PROVIDER_ShouldBe_run_by_prov() {
        assertEquals("run_by_prov", EpicEngineConstants.RUN_BY_PROVIDER);
    }

    @Test
    void PROVIDER_CHUNK_SIZE_ShouldBe_prov_chunk_size() {
        assertEquals("prov_chunk_size", EpicEngineConstants.PROVIDER_CHUNK_SIZE);
    }

    @Test
    void ORCHARDCLIENTID_TYPE_ShouldBe_orchardclienttyp() {
        assertEquals("orchardclienttyp", EpicEngineConstants.ORCHARDCLIENTID_TYPE);
    }

    @Test
    void POLICYHOLDER_RELATION_ShouldBe_policyRelation() {
        assertEquals("policyRelation", EpicEngineConstants.POLICYHOLDER_RELATION);
    }

    @Test
    void PATIENT_FLAG_STATUS_MESSAGE_ShouldBe_Failed_to_update_PatientFlagStatus() {
        assertEquals("Failed to update PatientFlagStatus:", EpicEngineConstants.PATIENT_FLAG_STATUS_MESSAGE);
    }

    @Test
    void SMART_DATA_ELEMENT_MESSAGE_ShouldBe_Failed_to_update_SmartDataElement() {
        assertEquals("Failed to update SmartDataElement:", EpicEngineConstants.SMART_DATA_ELEMENT_MESSAGE);
    }

    @Test
    void SUMMARY_VALUE_ShouldBe_Set_via_a_DocASAP() {
        assertEquals("Set via a DocASAP", EpicEngineConstants.SUMMARY_VALUE);
    }

    @Test
    void EPIC_CLIENT_ID_VERSION_ShouldBe_epic_client_vr() {
        assertEquals("epic_client_vr", EpicEngineConstants.EPIC_CLIENT_ID_VERSION);
    }

    @Test
    void ACTOR_ShouldBe_actor() {
        assertEquals("actor", EpicEngineConstants.ACTOR);
    }

    @Test
    void PARTICIPANT_ACTOR_IDS_ShouldBe_reference() {
        assertEquals("reference", EpicEngineConstants.PARTICIPANT_ACTOR_IDS);
    }

    @Test
    void PARTICIPANT_ACTOR_NAMES_ShouldBe_display() {
        assertEquals("display", EpicEngineConstants.PARTICIPANT_ACTOR_NAMES);
    }

    @Test
    void PATIENT_ShouldBe_Patient() {
        assertEquals("Patient", EpicEngineConstants.PATIENT);
    }

    @Test
    void PRACTITIONER_ShouldBe_Practitioner() {
        assertEquals("Practitioner", EpicEngineConstants.PRACTITIONER);
    }

    @Test
    void LOCATION_ShouldBe_Location() {
        assertEquals("Location", EpicEngineConstants.LOCATION);
    }

    @Test
    void PRACTIONER_ID_ShouldBe_PractitonerId() {
        assertEquals("PractitonerId", EpicEngineConstants.PRACTIONER_ID);
    }

    @Test
    void PRACTITIONER_FULLNAME_ShouldBe_PractitionerFullName() {
        assertEquals("PractitionerFullName", EpicEngineConstants.PRACTITIONER_FULLNAME);
    }

    @Test
    void PATIENT_FULLNAME_ShouldBe_PatientFullName() {
        assertEquals("PatientFullName", EpicEngineConstants.PATIENT_FULLNAME);
    }

    @Test
    void LOCATION_ID_ShouldBe_LocationId() {
        assertEquals("LocationId", EpicEngineConstants.LOCATION_ID);
    }

    @Test
    void LOCATION_NAME_ShouldBe_LocationName() {
        assertEquals("LocationName", EpicEngineConstants.LOCATION_NAME);
    }

    @Test
    void EXCEPTION_MESSAGE_ShouldBe_ExceptionMessage() {
        assertEquals("ExceptionMessage", EpicEngineConstants.EXCEPTION_MESSAGE);
    }

    @Test
    void MESSAGE_ShouldBe_Message() {
        assertEquals("Message", EpicEngineConstants.MESSAGE);
    }

    @Test
    void APPT_START_DATE_ShouldBe_ApptStartDate() {
        assertEquals("ApptStartDate", EpicEngineConstants.APPT_START_DATE);
    }

    @Test
    void APPT_END_DATE_ShouldBe_ApptEndDate() {
        assertEquals("ApptEndDate", EpicEngineConstants.APPT_END_DATE);
    }

    @Test
    void APPT_TIMING_START_ShouldBe_ApptTimingStart() {
        assertEquals("ApptTimingStart", EpicEngineConstants.APPT_TIMING_START);
    }

    @Test
    void APPT_STATUS_ShouldBe_ApptStatus() {
        assertEquals("ApptStatus", EpicEngineConstants.APPT_STATUS);
    }

    @Test
    void NUMBER_ShouldBe_Number() {
        assertEquals("Number", EpicEngineConstants.NUMBER);
    }

    @Test
    void PHONE_TYPE_ShouldBe_PhoneType() {
        assertEquals("PhoneType", EpicEngineConstants.PHONE_TYPE);
    }

    @Test
    void SYSTEM_ShouldBe_system() {
        assertEquals("system", EpicEngineConstants.SYSTEM);
    }

    @Test
    void USE_ShouldBe_use() {
        assertEquals("use", EpicEngineConstants.USE);
    }

    @Test
    void VALUE_ShouldBe_value() {
        assertEquals("value", EpicEngineConstants.VALUE);
    }

    @Test
    void USUAL_ShouldBe_usual() {
        assertEquals("usual", EpicEngineConstants.USUAL);
    }

    @Test
    void DA_PATIENT_ID_ShouldBe_DAPatientId() {
        assertEquals("DAPatientId", EpicEngineConstants.DA_PATIENT_ID);
    }

    @Test
    void UID_SYSTEM_ShouldBe_system_uid() {
        assertEquals("system_uid", EpicEngineConstants.UID_SYSTEM);
    }

    @Test
    void PAT_ID_TYPE_ShouldBe_pat_id_type() {
        assertEquals("pat_id_type", EpicEngineConstants.PAT_ID_TYPE);
    }
}