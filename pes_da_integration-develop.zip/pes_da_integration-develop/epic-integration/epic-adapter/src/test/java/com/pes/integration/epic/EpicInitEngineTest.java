package com.pes.integration.epic;

import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.exceptions.IHubException;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.pes.integration.constant.UtilitiesConstants.*;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class EpicInitEngineTest {

    @Mock
    private BaseInitEngine baseInitEngine;
    @InjectMocks
    private EpicInitEngine epicInitEngine;
    @Mock
    private EpicApiCaller epicApiCaller;
    @Mock
    private DataCacheManager cacheManager;
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @SneakyThrows
    @Test
    void init_callsBaseInitEngineAndEpicApiCaller() {
        try (MockedStatic<BaseEPMConstants> utilitiesConstantsMockedStatic = mockStatic(BaseEPMConstants.class)) {
            epicInitEngine.init();
            utilitiesConstantsMockedStatic.verify(() -> BaseEPMConstants.initialiseEPMConstants(
                    DATE_FORMAT,
                    DATE_TIME_FORMAT,
                    TIME_FORMAT,
                    BASE_URL,
                    TRUE,
                    EPM_NAME_PREFIX,
                    EPIC_CONFIG,
                    RETRY_COUNT,
                    REQUEST_MAPPING_KEY_NAME,
                    RESPONSE_MAPPING_KEY_NAME,
                    REQUEST_CONFIG_KEY_NAME,
                    RESPONSE_CODES_MAPPING_KEY_NAME,
                    new String[]{GENERIC_CONFIG, EPIC_CONFIG, ENVIRONMENT_CONFIG, FILTER_CONFIG}));
            verify(baseInitEngine).initializeConfig(EPM_NAME_PREFIX, false);
            verify(epicApiCaller).initializeObject();
        }
    }

    @Test
    void initEpicEngineThrowsIHubException() throws IHubException {
        doThrow(new RuntimeException("Base Init Engine Error"))
                .when(baseInitEngine).initializeConfig(anyString(), anyBoolean());
        assertThrows(RuntimeException.class, () -> epicInitEngine.init());
        verify(baseInitEngine).initializeConfig(EPM_NAME_PREFIX, false);
        verify(epicApiCaller, never()).initializeObject();
    }

    @Test
    void initEpicApiCallerThrowsException() throws IHubException {
        doThrow(new RuntimeException("API Caller Error"))
                .when(epicApiCaller).initializeObject();
        assertThrows(RuntimeException.class, () -> epicInitEngine.init());
        verify(baseInitEngine).initializeConfig(EPM_NAME_PREFIX, false);
        verify(epicApiCaller).initializeObject();
    }

    @Test
    void initBaseInitEngineThrowsException() throws IHubException {
        doThrow(new RuntimeException("Base Init Engine Error"))
                .when(baseInitEngine).initializeConfig(anyString(), anyBoolean());
        assertThrows(RuntimeException.class, () -> epicInitEngine.init());
        verify(baseInitEngine).initializeConfig(EPM_NAME_PREFIX, false);
        verify(epicApiCaller, never()).initializeObject();
    }
}
