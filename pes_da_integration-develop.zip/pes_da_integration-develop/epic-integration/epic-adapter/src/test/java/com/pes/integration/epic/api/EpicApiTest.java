package com.pes.integration.epic.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class EpicApiTest {
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void constructor_initializesAllFields() {
        EpicApi epicApi = new EpicApi("user", "pass", "endpoint", "authString", "clientId", "clientUserId", "clientUserIdType");
        assertEquals("user", epicApi.getUsername());
        assertEquals("pass", epicApi.getPassword());
        assertEquals("endpoint", epicApi.getEndPoint());
        assertEquals("authString", epicApi.getAuthStringEnc());
        assertEquals("clientId", epicApi.getEpicClientId());
        assertEquals("clientUserId", epicApi.getEpicClientUserId());
        assertEquals("clientUserIdType", epicApi.getEpicClientUserIdType());
    }

    @Test
    void noArgsConstructor_initializesFieldsToNull() {
        EpicApi epicApi = new EpicApi();
        assertNull(epicApi.getUsername());
        assertNull(epicApi.getPassword());
        assertNull(epicApi.getEndPoint());
        assertNull(epicApi.getAuthStringEnc());
        assertNull(epicApi.getEpicClientId());
        assertNull(epicApi.getEpicClientUserId());
        assertNull(epicApi.getEpicClientUserIdType());
    }

    @Test
    void setters_updateFieldsCorrectly() {
        EpicApi epicApi = new EpicApi();
        epicApi.setUsername("newUser");
        epicApi.setPassword("newPass");
        epicApi.setEndPoint("newEndpoint");
        epicApi.setAuthStringEnc("newAuthString");
        epicApi.setEpicClientId("newClientId");
        epicApi.setEpicClientUserId("newClientUserId");
        epicApi.setEpicClientUserIdType("newClientUserIdType");

        assertEquals("newUser", epicApi.getUsername());
        assertEquals("newPass", epicApi.getPassword());
        assertEquals("newEndpoint", epicApi.getEndPoint());
        assertEquals("newAuthString", epicApi.getAuthStringEnc());
        assertEquals("newClientId", epicApi.getEpicClientId());
        assertEquals("newClientUserId", epicApi.getEpicClientUserId());
        assertEquals("newClientUserIdType", epicApi.getEpicClientUserIdType());
    }
}
