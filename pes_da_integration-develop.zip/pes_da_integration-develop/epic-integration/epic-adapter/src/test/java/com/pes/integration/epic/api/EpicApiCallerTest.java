package com.pes.integration.epic.api;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.epic.component.EpicClientCaller;
import com.pes.integration.epic.constant.EpicEngineConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.TestUtils.TestUtils.getData;
import static com.pes.integration.constant.DocASAPConstants.Key.DA_APPOINTMENT_ID;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EpicApiCallerTest {
    @Mock
    EpicApiCaller epicApiCaller;
    @Mock
    EpicClientCaller epicClientCaller;
    @Mock
    DataCacheManager cacheManager;
    @Spy
    EpicApiCaller epicApiCallerSpy;
    JSONObject requestConfig;
    JSONObject requestMapping;
    JSONObject responseMapping;
    @Mock
    private WebClient webClient;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec<?> requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @BeforeEach
    void setUp() throws NoSuchMethodException {
        ReflectionTestUtils.setField(epicApiCaller, "authStringEnc", "");
        requestConfig = new JSONObject("{\"configkey\":\"configvalue\"}");
        requestMapping = new JSONObject("{\"requestkey\":\"requestvalue\"}");
        responseMapping = new JSONObject("{\"responsekey\":\"responsevalue\"}");
        ReflectionTestUtils.setField(epicApiCaller, "requestConfig", requestConfig);
        ReflectionTestUtils.setField(epicApiCaller, "requestMapping", requestMapping);
        ReflectionTestUtils.setField(epicApiCaller, "responseMapping", responseMapping);
    }

    @Test
    void initializeAvailabilityObject_handlesEmptyConfigurationData() throws IHubException {
        JSONObject configurationData = new JSONObject();

        epicApiCaller.initializeAvailabilityObject(configurationData);

        assertNotNull(configurationData);
    }

    @Test
    void testInitializeObject() throws IHubException {
        JSONObject requestConfig = new JSONObject("{\"key\":\"value\"}");
        JSONObject requestMapping = new JSONObject("{\"key\":\"value\"}");
        JSONObject responseMapping = new JSONObject("{\"key\":\"value\"}");

        lenient().when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, REQUEST_CONFIG_KEY_NAME, false))
                .thenReturn(requestConfig);
        lenient().when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, REQUEST_MAPPING_KEY_NAME, false))
                .thenReturn(requestMapping);
        lenient().when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, RESPONSE_MAPPING_KEY_NAME, false))
                .thenReturn(responseMapping);

        epicApiCaller.initializeObject();
    }

    @Test
    void testInitializeObject_throwsIHubException() throws IHubException {
        lenient().when(cacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("500"), "Error"));

        epicApiCaller.initializeObject();
    }

    @Test
    void testInitializeAvailabilityObject() throws IHubException {
        JSONObject configurationData = new JSONObject();
        configurationData.put(REQUEST_CONFIG_KEY_NAME, "{\"key\":\"value\"}");
        configurationData.put(REQUEST_MAPPING_KEY_NAME, "{\"key\":\"value\"}");
        configurationData.put(RESPONSE_MAPPING_KEY_NAME, "{\"key\":\"value\"}");
        configurationData.put(ORCHARDUSERID, "user");
        configurationData.put(ORCHARDPASSWORD, "password");
        configurationData.put(EPIC_ENDPOINT, "endpoint");
        configurationData.put(EPICCLIENT_ID, "clientId");

        epicApiCaller.initializeAvailabilityObject(configurationData);

    }

    @Test
    void testInitializeAvailabilityObject_setsAuthStringEnc() throws IHubException {
        JSONObject configurationData = new JSONObject();
        configurationData.put(REQUEST_CONFIG_KEY_NAME, "{\"key\":\"value\"}");
        configurationData.put(REQUEST_MAPPING_KEY_NAME, "{\"key\":\"value\"}");
        configurationData.put(RESPONSE_MAPPING_KEY_NAME, "{\"key\":\"value\"}");
        configurationData.put(ORCHARDUSERID, "user");
        configurationData.put(ORCHARDPASSWORD, "password");
        configurationData.put(EPIC_ENDPOINT, "endpoint");
        configurationData.put(EPICCLIENT_ID, "clientId");

        epicApiCaller.initializeAvailabilityObject(configurationData);

        assertEquals("", ReflectionTestUtils.getField(epicApiCaller, "authStringEnc"));
    }

    @Test
    void initializeObject_loadsRequestConfigSuccessfully() throws IHubException {
        when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, REQUEST_CONFIG_KEY_NAME, false))
                .thenReturn(new JSONObject("{\"configkey\":\"configvalue\"}"));
        epicApiCaller.initializeObject();
        assertEquals("{\"configkey\":\"configvalue\"}", cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, REQUEST_CONFIG_KEY_NAME, false).toString());
    }

    @Test
    void initializeObject_loadsRequestMappingSuccessfully() throws IHubException {
        when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, REQUEST_MAPPING_KEY_NAME, false))
                .thenReturn(new JSONObject("{\"requestkey\":\"requestvalue\"}"));
        assertEquals("{\"requestkey\":\"requestvalue\"}", cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, REQUEST_MAPPING_KEY_NAME, false).toString());
    }

    @Test
    void initializeObject_loadsResponseMappingSuccessfully() throws IHubException {
        when(cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, RESPONSE_MAPPING_KEY_NAME, false))
                .thenReturn(new JSONObject("{\"responsekey\":\"responsevalue\"}"));
        assertEquals("{\"responsekey\":\"responsevalue\"}", cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, RESPONSE_MAPPING_KEY_NAME, false).toString());
    }

    @Test
    void initializeObject_throwsIHubExceptionWhenConfigNotFound() throws IHubException {
        when(cacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "Config not found"));
        assertThrows(IHubException.class, () -> cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, EPIC_CONFIG, REQUEST_MAPPING_KEY_NAME, false));
    }

    @Test
    void initializeAvailabilityObjectTest() throws IHubException {
        JSONObject configurationData = getData("getConfig.json");
        epicApiCaller.initializeAvailabilityObject(configurationData);
    }

    @Test
    void getOnDemandAuthStringEncoded_returnsAuthStringWhenKeyExists() {
        JSONObject requestObject = new JSONObject("{\"onDemandAPIUser\":\"authString\"}");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getOnDemandAuthStringEncoded", requestObject);
        assertEquals("authString", result);
    }

    @Test
    void getOnDemandAuthStringEncoded_returnsNullWhenKeyDoesNotExist() {
        JSONObject requestObject = new JSONObject("{\"someOtherKey\":\"value\"}");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getOnDemandAuthStringEncoded", requestObject);
        assertNull(result);
    }

    @Test
    void customizeResponseMappingTest() {
        JSONObject responseObject = new JSONObject("{\"key\":\"value\"}");
        JSONObject inputObject = new JSONObject();
        inputObject.put(DA_APPOINTMENT_ID, "testDeploymentId");
        assertNull(ReflectionTestUtils.invokeMethod(epicApiCaller, "customizeResponseMapping", responseObject, "open_appointments", inputObject));
    }

    @Test
    void getOnDemandAuthStringEncoded_handlesInvalidJson() {
        Object requestObject = "invalid json";
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getOnDemandAuthStringEncoded", requestObject);
        assertNull(result);
    }

    @Test
    void checkNullResponse_replacesNullWithHTTPHeader() {
        JSONObject responseObject = new JSONObject("{\"null\":\"HTTP-Header\"}");
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(epicApiCaller, "checkNullResponse", responseObject);
        assertEquals("HTTP-Header", result.getString("HTTP-Header"));
    }

    @Test
    void checkNullResponse_returnsUnchangedObjectWhenNoNull() {
        JSONObject responseObject = new JSONObject("{\"key\":\"value\"}");
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(epicApiCaller, "checkNullResponse", responseObject);
        assertEquals("value", result.getString("key"));
    }

    @Test
    void checkNullResponse_handlesEmptyJsonObject() {
        JSONObject responseObject = new JSONObject("{}");
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(epicApiCaller, "checkNullResponse", responseObject);
        assertTrue(result.isEmpty());
    }

    @Test
    @Disabled
    void getEpicApi_createsNewEpicApiWhenNotFound() throws IHubException {
        EpicApi newEpicApi = new EpicApi("user", "password", "endpoint", "authString", "clientId", "clientUserId", "clientUserIdType");
        lenient().doReturn(newEpicApi).when(epicApiCaller).apiCaller("deploymentId");
        EpicApi result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getEpicApi", "deploymentId");
        assertEquals(newEpicApi.getEpicClientId(), result.getEpicClientId());
    }

    @Test
    @Disabled
    void getEpicApi_NullObject() throws IHubException {
        EpicApi result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getEpicApi", "deploymentId");
        assertNull(result);
    }

    @Test
    void getMappingConfigTest() throws IHubException {
        JSONObject mockRequestConfig = new JSONObject("""
                {"ep_req_conf":{"key":"value"},"ep_req_map":{"a":"b","c":"d","e":"f"},"ep_res_map":{"key":"b"}}""");

        lenient().when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, false))
                .thenReturn(mockRequestConfig);

        Assertions.assertDoesNotThrow(() -> epicApiCaller.getMappingConfig("deploymentId"));

    }

    @Test
    void getMappingConfigTestNull() throws IHubException {
        lenient().when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, false))
                .thenReturn(null);

        Assertions.assertDoesNotThrow(() -> epicApiCaller.getMappingConfig("deploymentId"));

    }
    @Test
    void getMappingConfig_loadsConfigSuccessfully() throws IHubException {
        JSONObject providerConfig = new JSONObject();
        providerConfig.put(REQUEST_CONFIG_KEY_NAME, new JSONObject("{\"configkey\":\"configvalue\"}"));
        providerConfig.put(REQUEST_MAPPING_KEY_NAME, new JSONObject("{\"requestkey\":\"requestvalue\"}"));
        providerConfig.put(RESPONSE_MAPPING_KEY_NAME, new JSONObject("{\"responsekey\":\"responsevalue\"}"));

        lenient().when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, false))
                .thenReturn(providerConfig);

        ReflectionTestUtils.invokeMethod(epicApiCaller, "getMappingConfig", "deploymentId");
        assertEquals("{\"configkey\":\"configvalue\"}", requestConfig.toString());
        assertEquals("{\"requestkey\":\"requestvalue\"}", requestMapping.toString());
        assertEquals("{\"responsekey\":\"responsevalue\"}", responseMapping.toString());
    }

    /*@Test
    void getMappingConfig_savesConfigSuccessfully() throws IHubException, InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        String deploymentId = "testDeploymentId";
        JSONObject providerConfig = new JSONObject();
        providerConfig.put(REQUEST_CONFIG_KEY_NAME, new JSONObject("{\"requestConfigKey\":\"requestConfigValue\"}"));
        providerConfig.put(REQUEST_MAPPING_KEY_NAME, new JSONObject("{\"requestMappingKey\":\"requestMappingValue\"}"));
        providerConfig.put(RESPONSE_MAPPING_KEY_NAME, new JSONObject("{\"responseMappingKey\":\"responseMappingValue\"}"));

        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, false))
                .thenReturn(providerConfig);
        // Use reflection to access the protected method
        Method getMappingConfigMethod = EpicApiCaller.class.getDeclaredMethod("getMappingConfig", String.class);
        getMappingConfigMethod.setAccessible(true);
        ReflectionTestUtils.setField(epicApiCallerSpy, "cacheManager", cacheManager);
        ReflectionTestUtils.setField(epicApiCallerSpy, "dataCacheManager", cacheManager);
        // Invoke the method
        getMappingConfigMethod.invoke(epicApiCaller, deploymentId);

        epicApiCallerSpy.getMappingConfig(deploymentId);

        verify(cacheManager).getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, EPIC_CONFIG, false);
        verify(cacheManager).saveRedisConfig(eq(deploymentId + "_configMapping"), anyString());
    }*/

    @Test
    void getMappingConfigTestEmptyReqConfig() throws IHubException {
        JSONObject mockRequestConfig = new JSONObject("""
                {"ep_req_conf":"","ep_req_map":{"a":"b","c":"d","e":"f"},"ep_res_map":{"key":"b"}}""");

        lenient().when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, false))
                .thenReturn(mockRequestConfig);

        Assertions.assertDoesNotThrow(() -> epicApiCaller.getMappingConfig("deploymentId"));

    }

    @Test
    void getMappingConfigTestEmptyReqMap() throws IHubException {
        JSONObject mockRequestConfig = new JSONObject("""
                {"ep_req_conf":{"key":"value"},"ep_req_map":"","ep_res_map":{"key":"b"}}""");

        lenient().when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, false))
                .thenReturn(mockRequestConfig);

        Assertions.assertDoesNotThrow(() -> epicApiCaller.getMappingConfig("deploymentId"));

    }

    @Test
    void getMappingConfigTestEmptyResponseMap() throws IHubException {
        JSONObject mockRequestConfig = new JSONObject("""
                {"ep_req_conf":{"key":"value"},"ep_req_map":{"a":"b","c":"d","e":"f"},"ep_res_map":""}""");

        lenient().when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, false))
                .thenReturn(mockRequestConfig);

        Assertions.assertDoesNotThrow(() -> epicApiCaller.getMappingConfig("deploymentId"));

    }

    @Test
    void getAuthStringEnc_returnsEncodedStringForValidInput() {
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getAuthStringEnc", "user", "password");
        assertEquals("dXNlcjpwYXNzd29yZA==", result);
    }

    @Test
    void getAuthStringEnc_returnsEncodedStringForEmptyUsername() {
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getAuthStringEnc", "", "password");
        assertEquals("OnBhc3N3b3Jk", result);
    }

    @Test
    void getAuthStringEnc_returnsEncodedStringForEmptyPassword() {
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getAuthStringEnc", "user", "");
        assertEquals("dXNlcjo=", result);
    }

    @Test
    void getAuthStringEnc_returnsEncodedStringForEmptyUsernameAndPassword() {
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getAuthStringEnc", "", "");
        assertEquals("Og==", result);
    }

    @Test
    void getHttpHeaders_setsEpicClientIdFromEpicApi() {
        JSONObject requestObject = new JSONObject();
        Map<String, String> params = new HashMap<>();
        EpicApi epicApi = new EpicApi();
        epicApi.setAuthStringEnc("authString");
        epicApi.setEpicClientId("clientId");
        HttpHeaders result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getHttpHeaders", "deploymentId", requestObject, epicApi, params, "api/epic", null);
        assertEquals("clientId", result.getFirst(EPIC_CLIENT_ID));
    }

    @Test
    void getHttpHeaders_setsBasicAuthForEpicApi() {
        JSONObject requestObject = new JSONObject();
        Map<String, String> params = new HashMap<>();
        EpicApi epicApi = new EpicApi();
        epicApi.setAuthStringEnc("authString");
        HttpHeaders result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getHttpHeaders", "deploymentId", requestObject, epicApi, params, "api/epic", null);
        assertEquals("Basic authString", result.getFirst(HttpHeaders.AUTHORIZATION));
    }


    @Test
    void getHttpHeaders_setsBasicAuthForOnDemandApi() {
        JSONObject requestObject = new JSONObject("{\"onDemandAPIUser\":\"authString\"}");
        Map<String, String> params = new HashMap<>();
        HttpHeaders result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getHttpHeaders", "deploymentId", requestObject, new EpicApi(), params, "api/other", null);
        assertEquals("Basic authString", result.getFirst(HttpHeaders.AUTHORIZATION));
    }

    @Test
    void getHttpHeaders_setsHeadersForFhirApi() {
        JSONObject requestObject = new JSONObject();
        Map<String, String> params = new HashMap<>();
        EpicApi epicApi = new EpicApi();
        epicApi.setEpicClientUserId("userId");
        epicApi.setEpicClientUserIdType("userIdType");
        epicApi.setAuthStringEnc("authString");
        HttpHeaders result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getHttpHeaders", "deploymentId", requestObject, epicApi, params, "api/FHIR", null);
        assertEquals("userId", result.getFirst(EPIC_USER_ID));
        assertEquals("userIdType", result.getFirst(EPIC_USER_ID_TYPE));
        assertEquals("application/json", result.getFirst(HttpHeaders.ACCEPT));
        assertEquals("Basic authString", result.getFirst(HttpHeaders.AUTHORIZATION));
    }

    @Test
    void getHttpHeaders_addsReadHeaderWhenTrue() {
        JSONObject requestObject = new JSONObject("{\"key\":\"value\"}");
        HttpHeaders headers = ReflectionTestUtils.invokeMethod(epicApiCaller, "getHttpHeaders", "deploymentId", requestObject, new EpicApi(), new HashMap<>(), "apiName", "true");
        assertEquals("true", headers.getFirst("readHeader"));
    }

    @Test
    void getHttpHeaders_setsEpicClientIdWhenPresentInParams() {
        JSONObject requestObject = new JSONObject("{\"key\":\"value\"}");
        Map<String, String> params = new HashMap<>();
        params.put(EPIC_CLIENTID, "clientIdValue");
        HttpHeaders headers = ReflectionTestUtils.invokeMethod(epicApiCaller, "getHttpHeaders", "deploymentId", requestObject, new EpicApi(), params, "apiName", null);
        assertEquals("clientIdValue", headers.getFirst(EPIC_CLIENT_ID));
        assertFalse(params.containsKey(EPIC_CLIENTID));
    }

    @Test
    void getHttpHeaders_setsEpicClientIdFromEpicApiWhenNotInParams() {
        JSONObject requestObject = new JSONObject("{\"key\":\"value\"}");
        EpicApi epicApi = new EpicApi();
        epicApi.setEpicClientId("epicClientIdValue");
        HttpHeaders headers = ReflectionTestUtils.invokeMethod(epicApiCaller, "getHttpHeaders", "deploymentId", requestObject, epicApi, new HashMap<>(), "apiName", null);
        assertEquals("epicClientIdValue", headers.getFirst(EPIC_CLIENT_ID));
    }

    @Test
    void loopingThroughUrl_returnsCommentValueWhenKeepCommentLastIsOne() {
        Object[] keyArray = {"key1", "key2", "comment"};
        String url = "http://example.com?key1=value1&key2=value2&comment=value3";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        parameters.put("key2", "value2");
        parameters.put("Comment", "value3");
        StringBuilder sb = new StringBuilder();

        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "loopingThroughUrl", keyArray, url, parameters, 1, sb);

        assertNull(result);
        assertEquals("key1=value1&key2=value2&comment=null", sb.toString());
    }

    @Test
    void loopingThroughUrl_appendsParametersCorrectly() {
        Object[] keyArray = {"key1", "key2"};
        String url = "http://example.com?key1=value1&key2=value2";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        parameters.put("key2", "value2");
        StringBuilder sb = new StringBuilder();

        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "loopingThroughUrl", keyArray, url, parameters, 0, sb);

        assertNull(result);
        assertEquals("key1=value1&key2=value2", sb.toString());
    }

    @Test
    void loopingThroughUrl_handlesEmptyKeyArray() {
        Object[] keyArray = {};
        String url = "http://example.com";
        Map<String, String> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder();

        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "loopingThroughUrl", keyArray, url, parameters, 0, sb);

        assertNull(result);
        assertEquals("", sb.toString());
    }

    @Test
    void loopingThroughUrl_handlesEmptyParameters() {
        Object[] keyArray = {"key1", "key2"};
        String url = "http://example.com";
        Map<String, String> parameters = new HashMap<>();
        StringBuilder sb = new StringBuilder();

        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "loopingThroughUrl", keyArray, url, parameters, 0, sb);

        assertNull(result);
        assertEquals("", sb.toString());
    }

    @Test
    void loopingThroughUrl_handlesNullCommentValue() {
        Object[] keyArray = {"key1", "key2", "comment"};
        String url = "http://example.com?key1=value1&key2=value2";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        parameters.put("key2", "value2");
        StringBuilder sb = new StringBuilder();

        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "loopingThroughUrl", keyArray, url, parameters, 1, sb);

        assertNull(result);
        assertEquals("key1=value1&key2=value2", sb.toString());
    }

    @Test
    void buildBaseUrl_replacesParametersCorrectly() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put(":param1", "value1");
        parameters.put(":param2", "value2");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildBaseUrl", "/api/:param1/resource/:param2", parameters);
        assertEquals("/api/value1/resource/value2", result);
    }

    @Test
    void buildBaseUrl_handlesEmptyParameters() {
        Map<String, String> parameters = new HashMap<>();
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildBaseUrl", "/api/resource", parameters);
        assertEquals("/api/resource", result);
    }


    @Test
    void buildBaseUrl_handlesNullParameterValue() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put(":param1", null);
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildBaseUrl", "/api/:param1/resource", parameters);
        assertEquals("/api/null/resource", result);
    }

    @Test
    void buildBaseUrl_handlesNoParametersInUrl() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put(":param1", "value1");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildBaseUrl", "api/resource", parameters);
        assertEquals("/api/resource", result);
    }

    @Test
    void buildUrl_appendsCommentValueWhenKeepCommentLastIsOne() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        parameters.put("key2", "value2");
        parameters.put("comment", "value3");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildUrl", "http://example.com", "api/resource?key1=value1&key2=value2&comment=value3", parameters);
        assertEquals("http://example.com/api/resource?key1=value1&key2=value2&comment=value3", result);
    }

    @Test
    void buildUrl_appendsParametersCorrectly() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        parameters.put("key2", "value2");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildUrl", "http://example.com", "api/resource?key1=value1&key2=value2", parameters);
        assertEquals("http://example.com/api/resource?key1=value1&key2=value2", result);
    }

    @Test
    void buildUrl_handlesEmptyParameters() {
        Map<String, String> parameters = new HashMap<>();
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildUrl", "http://example.com", "api/resource", parameters);
        assertEquals("http://example.com/api/resource", result);
    }

    @Test
    void buildUrl_handlesNoQueryParameters() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildUrl", "http://example.com", "api/resource", parameters);
        assertEquals("http://example.com/api/resource", result);
    }

    @Test
    void buildUrl_handlesNullCommentValue() {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        parameters.put("key2", "value2");
        String result = ReflectionTestUtils.invokeMethod(epicApiCaller, "buildUrl", "http://example.com", "api/resource?key1=value1&key2=value2", parameters);
        assertEquals("http://example.com/api/resource?key1=value1&key2=value2", result);
    }

    @Test
    public void testBuildUrl_withCommentValueAndColon() throws Exception {
        Object epicApiCaller;
        Method buildUrlMethod;
        epicApiCaller = EpicApiCaller.class.getDeclaredConstructor().newInstance();
        buildUrlMethod = EpicApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        buildUrlMethod.setAccessible(true);
        String baseUrl = "http://example.com";
        String url = "http://example.com/someEndpoint?POSTPATIENTMADEPAYMENTS";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        String result = (String) buildUrlMethod.invoke(epicApiCaller, baseUrl, url, parameters);
        assertEquals("http://example.com//http:/example.com/someEndpoint?", result);
    }

    @Test
    public void testBuildUrl_withCommentValueNoColon() throws Exception {
        Object epicApiCaller;
        Method buildUrlMethod;
        epicApiCaller = EpicApiCaller.class.getDeclaredConstructor().newInstance();
        buildUrlMethod = EpicApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        buildUrlMethod.setAccessible(true);
        String baseUrl = "http://example.com";
        String url = "http://example.com/someEndpoint?POSTPATIENTMADEPAYMENTS";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        String result = (String) buildUrlMethod.invoke(epicApiCaller, baseUrl, url, parameters);
        assertEquals("http://example.com//http:/example.com/someEndpoint?", result);
    }

    @Test
    public void testBuildUrl_withoutCommentValue() throws Exception {
        Object epicApiCaller;
        Method buildUrlMethod;
        epicApiCaller = EpicApiCaller.class.getDeclaredConstructor().newInstance();
        buildUrlMethod = EpicApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        buildUrlMethod.setAccessible(true);
        String baseUrl = "http://example.com";
        String url = "http://example.com/someEndpoint";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        String result = (String) buildUrlMethod.invoke(epicApiCaller, baseUrl, url, parameters);
        assertEquals("http://example.com//http:/example.com/someEndpoint", result);
    }

    @Test
    public void testBuildUrlWithCommentValue() throws Exception {
        Method buildUrlMethod;
        Method loopingThroughUrlMethod;
        epicApiCaller = spy(new EpicApiCaller());
        buildUrlMethod = EpicApiCaller.class.getDeclaredMethod("buildUrl", String.class, String.class, Map.class);
        buildUrlMethod.setAccessible(true);
        loopingThroughUrlMethod = EpicApiCaller.class.getDeclaredMethod("loopingThroughUrl", Object[].class, String.class, Map.class, int.class, StringBuilder.class);
        loopingThroughUrlMethod.setAccessible(true);

        String baseUrl = "http://Comment.com";
        String url = "http://Comment.com/someEndpoint?POSTPATIENTMADEPAYMENTS";

        Map<String, String> parameters = new HashMap<>();
        parameters.put("key1", "value1");
        parameters.put("Comment", "This is a comment");

        Object[] keyArray = new Object[]{"key1", "key2", "comment"};
        ReflectionTestUtils.invokeMethod(epicApiCaller, "loopingThroughUrl", keyArray, url, parameters, 1, new StringBuilder());

        String result = (String) buildUrlMethod.invoke(epicApiCaller, baseUrl, url, parameters);

        // Assert that the comment value is appended with `&`
        assertEquals("http://Comment.com//http:/Comment.com/someEndpoint?&This is a comment", result);
    }


    @Test
    void apiCaller_returnsEpicApiWithCorrectValues() throws IHubException {
        EpicApiCaller epicApiCaller = new EpicApiCaller();
        ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, ORCHARD_USR_ID, false)).thenReturn("user");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, ORCHARD_CLIENT_ID, false)).thenReturn("clientUserId");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, ORCHARD_CLIENT_ID_TYPE, false)).thenReturn("clientUserIdType");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, ORCHARD_USR_PSWD, false)).thenReturn("password");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, END_POINT, false)).thenReturn("endpoint");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, EPIC_CLIENT_ID, false)).thenReturn("clientId");

        EpicApi result = epicApiCaller.apiCaller("deploymentId");

        assertEquals("endpoint", result.getEndPoint());
        assertEquals("dXNlcjpwYXNzd29yZA==", result.getAuthStringEnc());
        assertEquals("clientId", result.getEpicClientId());
        assertEquals("clientUserId", result.getEpicClientUserId());
        assertEquals("clientUserIdType", result.getEpicClientUserIdType());
    }

    @Test
    @Disabled
    void apiCaller_returnsCachedEpicApiWhenExists() throws IHubException {
        // Initialize the real instance of EpicApiCaller
        EpicApiCaller epicApiCaller = new EpicApiCaller();

        // Set the mock cacheManager to the real instance
        ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);
        EpicApi cachedEpicApi = new EpicApi("user", "password", "endpoint", "authString", "clientId", "clientUserId", "clientUserIdType");
        ReflectionTestUtils.setField(EpicApiCaller.class, "apiMap", new HashMap<>());
        Map<String, EpicApi> apiMap = (Map<String, EpicApi>) ReflectionTestUtils.getField(EpicApiCaller.class, "apiMap");
        apiMap.put("deploymentId", cachedEpicApi);

        EpicApi result = epicApiCaller.apiCaller("deploymentId");

        assertNotNull(result);
    }

    @Test
    void getPropertyValue_returnsCorrectValueWhenConfigExists() throws IHubException {
        EpicApiCaller epicApiCaller = new EpicApiCaller();

        // Set the mock cacheManager to the real instance
        ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, "propertyKey", false)).thenReturn("propertyValue");

        Object result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getPropertyValue", "deploymentId", "propertyKey");

        assertEquals("propertyValue", result);
    }

    @Test
    void getPropertyValue_returnsNullWhenConfigDoesNotExist() throws IHubException {
        EpicApiCaller epicApiCaller = new EpicApiCaller();
        ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deploymentId", EPIC_CONFIG, "propertyKey", false)).thenThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "Config not found"));

        Object result = ReflectionTestUtils.invokeMethod(epicApiCaller, "getPropertyValue", "deploymentId", "propertyKey");

        assertNull(result);
    }

    /* @Test
     void callApiTestValid() throws IHubException {
         EpicApiCaller epicApiCaller = new EpicApiCaller();
         JSONObject apiConfig = new JSONObject("{\"url\":\"/?test\", \"method\":\"GET\", \"header\":\"123\"}");
         JSONObject requestObject = new JSONObject("""
 {"input":{"ep_clientid":"value"},"deployment_id":"74247^0001","key_store_passwd":"pwd","key_store_name":"name","is_ssl":"1"}""");
         EpicApi epicApi = new EpicApi("user", "pass", "endpoint", "authString", "clientId", "clientUserId", "clientUserIdType");
         String url = apiConfig.getString(EpicEngineConstants.URL);
         String method = apiConfig.getString(EpicEngineConstants.METHOD);

         when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_USR_ID, false)).thenReturn("user");
         when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_CLIENT_ID, false)).thenReturn("clientUserId");
         when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_CLIENT_ID_TYPE, false)).thenReturn("clientUserIdType");
         when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_USR_PSWD, false)).thenReturn("password");
         when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, END_POINT, false)).thenReturn("endpoint");
         when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, EPIC_CLIENT_ID, false)).thenReturn("clientId");

         HttpHeaders headers = new HttpHeaders();
         headers.add("Authorization", "Bearer token");
         when(webClient.method(HttpMethod.valueOf(GET))).thenAnswer(reqMethod -> requestBodyUriSpec);
         when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
         when(requestBodySpec.accept(any())).thenReturn(requestBodySpec);
         when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
         when(requestBodySpec.body(any(), eq(String.class))).thenAnswer(reqBody -> requestHeadersSpec);
         when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
         when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
         when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
         when(responseSpec.bodyToMono(eq(String.class))).thenReturn(Mono.just("{\"response\":\"value\"}"));

         epicApiCaller = spy(new EpicApiCaller());
         ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);
         ReflectionTestUtils.setField(epicApiCaller, "epicClientCaller", epicClientCaller);
         ReflectionTestUtils.setField(epicClientCaller, "webClient", webClient);
         Object result = ReflectionTestUtils.invokeMethod(epicApiCaller, "callApi", apiConfig, requestObject);
         assertEquals(new JSONObject("{\"response\":\"value\"}").toString(), result.toString());
         }*/
    @Test
    void callApiTestException() throws IHubException {
        EpicApiCaller epicApiCaller = new EpicApiCaller();
        JSONObject apiConfig = new JSONObject("{\"url\":\"/?test\", \"method\":\"GET\", \"header\":\"123\"}");
        JSONObject requestObject = new JSONObject("""
                {"input":{"ep_clientid":"value"},"deployment_id":"74247^0001","key_store_passwd":"pwd","key_store_name":"name","is_ssl":"1"}""");
        EpicApi epicApi = new EpicApi("user", "pass", "endpoint", "authString", "clientId", "clientUserId", "clientUserIdType");
        String url = apiConfig.getString(EpicEngineConstants.URL);
        String method = apiConfig.getString(EpicEngineConstants.METHOD);

        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_USR_ID, false)).thenReturn("user");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_CLIENT_ID, false)).thenReturn("clientUserId");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_CLIENT_ID_TYPE, false)).thenReturn("clientUserIdType");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_USR_PSWD, false)).thenReturn("password");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, END_POINT, false)).thenReturn("endpoint");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, EPIC_CLIENT_ID, false)).thenReturn("clientId");

        lenient().when(epicClientCaller.getData(eq(method), eq(url), eq(requestObject.toString()), any(HttpHeaders.class)))
                .thenReturn(String.valueOf(new JSONObject("{\"response\":\"value\"}")));

        epicApiCaller = spy(new EpicApiCaller());
        ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);
        ReflectionTestUtils.setField(epicApiCaller, "epicClientCaller", epicClientCaller);

        Object result = ReflectionTestUtils.invokeMethod(epicApiCaller, "callApi", apiConfig, requestObject);
        JSONObject exceptionResponse = new JSONObject("""
                {"ExceptionMessage":"{\\"errorCode\\":\\"UNABLE_TO_PROCESS_MESSAGE\\",\\"statusCode\\":\\"2108\\"}","Message":"A JSONObject text must begin with '{' at 1 [character 2 line 1]"}""");
        assertEquals(exceptionResponse.toString(), result.toString());
    }

    @Test
    void testInitializeObject_loadsConfigsSuccessfully() throws Exception {
        EpicApiCaller epicApiCaller = new EpicApiCaller();
        DataCacheManager cacheManager = mock(DataCacheManager.class);

        JSONObject mockRequestConfig = new JSONObject("{\"configkey\":\"configvalue\"}");
        JSONObject mockRequestMapping = new JSONObject("{\"requestkey\":\"requestvalue\"}");
        JSONObject mockResponseMapping = new JSONObject("{\"responsekey\":\"responsevalue\"}");

        when(cacheManager.getStoredComponentConfig(anyString(), anyString(), eq("ep_req_conf"), anyBoolean()))
                .thenReturn(mockRequestConfig);
        when(cacheManager.getStoredComponentConfig(anyString(), anyString(), eq("ep_req_map"), anyBoolean()))
                .thenReturn(mockRequestMapping);
        when(cacheManager.getStoredComponentConfig(anyString(), anyString(), eq("ep_res_map"), anyBoolean()))
                .thenReturn(mockResponseMapping);

        ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);

        // Use reflection to invoke the public method (not strictly needed, but for consistency)
        epicApiCaller.initializeObject();

        // Assert fields are set
        JSONObject requestConfig = (JSONObject) ReflectionTestUtils.getField(epicApiCaller, "requestConfig");
        JSONObject requestMapping = (JSONObject) ReflectionTestUtils.getField(epicApiCaller, "requestMapping");
        JSONObject responseMapping = (JSONObject) ReflectionTestUtils.getField(epicApiCaller, "responseMapping");

        assertEquals(mockRequestConfig.toString(), requestConfig.toString());
        assertEquals(mockRequestMapping.toString(), requestMapping.toString());
        assertEquals(mockResponseMapping.toString(), responseMapping.toString());
    }

    @Test
    void testInitializeAvailabilityObject_setsFieldsAndAuthStringEnc() throws Exception {
        EpicApiCaller epicApiCaller = new EpicApiCaller();

        JSONObject config = new JSONObject();
        config.put("ep_req_conf", "{\"configkey\":\"configvalue\"}");
        config.put("ep_req_map", "{\"requestkey\":\"requestvalue\"}");
        config.put("ep_res_map", "{\"responsekey\":\"responsevalue\"}");
        config.put("orchardUserId", "user");
        config.put("orchardPassword", "pass");

        // Ensure authStringEnc is empty
        ReflectionTestUtils.setField(epicApiCaller, "authStringEnc", "");

        // Mock StringUtils.isEmpty to always return true for empty string
        try (MockedStatic<StringUtils> stringUtilsMock = mockStatic(StringUtils.class)) {
            stringUtilsMock.when(() -> StringUtils.isEmpty(anyString())).thenAnswer(invocation -> {
                String arg = invocation.getArgument(0);
                return arg == null || arg.isEmpty();
            });

            epicApiCaller.initializeAvailabilityObject(config);

            // Assert fields are set
            JSONObject requestConfig = (JSONObject) ReflectionTestUtils.getField(epicApiCaller, "requestConfig");
            JSONObject requestMapping = (JSONObject) ReflectionTestUtils.getField(epicApiCaller, "requestMapping");
            JSONObject responseMapping = (JSONObject) ReflectionTestUtils.getField(epicApiCaller, "responseMapping");
            String authStringEnc = (String) ReflectionTestUtils.getField(epicApiCaller, "authStringEnc");

            assertEquals("{\"configkey\":\"configvalue\"}", requestConfig.toString());
            assertEquals("{\"requestkey\":\"requestvalue\"}", requestMapping.toString());
            assertEquals("{\"responsekey\":\"responsevalue\"}", responseMapping.toString());
            assertNotNull(authStringEnc);
            assertFalse(authStringEnc.isEmpty());
        }
    }

    @Test
    void callApiTestIhubException() throws IHubException {
        EpicApiCaller epicApiCaller = new EpicApiCaller();
        JSONObject apiConfig = new JSONObject("{\"url\":\"/?test\", \"method\":\"GET\", \"header\":\"123\"}");
        JSONObject requestObject = new JSONObject("""
                {"input":{"ep_clientid":"value"},"deployment_id":"74247^0001","key_store_passwd":"pwd","key_store_name":"name","is_ssl":"1"}""");
        EpicApi epicApi = new EpicApi("user", "pass", "endpoint", "authString", "clientId", "clientUserId", "clientUserIdType");
        String url = apiConfig.getString(EpicEngineConstants.URL);
        String method = apiConfig.getString(EpicEngineConstants.METHOD);

        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_USR_ID, false)).thenReturn("user");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_CLIENT_ID, false)).thenReturn("clientUserId");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_CLIENT_ID_TYPE, false)).thenReturn("clientUserIdType");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, ORCHARD_USR_PSWD, false)).thenReturn("password");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, END_POINT, false)).thenReturn("endpoint");
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "74247^0001", EPIC_CONFIG, EPIC_CLIENT_ID, false)).thenReturn("clientId");

        when(epicClientCaller.getData(eq("GET"), eq("endpoint//?"), eq("{}"), any(HttpHeaders.class)))
                .thenThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "Simulated exception"));

        epicApiCaller = spy(new EpicApiCaller());
        ReflectionTestUtils.setField(epicApiCaller, "cacheManager", cacheManager);
        ReflectionTestUtils.setField(epicApiCaller, "epicClientCaller", epicClientCaller);

        Object result = ReflectionTestUtils.invokeMethod(epicApiCaller, "callApi", apiConfig, requestObject);
        JSONObject exceptionResponse = new JSONObject("{\"statusCodes\":\"ERROR_IN_SERVICE_EXECUTION\",\"ExceptionMessage\":\"Error Occurred - Simulated exception\"}");
        assertEquals(exceptionResponse.toString(), result.toString());
    }

    @Test
    void checkNullResponse_replacesNullKeyWithHTTPHeader() {
        JSONObject input = new JSONObject();
        input.put("null", "HTTP-Header");
        Object result = ReflectionTestUtils.invokeMethod(EpicApiCaller.class, "checkNullResponse", input);
        assertTrue(result instanceof JSONObject);
        JSONObject output = (JSONObject) result;
        assertTrue(output.has("HTTP-Header"));
        assertEquals("HTTP-Header", output.getString("HTTP-Header"));
        assertFalse(output.has("null"));
    }

    @Test
    void checkNullResponse_returnsUnchangedIfNoNullKey() {
        JSONObject input = new JSONObject();
        input.put("key", "value");
        Object result = ReflectionTestUtils.invokeMethod(EpicApiCaller.class, "checkNullResponse", input);
        assertTrue(result instanceof JSONObject);
        JSONObject output = (JSONObject) result;
        assertEquals("value", output.getString("key"));
        assertFalse(output.has("HTTP-Header"));
    }

    @Test
    void checkNullResponses_handlesEmptyJsonObject() {
        JSONObject input = new JSONObject();
        Object result = ReflectionTestUtils.invokeMethod(EpicApiCaller.class, "checkNullResponse", input);
        assertTrue(result instanceof JSONObject);
        JSONObject output = (JSONObject) result;
        assertTrue(output.isEmpty());
    }

    @Test
    void checkNullResponse_throwsExceptionForNonJsonObject() {
        String invalidInput = "not a json object";
        Exception exception = assertThrows(ClassCastException.class, () -> {
            ReflectionTestUtils.invokeMethod(EpicApiCaller.class, "checkNullResponse", invalidInput);
        });
        assertTrue(exception.getMessage().contains("java.lang.String cannot be cast"));
    }
}
