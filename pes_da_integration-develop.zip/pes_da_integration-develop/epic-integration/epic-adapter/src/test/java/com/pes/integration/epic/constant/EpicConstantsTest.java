package com.pes.integration.epic.constant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EpicConstantsTest {
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void BASE_URL_ShouldBeCorrect() {
        assertEquals("https://ic-fhirworks.epic.com/interconnect-fhir-username/api/epic", EpicConstants.BASE_URL);
    }

    @Test
    void DATE_FORMAT_ShouldBeCorrect() {
        assertEquals("yyyy-MM-dd", EpicConstants.DATE_FORMAT);
    }

    @Test
    void ID_TYPES_ShouldContainExpectedValues() {
        assertNotNull(EpicConstants.ID_TYPES);
        assertEquals(4, EpicConstants.ID_TYPES.size());
        assertEquals("EPIC", EpicConstants.ID_TYPES.get(0));
        assertEquals("FHIR STU3", EpicConstants.ID_TYPES.get(1));
        assertEquals("FHIR", EpicConstants.ID_TYPES.get(2));
        assertEquals("MRN", EpicConstants.ID_TYPES.get(3));
    }

    @Test
    void EPICCLIENT_ID_ShouldBeCorrect() {
        assertEquals("ep_clientid", EpicConstants.EPICCLIENT_ID);
    }

    @Test
    void DATE_TIME_FORMAT_ShouldBeCorrect() {
        assertEquals("MM/dd/yyyy HH:mm:ss", EpicConstants.DATE_TIME_FORMAT);
    }
}