package com.pes.integration.epic;

import com.pes.integration.exceptions.IHubException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;

import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class InitEngineTest {
    @InjectMocks
    private InitEngine InitEngine;
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void init_callsEpicInitEngineInit() throws IHubException {
        InitEngine initEngine = new InitEngine();
        EpicInitEngine epicInitEngine = mock(EpicInitEngine.class);
        ReflectionTestUtils.setField(initEngine, "epicInitEngine", epicInitEngine);

        initEngine.init();

        verify(epicInitEngine, times(1)).init();
    }

    @Test
    void init_throwsIHubException_whenEpicInitEngineThrowsIHubException() throws IHubException {
        InitEngine initEngine = new InitEngine();
        EpicInitEngine epicInitEngine = mock(EpicInitEngine.class);
        ReflectionTestUtils.setField(initEngine, "epicInitEngine", epicInitEngine);
        doThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "Initialization error")).when(epicInitEngine).init();

        assertThrows(IHubException.class, () -> initEngine.init());
    }
}
