package com.pes.integration.epic.util;

import com.pes.integration.component.EventTracker;
import com.pes.integration.constant.EpmConstant;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.epic.InitEngine;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.Map;

import static com.pes.integration.constant.DocASAPConstants.Key.CAN_COMBINE;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.epic.constant.EpicConstants.PROVIDER_ID_TYPE_ID;
import static com.pes.integration.epic.constant.EpicConstants.TIME_FORMAT;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension .class)
public class EpicUtilTest {

    @InjectMocks
    private EpicUtil EpicUtil;
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @BeforeEach
    public void setup() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getNifiEvent_validInput_returnsExpectedNifiTrackingEvent() {
        AvailabilityRequest availabilityRequest = mock(AvailabilityRequest.class);
        when(availabilityRequest.getMessageControlId()).thenReturn("messageControlId");
        when(availabilityRequest.getAppointmentType()).thenReturn("appointmentType");
        when(availabilityRequest.getSliceId()).thenReturn("sliceId");
        when(availabilityRequest.getDeploymentId()).thenReturn("deploymentId");
        when(availabilityRequest.getTotalSlices()).thenReturn("totalSlices");
        when(availabilityRequest.getEntityType()).thenReturn("entityType");
        when(availabilityRequest.getEntityId()).thenReturn("entityId");
        when(availabilityRequest.getFlow()).thenReturn("flow");

        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "5";
        String fragmentId = "fragment-1";
        Map<String, Object> payload = mock(Map.class);

        NifiTrackingEvent result = EpicUtil.getNifiEvent(availabilityRequest, dataflowStatus, totalFragments, fragmentId, payload);

        assertEquals("SUCCESS", result.getFlowPoint());
        assertEquals("messageControlId", result.getMessageControlId());
        assertEquals("appointmentType", result.getAppointmentType());
        assertEquals("sliceId", result.getSliceId());
        assertEquals("deploymentId", result.getDeploymentId());
        assertEquals("5", result.getTotalFragments());
        assertEquals("fragment-1", result.getFragmentId());
        assertEquals("totalSlices", result.getTotalSlices());
        assertEquals(payload, result.getPayload());
        assertEquals("entityType", result.getEntityType());
        assertEquals("entityId", result.getEntityId());
        assertEquals("flow", result.getFlow());
    }

    @Test
    void getNifiEvent_nullAvailabilityRequest_throwsNullPointerException() {
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "5";
        String fragmentId = "fragment-1";
        Map<String, Object> payload = mock(Map.class);

        assertThrows(NullPointerException.class, () -> EpicUtil.getNifiEvent(null, dataflowStatus, totalFragments, fragmentId, payload));
    }

    @Test
    void getNifiEvent_nullDataflowStatus_throwsNullPointerException() {
        AvailabilityRequest availabilityRequest = mock(AvailabilityRequest.class);
        String totalFragments = "5";
        String fragmentId = "fragment-1";
        Map<String, Object> payload = mock(Map.class);

        assertThrows(NullPointerException.class, () -> EpicUtil.getNifiEvent(availabilityRequest, null, totalFragments, fragmentId, payload));
    }

    @Test
    void getNifiEvent_nullTotalFragments_returnsNifiTrackingEventWithNullTotalFragments() {
        AvailabilityRequest availabilityRequest = mock(AvailabilityRequest.class);
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String fragmentId = "fragment-1";
        Map<String, Object> payload = mock(Map.class);

        NifiTrackingEvent result = EpicUtil.getNifiEvent(availabilityRequest, dataflowStatus, null, fragmentId, payload);

        assertNull(result.getTotalFragments());
    }

    @Test
    void getNifiEvent_nullFragmentId_returnsNifiTrackingEventWithNullFragmentId() {
        AvailabilityRequest availabilityRequest = mock(AvailabilityRequest.class);
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "5";
        Map<String, Object> payload = mock(Map.class);

        NifiTrackingEvent result = EpicUtil.getNifiEvent(availabilityRequest, dataflowStatus, totalFragments, null, payload);

        assertNull(result.getFragmentId());
    }

    @Test
    void getNifiEvent_nullPayload_returnsNifiTrackingEventWithNullPayload() {
        AvailabilityRequest availabilityRequest = mock(AvailabilityRequest.class);
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "5";
        String fragmentId = "fragment-1";

        NifiTrackingEvent result = EpicUtil.getNifiEvent(availabilityRequest, dataflowStatus, totalFragments, fragmentId, null);

        assertNull(result.getPayload());
    }

    @Test
    void openAppointments_validInput_returnsExpectedResponse() throws Exception {
        EpicApiCaller epicApiCaller = mock(EpicApiCaller.class);
        JSONObject inputParam = new JSONObject();
        inputParam.put(PROVIDER, "providerId");
        inputParam.put(PROVIDER_ID_TYPE_ID, "providerTypeId");
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-31");

        JSONObject expectedResponse = new JSONObject();
        when(epicApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);

        JSONObject result = EpicUtil.openAppointments("deploymentId", epicApiCaller, inputParam);

        assertEquals(expectedResponse, result);
        verify(epicApiCaller, times(1)).call(anyString(), anyString(), any(JSONObject.class), anyString());
    }

    @Test
    void openAppointments_iHubException_throwsException() throws Exception {
        EpicApiCaller epicApiCaller = mock(EpicApiCaller.class);
        JSONObject inputParam = new JSONObject();
        inputParam.put(PROVIDER, "providerId");
        inputParam.put(PROVIDER_ID_TYPE_ID, "providerTypeId");
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-31");

        when(epicApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(),"IHub error"));

        assertThrows(IHubException.class, () -> EpicUtil.openAppointments("deploymentId", epicApiCaller, inputParam));
    }
    @Test
    void getInputObject_validInput_returnsExpectedJsonObject() {
        JSONObject inputParam = new JSONObject();
        inputParam.put(PROVIDER, "providerId");
        inputParam.put(PROVIDER_ID_TYPE_ID, "providerTypeId");
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-31");

        JSONObject result = EpicUtil.getInputObject(inputParam);

        assertEquals("providerId", result.getJSONObject("SchedulingData").getJSONArray("Provider").getJSONObject(0).getString("ProviderId"));
        assertEquals("providerTypeId", result.getJSONObject("SchedulingData").getJSONArray("Provider").getJSONObject(0).getString("ProviderIdType"));
        assertEquals("2023-01-01", result.getJSONObject("temp").getString("start_date"));
        assertEquals("2023-01-31", result.getJSONObject("temp").getString("end_date"));
    }

    @Test
    void getInputObject_missingProviderId_throwsJSONException() {
        JSONObject inputParam = new JSONObject();
        inputParam.put(PROVIDER_ID_TYPE_ID, "providerTypeId");
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-31");

        assertThrows(org.json.JSONException.class, () -> EpicUtil.getInputObject(inputParam));
    }

    @Test
    void getInputObject_missingProviderIdType_throwsJSONException() {
        JSONObject inputParam = new JSONObject();
        inputParam.put(PROVIDER, "providerId");
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-31");

        assertThrows(org.json.JSONException.class, () -> EpicUtil.getInputObject(inputParam));
    }

    @Test
    void getInputObject_missingStartDate_throwsJSONException() {
        JSONObject inputParam = new JSONObject();
        inputParam.put(PROVIDER, "providerId");
        inputParam.put(PROVIDER_ID_TYPE_ID, "providerTypeId");
        inputParam.put(ENDDATE, "2023-01-31");

        assertThrows(org.json.JSONException.class, () -> EpicUtil.getInputObject(inputParam));
    }

    @Test
    void getInputObject_missingEndDate_throwsJSONException() {
        JSONObject inputParam = new JSONObject();
        inputParam.put(PROVIDER, "providerId");
        inputParam.put(PROVIDER_ID_TYPE_ID, "providerTypeId");
        inputParam.put(STARTDATE, "2023-01-01");

        assertThrows(org.json.JSONException.class, () -> EpicUtil.getInputObject(inputParam));
    }

    @Test
    void transformOpenAppointment_validInput_returnsExpectedJsonObject() throws ParseException {
        JSONObject timeObj = new JSONObject();
        timeObj.put(START_TIME_VAL, "10:00");

        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(APPTREASON_ID, "reasonId");

        String date = "2023-01-01";
        int canCombine = 1;
        String providerId = "providerId";
        String timezone = "UTC";

        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat("10:00 AM", TIME_FORMAT, DOCASAP_TIME_FORMAT))
                    .thenReturn("10:00");
            mockedStatic.when(() -> DateUtils.convertDateFormat("2023-01-01", DATE_FORMAT, DATE_TIME_FORMAT))
                    .thenReturn("2023-01-01T00:00:00.000Z");

            JSONObject result = EpicUtil.transformOpenAppointment(timeObj, appointmentObject, date, canCombine, providerId, timezone);

            assertEquals("providerId", result.getString(PROVIDER_ID_KEY));
            assertEquals("locationId", result.getString(LOCATION_ID_KEY));
            assertEquals("reasonId", result.getString(REASON_ID_KEY));
//            assertEquals("startTime", result.getString(START_TIME));
            assertEquals("2023-01-01T00:00:00.000Z", result.getString(DATE_KEY));
            assertEquals(1, result.getInt(CAN_COMBINE));
            assertEquals("UTC", result.getString("timeZone"));
            assertEquals("", result.getString("duration"));
        }
    }

    @Test
    void transformOpenAppointment_nullTimezone_returnsJsonObjectWithoutTimezone() throws ParseException {
        JSONObject timeObj = new JSONObject();
        timeObj.put(START_TIME_VAL, "10:00 AM");

        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(APPTREASON_ID, "reasonId");

        String date = "2023-01-01";
        int canCombine = 1;
        String providerId = "providerId";
        String timezone = null;
        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat("10:00 AM", TIME_FORMAT, DOCASAP_TIME_FORMAT))
                    .thenReturn("10:00");
            mockedStatic.when(() -> DateUtils.convertDateFormat("2023-01-01", DATE_FORMAT, DATE_TIME_FORMAT))
                    .thenReturn("2023-01-01T00:00:00.000Z");

            JSONObject result = EpicUtil.transformOpenAppointment(timeObj, appointmentObject, date, canCombine, providerId, timezone);

            assertFalse(result.has("timeZone"));
            assertFalse(result.has("duration"));
        }
    }

    @Test
    void transformOpenAppointment_emptyTimezone_returnsJsonObjectWithoutTimezone() throws ParseException {
        JSONObject timeObj = new JSONObject();
        timeObj.put(START_TIME_VAL, "10:00 AM");

        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(APPTREASON_ID, "reasonId");

        String date = "2023-01-01";
        int canCombine = 1;
        String providerId = "providerId";
        String timezone = "";
        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat("10:00 AM", TIME_FORMAT, DOCASAP_TIME_FORMAT))
                    .thenReturn("10:00");
            mockedStatic.when(() -> DateUtils.convertDateFormat("2023-01-01", DATE_FORMAT, DATE_TIME_FORMAT))
                    .thenReturn("2023-01-01T00:00:00.000Z");

            JSONObject result = EpicUtil.transformOpenAppointment(timeObj, appointmentObject, date, canCombine, providerId, timezone);

            assertFalse(result.has("timeZone"));
            assertFalse(result.has("duration"));
        }
    }

    @Test
    void transformOpenAppointment_invalidTimeFormat_throwsParseException() {
        JSONObject timeObj = new JSONObject();
        timeObj.put(START_TIME_VAL, "10:00");

        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(APPTREASON_ID, "reasonId");

        String date = "2023-01-01";
        int canCombine = 1;
        String providerId = "providerId";
        String timezone = "UTC";
        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenThrow(new ParseException("Invalid time format", 0));

            assertThrows(ParseException.class, () -> EpicUtil.transformOpenAppointment(timeObj, appointmentObject, date, canCombine, providerId, timezone));
        }
    }

    @Test
    void transform_validInput_returnsExpectedJsonObject() throws ParseException {
        String time = "10:00 AM";
        String locationId = "locationId";
        String reasonId = "reasonId";
        String date = "01/01/2023";
        String duration = "30";
        int canCombine = 1;
        String providerId = "providerId";

        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat("10:00", STD_TIME_FORMAT, DOCASAP_TIME_FORMAT))
                    .thenReturn("10:00");
            mockedStatic.when(() -> DateUtils.convertDateFormat("01/01/2023", "MM/dd/yyyy", DATE_TIME_FORMAT))
                    .thenReturn("2023-01-01T00:00:00.000Z");

            JSONObject result = EpicUtil.transform(time, locationId, reasonId, date, duration, canCombine, providerId);

            assertEquals("providerId", result.getString(PROVIDER_ID_KEY));
            assertEquals("locationId", result.getString(LOCATION_ID_KEY));
            assertEquals("reasonId", result.getString(REASON_ID_KEY));
            assertEquals("10:00", result.getString(START_TIME));
            assertEquals("2023-01-01T00:00:00.000Z", result.getString(DATE_KEY));
            assertEquals(1, result.getInt(CAN_COMBINE));
            assertEquals("30", result.getString("duration"));
        }
    }

    @Test
    void transform_pmTime_returnsExpectedJsonObject() throws ParseException {
        String time = "02:00 PM";
        String locationId = "locationId";
        String reasonId = "reasonId";
        String date = "01/01/2023";
        String duration = "30";
        int canCombine = 1;
        String providerId = "providerId";

        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat("14:00:00", "HH:mm:ss", STD_TIME_FORMAT))
                    .thenReturn("14:00");
            mockedStatic.when(() -> DateUtils.convertDateFormat("14:00", STD_TIME_FORMAT, DOCASAP_TIME_FORMAT))
                    .thenReturn("14:00");
            mockedStatic.when(() -> DateUtils.convertDateFormat("01/01/2023", "MM/dd/yyyy", DATE_TIME_FORMAT))
                    .thenReturn("2023-01-01T00:00:00.000Z");

            JSONObject result = EpicUtil.transform(time, locationId, reasonId, date, duration, canCombine, providerId);

            assertEquals("providerId", result.getString(PROVIDER_ID_KEY));
            assertEquals("locationId", result.getString(LOCATION_ID_KEY));
            assertEquals("reasonId", result.getString(REASON_ID_KEY));
            assertEquals("14:00", result.getString(START_TIME));
            assertEquals("2023-01-01T00:00:00.000Z", result.getString(DATE_KEY));
            assertEquals(1, result.getInt(CAN_COMBINE));
            assertEquals("30", result.getString("duration"));
        }
    }

    @Test
    void transform_invalidTimeFormat_throwsParseException() {
        String time = "10:00 AM";
        String locationId = "locationId";
        String reasonId = "reasonId";
        String date = "01/01/2023";
        String duration = "30";
        int canCombine = 1;
        String providerId = "providerId";

        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenThrow(new ParseException("Invalid time format", 0));

            assertThrows(ParseException.class, () -> EpicUtil.transform(time, locationId, reasonId, date, duration, canCombine, providerId));
        }
    }
    @Test
    void extractOpenSlotsFromResponse_withValidData_returnsExpectedOpenAppointments() throws ParseException {
        JSONObject outputObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("ApptReasonId", "reason1");
        appointmentObject.put("ProviderId", "provider1");
        appointmentObject.put("LocationId", "location1");
        JSONArray timeArray = new JSONArray();
        JSONObject timeObject = new JSONObject();
        timeObject.put(START_TIME_VAL, "10:00:00");
        timeObject.put(DATE, "2023-01-01T00:00:00");
        timeArray.put(timeObject);
        appointmentObject.put("Time", timeArray);
        appointmentObject.put(DATE, "2023-01-01T00:00:00");
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(REASON_ID_KEY, "reason1");
        appointmentObject.put(START_TIME, "1000");
        appointmentObject.put(DATE_KEY, "2023-01-01T00:00:00");
        appointmentObject.put(CAN_COMBINE, 1);
        appointmentObject.put("timeZone", "UTC");
        appointmentsArray.put(appointmentObject);

        outputObject.put(EpmConstant.OPEN_APPOINTMENTS, appointmentsArray);

        JSONArray expectedOpenAppointments = new JSONArray();
        JSONObject expectedAppointment = new JSONObject();
        expectedAppointment.put(LOCATION_ID_KEY, "locationId");
        expectedAppointment.put(PROVIDER_ID_KEY, "provider1");
        expectedAppointment.put(REASON_ID_KEY, "reason1");
        expectedAppointment.put(START_TIME, "1000");
        expectedAppointment.put(DATE_KEY, "2023-01-01T00:00:00");
        expectedAppointment.put(CAN_COMBINE, 1);
        expectedAppointment.put("timeZone", "UTC");
        expectedAppointment.put(DURATION, "");
        expectedAppointment.put(DURATION_UNIT_KEY, "minutes");
        expectedOpenAppointments.put(expectedAppointment);

        JSONArray result = EpicUtil.extractOpenSlotsFromResponse(outputObject, "provider1", 1, "UTC", "reason1", "locationId");
        assertEquals(expectedOpenAppointments.toString(), result.toString());
    }
    @Test
    void extractOpenSlotsFromResponse_ApptReasonId_NotEquals_extReasonId() throws ParseException {
        JSONObject outputObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("ApptReasonId", "reason2");
        JSONArray timeArray = new JSONArray();
        JSONObject timeObject = new JSONObject();
        timeObject.put(START_TIME_VAL, "10:00:00");
        timeObject.put(DATE, "2023-01-01T00:00:00.000Z");
        timeArray.put(timeObject);
        appointmentObject.put("Time", timeArray);
        appointmentObject.put(DATE, "2023-01-01T00:00:00.000Z");
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(REASON_ID_KEY, "reason1");
        appointmentObject.put(START_TIME, "10:00");
        appointmentObject.put(DATE_KEY, "2023-01-01T00:00:00.000Z");
        appointmentObject.put(CAN_COMBINE, 1);
        appointmentObject.put("timeZone", "UTC");
        appointmentsArray.put(appointmentObject);

        outputObject.put(EpmConstant.OPEN_APPOINTMENTS, appointmentsArray);

        JSONArray result = EpicUtil.extractOpenSlotsFromResponse(outputObject, "provider1", 1, "UTC", "reason1","location1");
        assertEquals(result.toString(), new JSONArray().toString());
    }

    @Test
    void extractOpenSlotsFromResponse_NullAppointmentsArray() {
        JSONObject outputObject = new JSONObject();
        JSONArray result = EpicUtil.extractOpenSlotsFromResponse(outputObject, "provider1", 1, "UTC", "reason1","location1");
        assertEquals(new JSONArray().toString(), result.toString());
    }


    @Test
    void extractOpenSlotsFromResponse_withNullTimeArray() {
        JSONObject outputObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("ApptReasonId", "reason1");
        appointmentObject.put("ProviderId", "provider1");
        appointmentObject.put("LocationId", "location1");
        appointmentsArray.put(appointmentObject);

        outputObject.put(EpmConstant.OPEN_APPOINTMENTS, appointmentsArray);

        JSONArray result = EpicUtil.extractOpenSlotsFromResponse(outputObject, "provider1", 1, "UTC", "reason1","location1");
        assertEquals(result.toString(), new JSONArray().toString());
    }

    /*@Test
    void extractOpenSlotsFromResponse_withParseException_throwsRuntimeException() {
        JSONObject outputObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("ApptReasonId", "reason1");
        JSONArray timeArray = new JSONArray();
        JSONObject timeObject = new JSONObject();
        timeObject.put(START_TIME_VAL, "invalid");
        timeObject.put(DATE, "invalidDate");
        timeArray.put(timeObject);
        appointmentObject.put("Time", timeArray);
        appointmentObject.put(DATE, "2023-01-01T00:00:00.000Z");
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(REASON_ID_KEY, "reason1");
        appointmentObject.put(START_TIME, "10:00");
        appointmentObject.put(DATE_KEY, "invalidDate");
        appointmentObject.put(CAN_COMBINE, 1);
        appointmentObject.put("timeZone", "UTC");
        appointmentsArray.put(appointmentObject);
        outputObject.put(EpmConstant.OPEN_APPOINTMENTS, appointmentsArray);

        Exception e = assertThrows(RuntimeException.class, () -> EpicUtil.extractOpenSlotsFromResponse(outputObject, "provider1", 1, "UTC", "reason1","location1"));
        assertInstanceOf(RuntimeException.class, e);
    }*/

    @Test
    void trackEventToNifi_withNullAvailabilityRequest_throwsNullPointerException() {
        EventTracker trackEvents = mock(EventTracker.class);
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "5";
        String fragmentId = "fragment-1";
        Map<String, Object> payload = mock(Map.class);

        assertThrows(NullPointerException.class, () -> EpicUtil.trackEventToNifi(trackEvents, null, dataflowStatus, totalFragments, fragmentId, payload));
    }

    @Test
    void trackEventToNifi_withNullDataflowStatus_throwsNullPointerException() {
        EventTracker trackEvents = mock(EventTracker.class);
        AvailabilityRequest availabilityRequest = mock(AvailabilityRequest.class);
        String totalFragments = "5";
        String fragmentId = "fragment-1";
        Map<String, Object> payload = mock(Map.class);

        assertThrows(NullPointerException.class, () -> EpicUtil.trackEventToNifi(trackEvents, availabilityRequest, null, totalFragments, fragmentId, payload));
    }

    @Test
    void trackEventToNifi_withNullTrackEvents_throwsNullPointerException() {
        AvailabilityRequest availabilityRequest = mock(AvailabilityRequest.class);
        DataflowStatus dataflowStatus = DataflowStatus.SUCCESS;
        String totalFragments = "5";
        String fragmentId = "fragment-1";
        Map<String, Object> payload = mock(Map.class);

        assertThrows(NullPointerException.class, () -> EpicUtil.trackEventToNifi(null, availabilityRequest, dataflowStatus, totalFragments, fragmentId, payload));
    }

    @Test
    void extractOpenSlotsFromResponse_withValidDataAndIsCenter_returnsExpectedOpenAppointments() throws ParseException {
        JSONObject outputObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("ApptReasonId", "reason1");
        appointmentObject.put("ProviderId", "provider1");
        appointmentObject.put("LocationId", "location1");
        JSONArray timeArray = new JSONArray();
        JSONObject timeObject = new JSONObject();
        timeObject.put(START_TIME_VAL, "10:00:00");
        timeObject.put(DATE, "2023-01-01T00:00:00.000Z");
        timeArray.put(timeObject);
        appointmentObject.put("Time", timeArray);
        appointmentObject.put(DATE, "2023-01-01T00:00:00.000Z");
        appointmentObject.put(LOCATION_ID, "locationId");
        appointmentObject.put(REASON_ID_KEY, "reason1");
        appointmentObject.put(START_TIME, "1000");
        appointmentObject.put(DATE_KEY, "2023-01-01T00:00:00.000Z");
        appointmentObject.put(CAN_COMBINE, 1);
        appointmentObject.put("timeZone", "UTC");
        appointmentsArray.put(appointmentObject);

        outputObject.put(EpmConstant.OPEN_APPOINTMENTS, appointmentsArray);

        JSONArray expectedOpenAppointments = new JSONArray();
        JSONObject expectedAppointment = new JSONObject();
        expectedAppointment.put(LOCATION_ID_KEY, "locationId");
        expectedAppointment.put(PROVIDER_ID_KEY, "provider1");
        expectedAppointment.put(REASON_ID_KEY, "reason1");
        expectedAppointment.put(START_TIME, "1000");
        expectedAppointment.put(DATE_KEY, "2023-01-01T00:00:00");
        expectedAppointment.put(CAN_COMBINE, 1);
        expectedAppointment.put("timeZone", "UTC");
        expectedAppointment.put(DURATION, "");
        expectedAppointment.put(DURATION_UNIT_KEY, "minutes");
        expectedOpenAppointments.put(expectedAppointment);

        JSONArray result = EpicUtil.extractOpenSlotsFromResponse(outputObject, "provider1", 1, "UTC", "reason1", "locationId");
        assertEquals(expectedOpenAppointments.toString(), result.toString());
    }
}
