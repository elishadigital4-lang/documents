package com.pes.integration.epic.service.open;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.task.RealTimeOpenSlotsTask;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.upload.AwsS3FileUploader;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.MetricsUtil;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import static com.pes.integration.constant.DocASAPConstants.Key.CAN_COMBINE;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPIC_CONFIG;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_REQUEST;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpenAppointmentServiceImplTest {

    @Mock
    private EventTracker trackEvents;
    @Mock
    private FileUploader fileUploader;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private NifiTrackingEvent nifiTrackingEvent;

    @InjectMocks
    private OpenAppointmentServiceImpl openAppointmentServiceImpl;
    @Mock
    private EpicApiCaller epicApiCaller;

    private AvailabilityRequest availabilityRequest;
    private JSONObject inputParam;
    private JSONObject outputObject;
    private JSONObject provLocObj;
    private RealTimeRequest realTimeRequest;
    private Map<String, JSONArray> providerLocationMap;
    private String startDate;
    private String endDate;
    private JSONArray locations;
    private String deploymentId;

    private Object provider;
    private String providerId;
    private String providerIdType;
    private String epmPrefix;
    private JSONObject appointmentTypeRequest;
    @Mock
    AwsS3FileUploader awsS3FileUploader;
    @Mock
    private CompletableFuture completableFuture;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        startDate = "2024-01-01";
        endDate = "2024-01-10";
        locations = new JSONArray().put("location1");
        deploymentId = "deploymentId";
        providerId = "providerId";
        providerIdType = "providerIdType";
        epmPrefix = "ep";
        provider = "provider";

        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("messageControlId");
        availabilityRequest.setAppointmentType("appointmentType");
        availabilityRequest.setSliceId("sliceId");
        availabilityRequest.setDeploymentId("deploymentId");
        availabilityRequest.setTotalSlices("5");
        availabilityRequest.setFlow("flow");
        availabilityRequest.setStartDate("2024-01-01");
        availabilityRequest.setEndDate("2024-01-10");
        availabilityRequest.setIndex("1");
        availabilityRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));

        providerLocationMap = new HashMap<>();
        providerLocationMap.put("locationIdList", new JSONArray().put("location1"));
        providerLocationMap.put("providerIdList", new JSONArray().put("provider1"));
        realTimeRequest = new RealTimeRequest();
        realTimeRequest.setDeploymentId("deploymentId");
        realTimeRequest.setMessageControlId("messageControlId");
        realTimeRequest.setStartDate("2024-01-01");
        realTimeRequest.setEndDate("2024-01-10");
        realTimeRequest.setEntityType("entityType");
        realTimeRequest.setFlow("flow");
        realTimeRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));

        provLocObj = new JSONObject();
        provLocObj.put("locationId", "location");
        provLocObj.put("providerId", "provider");
        provLocObj.put("reasonId", "reason");
        provLocObj.put("patientId", "patient");
        provLocObj.put("appId", "AppId");

        inputParam = new JSONObject();
        inputParam.put("providerId", "providerId");
        inputParam.put("deploymentId", "deployment123");
        inputParam.put("reasonMapExist", "true");
        inputParam.put("maxPoolSize", "10");
        inputParam.put("startDate", "2024-01-01");
        inputParam.put("endDate", "2024-01-10");

        inputParam.put("limit", "10");
        inputParam.put("reason_id", "reasonId");
        inputParam.put("appt_resource_id", "resourceId");
        inputParam.put("appt_location_id", "locationId");

        ReflectionTestUtils.setField(openAppointmentServiceImpl, "trackEvents", trackEvents);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataCacheManager", dataCacheManager);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "iHubDataServiceDelegator", iHubDataServiceDelegator);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "fileUploader", fileUploader);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "datediff", 5);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "threadSize", 10);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "epicApiCaller", epicApiCaller);
    }
    @Test
    @Disabled
    void testGetAvailability_withValidData_returnsOpenAppointments() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2024-01-01");
        availabilityRequest.setEndDate("2024-01-10");
        availabilityRequest.setIndex("1");
        availabilityRequest.setDeploymentId("74247^0001");
        availabilityRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));
        availabilityRequest.setTotalSlices("5");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        providerLocationMap.put("locationIdList", new JSONArray().put("location1"));
        providerLocationMap.put("providerIdList", new JSONArray().put("provider1"));

        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequestJson");
        doReturn("External").when(dataCacheManager).getConfiguration(eq("ep"), eq("74247^0001"), eq(EPIC_CONFIG), eq(PROVIDER_ID_TYPE_ID));
        doReturn("1").when(dataCacheManager).getConfiguration(eq("ep"), eq("74247^0001"), eq(GENERIC_CONFIG), eq(CAN_COMBINE));

        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataLocation", "valid/path/to/data");
        CompletableFuture<List<Void>> openApptCompletableFuture = mock(CompletableFuture.class);
        lenient().when(openApptCompletableFuture.get()).thenReturn(Collections.emptyList());
        openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "ep");

        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
    }
    @Test
    @Disabled
    void testGetAvailability_withValidData_EpmApiCallerException() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2024-01-01");
        availabilityRequest.setEndDate("2024-01-10");
        availabilityRequest.setIndex("1");
        availabilityRequest.setDeploymentId("74247^0001");
        availabilityRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));
        availabilityRequest.setTotalSlices("5");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        providerLocationMap.put("locationIdList", new JSONArray().put("location1"));
        providerLocationMap.put("providerIdList", new JSONArray().put("provider1"));

        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequestJson");
        doReturn("External").when(dataCacheManager).getConfiguration(eq("ep"), eq("74247^0001"), eq(EPIC_CONFIG), eq(PROVIDER_ID_TYPE_ID));
        doReturn("1").when(dataCacheManager).getConfiguration(eq("ep"), eq("74247^0001"), eq(GENERIC_CONFIG), eq(CAN_COMBINE));

        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataLocation", "valid/path/to/data");
        openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "ep");

        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
    }

    @Test
    void testGetAvailability_withNullAvailabilityRequest_throwsException() {
        assertThrows(NullPointerException.class, () -> openAppointmentServiceImpl.getAvailability(null, new HashMap<>(), "epmPrefix"));
    }

    @Test
    void testGetAvailability_withEmptyProviderLocationMap_returnsEmptyArray() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2024-01-01");
        availabilityRequest.setEndDate("2024-01-10");
        availabilityRequest.setIndex("1");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        providerLocationMap.put("providerIdList", new JSONArray());

        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequestJson");

        JSONArray result = openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix");

        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void testGetAvailability_withInvalidDates_returnsEmptyArray() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2024-01-10");
        availabilityRequest.setEndDate("2024-01-01");
        availabilityRequest.setIndex("1");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        providerLocationMap.put("locationIdList", new JSONArray().put("location1"));
        providerLocationMap.put("providerIdList", new JSONArray().put("provider1"));

        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequestJson");

        JSONArray result = openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix");

        assertNotNull(result);
        assertEquals(0, result.length());
    }
    @Test
    @Disabled
    void testGetAvailability_threadSize() throws Exception {
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "threadSize", 10);
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("20");

        openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "ep");

        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
        verify(dataCacheManager, times(2)).getConfiguration(anyString(), anyString(), anyString(), anyString());
    }

    @Test
    @Disabled
    void testGetAvailability_withExceptionInFetchOpenAppointments_throwsException() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2024-01-01");
        availabilityRequest.setEndDate("2024-01-10");
        availabilityRequest.setIndex("1");
        availabilityRequest.setDeploymentId("74247^0001");
        availabilityRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));
        availabilityRequest.setTotalSlices("5");
        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        providerLocationMap.put("locationIdList", new JSONArray().put("location1"));
        providerLocationMap.put("providerIdList", new JSONArray().put("provider1"));

        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequestJson");
        doReturn("External").when(dataCacheManager).getConfiguration(eq("ep"), eq("74247^0001"), eq(EPIC_CONFIG), eq(PROVIDER_ID_TYPE_ID));
        doReturn("1").when(dataCacheManager).getConfiguration(eq("ep"), eq("74247^0001"), eq(GENERIC_CONFIG), eq(CAN_COMBINE));
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataLocation", "valid/path/to/data");

        openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "ep");
    }
    @Test
    void testGetAvailability_IHubException() throws Exception {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenThrow(new IHubException(ERROR_IN_REQUEST.getErrorCode(), "Error in requestObject parsing "));

        assertThrows(IHubException.class, () -> openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "EPM_PREFIX"));

        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
    }

    @Test
    void testGetFragmentsDetails() throws Exception {
        Map<String, Object> result = (Map<String, Object>) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getFragmentsDetails", availabilityRequest, providerLocationMap);

        assertEquals("1", result.get(TOTAL_FRAGMENTS));
        assertEquals("5", result.get(TOTAL_SLICES));
    }

    @Test
    void getRealTimeInputObject_withValidData_returnsCorrectJsonObject() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("providerConfigValue");
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getRealTimeInputObject", realTimeRequest, deploymentId, epmPrefix, provLocObj);

        assertEquals(realTimeRequest.getStartDate(), result.getString(STARTDATE));
        assertEquals(realTimeRequest.getEndDate(), result.getString(ENDDATE));
        assertEquals("providerConfigValue", result.getString(PROVIDER_ID_TYPE_ID));
        assertEquals("providerConfigValue", result.getString("locationType"));
        assertEquals("providerConfigValue", result.getString("visitType"));
        assertEquals("providerConfigValue", result.getString("useridtype"));
        assertEquals(provLocObj.opt("locationId"), result.getString("location"));
        assertEquals(provLocObj.opt("reasonId"), result.getString("reason"));
        assertEquals(provLocObj.opt("providerId"), result.getString("provider"));
        assertEquals(provLocObj.opt("patientId"), result.getString("patient"));
        assertEquals(provLocObj.opt("appId"), result.getString("AppId"));
        assertEquals("configValue", result.getString("userid"));
        assertEquals("configValue", result.getString("patientidtype"));
        assertEquals("configValue", result.getString("maxsolution"));
    }

    @Test
    void getRealTimeInputObject_withEmptyProvider_returnsJsonObjectWithEmptyProvider() throws IHubException {
        JSONObject provLocObj = new JSONObject();
        provLocObj.put("locationId", "location1");
        provLocObj.put("reasonId", "reason1");
        provLocObj.put("providerId", "");
        provLocObj.put("patientId", "patient1");
        provLocObj.put("appId", "app1");

        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getRealTimeInputObject", realTimeRequest, deploymentId, epmPrefix, provLocObj);

        assertEquals("", result.getString(PROVIDER));
    }

    @Test
    void getRealTimeInputObject_withEmptyDates_returnsJsonObjectWithEmptyDates() throws IHubException {
        realTimeRequest.setStartDate("");
        realTimeRequest.setEndDate("");

        JSONObject provLocObj = new JSONObject();
        provLocObj.put("locationId", "location1");
        provLocObj.put("reasonId", "reason1");
        provLocObj.put("providerId", "provider1");
        provLocObj.put("patientId", "patient1");
        provLocObj.put("appId", "app1");

        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getRealTimeInputObject", realTimeRequest, deploymentId, epmPrefix, provLocObj);

        assertEquals("", result.getString(STARTDATE));
        assertEquals("", result.getString(ENDDATE));
    }

    @Test
    void testGetInputObject() throws IHubException {
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getInputObject", startDate, endDate, providerIdType, provider);
        assertEquals(startDate, result.getString(STARTDATE));
        assertEquals(endDate, result.getString(ENDDATE));
        assertEquals(provider.toString(), result.getString(PROVIDER));
        assertEquals(providerIdType, result.getString(PROVIDER_ID_TYPE_ID));
    }

    @Test
    void fetchOpenAppointmentsHandlesInvalidDates() throws IHubException {
        JSONArray result = openAppointmentServiceImpl.fetchOpenAppointments("2024-01-10", "2024-01-01", providerLocationMap, availabilityRequest, epmPrefix);
        assertEquals(0, result.length());
    }

    @Test
    void fetchOpenAppointmentsHandlesIHubException() {
        RuntimeException exception = assertThrows(RuntimeException.class, () -> openAppointmentServiceImpl.fetchOpenAppointments("2023-01-01", "2023-01-10", providerLocationMap, availabilityRequest, epmPrefix));
        assertFalse(exception.getCause() instanceof RuntimeException);
    }

    @Test
    void getRealTimeAvailability_withEmptyEntityId_returnsEmptyOpenAppointments() throws JsonProcessingException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setEntityId(Collections.emptyList());
        ObjectWriter objectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(anyList())).thenReturn(null);
        assertThrows(NullPointerException.class, ()->openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest));
    }

    @Test
    void getRealTimeAvailability_withMissingAppId_throwsEpmApiCallerException() throws JsonProcessingException, IHubException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setEntityId(Arrays.asList(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));
        realTimeRequest.setDeploymentId("deploymentId");

        ObjectWriter objectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(anyList())).thenReturn("[{\"locationId\":\"1\",\"providerId\":\"1\",\"reasonId\":\"1\",\"appId\":\"1\"}]");
        when(dataCacheManager.getRedisConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn(new JSONObject("{\"1\":\"clientId\"}"));
        when(dataCacheManager.getRedisConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn(new JSONObject("{\"clientId\":\"flow\"}"));
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);

            assertThrows(EpmApiCallerException.class, () -> openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest));

        }
    }

    @Test
    void getRealTimeAvailability_withAgentFlowAndMissingPatientId_throwsEpmApiCallerException() throws JsonProcessingException, IHubException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setEntityId(Arrays.asList(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1").put("appId", "1")));
        realTimeRequest.setDeploymentId("deploymentId");

        ObjectWriter objectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(anyList())).thenReturn("[{\"locationId\":\"1\",\"providerId\":\"1\",\"reasonId\":\"1\",\"appId\":\"1\"}]");
        when(dataCacheManager.getRedisConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn(new JSONObject("{\"1\":\"clientId\"}"));
        when(dataCacheManager.getRedisConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn(new JSONObject("{\"clientId\":\"Agent_Flow\"}"));
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            assertThrows(EpmApiCallerException.class, () -> openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest));

        }
    }



    @Test
    void testGetRealTimeAvailability_withMissingAppId_throwsEpmApiCallerException() throws JsonProcessingException, IHubException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setEntityId(Arrays.asList(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));
        realTimeRequest.setDeploymentId("74247^0001");

        ObjectWriter objectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(anyList())).thenReturn("[{\"locationId\":\"1\",\"providerId\":\"1\",\"reasonId\":\"1\"}]");
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            assertThrows(EpmApiCallerException.class, () -> openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest));
        }
    }

    @Test
    void testGetRealTimeAvailability_withAgentFlowAndMissingPatientId_throwsEpmApiCallerException() throws JsonProcessingException, IHubException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setEntityId(Arrays.asList(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1").put("appId", "1")));
        realTimeRequest.setDeploymentId("74247^0001");

        ObjectWriter objectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(anyList())).thenReturn("[{\"locationId\":\"1\",\"providerId\":\"1\",\"reasonId\":\"1\",\"appId\":\"1\"}]");
        when(dataCacheManager.getRedisConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn(new JSONObject("{\"1\":\"clientId\"}"));
        when(dataCacheManager.getRedisConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn(new JSONObject("{\"clientId\":\"Agent_Flow\"}"));
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            assertThrows(EpmApiCallerException.class, () -> openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest));

        }
    }

    @Test
    void testGetRealTimeAvailability_withInvalidJsonData_throwsEpmApiCallerException() throws JsonProcessingException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setEntityId(Arrays.asList(new JSONObject().put("invalidJson", "data")));
        realTimeRequest.setDeploymentId("74247^0001");

        ObjectWriter objectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(anyList())).thenThrow(JsonProcessingException.class);

        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            assertThrows(EpmApiCallerException.class, () -> openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest));

        }
    }

    @Test
    void testGetRealTimeAvailability_withDataCacheManagerThrowingIHubException_throwsRuntimeException() throws JsonProcessingException, IHubException {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setEntityId(Arrays.asList(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1").put("appId", "1")));
        realTimeRequest.setDeploymentId("74247^0001");

        ObjectWriter objectWriter = mock(ObjectWriter.class);
        when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
        when(objectWriter.writeValueAsString(anyList())).thenReturn("[{\"locationId\":\"1\",\"providerId\":\"1\",\"reasonId\":\"1\",\"appId\":\"1\"}]");
        when(dataCacheManager.getRedisConfiguration(anyString(), anyString(), anyString(), anyString())).thenThrow(IHubException.class);

        assertThrows(RuntimeException.class, () -> openAppointmentServiceImpl.getRealTimeAvailability(realTimeRequest));
    }
}
