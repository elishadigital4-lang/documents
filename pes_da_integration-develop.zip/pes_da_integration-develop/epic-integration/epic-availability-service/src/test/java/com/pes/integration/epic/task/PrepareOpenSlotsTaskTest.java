package com.pes.integration.epic.task;

import com.pes.integration.adapter.Utils;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.util.EpicUtil;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.upload.FileUploader;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.FRAGMENT_ID_KEY;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class PrepareOpenSlotsTaskTest {

    private PrepareOpenSlotsTask prepareOpenSlotsTask;
    private EpicApiCaller epicApiCaller;
    private FileUploader fileUploader;
    private EventTracker trackEvents;
    private AvailabilityRequest availabilityRequest;
    private DataCacheManager dataCacheManager;
    private JSONObject inputObject;


    @BeforeEach
    void setUp() throws IHubException {
        epicApiCaller = mock(EpicApiCaller.class);
        fileUploader = mock(FileUploader.class);
        trackEvents = mock(EventTracker.class);
        availabilityRequest = mock(AvailabilityRequest.class);
        availabilityRequest.setIndex("1");
        dataCacheManager = mock(DataCacheManager.class);
        inputObject = new JSONObject();
        inputObject.put("startDate", "2023-01-01");
        inputObject.put("endDate", "2023-01-31");
        inputObject.put("provider", "providerId");
        inputObject.put("appointmentPath", "appointments/");
        when(dataCacheManager.getConfiguration("epmPrefix", null, "genericconfig", "can_combine")).thenReturn("0");
        prepareOpenSlotsTask = new PrepareOpenSlotsTask(epicApiCaller, inputObject, fileUploader, trackEvents, availabilityRequest, "epmPrefix", dataCacheManager);
    }

    @Test
    void getOpenAppointment_validResponse_returnsOpenAppointment() throws Exception {
        JSONObject responseObject = new JSONObject();
        responseObject.put("data", new JSONArray());
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenReturn(responseObject);
            mockedStatic.when(() -> EpicUtil.extractOpenSlotsFromResponse(any(), anyString(), anyInt(), anyString(), anyString(),anyString()))
                    .thenReturn(new JSONArray());

            JSONObject result = ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getOpenAppointment");

            assertNotNull(result);
            assertEquals(0, result.getJSONArray("data").length());
        }
    }

    @Test
    void getOpenAppointment_invalidIdException_throwsNullPointerException() throws Exception {
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new InvalidIdException("Invalid Id"));
            assertThrows(NullPointerException.class, () -> {
                ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getOpenAppointment");
            });
        }
    }

    @Test
    void uploadFiles_validInput_callsUploadFile() {
        Map<String, File> appointmentDataFiles = new HashMap<>();
        JSONObject openApptOutput = new JSONObject();
        openApptOutput.put("key", "value");
        when(availabilityRequest.getMessageControlId()).thenReturn("messageControlId");
        when(availabilityRequest.getAppointmentType()).thenReturn("appointmentType");
        when(availabilityRequest.getSliceId()).thenReturn("sliceId");

        ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "uploadFiles", appointmentDataFiles, openApptOutput);

        verify(fileUploader, times(1)).uploadFile(anyString(), anyString(), anyString(), any(File.class));
    }

    @Test
    void prepareOpenAppointmentFile_validInput_returnsFile() {
        JSONObject apptresponse = new JSONObject();
        apptresponse.put("key", "value");

        File result = ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "prepareOpenAppointmentFile", apptresponse, availabilityRequest);

        assertNotNull(result);
    }

    @Test
    void getNifiPayload_returnsCorrectPayload() {
        JSONObject result = ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getNifiPayload");
        assertNotNull(result);
        assertEquals("2023-01-01", result.getString("startDate"));
        assertEquals("2023-01-31", result.getString("endDate"));
        assertEquals("providerId", result.getString("fragmentId"));
    }
    @Test
    void getOpenAppointment_invalidIdException_throwsEpmApiCallerException() throws Exception {
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class);
             MockedStatic<Utils> mockedStatic2 = mockStatic(Utils.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new InvalidIdException("Invalid Id"));
            mockedStatic2.when(()-> Utils.trackOpenFragmentError(any(), any(), anyString(), anyString())).thenAnswer(invocation -> {
                return null;
            });
            EpmApiCallerException exception = assertThrows(EpmApiCallerException.class, () -> {
                ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getOpenAppointment");
            });

            assertTrue(exception.getMessage().contains("Error in processing the data for open appointment slot"));
        }
    }

    @Test
    void getOpenAppointment_epmApiCallerException_throwsEpmApiCallerException() throws Exception {
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class);
        MockedStatic<Utils> mockedStatic2 = mockStatic(Utils.class)) {
            mockedStatic2.when(()-> Utils.trackOpenFragmentError(any(), any(), anyString(), anyString())).thenAnswer(invocation -> {
                return null;
            });
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new EpmApiCallerException("API call failed"));

            EpmApiCallerException exception = assertThrows(EpmApiCallerException.class, () -> {
                ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getOpenAppointment");
            });

            assertTrue(exception.getMessage().contains("Error in processing the data for open appointment slot"));
        }
    }

    @Test
    void getOpenAppointment_invalidResourceException_throwsInvalidResourceException() throws Exception {
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new InvalidResourceException("Invalid Open Resource"));


            UndeclaredThrowableException exception = assertThrows(UndeclaredThrowableException.class, () -> {
                ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getOpenAppointment");
            });

            Throwable cause = exception.getCause();
            assertInstanceOf(InvalidResourceException.class, cause);
        }
    }

    @Test
    void getOpenAppointment_iHubException_throwsRuntimeException() throws Exception {
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(),"IHub error"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getOpenAppointment");
            });

            assertTrue(exception.getCause() instanceof IHubException);
        }
    }

    @Test
    void getOpenAppointment_ioException_throwsRuntimeException() throws Exception {
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new IOException("IO error"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "getOpenAppointment");
            });

            assertTrue(exception.getCause() instanceof IOException);
        }
    }
    @Test
    void get_validOpenAppointment_callsUploadFilesAndTracksEvent() throws Exception {
        Map<String, Object> payload = new HashMap<>();
        payload.put(STARTDATE, "StartDate");
        payload.put(ENDDATE, "EndDate");
        payload.put(FRAGMENT_ID_KEY, "FragmentIdKey");
        when(availabilityRequest.getMessageControlId()).thenReturn("messageControlId");
        when(availabilityRequest.getAppointmentType()).thenReturn("appointmentType");
        when(availabilityRequest.getSliceId()).thenReturn("sliceId");
        try (MockedStatic<EpicUtil> mockedStatic1 = mockStatic(EpicUtil.class);
             MockedStatic<Utils> mockedStatic2 = mockStatic(Utils.class);
             MockedStatic<DataflowStatus> mockedStatic = mockStatic(DataflowStatus.class)) {
            mockedStatic.when(() -> DataflowStatus.valueOf("PULL_OPEN_APPOINTMENT_FRAGMENT")).thenReturn(DataflowStatus.PULL_OPEN_APPOINTMENT_FRAGMENT);
            mockedStatic2.when(() -> Utils.getOpenDataFlowNifiStatus(availabilityRequest)).thenReturn(DataflowStatus.PULL_OPEN_APPOINTMENT_FRAGMENT);
            mockedStatic2.when(() -> Utils.createNifiErrorPayload(any(JSONObject.class))).thenReturn(payload);
            mockedStatic1.when(() -> EpicUtil.trackEventToNifi(eq(trackEvents), eq(availabilityRequest), any(), anyString(), anyString(), any())).thenAnswer(invocation -> {
                return null;
            });
            ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "get");
            verify(fileUploader, times(1)).uploadFile(eq("messageControlId"), eq("appointmentType"), eq("sliceId/providerId"), any(File.class));
        }
    }

    @Test
    void get_jsonProcessingException_throwsJSONException() {
        try (MockedStatic<Utils> mockedStatic = mockStatic(Utils.class)) {
            mockedStatic.when(() -> Utils.getOpenDataFlowNifiStatus(availabilityRequest)).thenThrow(new RuntimeException("JSON error") {});

            JSONException exception = assertThrows(JSONException.class, () -> {
                ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "get");
            });

            assertTrue(exception.getMessage().contains("JSONObject[\"provideridtype\"] not found."));
        }
    }
}