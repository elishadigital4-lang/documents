package com.pes.integration.epic.service.booked;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.epic.api.ApiName;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.task.PrepareBookedSlotsTask;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.upload.FileUploader;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.epic.constant.EpicConstants.ID_TYPE_VALUE;
import static com.pes.integration.epic.constant.EpicConstants.LOCATIONS;
import static com.pes.integration.epic.constant.EpicEngineConstants.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;
import static software.amazon.awssdk.http.nio.netty.internal.ProxyTunnelInitHandler.log;

@ExtendWith(MockitoExtension.class)
class BookedAppointmentServiceImplTest {

    @Mock
    private EpicApiCaller epicApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private DataCacheManager dataCacheManager;

    @InjectMocks
    private BookedAppointmentServiceImpl bookedAppointmentService;

    private AvailabilityRequest availabilityRequest;
    private RealTimeRequest realTimeRequest;
    private JSONArray locationJsonArray;

    private JSONObject responseObject;

    private Map<String, JSONArray> providerLocationMap;
    private String startDate;
    private String endDate;
    private String epmPrefix;
    private String deploymentId;
    @Mock
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("1");
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-31");
        availabilityRequest.setIndex("1");
        availabilityRequest.setTotalSlices("5");
        availabilityRequest.setDeploymentId("deploymentId");

        responseObject = new JSONObject();
        responseObject.put("BookedAppointments", new JSONArray());

        startDate = "2023-01-01";
        endDate = "2023-01-31";
        locationJsonArray = new JSONArray();
        epmPrefix = "ep";
        deploymentId = "74247^0001";

        providerLocationMap = new HashMap<>();
        providerLocationMap.put(LOCATION_ID_LIST, new JSONArray());
        epmPrefix = "ep";
    }

    @Test
    void testGetInputObject() throws IHubException {
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                bookedAppointmentService, "getInputObject", startDate, endDate, locationJsonArray, epmPrefix, deploymentId);
        assertEquals(startDate, result.getString(STARTDATE));
        assertEquals(endDate, result.getString(ENDDATE));
        assertEquals("appointment/", result.getString(APPOINTMENT_PATH));
        assertEquals(locationJsonArray.toString(), result.getString(LOCATIONS));
        assertEquals(deploymentId, result.getString("deploymentId"));
    }
    @Test
    void testGetFragmentsDetails() {
        Map<String, Object> result = (Map<String, Object>) ReflectionTestUtils.invokeMethod(
                bookedAppointmentService, "getFragmentsDetails", availabilityRequest);

        assertEquals("1", result.get(TOTAL_FRAGMENTS));
        assertEquals("5", result.get(TOTAL_SLICES));
    }


    @Test
    public void testFetchBookedAppointments() throws Exception {
        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray locationJsonArray = new JSONArray();
        locationJsonArray.put("location1").put("location2").put("location3").put("location4");
        providerLocationMap.put(REASON_ID_LIST, locationJsonArray);
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("provider1").put("provider2").put("provider3"));

        Mockito.when(dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, ORCHARDCLIENTID_TYPE))
                .thenReturn("usertype");
        Mockito.when(dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, ORCHARDCLIENTID))
                .thenReturn("user");
        Mockito.when(dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, ID_TYPE_VALUE))
                .thenReturn("idTypeVal");
        bookedAppointmentService.fetchBookedAppointments("2025-01-09", "2025-05-09", locationJsonArray, availabilityRequest, "epmPrefix");

    }
    @Test
    void fetchBookedAppointments_withInvalidDateFormat_throwsRuntimeException() {
        assertThrows(RuntimeException.class, () -> bookedAppointmentService.fetchBookedAppointments("invalid-date", "invalid-date", locationJsonArray, availabilityRequest, "epmPrefix"));
    }


    @Test
    void getAvailabilityTracksEventWhenFirstIndex() throws JsonProcessingException {
        availabilityRequest.setIndex("1");
        availabilityRequest.setTotalSlices("5");
        when(objectMapper.writeValueAsString(availabilityRequest)).thenReturn("Input value");
        bookedAppointmentService.getAvailability(availabilityRequest, providerLocationMap, epmPrefix);
        verify(trackEvents, times(1)).trackEvent(eq(availabilityRequest), eq(BOOKED_APPOINTMENT_PROCESSING_STARTED), anyString(), anyMap());
    }

    @Test
    void getAvailabilityDoesNotTrackEventWhenNotFirstIndex() throws JsonProcessingException {
        availabilityRequest.setIndex("2");
        bookedAppointmentService.getAvailability(availabilityRequest, providerLocationMap, epmPrefix);
        verify(trackEvents, never()).trackEvent(any(), any(), any(), any());
    }
    @Test
    void getRealTimeAvailability() throws JsonProcessingException {
        JSONObject result = bookedAppointmentService.getRealTimeAvailability(realTimeRequest);
        assertNull(result);
    }
    }

