package com.pes.integration.epic.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.InvocationTargetException;

@ExtendWith(MockitoExtension.class)
class DemographicsDataTest {
    @BeforeEach
    public void setup() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void demographicsData_withValidData_returnsCorrectValues() {
        DemographicsData data = new DemographicsData("type1", "value1");
        assertEquals("type1", data.getDemogIdType());
        assertEquals("value1", data.getIdTypeValue());
    }

    @Test
    void demographicsData_withNullValues_returnsNull() {
        DemographicsData data = new DemographicsData(null, null);
        assertNull(data.getDemogIdType());
        assertNull(data.getIdTypeValue());
    }

    @Test
    void demographicsData_withEmptyStrings_returnsEmptyStrings() {
        DemographicsData data = new DemographicsData("", "");
        assertEquals("", data.getDemogIdType());
        assertEquals("", data.getIdTypeValue());
    }
}