package com.pes.integration.epic.task;

import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.SlotDTO;
import com.pes.integration.epic.InitEngine;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.model.DemographicsData;
import com.pes.integration.epic.util.EpicUtil;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.constant.DocASAPConstants.Key.CAN_COMBINE;
import static com.pes.integration.constant.DocASAPConstants.Key.ID;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.*;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.util.ReflectionTestUtils.*;

@ExtendWith(MockitoExtension.class)
class PrepareBookedSlotsTaskTest {
    private PrepareBookedSlotsTask prepareBookedSlotsTask;

    private EpicApiCaller epicApiCaller;
    private FileUploader fileUploader;
    private EventTracker trackEvents;
    private AvailabilityRequest availabilityRequest;
    private DataCacheManager dataCacheManager;
    private JSONObject inputObject;
    private SlotDTO slotDTO;

    @BeforeEach
    void setUp() {
        epicApiCaller = mock(EpicApiCaller.class);
        fileUploader = mock(FileUploader.class);
        trackEvents = mock(EventTracker.class);
        availabilityRequest = mock(AvailabilityRequest.class);
        dataCacheManager = mock(DataCacheManager.class);
        inputObject = new JSONObject();
        inputObject.put("startDate", "2023-01-01");
        inputObject.put("endDate", "2023-01-31");
        inputObject.put("locations", "[\"location1\"]");
        inputObject.put("appointmentPath", "appointments/");
        slotDTO = new SlotDTO();
        slotDTO.setSlotId("1");
        slotDTO.setProviderId("1");
        slotDTO.setLocationId("1");
        slotDTO.setReasonId("1");
        slotDTO.setDate("01-01-2023");
        slotDTO.setStartTime("10:00");
        slotDTO.setDuration("30");


        prepareBookedSlotsTask = new PrepareBookedSlotsTask(epicApiCaller, inputObject, fileUploader, trackEvents, availabilityRequest, dataCacheManager);
    }

    @Test
    void testGetBookedAppointment() throws Exception {
        // Prepare the input parameters
        JSONObject responseObject = new JSONObject();
        responseObject.put("BookedAppointments", new JSONArray());
        when(epicApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(responseObject);

        // Use reflection to invoke the private method
        Method method = PrepareBookedSlotsTask.class.getDeclaredMethod("getBookedAppointment");
        method.setAccessible(true);

        // Invoke the method
        JSONObject result = (JSONObject) method.invoke(prepareBookedSlotsTask);

        // Verify the result
        assertNotNull(result);
    }

    @Test
    void testUploadBookedFiles() {
        // Prepare the input parameters
        Map<String, File> appointmentDataFiles = new HashMap<>();
        JSONObject bookedApptOutput = new JSONObject();
        bookedApptOutput.put("key", "value");
        when(availabilityRequest.getMessageControlId()).thenReturn("messageControlId");
        when(availabilityRequest.getAppointmentType()).thenReturn("appointmentType");
        when(availabilityRequest.getSliceId()).thenReturn("sliceId");

        // Use reflection to invoke the private method
        invokeMethod(prepareBookedSlotsTask, "uploadBookedFiles", appointmentDataFiles, bookedApptOutput);

        // Verify the behavior
        verify(fileUploader, times(1)).uploadFile(anyString(), anyString(), anyString(), any(File.class));
    }

    @Test
    void testPrepareBookedFile() {
        // Prepare the input parameters
        JSONObject apptresponse = new JSONObject();
        apptresponse.put("key", "value");

        // Use reflection to invoke the private method
        File result = invokeMethod(prepareBookedSlotsTask, "prepareBookedFile", apptresponse, availabilityRequest);

        // Verify the result
        assertNotNull(result);
    }

    @Test
    void testExtractBookedSlots() throws Exception {
        // Prepare the input parameters
        JSONObject outputObject = new JSONObject();
        outputObject.put("BookedAppointments", new JSONArray());

        // Use reflection to invoke the private method
        JSONArray result = invokeMethod(prepareBookedSlotsTask, "extractBookedSlots", outputObject);

        // Verify the result
        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void testExtractBookedSlotsBookedAppts() throws Exception {
        JSONObject outputObject = new JSONObject();
        JSONObject appts = new JSONObject();
        appts.put("Duration","30");
        appts.put("ApptReasonId","aptrsn1");
        appts.put("ProviderId","provider2");
        appts.put("LocationId","loc2");
        appts.put("slotId","slot");
        JSONObject temp = new JSONObject("""
                {"start_time": "10:00 am", "start_date": "12/08/2025"}""");
        appts.put("temp",temp);
        JSONArray arr = new JSONArray();
        arr.put(appts);
        outputObject.put("BookedAppointments", arr);

        JSONArray result = invokeMethod(prepareBookedSlotsTask, "extractBookedSlots", outputObject);

        assertNotNull(result);
        assertEquals(1, result.length());
        JSONObject jsonObject = result.getJSONObject(0);
        assertEquals("2025-12-08T00:00:00", getValue(jsonObject , "date").toString());
        assertEquals("1000", getValue(jsonObject , "startTime").toString());
    }
    @Test
    void testExtractBookedSlotsAllFieldsPresent() throws Exception {
        JSONObject outputObject = new JSONObject();
        JSONObject appts = new JSONObject();
        JSONArray extApptObject = new JSONArray("""
                [{"IdType": "idtyp", "appt2": "1289"}]""");
        appts.put("Duration","30");
        appts.put("ApptReasonId","aptrsn1");
        appts.put("ProviderId","provider2");
        appts.put("LocationId","loc2");
        appts.put("Providers",extApptObject);
        appts.put("Locations",extApptObject);
        appts.put("ApptReason",extApptObject);
        appts.put("slotId","slot");
        appts.put("ExternalAppt",extApptObject);

        JSONObject temp = new JSONObject("""
                {"start_time": "10:00 am", "start_date": "12/08/2025"}""");
        appts.put("temp",temp);
        JSONArray arr = new JSONArray();
        arr.put(appts);
        outputObject.put("BookedAppointments", arr);

        JSONArray result = invokeMethod(prepareBookedSlotsTask, "extractBookedSlots", outputObject);

        assertNotNull(result);
        assertEquals(1, result.length());
        JSONObject jsonObject = result.getJSONObject(0);
        assertEquals("2025-12-08T00:00:00", getValue(jsonObject , "date").toString());
        assertEquals("1000", getValue(jsonObject , "startTime").toString());
    }

    @Test
    void testTransformBookedAppointment() throws Exception {
        // Mock the static method
        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertTime(anyString())).thenReturn("10:00");
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString())).thenReturn("01-01-2023'T'00:00:00");

            String bookedAppointment = "{\"temp\": {\"start_time\": \"10:00\", \"start_date\": \"01-01-2023\"}, \"ApptReasonId\": \"1\", \"ProviderId\": \"1\", \"LocationId\": \"1\", \"slotId\": \"1\", \"Duration\": \"30\"}";

            SlotDTO result = invokeMethod(prepareBookedSlotsTask, "transformBookedAppointment", bookedAppointment);

            assertNotNull(result);
            assertEquals("10:00", result.getStartTime());
            assertEquals("01-01-2023'T'00:00:00", result.getDate());
        }
    }
    @Test
    void testTransformBookedAppointmentException() throws Exception {
        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString())).thenThrow(ParseException.class);

            String bookedAppointment = "{\"temp\": {\"start_time\": \"invalid\", \"start_date\": \"null\"}, \"ApptReasonId\": \"1\", \"ProviderId\": \"1\", \"LocationId\": \"1\", \"slotId\": \"1\", \"Duration\": \"30\"}";

            Exception e = assertThrows(RuntimeException.class, () -> invokeMethod(prepareBookedSlotsTask, "transformBookedAppointment", bookedAppointment));
            assertInstanceOf(RuntimeException.class, e);
        }
    }

    @Test
    void setAppointmentId_withMatchingIdType_setsSlotId() {
        JSONArray appointmentArray = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointment.put(ID_TYPE, "matchingIdType");
        appointment.put(ID, "appointmentId");
        appointmentArray.put(appointment);

        String idTypeValue = "matchingIdType";
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject());

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setAppointmentId", appointmentArray, idTypeValue);

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertEquals("appointmentId", appointmentObject.getString(SLOTID));
    }

    @Test
    void setAppointmentId_withNonMatchingIdType_doesNotSetSlotId() {
        JSONArray appointmentArray = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointment.put(ID_TYPE, "nonMatchingIdType");
        appointment.put(ID, "appointmentId");
        appointmentArray.put(appointment);

        String idTypeValue = "matchingIdType";
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject());

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setAppointmentId", appointmentArray, idTypeValue);

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertFalse(appointmentObject.has(SLOTID));
    }

    @Test
    void setAppointmentId_withEmptyAppointmentArray_doesNotSetSlotId() {
        JSONArray appointmentArray = new JSONArray();
        String idTypeValue = "matchingIdType";
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject());

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setAppointmentId", appointmentArray, idTypeValue);

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertFalse(appointmentObject.has(SLOTID));
    }

    @Test
    void processBookedAppointment_iHubException_throwsRuntimeException() throws Exception {
        availabilityRequest.setIndex("1");
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "IHub error"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                invokeMethod(prepareBookedSlotsTask, "processBookedAppointment");
            });

            assertTrue(exception instanceof NullPointerException);
        }
    }

    @Test
    void processBookedAppointment_ioException_throwsRuntimeException() throws Exception {
        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.openAppointments(any(), any(), any()))
                    .thenThrow(new IOException("IO error"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                invokeMethod(prepareBookedSlotsTask, "processBookedAppointment");
            });

            assertInstanceOf(NullPointerException.class, exception);
        }
    }
    @Test
    void updateBookedApptId_withNonEmptyIdTypeArray_updatesDemographicId() {
        JSONArray idTypeArray = new JSONArray();
        JSONObject idTypeObject = new JSONObject();
        idTypeObject.put("IdType", "idTypeValue");
        idTypeObject.put("Id","id");
        idTypeArray.put(idTypeObject);

        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject().put("IdType", idTypeArray));

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "updateBookedApptId", "idTypeValue", "appointmentId", "IdType");

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertEquals(getValue(appointmentObject, "appointmentId").toString(), "id");
    }

    @Test
    void updateBookedApptId_withEmptyIdTypeArray_doesNotUpdateDemographicId() {
        JSONArray idTypeArray = new JSONArray();
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject().put("idType", idTypeArray));

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "updateBookedApptId", "idTypeValue", "appointmentId", "idType");

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertFalse(appointmentObject.has("appointmentId"));
    }

    @Test
    void updateBookedApptId_withNullIdTypeArray_throwsJSONException() {
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject());

        assertThrows(org.json.JSONException.class, () -> {
            ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "updateBookedApptId", "idTypeValue", "appointmentId", "idType");
        });
    }
    @Test
    void setIdIfTypeNotMatch_withLocationIdNotPresent_setsLocationId() {
        JSONObject appointmentObject = new JSONObject();
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", appointmentObject);

        JSONObject tempObject = new JSONObject();
        tempObject.put(ID, "locationIdValue");

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setIdIfTypeNotMatch", "appointmentId", "idType", tempObject);

        assertEquals("locationIdValue", appointmentObject.getString("appointmentId"));
    }

    @Test
    void setIdIfTypeNotMatch_withLocationIdPresent_doesNotSetLocationId() {
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("LocationId", "existingLocationId");
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", appointmentObject);

        JSONObject tempObject = new JSONObject();
        tempObject.put(ID, "locationIdValue");

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setIdIfTypeNotMatch", "appointmentId", "idType", tempObject);

        assertFalse(appointmentObject.has("appointmentId"));
    }

    @Test
    void setIdIfTypeNotMatch_accumulatesIdTypeWithNull() {
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put(ID_TYPE, JSONObject.NULL);
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", appointmentObject);

        JSONObject tempObject = new JSONObject();
        tempObject.put(ID, "locationIdValue");
        tempObject.put(ID_TYPE, "idTypeValue");

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setIdIfTypeNotMatch", "appointmentId", "idType", tempObject);

        assertTrue(appointmentObject.has("IdType"));
    }
    @Test
    void setDemographicId_withMatchingIdType_setsDemographicId() {
        JSONArray demographicArray = new JSONArray();
        JSONObject demographic = new JSONObject();
        demographic.put(ID_TYPE, "matchingIdType");
        demographic.put(ID, "demographicId");
        demographicArray.put(demographic);

        DemographicsData demographicObject = new DemographicsData("demogIdType", "matchingIdType");
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject());

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setDemographicId", demographicArray, demographicObject);

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertEquals("demographicId", appointmentObject.getString("demogIdType"));
    }


    @Test
    void getDemographicObject_returnsDemographicsData() {
        DemographicsData result = ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "getDemographicObject", "idTypeValue", "demographicIdType");
        assertNotNull(result);
        assertEquals("demographicIdType", result.getIdTypeValue());
        assertEquals("idTypeValue", result.getDemogIdType());
    }

    @Test
    void setDemographicId_withNonMatchingIdType_doesNotSetDemographicId() {
        JSONArray demographicArray = new JSONArray();
        JSONObject demographic = new JSONObject();
        demographic.put(ID_TYPE, "nonMatchingIdType");
        demographic.put(ID, "demographicId");
        demographicArray.put(demographic);

        DemographicsData demographicObject = new DemographicsData("matchingIdType", "demogIdType");
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject());

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setDemographicId", demographicArray, demographicObject);

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertFalse(appointmentObject.has("demogIdType"));
    }

    @Test
    void setDemographicId_withEmptyDemographicArray_doesNotSetDemographicId() {
        JSONArray demographicArray = new JSONArray();
        DemographicsData demographicObject = new DemographicsData("matchingIdType", "demogIdType");
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "appointmentObject", new JSONObject());

        ReflectionTestUtils.invokeMethod(prepareBookedSlotsTask, "setDemographicId", demographicArray, demographicObject);

        JSONObject appointmentObject = (JSONObject) ReflectionTestUtils.getField(prepareBookedSlotsTask, "appointmentObject");
        assertFalse(appointmentObject.has("demogIdType"));
    }

}