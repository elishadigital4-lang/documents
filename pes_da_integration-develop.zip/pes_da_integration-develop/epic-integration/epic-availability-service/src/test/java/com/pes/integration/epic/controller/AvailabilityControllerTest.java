package com.pes.integration.epic.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.utils.MetricsUtil;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AvailabilityControllerTest {
        private RealTimeRequest realTimeRequest;
        private JSONObject mockResponse;

        @Mock
        private AppointmentService openAppointmentService;

        @InjectMocks
        private AvailabilityController availabilityController;

        @BeforeEach
        void setUp() {
            MockitoAnnotations.openMocks(this);
            realTimeRequest = new RealTimeRequest();
            realTimeRequest.setMessageControlId("testMessageControlId");
            realTimeRequest.setEntityId("testEntityId");
            realTimeRequest.setReasonId("testReasonId");
            realTimeRequest.setFlow("testFlow");
            realTimeRequest.setDeploymentId("testDeploymentId");
            realTimeRequest.setEntityType("testEntityType");
            realTimeRequest.setStartDate("2024-08-20");
            realTimeRequest.setEndDate("2024-08-26");

            mockResponse = new JSONObject();
            mockResponse.put("key", "value");
        }

        @Test
        void getRealTimeData_withValidRequest_callsGetRealTimeAvailability() throws JsonProcessingException {
            when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class))).thenReturn(mockResponse);
            try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

                metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeRequestCountWithDeploymentId(anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
                availabilityController.getRealTimeData(realTimeRequest);
                verify(openAppointmentService, times(1)).getRealTimeAvailability(realTimeRequest);
            }
    }

//        @Test
//        void getRealTimeData_withInvalidRequest_throwsJsonProcessingException(){
//            when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class))).thenThrow(JsonProcessingException.class);
//            assertThrows(JsonProcessingException.class, () -> availabilityController.getRealTimeData(realTimeRequest));
//        }

    @Test
    void getRealTimeData_withInvalidRequest_throwsRuntimeException() {
        when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class))).thenThrow(RuntimeException.class);
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {

            metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeRequestCountWithDeploymentId(anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);

            assertThrows(RuntimeException.class, () -> availabilityController.getRealTimeData(realTimeRequest));
        }
    }
}
