package com.pes.integration.epic.task;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.util.EpicUtil;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.MetricsUtil;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;


import java.io.IOException;
import java.text.ParseException;

import static com.pes.integration.constant.DocASAPConstants.Key.CAN_COMBINE;
import static com.pes.integration.constant.EpmConstant.DATE;
import static com.pes.integration.constant.EpmConstant.START_TIME_VAL;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RealTimeOpenSlotsTaskTest {

    private RealTimeOpenSlotsTask realTimeOpenSlotsTask;
    private EpicApiCaller epicApiCaller;
    private DataCacheManager dataCacheManager;
    private JSONObject inputObject;
    private RealTimeRequest realTimeRequest;
    private String engineName = "epic";
    private String appDescription = "Epic Availability Integration";

    @BeforeEach
    void setUp() throws Exception {
        epicApiCaller = mock(EpicApiCaller.class);
        dataCacheManager = mock(DataCacheManager.class);
        inputObject = new JSONObject();
        inputObject.put("startDate", "2023-01-01");
        inputObject.put("endDate", "2023-01-31");
        inputObject.put("provider", "providerId");
        inputObject.put("reason", "reasonId");
        realTimeRequest = new RealTimeRequest();

        when(dataCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), eq(false))).thenReturn("0");

        realTimeOpenSlotsTask = new RealTimeOpenSlotsTask(epicApiCaller, inputObject, "Agent_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
    }

    @Test
    void get_validResponse_returnsOpenAppointments() throws Exception {
        JSONObject mockResponse = new JSONObject();
        mockResponse.put("OpenAppointments", new JSONArray());
        try (MockedStatic<RealTimeOpenSlotsTask> mockedStatic = Mockito.mockStatic(RealTimeOpenSlotsTask.class)) {
            mockedStatic.when(() -> RealTimeOpenSlotsTask.getRealTimeAppointments(any(), any(), any(), anyString()))
                    .thenReturn(mockResponse);

            JSONArray result = realTimeOpenSlotsTask.get();

            assertNotNull(result);
            assertEquals(0, result.length());
        }
    }

    @Test
    void get_invalidIdException_logsErrorAndThrowsEpmApiCallerException() throws Exception {
        try (MockedStatic<RealTimeOpenSlotsTask> mockedStatic = Mockito.mockStatic(RealTimeOpenSlotsTask.class)) {
            mockedStatic.when(() -> RealTimeOpenSlotsTask.getRealTimeAppointments(any(), any(), any(), anyString()))
                    .thenThrow(new InvalidIdException("Invalid ID"));
            try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
                metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(),
                        anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
                EpmApiCallerException exception = assertThrows(EpmApiCallerException.class, () -> {
                    realTimeOpenSlotsTask.get();
                });


                assertTrue(exception.getMessage().contains("Error in processing the data for open appointment slot"));
            }
        }
    }
    @Test
    void getRealTimeAppointments_agentFlow_returnsTransformedDates() throws Exception {
        RealTimeRequest request = mock(RealTimeRequest.class);
        EpicApiCaller epicApiCaller = mock(EpicApiCaller.class);
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-31");
        String flow = "Agent_Flow";

        when(request.getDeploymentId()).thenReturn("deploymentId");
        when(epicApiCaller.callUpdatedInput(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(new JSONObject());

        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat("2023-01-01", "yyyy-MM-dd", "MM/dd/yyyy"))
                    .thenReturn("01/01/2023");
            mockedStatic.when(() -> DateUtils.convertDateFormat("2023-01-31", "yyyy-MM-dd", "MM/dd/yyyy"))
                    .thenReturn("01/31/2023");

            JSONObject result = RealTimeOpenSlotsTask.getRealTimeAppointments(request, epicApiCaller, inputParam, flow);

            assertEquals("01/01/2023", inputParam.getString("startDate"));
            assertEquals("01/31/2023", inputParam.getString("endDate"));
            assertNotNull(result);
        }
    }

    @Test
    void getRealTimeAppointments_patientFlow_returnsResponseObject() throws Exception {
        RealTimeRequest request = mock(RealTimeRequest.class);
        EpicApiCaller epicApiCaller = mock(EpicApiCaller.class);
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-31");
        String flow = "Patient_Flow";

        when(request.getDeploymentId()).thenReturn("deploymentId");
        when(epicApiCaller.callUpdatedInput(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(new JSONObject());

        JSONObject result = RealTimeOpenSlotsTask.getRealTimeAppointments(request, epicApiCaller, inputParam, flow);

        assertNotNull(result);
    }


    @Test
    void getRealTimeAppointments_parseException_throwsException() throws Exception {
        RealTimeRequest request = mock(RealTimeRequest.class);
        EpicApiCaller epicApiCaller = mock(EpicApiCaller.class);
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-31");
        String flow = "Agent_Flow";

        lenient().when(request.getDeploymentId()).thenReturn("deploymentId");


        try (MockedStatic<DateUtils> mockedStatic = Mockito.mockStatic(DateUtils.class)) {
            mockedStatic.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenThrow(new ParseException("Invalid date format", 0));

            assertThrows(ParseException.class, () -> {
                RealTimeOpenSlotsTask.getRealTimeAppointments(request, epicApiCaller, inputParam, flow);
            });
        }
    }

    @Test
    void get_epmApiCallerException_logsErrorAndThrowsEpmApiCallerException() throws Exception {
        try (MockedStatic<RealTimeOpenSlotsTask> mockedStatic = Mockito.mockStatic(RealTimeOpenSlotsTask.class)) {
            mockedStatic.when(() -> RealTimeOpenSlotsTask.getRealTimeAppointments(any(), any(), any(), anyString()))
                    .thenThrow(new EpmApiCallerException("API call failed"));
            try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
                metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(),
                        anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
                EpmApiCallerException exception = assertThrows(EpmApiCallerException.class, () -> {
                    realTimeOpenSlotsTask.get();
                });

                assertTrue(exception.getMessage().contains("Error in processing the data for open appointment slot"));
            }
        }
    }

    @Test
    void get_invalidResourceException_logsErrorAndContinues() throws Exception {
        try (MockedStatic<RealTimeOpenSlotsTask> mockedStatic = Mockito.mockStatic(RealTimeOpenSlotsTask.class)) {
            mockedStatic.when(() -> RealTimeOpenSlotsTask.getRealTimeAppointments(any(), any(), any(), anyString()))
                    .thenThrow(new InvalidResourceException("Invalid resource"));
            try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
                metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeErrorCountWithDeploymentId(anyString(),
                        anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
                JSONArray result = realTimeOpenSlotsTask.get();
                assertNotNull(result);
                assertEquals(0, result.length());
            }
        }
    }

    @Test
    void get_parseException_throwsRuntimeException() throws Exception {
        try (MockedStatic<RealTimeOpenSlotsTask> mockedStatic = Mockito.mockStatic(RealTimeOpenSlotsTask.class)) {
            mockedStatic.when(() -> RealTimeOpenSlotsTask.getRealTimeAppointments(any(), any(), any(), anyString()))
                    .thenThrow(new ParseException("Invalid date format", 0));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                realTimeOpenSlotsTask.get();
            });

            assertTrue(exception instanceof Exception);
        }
    }

    @Test
    void get_iHubException_throwsRuntimeException() throws Exception {
        try (MockedStatic<RealTimeOpenSlotsTask> mockedStatic = Mockito.mockStatic(RealTimeOpenSlotsTask.class)) {
            mockedStatic.when(() -> RealTimeOpenSlotsTask.getRealTimeAppointments(any(), any(), any(), anyString()))
                    .thenThrow(new IHubException(ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "IHub error"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                realTimeOpenSlotsTask.get();
            });

            assertTrue(exception instanceof Exception);
        }
    }

    @Test
    void get_ioException_throwsRuntimeException() throws Exception {
        try (MockedStatic<RealTimeOpenSlotsTask> mockedStatic = Mockito.mockStatic(RealTimeOpenSlotsTask.class)) {
            mockedStatic.when(() -> RealTimeOpenSlotsTask.getRealTimeAppointments(any(), any(), any(), anyString()))
                    .thenThrow(new IOException("IO error"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                realTimeOpenSlotsTask.get();
            });

            assertTrue(exception instanceof Exception);
        }
    }
    @Test
    void getRealTimeAppointments_nonEmptyResponseWithTimezone_returnsExtractedOpenSlots() throws Exception {
        RealTimeRequest request = mock(RealTimeRequest.class);
        EpicApiCaller epicApiCaller = mock(EpicApiCaller.class);
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-31");
        String flow = "Patient_Flow";

        when(request.getDeploymentId()).thenReturn("deploymentId");
        JSONObject responseObject = new JSONObject();
        responseObject.put("Timezone", "UTC");
        when(epicApiCaller.callUpdatedInput(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(responseObject);

        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.extractOpenSlotsFromResponse(any(), anyString(), anyInt(), anyString(), anyString(),anyString()))
                    .thenReturn(new JSONArray());

            JSONObject result = RealTimeOpenSlotsTask.getRealTimeAppointments(request, epicApiCaller, inputParam, flow);

            assertNotNull(result);
            assertEquals("UTC", result.getString("Timezone"));
        }
    }

    @Test
    void getRealTimeAppointments_nonEmptyResponseWithoutTimezone_returnsExtractedOpenSlots() throws Exception {
        RealTimeRequest request = mock(RealTimeRequest.class);
        EpicApiCaller epicApiCaller = mock(EpicApiCaller.class);
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-31");
        String flow = "Patient_Flow";

        when(request.getDeploymentId()).thenReturn("deploymentId");
        JSONObject responseObject = new JSONObject();
        when(epicApiCaller.callUpdatedInput(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(responseObject);

        try (MockedStatic<EpicUtil> mockedStatic = Mockito.mockStatic(EpicUtil.class)) {
            mockedStatic.when(() -> EpicUtil.extractOpenSlotsFromResponse(any(), anyString(), anyInt(), anyString(), anyString(),anyString()))
                    .thenReturn(new JSONArray());

            JSONObject result = RealTimeOpenSlotsTask.getRealTimeAppointments(request, epicApiCaller, inputParam, flow);

            assertNotNull(result);
            assertFalse(result.has("Timezone"));
        }
    }

    @Test
    void get_validResponseForAgentFlow_returnsOpenAppointments() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2024-02-25");
        inputParam.put("endDate", "2024-02-31");
        inputParam.put("provider", "xyz");
        realTimeRequest.setDeploymentId("74247^0001");
        when(dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false)).thenReturn("1");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Agent_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        appointmentsArray.put(new JSONObject().put("StartTime", "10:00 AM").put("LocationId", "1").put("ApptReasonId", "reason").put("Date", "10/01/2024").put("Duration", "30"));
        responseObject.put("OpenAppointments", appointmentsArray);
        when(epicApiCaller.callUpdatedInput(realTimeRequest.getDeploymentId(), "real_time_app_patient", inputParam,"real_time_app_patient"))
                .thenReturn(responseObject);

        JSONArray result = task.get();

        assertNotNull(result);
        assertEquals(1, result.length());
        assertEquals(result.getJSONObject(0).getString("date"), "2024-10-01T00:00:00");
        assertEquals(result.getJSONObject(0).getString("startTime"), "1000");
    }
    @Test
    void get_validResponseForAgentFlow_returnsOpenAppointments12PMTime() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2024-02-25");
        inputParam.put("endDate", "2024-02-31");
        inputParam.put("provider", "xyz");
        realTimeRequest.setDeploymentId("74247^0001");
        when(dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false)).thenReturn("1");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Agent_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        appointmentsArray.put(new JSONObject().put("StartTime", "12:00 PM").put("LocationId", "1").put("ApptReasonId", "reason").put("Date", "10/01/2024").put("Duration", "30"));
        responseObject.put("OpenAppointments", appointmentsArray);
        when(epicApiCaller.callUpdatedInput(realTimeRequest.getDeploymentId(), "real_time_app_patient", inputParam,"real_time_app_patient"))
                .thenReturn(responseObject);

        JSONArray result = task.get();

        assertNotNull(result);
        assertEquals(1, result.length());
        assertEquals(result.getJSONObject(0).getString("date"), "2024-10-01T00:00:00");
        assertEquals(result.getJSONObject(0).getString("startTime"), "1200");
    }
    @Test
    void get_validResponseForAgentFlow_returnsOpenAppointmentsOtherPMTime() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2024-02-25");
        inputParam.put("endDate", "2024-02-31");
        inputParam.put("provider", "xyz");
        realTimeRequest.setDeploymentId("74247^0001");
        when(dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false)).thenReturn("1");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Agent_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        appointmentsArray.put(new JSONObject().put("StartTime", "11:40 PM").put("LocationId", "1").put("ApptReasonId", "reason").put("Date", "10/01/2024").put("Duration", "30"));
        responseObject.put("OpenAppointments", appointmentsArray);
        when(epicApiCaller.callUpdatedInput(realTimeRequest.getDeploymentId(), "real_time_app_patient", inputParam,"real_time_app_patient"))
                .thenReturn(responseObject);

        JSONArray result = task.get();

        assertNotNull(result);
        assertEquals(1, result.length());
        assertEquals(result.getJSONObject(0).getString("date"), "2024-10-01T00:00:00");
        assertEquals(result.getJSONObject(0).getString("startTime"), "2340");
    }
    @Test
    void get_validResponseForPatientFlow_ExtReasonId() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2024-02-25");
        inputParam.put("endDate", "2024-02-31");
        inputParam.put("provider", "xyz");
        inputParam.put("reason", "visit1");
        realTimeRequest.setDeploymentId("74247^0001");
        when(dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false)).thenReturn("1");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Patient_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONArray timeArray = new JSONArray();
        JSONObject timeObject = new JSONObject();
        timeObject.put(START_TIME_VAL, "10:00:00");
        timeObject.put(DATE, "2023-01-01T00:00:00.000Z");
        timeArray.put(timeObject);
        appointmentsArray.put(new JSONObject().put("StartTime", "12:00 PM").put("LocationId", "1").put("ApptReasonId", "visit").put("Date", "10/01/2024").put("Duration", "30").put("Time", timeArray));


        responseObject.put("OpenAppointments", appointmentsArray);
        responseObject.put("Timezone", "UTC");
        when(epicApiCaller.callUpdatedInput(realTimeRequest.getDeploymentId(), "real_time_appointments", inputParam,"real_time_appointments"))
                .thenReturn(responseObject);

        JSONArray result = task.get();

        assertNotNull(result);
        assertEquals(0, result.length());
    }
    //    @Test
//    void get_validResponseForPatientFlow_returnsOpenAppointments12PMTime() throws Exception {
//        JSONObject inputParam = new JSONObject();
//        inputParam.put("startDate", "2024-02-25");
//        inputParam.put("endDate", "2024-02-31");
//        inputParam.put("provider", "xyz");
//        inputParam.put("reason", "visit");
//        realTimeRequest.setDeploymentId("74247^0001");
//        when(dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false)).thenReturn("1");
//        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Patient_Flow", realTimeRequest, dataCacheManager);
//        JSONObject responseObject = new JSONObject();
//        JSONArray appointmentsArray = new JSONArray();
//        JSONArray timeArray = new JSONArray();
//        JSONObject timeObject = new JSONObject();
//        timeObject.put(START_TIME_VAL, "10:00:00");
//        timeObject.put(DATE, "2023-01-01T00:00:00.000Z");
//        timeArray.put(timeObject);
//        appointmentsArray.put(new JSONObject().put("StartTime", "12:00 PM").put("LocationId", "1").put("ApptReasonId", "visit").put("ProviderId", "visit").put("Date", "2024-01-10").put("Duration", "30").put("Time", timeArray));
//
//
//        responseObject.put("OpenAppointments", appointmentsArray);
//        responseObject.put("Timezone", "UTC");
////        when(epicApiCaller.callUpdatedInput(realTimeRequest.getDeploymentId(), "real_time_appointments", inputParam,"real_time_appointments"))
////                .thenReturn(responseObject);
//
//        JSONArray result = task.get();
//
//        assertNotNull(result);
//        assertEquals(1, result.length());
//        assertEquals(result.getJSONObject(0).getString("date"), "2024-01-10T00:00:00");
//        assertEquals(result.getJSONObject(0).getString("startTime"), "1000");
//    }
    @Test
    void get_PatientFlow_returnsOpenAppointmentsParsing() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2024-02-25");
        inputParam.put("endDate", "2024-02-31");
        inputParam.put("provider", "xyz");
        inputParam.put("reason", "visit");
        realTimeRequest.setDeploymentId("74247^0001");
        when(dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false)).thenReturn("1");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Patient_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONArray timeArray = new JSONArray();
        JSONObject timeObject = new JSONObject();
        timeObject.put(START_TIME_VAL, "10:00:00");
        timeObject.put(DATE, "2023-01-01T00:00:00.000Z");
        timeArray.put(timeObject);
        appointmentsArray.put(new JSONObject().put("StartTime", "12:00 PM").put("LocationId", "1").put("ApptReasonId", "visit").put("Date", "10/01/2024").put("Duration", "30").put("Time", timeArray));


        responseObject.put("OpenAppointments", appointmentsArray);
        responseObject.put("Timezone", "UTC");
        when(epicApiCaller.callUpdatedInput(realTimeRequest.getDeploymentId(), "real_time_appointments", inputParam,"real_time_appointments"))
                .thenReturn(responseObject);

        Exception e = assertThrows(RuntimeException.class, () -> task.get());
        assertInstanceOf(RuntimeException.class, e);
    }
    @Test
    void get_emptyResponseForPatientFlow_returnsEmptyArray() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-31");
        inputParam.put("provider", "xyz");
        inputParam.put("reason", "visit");
        realTimeRequest.setDeploymentId("74247^0001");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Patient_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        when(epicApiCaller.callUpdatedInput(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(responseObject);

        JSONArray result = task.get();

        assertNotNull(result);
        assertEquals(0, result.length());
    }
    @Test
    void get_emptyResponseForAgentFlow_returnsEmptyArray() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-31");
        inputParam.put("provider", "xyz");
        inputParam.put("reason", "visit");
        realTimeRequest.setDeploymentId("74247^0001");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Agent_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        when(epicApiCaller.callUpdatedInput(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(responseObject);

        JSONArray result = task.get();

        assertNotNull(result);
        assertEquals(0, result.length());
    }
    @Test
    void get_nonEmptyResponseWithoutTimezoneForPatientFlow_returnsExtractedOpenSlots() throws Exception {
        JSONObject inputParam = new JSONObject();
        inputParam.put("startDate", "2024-02-25");
        inputParam.put("endDate", "2024-02-31");
        inputParam.put("provider", "xyz");
        inputParam.put("reason", "visit1");
        realTimeRequest.setDeploymentId("74247^0001");
        when(dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false)).thenReturn("1");
        RealTimeOpenSlotsTask task = new RealTimeOpenSlotsTask(epicApiCaller, inputParam, "Patient_Flow", realTimeRequest, dataCacheManager,engineName,appDescription);
        JSONObject responseObject = new JSONObject();
        JSONArray appointmentsArray = new JSONArray();
        JSONArray timeArray = new JSONArray();
        JSONObject timeObject = new JSONObject();
        timeObject.put(START_TIME_VAL, "10:00:00");
        timeObject.put(DATE, "2023-01-01T00:00:00.000Z");
        timeArray.put(timeObject);
        appointmentsArray.put(new JSONObject().put("StartTime", "12:00 PM").put("LocationId", "1").put("ApptReasonId", "visit").put("Date", "10/01/2024").put("Duration", "30").put("Time", timeArray));


        responseObject.put("OpenAppointments", appointmentsArray);
        when(epicApiCaller.callUpdatedInput(realTimeRequest.getDeploymentId(), "real_time_appointments", inputParam,"real_time_appointments"))
                .thenReturn(responseObject);

        JSONArray result = task.get();

        assertNotNull(result);
        assertEquals(0, result.length());
    }

}