package com.pes.integration.epic.consumer.Open;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.adapter.Utils;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.epic.constant.EpicEngineConstants;
import com.pes.integration.epic.consumer.OpenAppointmentConsumer;
import com.pes.integration.repository.RedisRepository;
import com.pes.integration.service.AppointmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;

import static com.pes.integration.adapter.Utils.isTerminatedBaseline;
import static com.pes.integration.constant.EpmConstant.TERMINATE_HASH_KEY;
import static com.pes.integration.constant.EpmConstant.TERMINATE_KEY_PREFIX;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class OpenAppointmentConsumerTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private RedisRepository terminateBaselineRepository;

    @Mock
    private EventTracker trackEvents;
    @Mock
    private Utils utils;
    @Mock
    private AppointmentService openAppointmentService;

    @InjectMocks
    private OpenAppointmentConsumer openAppointmentConsumer;

    @Value("${application.queue.openAppt.process}")
    private String queue;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testConsume_Success() throws Exception {
        String request = "{\"messageControlId\":\"12345\"}";
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("-1");

        when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);
        when(terminateBaselineRepository.findCacheById("terminateFlowCache", "terminated-msid-", "12345")).thenReturn("true");
        openAppointmentConsumer.consume(request);
    }
    @Test
    void testConsume_whenIsTerminatedBaselineIsFalse_thenValidateInputAndGetAppointmentsAreCalled() throws Exception {
        String request = "{\"messageControlId\":\"12345\"}";
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setStartDate("2024-09-25");
        availabilityRequest.setEndDate("2024-10-25");
        when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);
        when(terminateBaselineRepository.findCacheById(TERMINATE_HASH_KEY, TERMINATE_KEY_PREFIX,
                availabilityRequest.getMessageControlId())).thenReturn(null);
        boolean result = utils.isTerminatedBaseline(terminateBaselineRepository, trackEvents, availabilityRequest);
        openAppointmentConsumer.consume(request);
        assertFalse(result);
    }
    

    @Test
    void testConsume_GeneralException() throws Exception {
        String request = "{\"messageControlId\":\"12345\"}";
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("-1");

        when(objectMapper.readValue(request, AvailabilityRequest.class)).thenReturn(availabilityRequest);

        openAppointmentConsumer.consume(request);
    }
    @Test
    void consume_withJsonProcessingException_logsErrorAndTracksError() throws Exception {
        String request = "{\"messageControlId\":\"12345\"}";
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        JsonProcessingException jpe = new JsonProcessingException("sampleError") {};

        when(objectMapper.readValue(request, AvailabilityRequest.class)).thenThrow(jpe);
        try (MockedStatic<Utils> utilities = Mockito.mockStatic(Utils.class)) {
            openAppointmentConsumer.consume(request);

            ArgumentCaptor<AvailabilityRequest> requestCaptor = ArgumentCaptor.forClass(AvailabilityRequest.class);
            ArgumentCaptor<String> messageCaptor = ArgumentCaptor.forClass(String.class);

            utilities.verify(() -> Utils.trackOpenSliceError(requestCaptor.capture(), eq(trackEvents), messageCaptor.capture()));

            assertTrue(messageCaptor.getValue().contains("Error while parsing the request"));
            assertTrue(messageCaptor.getValue().contains("sampleError"));
        }
    }
}