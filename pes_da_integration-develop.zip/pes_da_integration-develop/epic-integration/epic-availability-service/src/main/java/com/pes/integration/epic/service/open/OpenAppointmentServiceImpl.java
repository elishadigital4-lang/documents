package com.pes.integration.epic.service.open;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.constant.EpicConstants;
import com.pes.integration.epic.constant.EpicEngineConstants;
import com.pes.integration.epic.task.PrepareOpenSlotsTask;
import com.pes.integration.epic.task.RealTimeOpenSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.DATE_FORMAT;
import static com.pes.integration.constant.EpmConstant.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.FILTER_DATA;
import static com.pes.integration.constant.EpmConstant.LOCATION_ID;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.constant.UtilitiesConstants.FILTER_CONFIG;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPIC_CONFIG;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.utils.DateUtils.*;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeErrorCountWithDeploymentId;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.Math.ceil;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.util.Objects.nonNull;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static javax.swing.UIManager.put;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;

@Slf4j
@Service
@Qualifier(OPEN_APPOINTMENT)
public class OpenAppointmentServiceImpl extends AppointmentService {

    public static final String REAL_TIME_AVAILABILITY = "realTimeAvailability- ";
    public static final String CONFIG_ERROR = "Error in getting config";

    @Value("#{${configuration.api.datediff}}")
    private int datediff;

    @Value("#{${configuration.api.threadsize}}")
    private int threadSize;


    @Autowired
    private EventTracker trackEvents;

    @Autowired
    private EpicApiCaller epicApiCaller;

    @Value("${application.data.path}")
    private String dataLocation;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;


    @Autowired
    private FileUploader fileUploader;

    @Autowired
    DataCacheManager dataCacheManager;
    @Autowired
    IHubDataServiceDelegator iHubDataServiceDelegator;


    @Override
    public JSONArray getAvailability(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap, String epmPrefix)
            throws JsonProcessingException, IHubException {
        String startDate = availabilityRequest.getStartDate();
        String endDate = availabilityRequest.getEndDate();
        if (availabilityRequest.getIndex().equals(valueOf(FIRST_INDEX))) {
            trackEvents.trackEvent(availabilityRequest, OPEN_APPOINTMENT_PROCESSING_STARTED,
                    format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
                    getFragmentsDetails(availabilityRequest, providerLocationMap));
        }
        return fetchOpenAppointments(startDate, endDate, providerLocationMap,
                availabilityRequest,epmPrefix);
    }

    public JSONArray fetchOpenAppointments(String startDate, String endDate, Map<String,
            JSONArray> providerLocationMap, AvailabilityRequest availabilityRequest,String epmPrefix) throws IHubException {
        String nextDate = null;
        JSONArray openAppointmentsArray = new JSONArray();
        for (; getDateDiff(startDate, endDate, DATE_FORMAT) >= 0; startDate = nextDate) {
            int dateDiff = getTimeDiffInDays(startDate, endDate, DATE_FORMAT);
            nextDate = dateDiff > datediff ? getNextDate(startDate, DATE_FORMAT, 30) : endDate;
            openAppointmentsArray.putAll(getAvailabilityOverDays(epicApiCaller, startDate, nextDate,
                    providerLocationMap, availabilityRequest, epmPrefix));
            nextDate = getNextDate(nextDate, DATE_FORMAT);
        }

        return openAppointmentsArray;
    }
    private JSONArray getAvailabilityOverDays(EpicApiCaller epicApiCaller, String startDate,
                                              String endDate, Map<String, JSONArray> providerLocationMap,
                                              AvailabilityRequest availabilityRequest, String epmPrefix) throws IHubException {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray providerList = new JSONArray();
        String maxPoolSize;
        if (nonNull(availabilityRequest.getEntityId())) {
            JSONArray providers = new JSONArray(availabilityRequest.getEntityId().toString());
            providerList.putAll(providers);
            maxPoolSize = valueOf(ONE);
        } else {
            providerList = providerLocationMap.get(PROVIDER_ID_LIST);
            String configuredPoolSize = dataCacheManager.getConfiguration(epmPrefix, availabilityRequest.getDeploymentId(), EPIC_CONFIG, MAX_POOL_SIZE);
            maxPoolSize = !isEmpty(configuredPoolSize) ? configuredPoolSize : String.valueOf(threadSize);
        }
        String providerIdType = dataCacheManager.getConfiguration(epmPrefix, availabilityRequest.getDeploymentId(), EPIC_CONFIG, PROVIDER_ID_TYPE_ID);
        ExecutorService executorService = newFixedThreadPool(parseInt(maxPoolSize));
        List<CompletableFuture<Void>> openApptFutureList = new ArrayList<>();
        try {
            providerList.forEach(provider -> {
                JSONObject inputObject = getInputObject(startDate, endDate, providerIdType, provider);
                try {
                    openApptFutureList.add(CompletableFuture.supplyAsync(
                            new PrepareOpenSlotsTask(epicApiCaller, inputObject, fileUploader, trackEvents,
                                    availabilityRequest, epmPrefix,dataCacheManager),
                            executorService));
                } catch (IHubException e) {
                    throw new RuntimeException(e);
                }
            });
            CompletableFuture<Void> openApptAllFutures = CompletableFuture
                    .allOf(openApptFutureList.toArray(new CompletableFuture[openApptFutureList.size()]));

            CompletableFuture<List<Void>> openApptAllCompletableFuture =
                    openApptAllFutures.thenApply(future -> openApptFutureList.stream()
                            .map(CompletableFuture<Void>::join).collect(Collectors.toList()));

            CompletableFuture<List<Void>> openApptCompletableFuture =
                    openApptAllCompletableFuture.toCompletableFuture();

            openApptCompletableFuture.get();
        } catch (ExecutionException ee) {
            Thread.currentThread().interrupt();
            log.error("Error in getting the slotId " + ee);
            throw new EpmApiCallerException("Error in getting the slot " + ee.getMessage());
        } catch (InterruptedException ie) {
            log.error("Error in getting the slotId " + ie);
        } finally {
            executorService.shutdown();
        }
        return openAppointmentsArray;
    }

    private JSONObject getInputObject(String startDate, String endDate, String providerIdType,
                                      Object provider) {
        JSONObject inputParameter = new JSONObject();
        inputParameter.put(STARTDATE, startDate);
        inputParameter.put(ENDDATE, endDate);
        inputParameter.put(PROVIDER_ID_TYPE_ID, providerIdType);
        inputParameter.put(PROVIDER, provider.toString());
        inputParameter.put(APPOINTMENT_PATH, dataLocation);
        return inputParameter;
    }

    private JSONObject getRealTimeInputObject(RealTimeRequest realTimeRequest,
                                              String deploymentId, String epmPrefix, JSONObject provLocObj) throws IHubException {
        JSONObject inputParameter = new JSONObject();
        inputParameter.put(STARTDATE, realTimeRequest.getStartDate());
        inputParameter.put(ENDDATE, realTimeRequest.getEndDate());
        inputParameter.put(PROVIDER_ID_TYPE_ID, dataCacheManager.getStoredProvidersConfig(epmPrefix, deploymentId, EPIC_CONFIG, PROVIDER_ID_TYPE_ID,false));
        inputParameter.put("locationType", dataCacheManager.getStoredProvidersConfig(epmPrefix, deploymentId, EPIC_CONFIG, ID_TYPE_VALUE,false));
        inputParameter.put("visitType", dataCacheManager.getStoredProvidersConfig(epmPrefix, deploymentId, EPIC_CONFIG, ID_TYPE_VALUE,false));
        inputParameter.put("useridtype", dataCacheManager.getStoredProvidersConfig(epmPrefix, deploymentId, EPIC_CONFIG, ID_TYPE_VALUE,false));
        inputParameter.putOpt("location", provLocObj.opt("locationId"));
        inputParameter.putOpt("reason", provLocObj.opt("reasonId"));
        inputParameter.putOpt(PROVIDER, provLocObj.opt("providerId"));
        inputParameter.put("patient",provLocObj.opt("patientId"));
        inputParameter.put(APP_ID,provLocObj.opt("appId"));
        inputParameter.put("userid", dataCacheManager.getConfiguration(epmPrefix, deploymentId, EPIC_CONFIG, "userid"));
        inputParameter.put("patientidtype", dataCacheManager.getConfiguration(epmPrefix, deploymentId, EPIC_CONFIG, "pat_id_type"));
        inputParameter.put("maxsolution", dataCacheManager.getConfiguration(epmPrefix, deploymentId, EPIC_CONFIG, "maxsolution"));
        inputParameter.put(APPOINTMENT_PATH, dataLocation);
        return inputParameter;
    }

    private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest,
                                                    Map<String, JSONArray> providerLocationMap) {
        int noOfDays = getTimeDiffInDays(availabilityRequest.getStartDate(),
                availabilityRequest.getEndDate(), DATE_FORMAT);
        Map<String, Object> providerDetails = new HashMap<>();
        String totalFragmentCall = valueOf((int) ceil(noOfDays * 1.0 / datediff)
                * (providerLocationMap.get(PROVIDER_ID_LIST).length()));
        if (Objects.nonNull(availabilityRequest.getEntityId())) {
            providerDetails.put(TOTAL_FRAGMENTS, "1");
            put(TOTAL_FRAGMENTS, "1");
        } else {
            providerDetails.put(TOTAL_FRAGMENTS, totalFragmentCall);
            put(TOTAL_FRAGMENTS, totalFragmentCall);
        }
        providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        return providerDetails;
    }

    public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest){
        JSONArray openAppointmentsArray = new JSONArray();
        String deploymentId = realTimeRequest.getDeploymentId() != null ? realTimeRequest.getDeploymentId() : EMPTY;
        String requestType = realTimeRequest.getRequestType() != null ? realTimeRequest.getRequestType() : EMPTY;
        if (nonNull(realTimeRequest.getEntityId())) {
            List<Object> list = (List<Object>) realTimeRequest.getEntityId();
            try {
                JSONArray providerLocList =
                        new JSONArray(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(list));
                providerLocList.forEach(obj -> {
                    JSONObject inputParam = setInputParam(realTimeRequest, deploymentId, requestType, obj);
                    JSONObject doc_appid_map = null;
                    try {
                        doc_appid_map = new JSONObject(dataCacheManager.getRedisConfiguration(EPM_NAME_PREFIX, realTimeRequest.getDeploymentId(),
                                EPIC_CONFIG, EpicConstants.DOCASAP_EPM_APPID_MAP).toString());
                    } catch (IHubException e) {
                        metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType, REAL_TIME_AVAILABILITY + CONFIG_ERROR);
                        throw new RuntimeException(e);
                    }
                    JSONObject epic_appid_map= null;
                    try {
                        epic_appid_map = new JSONObject(dataCacheManager.getRedisConfiguration(EPM_NAME_PREFIX, realTimeRequest.getDeploymentId(),
                                EPIC_CONFIG, EpicConstants.IHUB_EPIC_APPID_MAP).toString());
                    } catch (IHubException e) {
                        //TODO : need to review action message same in above (can we combine all in one)
                        metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType, REAL_TIME_AVAILABILITY + CONFIG_ERROR);
                        throw new RuntimeException(e);
                    }

                    agentFlow(doc_appid_map, inputParam, epic_appid_map, openAppointmentsArray, deploymentId, requestType, realTimeRequest);
                });
            } catch (JSONException | JsonProcessingException e) {
                log.error("error in getting provider/location list from request {} ", e.getMessage());
                metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType, "error in getting provider/location list from request");
                throw new EpmApiCallerException(
                        "error in getting provider/location list from request " + e.getMessage());
            }
        }
        return getOpenAppointmentObject(openAppointmentsArray, realTimeRequest);
    }

    private JSONObject setInputParam(RealTimeRequest realTimeRequest, String deploymentId, String requestType, Object obj) {
        JSONObject inputParam = null;

        try {
            inputParam = getRealTimeInputObject(realTimeRequest, realTimeRequest.getDeploymentId(), EpicEngineConstants.EPM_NAME_PREFIX, new JSONObject(obj.toString()));
        } catch (IHubException e) {
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType,REAL_TIME_AVAILABILITY + CONFIG_ERROR);
            throw new IllegalArgumentException("Error in getting setInputParam "+e.getMessage());
        }
        if (inputParam.optString(APP_ID).isEmpty()) {
            String error = "AppID can not be null";
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType, error);
            throw new EpmApiCallerException(error);
        }
        return inputParam;
    }

    private void agentFlow(JSONObject doc_appid_map, JSONObject inputParam, JSONObject epic_appid_map, JSONArray openAppointmentsArray, String deploymentId,
                           String requestType, RealTimeRequest realTimeRequest) {
        String clientId= doc_appid_map.getString(inputParam.optString(APP_ID));
        String flow = epic_appid_map.getString(clientId);
        if(flow.equals("Agent_Flow") && inputParam.optString("patient").isEmpty()) {
            String error = "Patient Id can not be null";
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType, error);
            throw new EpmApiCallerException(error);
        }
        inputParam.put("ep_clientid", clientId);

        try {
            openAppointmentsArray.putAll(
                    new RealTimeOpenSlotsTask(epicApiCaller, inputParam,flow, realTimeRequest,dataCacheManager,engineName,appDescription).get());
        } catch (IHubException e) {
            throw new IllegalArgumentException("Error in getting agentFlow "+e.getMessage());
        }
    }
}