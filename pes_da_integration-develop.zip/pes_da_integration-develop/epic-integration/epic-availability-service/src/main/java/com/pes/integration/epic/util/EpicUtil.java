package com.pes.integration.epic.util;

import com.pes.integration.component.EventTracker;
import com.pes.integration.constant.EpmConstant;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.epic.api.ApiName;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.exceptions.IHubException;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

import static com.pes.integration.constant.DocASAPConstants.Key.CAN_COMBINE;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.epic.api.ApiName.OPEN_APPOINTMENTS;
import static com.pes.integration.epic.constant.EpicConstants.PROVIDER_ID_TYPE_ID;
import static com.pes.integration.epic.constant.EpicConstants.TIME_FORMAT;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeErrorCountWithDeploymentId;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;

public class EpicUtil {
  private EpicUtil() {}
    private static String deploymentId;
    @Value("${epm.engine.name}")
    private static String engineName;
    @Value("${info.app.description}")
    private static String appDescription;

    public static void trackEventToNifi(EventTracker trackEvents,
                                      AvailabilityRequest availabilityRequest, DataflowStatus dataflowStatus, String totalFragments,
                                      String fragmentId, Map<String, Object> payload) {
    NifiTrackingEvent nifiEvent =
        getNifiEvent(availabilityRequest, dataflowStatus, totalFragments, fragmentId, payload);
    trackEvents.trackEventToNifi(nifiEvent);
  }


  public static NifiTrackingEvent getNifiEvent(AvailabilityRequest availabilityRequest,
      DataflowStatus dataflowStatus, String totalFragments, String fragmentId,
      Map<String, Object> payload) {
    return NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
        .messageControlId(availabilityRequest.getMessageControlId())
        .appointmentType(availabilityRequest.getAppointmentType())
        .sliceId(availabilityRequest.getSliceId())
        .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
        .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices()).payload(payload)
        .entityType(availabilityRequest.getEntityType()).entityId(availabilityRequest.getEntityId())
        .flow(availabilityRequest.getFlow()).build();
  }

  public static JSONObject openAppointments(String deploymentId,EpicApiCaller epicApiCaller, JSONObject inputParam)
          throws InvalidResourceException, IHubException, IOException {
    JSONObject openAppointmentRequest = getInputObject(inputParam);
    //return epicApiCaller.call(OPEN_APPOINTMENTS.getKey(), openAppointmentRequest);
      return epicApiCaller.call(deploymentId, ApiName.GET_SCHEDULE_DAYS_FOR_PROVIDER.getKey(), openAppointmentRequest, "open");
  }

  public static JSONObject getInputObject(JSONObject inputParam) {
    JSONObject openAppointmentRequest = new JSONObject();
    JSONObject providerObj = new JSONObject();

    providerObj.put("ProviderId", inputParam.getString(PROVIDER));
    providerObj.put("ProviderIdType", inputParam.getString(PROVIDER_ID_TYPE_ID));
    JSONArray providerArray = new JSONArray();
    providerArray.put(providerObj);
    JSONObject provider = new JSONObject();
    provider.put("Provider", providerArray);

    JSONObject temObj = new JSONObject();
    temObj.put("start_date", inputParam.getString(STARTDATE));
    temObj.put("end_date", inputParam.getString(ENDDATE));
    openAppointmentRequest.put("SchedulingData", provider);
    openAppointmentRequest.put("temp", temObj);
    return openAppointmentRequest;
  }


    public static JSONArray extractOpenSlotsFromResponse(JSONObject outputObject, String providerId, int canCombine,
                                                         String timezone, String extReasonId, String extLocationId) {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray appointmentsArray = outputObject.optJSONArray(EpmConstant.OPEN_APPOINTMENTS);
        if (nonNull(appointmentsArray)) {
            for (Object appointmentObject : appointmentsArray) {
                JSONObject apptObject = new JSONObject(appointmentObject.toString());
                if (!extReasonId.isEmpty() && !apptObject.opt("ApptReasonId").toString().trim().equals(extReasonId)) {
                    continue;
                }
                if(!extLocationId.isEmpty() && !apptObject.opt("LocationId").toString().trim().equals(extLocationId)){
                    continue;
                }
                processAppointment(providerId, canCombine, timezone, apptObject, openAppointmentsArray);
            }
        }
        return openAppointmentsArray;
    }

    private static void processAppointment(String providerId, int canCombine, String timezone, JSONObject apptObject, JSONArray openAppointmentsArray) {
        JSONArray timeJsonArray = apptObject.optJSONArray(TIME);
        if (nonNull(timeJsonArray)) {
            timeJsonArray
                    .forEach(timeObj -> {
                        try {
                            openAppointmentsArray.put(transformOpenAppointment((JSONObject) timeObj,
                                    apptObject, apptObject.getString(DATE), canCombine, providerId, timezone));
                        } catch (ParseException e) {
                            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription,"",
                                    "", "extractOpenSlotsFromResponse - " + e.getMessage());
                            throw new RuntimeException(e);
                        }
                    });
        }
    }


    public static JSONObject transformOpenAppointment(JSONObject timeObj,
      JSONObject appointmentObject, String date, int canCombine, String providerId, String timezone) throws ParseException {
    JSONObject openAppointment = new JSONObject();
    openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
    openAppointment.put(LOCATION_ID_KEY, appointmentObject.opt(LOCATION_ID));
    openAppointment.put(PROVIDER_ID_KEY, providerId);
    openAppointment.put(REASON_ID_KEY, appointmentObject.opt(APPTREASON_ID));
    String startTime = timeObj.getString(START_TIME_VAL);
    openAppointment.put(START_TIME,
        convertDateFormat(startTime.trim(), TIME_FORMAT, DOCASAP_TIME_FORMAT));
    openAppointment.put(DATE_KEY, convertDateFormat(date.trim(), DATE_FORMAT, DATE_TIME_FORMAT));
    openAppointment.put(CAN_COMBINE, canCombine);
    
    if(timezone!= null && (!timezone.isEmpty())) {
    	openAppointment.put("timeZone", timezone);
    	openAppointment.put("duration", EMPTY);
    }
    return openAppointment;
  }
    
    public static JSONObject transform(String time,
    	      String locationId, String reasonId, String date, String duration, int canCombine, String providerId) throws ParseException {
    	    JSONObject openAppointment = new JSONObject();
    	    openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
    	    openAppointment.put(LOCATION_ID_KEY, locationId.trim());
    	    openAppointment.put(PROVIDER_ID_KEY, providerId.trim());
    	    openAppointment.put(REASON_ID_KEY, reasonId.trim());
    	    String startTime = time.trim().split("\\s+")[0];
    	    if(time.trim().split("\\s+")[1].equals("PM") && !startTime.split(":")[0].equals("12")) {
	    	    DateTimeFormatter formatter = DateTimeFormat.forPattern(STD_TIME_FORMAT);
	            LocalTime timee = formatter.parseLocalTime(startTime);
	            timee=timee.plusHours(12);
	            String final_time=timee.toString().trim().split("\\.")[0];
	            final_time=convertDateFormat(final_time,"HH:mm:ss",STD_TIME_FORMAT);
	            startTime=final_time;
    	    }
    	    openAppointment.put(START_TIME,
    	        convertDateFormat(startTime, STD_TIME_FORMAT, DOCASAP_TIME_FORMAT));
    	    openAppointment.put(DATE_KEY, convertDateFormat(date.trim(), "MM/dd/yyyy", DATE_TIME_FORMAT));
    	    openAppointment.put(CAN_COMBINE, canCombine);
    	    openAppointment.put("duration", duration);

    return openAppointment;
  }
}
