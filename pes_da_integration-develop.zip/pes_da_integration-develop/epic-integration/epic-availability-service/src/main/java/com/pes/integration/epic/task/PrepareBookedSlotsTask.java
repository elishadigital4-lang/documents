package com.pes.integration.epic.task;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.SlotDTO;
import com.pes.integration.epic.api.ApiName;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.model.DemographicsData;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.adapter.Utils.createNifiErrorPayload;
import static com.pes.integration.adapter.Utils.getBookedDataFlowNifiStatus;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.EpmConstant.DATE_TIME_FORMAT;
import static com.pes.integration.constant.EpmConstant.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.LOCATION_ID;
import static com.pes.integration.constant.EpmConstant.MINUTES;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.constant.NumberConstants.ZERO;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.epic.constant.EpicConstants.*;
import static com.pes.integration.epic.constant.EpicConstants.APPT_REASON;
import static com.pes.integration.epic.constant.EpicConstants.LOCATIONS;
import static com.pes.integration.epic.constant.EpicConstants.USER_ID;
import static com.pes.integration.epic.constant.EpicConstants.USER_ID_TYPE;
import static com.pes.integration.epic.constant.EpicEngineConstants.*;
import static com.pes.integration.epic.util.EpicUtil.trackEventToNifi;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.DateUtils.convertTime;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext; 
import static java.lang.String.valueOf;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.compare;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class PrepareBookedSlotsTask {

    private String startDate;
    private String endDate;
    private String locations;
    private String dataLocation;
    private EventTracker trackEvents;
    private FileUploader fileUploader;
    private EpicApiCaller epicApiCaller;
    private AvailabilityRequest availabilityRequest;
    private Map<String, String> contextMap = getCopyOfContextMap();
    private JSONObject inputObject;
    private JSONObject appointmentObject;
    private DataCacheManager dataCacheManager;

    private String epmPrefix;

    private String deploymentId;

    public PrepareBookedSlotsTask(EpicApiCaller epicApiCaller, JSONObject inputObject,
                                  FileUploader fileUploader, EventTracker trackEvents, AvailabilityRequest availabilityRequest,
                                  DataCacheManager dataCacheManager) {
        this.startDate = inputObject.getString(STARTDATE);
        this.endDate = inputObject.getString(ENDDATE);
        this.locations = inputObject.getString(LOCATIONS);
        this.dataLocation = inputObject.getString(APPOINTMENT_PATH);
        this.epicApiCaller = epicApiCaller;
        this.fileUploader = fileUploader;
        this.trackEvents = trackEvents;
        this.availabilityRequest = availabilityRequest;
        this.dataCacheManager=dataCacheManager;
        this.inputObject = inputObject;
        this.epmPrefix=inputObject.optString("epmPrefix");
        this.deploymentId=inputObject.optString("deploymentId");
    }

    public void processBookedAppointment() {
        setContext(contextMap);
        Map<String, File> appointmentDataFiles = new HashMap<>();
        try {
            JSONObject bookedApptOutput = null;
            try {
                bookedApptOutput = getBookedAppointment();
            } catch (IHubException | IOException e) {
                throw new RuntimeException(e);
            }
            uploadBookedFiles(appointmentDataFiles, bookedApptOutput);
            trackEventToNifi(trackEvents, availabilityRequest,
                    getBookedDataFlowNifiStatus(availabilityRequest), valueOf(ONE), EMPTY,
                    createNifiErrorPayload(getNifiPayload()));
        } catch (InvalidResourceException exception) {
            log.error("INVALID RESOURCE");
        } finally {
            deleteFiles(appointmentDataFiles);
        }
    }

    private JSONObject getBookedAppointment() throws InvalidResourceException, IHubException, IOException {
        JSONArray bookedAppointmentsArray = new JSONArray();
        JSONObject responseObject =
                bookedAppointments(epicApiCaller, startDate, endDate, locations, availabilityRequest);
        if (nonNull(responseObject) && (!responseObject.isEmpty())) {
            bookedAppointmentsArray.putAll(extractBookedSlots(responseObject));
        }

        return getBookedAppointmentObject(bookedAppointmentsArray);

    }


    private void uploadBookedFiles(Map<String, File> appointmentDataFiles,
                                   JSONObject bookedApptOutput) {
        appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
                prepareBookedFile(bookedApptOutput, availabilityRequest));
        fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
                availabilityRequest.getAppointmentType(), availabilityRequest.getSliceId(),
                appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    }

    private JSONObject getBookedAppointmentObject(JSONArray bookedAppointmentsArray) {
        JSONObject openApptOutput = new JSONObject();
        openApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
        openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
        openApptOutput.put(TOTAL_COUNT, bookedAppointmentsArray.length());
        openApptOutput.put(DATA, bookedAppointmentsArray);
        return openApptOutput;
    }

    private File prepareBookedFile(JSONObject apptresponse, AvailabilityRequest availabilityRequest) {
        return prepareFile(apptresponse.toString(),
                dataLocation + availabilityRequest.getMessageControlId() + SLASH
                        + availabilityRequest.getSliceId(),
                SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
    }

    private JSONObject bookedAppointments(EpicApiCaller epicApiCaller, String startDate,
                                          String endDate, String locations, AvailabilityRequest availabilityRequest)
            throws InvalidResourceException, IHubException, IOException {

        JSONObject epmRequestObject = new JSONObject();
        epmRequestObject.put(START_DATE, startDate);
        epmRequestObject.put(END_DATE, endDate);
//        epmRequestObject.put(USER_ID_TYPE, configurationData.getString(ORCHARDCLIENTID_TYPE));
//        epmRequestObject.put(USER_ID, configurationData.getString(ORCHARDCLIENTID));
        epmRequestObject.put(USER_ID_TYPE, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, ORCHARDCLIENTID_TYPE));
        epmRequestObject.put(USER_ID, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, ORCHARDCLIENTID));


        JSONArray locationJsonArray = new JSONArray();
//        String idType = configurationData.getString(ID_TYPE_VALUE);
        String idType = dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, ID_TYPE_VALUE);

        new JSONArray(locations).forEach(locationId -> {
            JSONObject locationJson = new JSONObject();
            locationJson.put(LOCATION_ID, locationId);
            locationJson.put(ID_TYPE, idType);
            locationJsonArray.put(locationJson);
        });
        JsonUtils.setValue(epmRequestObject, PROVIDER_PATH, locationJsonArray);
        return epicApiCaller.call(deploymentId,ApiName.BOOKED_APPOINTMENTS.getKey(), epmRequestObject, "booked");
    }

    private JSONArray extractBookedSlots(JSONObject outputObject) {
        List<SlotDTO> res = new ArrayList<>();
        JSONArray bookedAppointmentsArray = outputObject.optJSONArray(BOOKED_APPT);
        bookedAppointmentsArray.forEach(
                bookedAppointment -> {
                    try {
                        res.add(transformBookedAppointment(bookedAppointment.toString()));
                    } catch (IHubException e) {
                        throw new RuntimeException(e);
                    }
                });
        return new JSONArray(res);
    }

    private SlotDTO transformBookedAppointment(String bookedAppointment) throws IHubException {
        appointmentObject = new JSONObject(bookedAppointment);
        prepareBookedAppointment();
        JSONObject temp = (JSONObject) appointmentObject.get(TEMP);
        String duration = appointmentObject.getString(BOOKED_APPT_DURATION);
        String reasonId = appointmentObject.getString(APPTREASON_ID);
        String providerId = appointmentObject.getString(PROVIDER_ID);
        String locationId = appointmentObject.getString(LOCATION_ID);
        String slotId = appointmentObject.getString(SLOTID);
        SlotDTO slotDto = SlotDTO.builder().slotId(slotId).duration(duration).durationUnit(MINUTES)
                .reasonId(reasonId.trim()).providerId(providerId.trim()).locationId(locationId.trim())
                .build();
        String startTime = convertTime(temp.getString(BOOKED_APPT_TIME));
        String date = null;
        try {
            date = convertDateFormat(temp.getString(BOOKED_APPT_DATE), DATE_FORMAT_MM_DD_YYYY,
                    DATE_TIME_FORMAT);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        slotDto.setStartTime(startTime);
        slotDto.setDate(date);
        return slotDto;
    }

    private void prepareBookedAppointment() throws IHubException {
//        String apptIdTypeValue = configurationData.getString(EXTERNAL_APPT_ID_TYPE_VALUE);
//        String idTypeValue = configurationData.getString(ID_TYPE_VALUE);
//        String providerIdTypeValue = configurationData.getString(PROVIDER_ID_TYPE_ID);
        String apptIdTypeValue = dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, EXTERNAL_APPT_ID_TYPE_VALUE);
        String idTypeValue = dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, ID_TYPE_VALUE);
        String providerIdTypeValue = dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), EPIC_CONFIG, PROVIDER_ID_TYPE_ID);

        if (!appointmentObject.isEmpty()) {
            JSONArray apptArray = appointmentObject.optJSONArray(EXTERNAL_APPT);
            if (!NullChecker.isEmpty(apptArray)) {
                setAppointmentId(apptArray, apptIdTypeValue);
            }
            if (appointmentObject.has(APPT_REASON)) {
                updateBookedApptId(idTypeValue, APPTREASON_ID, APPT_REASON);
            }
            if (appointmentObject.has(BOOKED_APPT_PROVIDER)) {
                updateBookedApptId(providerIdTypeValue, PROVIDER_ID, BOOKED_APPT_PROVIDER);
            }
            if (appointmentObject.has(BOOKED_APPT_LOCATION)) {
                updateBookedApptId(idTypeValue, LOCATION_ID, BOOKED_APPT_LOCATION);
            }
        }
    }
    private void setAppointmentId(JSONArray appointmentArray, String idTypeValue) {
        appointmentArray.forEach(appointment -> {
            String appointIdType = ((JSONObject) appointment).getString(ID_TYPE);
            if (compare(appointIdType, idTypeValue) == ZERO) {
                String appointmentId = ((JSONObject) appointment).getString(ID);
                appointmentObject.put(SLOTID, appointmentId);
            }
        });
        appointmentObject.accumulate(EXTERNAL_APPT, null);
    }

    private void updateBookedApptId(String idTypeValue, String appointmentId, String idType) {
        JSONArray idTypeArray = appointmentObject.getJSONArray(idType);
        if (!idTypeArray.isEmpty()) {
            Object tmplocation = idTypeArray.get(0);
            DemographicsData demographicObject = getDemographicObject(idTypeValue, appointmentId);
            setDemographicId(idTypeArray, demographicObject);
            setIdIfTypeNotMatch(appointmentId, idType, tmplocation);
        }
    }
    private void setIdIfTypeNotMatch(String id, String idType, Object tempObject) {
        if (!appointmentObject.has(LOCATION_ID)) {
            String locationId = ((JSONObject) tempObject).getString(ID);
            appointmentObject.put(id, locationId.trim());
        }
        appointmentObject.accumulate(idType, null);
    }

    private void setDemographicId(JSONArray demographicArray, DemographicsData demographicObject) {
        demographicArray.forEach(demographic -> {
            String appointmentType = ((JSONObject) demographic).getString(ID_TYPE);
            if (compare(appointmentType, demographicObject.getIdTypeValue()) == ZERO) {
                String appointmentId = ((JSONObject) demographic).getString(ID);
                appointmentObject.put(demographicObject.getDemogIdType(), appointmentId.trim());
            }
        });
    }

    private DemographicsData getDemographicObject(String idTypeValue, String demographicIdType) {
        return new DemographicsData(idTypeValue, demographicIdType);
    }
    private JSONObject getNifiPayload() {
        JSONObject nifiObject = new JSONObject();
        nifiObject.put(STARTDATE, availabilityRequest.getStartDate());
        nifiObject.put(ENDDATE, availabilityRequest.getEndDate());
        nifiObject.put(FRAGMENT_ID_KEY, EMPTY);
        return nifiObject;
    }

}
