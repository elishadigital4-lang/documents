package com.pes.integration.epic.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DemographicsData {

  private String demogIdType;
  private String idTypeValue;
}
