package com.pes.integration.epic.task;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.epic.util.EpicUtil;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;
import java.util.function.Supplier;

import static com.pes.integration.constant.DocASAPConstants.Key.CAN_COMBINE;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPIC_CONFIG;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.epic.util.EpicUtil.extractOpenSlotsFromResponse;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.MdcUtil.setContext;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeErrorCountWithDeploymentId;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.String.format;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.slf4j.MDC.getCopyOfContextMap;


@Slf4j
public class RealTimeOpenSlotsTask implements Supplier<JSONArray> {

    private static final String ERROR_PROCESSING_DATA = "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";
    private static final String REAL_TIME_OPEN_SLOTS_TASK = "RealTimeOpenSlotsTask - ";

    private String startDate;
    private String endDate;
    private String providerId;
    private int canCombine;
    private EpicApiCaller epicApiCaller;
    private JSONObject inputParam;
    private String flow;

    private String engineName;

    private String appDescription;

    private RealTimeRequest realTimeRequest;
    private Map<String, String> contextMap = getCopyOfContextMap();
    DataCacheManager dataCacheManager;

    public RealTimeOpenSlotsTask(EpicApiCaller epicApiCaller, JSONObject inputObject,
                                 String flow,  RealTimeRequest realTimeRequest, DataCacheManager dataCacheManager,String engineName,String appDescription) throws IHubException {
        this.startDate = inputObject.getString(STARTDATE);
        this.endDate = inputObject.getString(ENDDATE);
        this.providerId = inputObject.getString(PROVIDER);
        this.epicApiCaller = epicApiCaller;
        this.inputParam = inputObject;
        this.flow = flow;
        this.realTimeRequest = realTimeRequest;
        this.dataCacheManager = dataCacheManager;
        this.canCombine = parseInt((String) dataCacheManager.getStoredComponentConfig(EPM_NAME_PREFIX, GENERIC_CONFIG, CAN_COMBINE,false));
        this.engineName=engineName;
        this.appDescription=appDescription;
    }

    @Override
    public JSONArray get() {
        setContext(contextMap);
        JSONArray openAppointmentsArray = new JSONArray();
        String deploymentId = realTimeRequest.getDeploymentId() != null ? realTimeRequest.getDeploymentId() : EMPTY;
        String requestType = realTimeRequest.getRequestType() != null ? realTimeRequest.getRequestType() : EMPTY;
        try {
            JSONObject responseObject = getRealTimeAppointments(realTimeRequest,epicApiCaller, inputParam, flow);

            if (flow.equals("Patient_Flow")) {
                if (!isEmpty(responseObject)) {
                    String timezone= responseObject.optString("Timezone");
                    openAppointmentsArray.putAll(extractOpenSlotsFromResponse(responseObject, providerId, canCombine,
                            timezone, (String) inputParam.optString("reason"), inputParam.optString("location")));
                }
            }
            if (flow.equals("Agent_Flow")) {
                agentFlow(responseObject, openAppointmentsArray);
            }

        } catch (InvalidIdException ide) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ide.getMessage());
            log.error(escapeJava(exceptionDetails));
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType, REAL_TIME_OPEN_SLOTS_TASK + "Invalid Id Exception");
            throw new EpmApiCallerException(exceptionDetails);
        } catch (EpmApiCallerException ee) {
            String exceptionDetails = format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ee.getMessage());
            log.error(escapeJava(exceptionDetails));
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType, REAL_TIME_OPEN_SLOTS_TASK + "Epm Api Caller Exception");
            throw new EpmApiCallerException(exceptionDetails);
        } catch (InvalidResourceException exception) {
            log.error("Invalid Resource Exception");
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType,REAL_TIME_OPEN_SLOTS_TASK + "Invalid Resource Exception");
            exception.printStackTrace();
        } catch (ParseException e) {
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType,REAL_TIME_OPEN_SLOTS_TASK + "Parse Exception");
            throw new RuntimeException(e);
        } catch (IHubException | IOException e) {
            metricRealTimeErrorCountWithDeploymentId(engineName, appDescription, deploymentId, requestType,REAL_TIME_OPEN_SLOTS_TASK + "Error in getting real time open slots task");
            throw new RuntimeException(e);
        }
        log.info("Response received successfully from EPM");
        return openAppointmentsArray;
    }

    private void agentFlow(JSONObject responseObject, JSONArray openAppointmentsArray) throws ParseException {
        JSONArray appointmentsArray = responseObject.optJSONArray(OPEN_APPOINTMENTS);
        if (nonNull(appointmentsArray)) {
            for (Object appointmentObject : appointmentsArray) {
                JSONObject apptObject = new JSONObject(appointmentObject.toString());
                String extReasonId = (String) inputParam.optString("reason");
                if (!extReasonId.isEmpty() && !apptObject.opt("ApptReasonId").toString().trim().equals(extReasonId)) {
                    continue;
                }
                openAppointmentsArray.put(EpicUtil.transform((String) apptObject.opt("StartTime"),
                        (String) apptObject.opt("LocationId"), (String) apptObject.opt("ApptReasonId"),
                        (String) apptObject.opt("Date"), (String) apptObject.opt("Duration"), canCombine,
                        providerId));
            }
        }
    }

    public static JSONObject getRealTimeAppointments(RealTimeRequest request ,EpicApiCaller epicApiCaller, JSONObject inputParam, String flow)
            throws InvalidResourceException, ParseException, IHubException, IOException {

        JSONObject responseObject = new JSONObject();
        if (flow.equals("Agent_Flow")) {
            String start = inputParam.getString("startDate");
            String end = inputParam.getString("endDate");
            start = convertDateFormat(start, "yyyy-MM-dd", "MM/dd/yyyy");
            end = convertDateFormat(end, "yyyy-MM-dd", "MM/dd/yyyy");
            inputParam.put("startDate", start);
            inputParam.put("endDate", end);
            log.info("Request for Real Time Appointments for Agent Flow : {}", escapeJava(inputParam.toString()));
            responseObject = epicApiCaller.callUpdatedInput(request.getDeploymentId(),"real_time_app_patient", inputParam,"real_time_app_patient");
        }
        else if(flow.equals("Patient_Flow")){
            log.info("Request for Real Time Appointments for Patient Flow : {}", escapeJava(inputParam.toString()));
            responseObject = epicApiCaller.callUpdatedInput(request.getDeploymentId(),"real_time_appointments", inputParam,"real_time_appointments");
        }
        log.info("Response for Epic Real Time Appointments: {}", escapeJava(responseObject.toString()));
        Object errorMessage = getValue(responseObject, "temp.error_message");
        if(errorMessage !=null){
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), errorMessage.toString());
        }
        return responseObject;
    }
}
