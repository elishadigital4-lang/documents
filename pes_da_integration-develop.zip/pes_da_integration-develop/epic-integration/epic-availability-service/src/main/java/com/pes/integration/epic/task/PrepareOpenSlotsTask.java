package com.pes.integration.epic.task;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.constant.DocASAPConstants.Key.CAN_COMBINE;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;
import static com.pes.integration.epic.constant.EpicConstants.PROVIDER_ID_TYPE_ID;
import static com.pes.integration.epic.constant.EpicEngineConstants.EPIC_CONFIG;
import static com.pes.integration.epic.util.EpicUtil.*;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.String.format;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.slf4j.MDC.getCopyOfContextMap;


import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.epic.api.EpicApiCaller;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.ajde.ui.InvalidResourceException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
public class PrepareOpenSlotsTask implements Supplier<Void> {

    private static final String ERROR_PROCESSING_DATA =
            "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";

    private String startDate;
    private String endDate;
    private String providerId;
    private int canCombine;
    private String dataLocation;
    private EventTracker trackEvents;
    private FileUploader fileUploader;
    private EpicApiCaller epicApiCaller;

    private AvailabilityRequest availabilityRequest;
    private JSONObject inputParam;
    private Map<String, String> contextMap = getCopyOfContextMap();

    private  DataCacheManager dataCacheManager;


    public PrepareOpenSlotsTask(EpicApiCaller epicApiCaller, JSONObject inputObject,
                                FileUploader fileUploader, EventTracker trackEvents, AvailabilityRequest availabilityRequest, String epmPrefix, DataCacheManager dataCacheManager) throws IHubException {
        this.startDate = inputObject.getString(STARTDATE);
        this.endDate = inputObject.getString(ENDDATE);
        this.providerId = inputObject.getString(PROVIDER);
        this.epicApiCaller = epicApiCaller;
        this.fileUploader = fileUploader;
        this.dataLocation = inputObject.optString(APPOINTMENT_PATH);
        this.trackEvents = trackEvents;
        this.availabilityRequest = availabilityRequest;
        this.inputParam = inputObject;
        this.dataCacheManager=dataCacheManager;
        this.canCombine = parseInt(dataCacheManager.getConfiguration(epmPrefix,
                availabilityRequest.getDeploymentId(), GENERIC_CONFIG, CAN_COMBINE));
        //this.canCombine = parseInt((String) getValue(configurationData, CAN_COMBINE));
    }

    @Override
    public Void get() {
        setContext(contextMap);
        Map<String, File> appointmentDataFiles = new HashMap<>();
        try {
            JSONObject openApptOutput = getOpenAppointment();
            uploadFiles(appointmentDataFiles, openApptOutput);
            trackEventToNifi(trackEvents, availabilityRequest,
                    getOpenDataFlowNifiStatus(availabilityRequest), MDC.get(TOTAL_FRAGMENTS), providerId,
                    createNifiErrorPayload(getNifiPayload()));
        } catch (JsonProcessingException e) {
            log.error("error while tracking the request", e.getMessage());
            throw new EpmApiCallerException("error while tracking the request");
        } catch (EpmApiCallerException ee) {
            log.error("Error in getting the open slotId " + ee.getMessage());
        } catch (InvalidResourceException exception) {
            log.error("Invalid Open Appointments");
        } finally {
            deleteFiles(appointmentDataFiles);
        }
        return null;
    }

    private JSONObject getOpenAppointment() throws JsonProcessingException, InvalidResourceException {
        String cacheKeyValue = availabilityRequest.getDeploymentId() + ":" + providerId;
        /*if (cacheService.isInvalidResourceDataInCache(cacheKeyValue)) {
            String message = "INVALID OPEN RESOURCE: "+providerId;
            trackInvalidOpenFragmentError(availabilityRequest, trackEvents, message, providerId);
            throw new InvalidResourceException("Invalid Open Appointment");
        }
         */
        JSONArray openAppointmentsArray = new JSONArray();
        JSONObject openApptOutput = new JSONObject();
        try {
            JSONObject responseObject = openAppointments(availabilityRequest.getDeploymentId(),epicApiCaller, inputParam);
            if (!isEmpty(responseObject)) {
                openAppointmentsArray
                        .putAll(extractOpenSlotsFromResponse(responseObject, providerId, canCombine,EMPTY,EMPTY,EMPTY));
            }
            openApptOutput = getOpenAppointmentObject(openAppointmentsArray);
        } catch (InvalidIdException ide) {
            String exceptionDetails =
                    format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ide.getMessage());
            log.error(exceptionDetails);
            trackOpenFragmentError(availabilityRequest, trackEvents, providerId, exceptionDetails);
            throw new EpmApiCallerException(exceptionDetails);
        } catch (EpmApiCallerException ee) {
            String exceptionDetails =
                    format(ERROR_PROCESSING_DATA, startDate, endDate, providerId, ee.getMessage());
            log.error(exceptionDetails);
            trackOpenFragmentError(availabilityRequest, trackEvents, providerId, exceptionDetails);
            throw new EpmApiCallerException(exceptionDetails);
        } catch (InvalidResourceException exception) {
            String message = "Invalid Open Resource";
            //cacheService.updateInvalidResourceCache(cacheKeyValue, cacheKeyValue);
            trackInvalidOpenFragmentError(availabilityRequest, trackEvents, message, providerId);
            throw exception;
        } catch (IHubException | IOException e) {
            throw new RuntimeException(e);
        }
        return openApptOutput;
    }

    private void uploadFiles(Map<String, File> appointmentDataFiles, JSONObject openApptOutput) {
        appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
                prepareOpenAppointmentFile(openApptOutput, availabilityRequest));
        fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
                availabilityRequest.getAppointmentType(),
                availabilityRequest.getSliceId() + SLASH + providerId,
                appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    }

    private JSONObject getOpenAppointmentObject(JSONArray openAppointmentsArray) {
        JSONObject openApptOutput = new JSONObject();
        openApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
        openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
        openApptOutput.put(TOTAL_COUNT, openAppointmentsArray.length());
        openApptOutput.put(DATA, openAppointmentsArray);
        return openApptOutput;
    }

    private File prepareOpenAppointmentFile(JSONObject apptresponse,
                                            AvailabilityRequest availabilityRequest) {
        return prepareFile(apptresponse.toString(),
                dataLocation + availabilityRequest.getMessageControlId() + SLASH
                        + availabilityRequest.getSliceId() + SLASH + providerId,
                SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
    }


    private JSONObject getNifiPayload() {
        JSONObject nifiObject = new JSONObject();
        nifiObject.put(STARTDATE, startDate);
        nifiObject.put(ENDDATE, endDate);
        nifiObject.put(FRAGMENT_ID_KEY, providerId);
        return nifiObject;
    }
}
