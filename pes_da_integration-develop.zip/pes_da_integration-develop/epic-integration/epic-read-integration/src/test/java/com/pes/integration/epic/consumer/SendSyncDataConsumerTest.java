package com.pes.integration.epic.consumer;

import static org.mockito.Mockito.*;

import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SendSyncDataConsumerTest {

    @Mock
    private SyncDataConsumerService syncDataConsumerService;

    @InjectMocks
    private SendSyncDataConsumer sendSyncDataConsumer;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void consumeSendSyncDataMessage_withValidPayload_callsProcessSendSyncData() {
        String payload = "{\"key\":\"value\"}";
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.syncLayerRequestCountWithDeploymentId(anyString(),anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            sendSyncDataConsumer.consumeSendSyncDataMessage(payload);
            verify(syncDataConsumerService, times(1)).processSendSyncData(payload);

        }
    }

    @Test
    void consumeSendSyncDataMessage_withNullPayload_doesNotCallProcessSendSyncData() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.syncLayerRequestCountWithDeploymentId(anyString(),anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            sendSyncDataConsumer.consumeSendSyncDataMessage(null);
            verify(syncDataConsumerService, times(1)).processSendSyncData(null);

        }
    }

    @Test
    void consumeSendSyncDataMessage_withEmptyPayload_doesNotCallProcessSendSyncData() {
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.syncLayerRequestCountWithDeploymentId(anyString(),anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            sendSyncDataConsumer.consumeSendSyncDataMessage("");
            verify(syncDataConsumerService, times(1)).processSendSyncData("");
        }
    }

    @Test
    void listen_withValidMessage_callsProcessSendSyncData() {
        String message = "{\"key\":\"value\"}";
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.syncLayerRequestCountWithDeploymentId(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            sendSyncDataConsumer.listen("test-topic", message);
            verify(syncDataConsumerService, times(1)).processSendSyncData(message);
        }
    }


    @Test
    void listen_withEmptyMessage_callsProcessSendSyncData() {
        String topic = "test-topic";
        String message = "";
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.syncLayerRequestCountWithDeploymentId(anyString(),anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            sendSyncDataConsumer.listen(topic, message);
            verify(syncDataConsumerService, times(1)).processSendSyncData(message);

        }
    }
    @Test
    void listen_withNullMessage_callsProcessSendSyncData() {
        String topic = "test-topic";
        String message = null;
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.syncLayerRequestCountWithDeploymentId(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            sendSyncDataConsumer.listen(topic, message);
            verify(syncDataConsumerService, times(1)).processSendSyncData(message);
        }
    }
}