package com.pes.integration.epic;

import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.service.KafkaService;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Value;

import static com.pes.integration.epic.constant.EpicEngineConstants.EPM_NAME_PREFIX;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class InitEngineTests {
    @Value("${kafka.sync.data.topic}")
    String syncTopicName;

    @Value("${kafka.config.group.id}")
    String groupId;
    @Mock
    private KafkaService kafkaService;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private EpicInitEngine epicInitEngine;

    @InjectMocks
    private InitEngine initEngine;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void initEngineInitializesSuccessfully() throws IHubException {
        when(cacheManager.getRedisConfig(anyString())).thenReturn(new JSONObject());
        epicInitEngine.init();
        kafkaService.createTopicAndListener(cacheManager.getRedisConfig(EPM_NAME_PREFIX).toString(),
                syncTopicName, groupId);

        verify(epicInitEngine, times(1)).init();
        verify(kafkaService, times(1)).createTopicAndListener(anyString(), eq(syncTopicName), eq(groupId));
    }

    @Test
    void initEngineThrowsIHubException() throws IHubException {
        doThrow(new IHubException(UtilityErrors.DEFAULT_IHUB_ERROR.getErrorCode(), "Initialization failed")).when(epicInitEngine).init();
        assertThrows(IHubException.class, () -> initEngine.init());
    }
}