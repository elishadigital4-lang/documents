package com.pes.integration.epic.consumer;

import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.MetricsUtil.syncLayerRequestCountWithDeploymentId;
import static org.apache.commons.lang3.StringUtils.isEmpty;

import com.pes.integration.service.SendSyncDataService;
import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.service.impl.KafkaServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SendSyncDataConsumer extends KafkaServiceImpl {

  @Autowired
  SyncDataConsumerService syncDataConsumerService;
  @Value("${epm.engine.name}")
  private String engineName;
  @Value("${info.app.description}")
  private String appDescription;

  @KafkaListener(topics = "${kafka.sync.data.topic}",
          groupId = "${kafka.config.group.id}", containerFactory = "sampleListListener")
  public void consumeSendSyncDataMessage(@Payload(required = false) String payload) {
    syncLayerRequestCountWithDeploymentId(engineName, appDescription, getDeploymentId(payload),"consumeSendSyncDataMessage on epm topic");
    syncDataConsumerService.processSendSyncData(payload);
    log.info("sync data event consumed and processed on epm topic");
  }

  @Override
  public void listen(String topic, String message) {
    syncLayerRequestCountWithDeploymentId(engineName, appDescription, getDeploymentId(message), "SendSyncDataConsumer-listen on org topic");
    syncDataConsumerService.processSendSyncData(message);
    log.info("sync data event consumed and process on org topic");
  }

  private String getDeploymentId(String sendSyncDataPayload) {
    try {
      return getValue(new JSONObject(sendSyncDataPayload), "deployment_id").toString();
    } catch (Exception e) {
      log.error("Error while fetching deployment id from request object with message {}", e.getMessage());
      return "";
    }
  }
}