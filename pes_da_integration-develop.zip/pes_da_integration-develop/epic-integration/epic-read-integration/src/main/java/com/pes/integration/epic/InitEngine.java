package com.pes.integration.epic;

import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.KafkaService;
import com.pes.integration.service.RefreshBaseInitEngine;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static com.pes.integration.epic.constant.EpicEngineConstants.EPM_NAME_PREFIX;

@Component
public class InitEngine implements RefreshBaseInitEngine {

  @Value("${kafka.sync.data.topic}")
  String syncTopicName;

  @Value("${kafka.config.group.id}")
  String groupId;

  @Autowired
  BaseInitEngine baseInitEngine;

  @Autowired
  KafkaService kafkaService;

  @Autowired
  DataCacheManager cacheManager;

  @Autowired
  EpicInitEngine epicInitEngine;

  @PostConstruct
  public void init() throws IHubException {
    epicInitEngine.init();
    kafkaService.createTopicAndListener(cacheManager.getRedisConfig(EPM_NAME_PREFIX).toString(),
        syncTopicName, groupId);
  }
}
