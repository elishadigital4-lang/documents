package com.pes.integration.allscripts;
import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.allscripts.AllscriptsInitEngine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.EPM_NAME_PREFIX;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AllscriptsInitEngineTest {

    @Mock
    private BaseInitEngine baseInitEngine;

    @InjectMocks
    private AllscriptsInitEngine allscriptsInitEngine;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void initInitializesConfigSuccessfully() {
        allscriptsInitEngine.init();
        verify(baseInitEngine, times(1)).initializeConfig(EPM_NAME_PREFIX, false);
    }

    @Test
    void initHandlesNullBaseInitEngine() {
        allscriptsInitEngine.baseInitEngine = null;
        assertThrows(NullPointerException.class, () -> allscriptsInitEngine.init());
    }
}