package com.pes.integration.allscripts.api;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ApiNameTest {

    @Test
    void getKeyReturnsCorrectKey() {
        assertEquals("SetAppointmentStatus", ApiName.SET_APPOINTMENT_STATUS.getKey());
        assertEquals("GetCarriers", ApiName.GET_INSURANCE_CARRIERS.getKey());
        assertEquals("changed_appointments", ApiName.CHANGED_APPOINTMENTS.getKey());
        assertEquals("get_avilable_time_blocks", ApiName.GET_AVAILABLE_TIME_BLOCKS.getKey());
        assertEquals("GetUserAuthentication", ApiName.GET_USER_AUTHENTICATION.getKey());
        assertEquals("get_providers", ApiName.GET_RESOURCES.getKey());
        assertEquals("get_appointment_types", ApiName.GET_APPOINTMENT_TYPES.getKey());
        assertEquals("new_patient", ApiName.NEW_PATIENT.getKey());
        assertEquals("get_patient_demographics", ApiName.GET_PATIENT_DEMOGRAPHICS.getKey());
        assertEquals("get_locations", ApiName.GET_SCHEDULING_LOCATIONS.getKey());
        assertEquals("cancel_appointment", ApiName.CANCEL_APPOINTMENT.getKey());
        assertEquals("booked_appointments", ApiName.BOOKED_APPOINTMENTS.getKey());
        assertEquals("open_appointments", ApiName.OPEN_APPOINTMENTS.getKey());
        assertEquals("new_appointment", ApiName.NEW_APPOINTMENT.getKey());
        assertEquals("get_patient", ApiName.GET_PATIENT.getKey());
        assertEquals("get_patient_insurance", ApiName.GET_PATIENT_INSURANCE.getKey());
        assertEquals("set_patient_insurance", ApiName.SET_PATIENT_INSURANCE.getKey());
        assertEquals("update_patient_preference", ApiName.UPDATE_PATIENT_PREFERENCE.getKey());
        assertEquals("get_patient_preference", ApiName.GET_PATIENT_PREFERENCE.getKey());
        assertEquals("changed_patients", ApiName.CHANGED_PATIENTS.getKey());
        assertEquals("get_schedule_days_for_provider", ApiName.GET_SCHEDULE_DAYS_FOR_PROVIDER.getKey());
        assertEquals("confirm_appointment", ApiName.CONFIRM_APPOINTMENT.getKey());
        assertEquals("get_patient_policy_primary_care_provider", ApiName.GET_PATIENT_POLICY_PRIMARY_CARE_PROVIDER.getKey());
    }

    @Test
    void getEnumReturnsCorrectEnumForValidKey() {
        assertEquals(ApiName.SET_APPOINTMENT_STATUS, ApiName.SET_APPOINTMENT_STATUS.getEnum("SetAppointmentStatus"));
        assertEquals(ApiName.GET_INSURANCE_CARRIERS, ApiName.GET_INSURANCE_CARRIERS.getEnum("GetCarriers"));
        assertEquals(ApiName.CHANGED_APPOINTMENTS, ApiName.CHANGED_APPOINTMENTS.getEnum("changed_appointments"));
        assertEquals(ApiName.GET_AVAILABLE_TIME_BLOCKS, ApiName.GET_AVAILABLE_TIME_BLOCKS.getEnum("get_avilable_time_blocks"));
        assertEquals(ApiName.GET_USER_AUTHENTICATION, ApiName.GET_USER_AUTHENTICATION.getEnum("GetUserAuthentication"));
        assertEquals(ApiName.GET_RESOURCES, ApiName.GET_RESOURCES.getEnum("get_providers"));
        assertEquals(ApiName.GET_APPOINTMENT_TYPES, ApiName.GET_APPOINTMENT_TYPES.getEnum("get_appointment_types"));
        assertEquals(ApiName.NEW_PATIENT, ApiName.NEW_PATIENT.getEnum("new_patient"));
        assertEquals(ApiName.GET_PATIENT_DEMOGRAPHICS, ApiName.GET_PATIENT_DEMOGRAPHICS.getEnum("get_patient_demographics"));
        assertEquals(ApiName.GET_SCHEDULING_LOCATIONS, ApiName.GET_SCHEDULING_LOCATIONS.getEnum("get_locations"));
        assertEquals(ApiName.CANCEL_APPOINTMENT, ApiName.CANCEL_APPOINTMENT.getEnum("cancel_appointment"));
        assertEquals(ApiName.BOOKED_APPOINTMENTS, ApiName.BOOKED_APPOINTMENTS.getEnum("booked_appointments"));
        assertEquals(ApiName.OPEN_APPOINTMENTS, ApiName.OPEN_APPOINTMENTS.getEnum("open_appointments"));
        assertEquals(ApiName.NEW_APPOINTMENT, ApiName.NEW_APPOINTMENT.getEnum("new_appointment"));
        assertEquals(ApiName.GET_PATIENT, ApiName.GET_PATIENT.getEnum("get_patient"));
        assertEquals(ApiName.GET_PATIENT_INSURANCE, ApiName.GET_PATIENT_INSURANCE.getEnum("get_patient_insurance"));
        assertEquals(ApiName.SET_PATIENT_INSURANCE, ApiName.SET_PATIENT_INSURANCE.getEnum("set_patient_insurance"));
        assertEquals(ApiName.UPDATE_PATIENT_PREFERENCE, ApiName.UPDATE_PATIENT_PREFERENCE.getEnum("update_patient_preference"));
        assertEquals(ApiName.GET_PATIENT_PREFERENCE, ApiName.GET_PATIENT_PREFERENCE.getEnum("get_patient_preference"));
        assertEquals(ApiName.CHANGED_PATIENTS, ApiName.CHANGED_PATIENTS.getEnum("changed_patients"));
        assertEquals(ApiName.GET_SCHEDULE_DAYS_FOR_PROVIDER, ApiName.GET_SCHEDULE_DAYS_FOR_PROVIDER.getEnum("get_schedule_days_for_provider"));
        assertEquals(ApiName.CONFIRM_APPOINTMENT, ApiName.CONFIRM_APPOINTMENT.getEnum("confirm_appointment"));
        assertEquals(ApiName.GET_PATIENT_POLICY_PRIMARY_CARE_PROVIDER, ApiName.GET_PATIENT_POLICY_PRIMARY_CARE_PROVIDER.getEnum("get_patient_policy_primary_care_provider"));
    }

    @Test
    void getEnumReturnsNullForInvalidKey() {
        assertNull(ApiName.SET_APPOINTMENT_STATUS.getEnum("InvalidKey"));
    }

    @Test
    void getEnumIsCaseSensitive() {
        assertNull(ApiName.SET_APPOINTMENT_STATUS.getEnum("setappointmentstatus"));
    }

    @Test
    void getEnumHandlesNullKey() {
        assertNull(ApiName.SET_APPOINTMENT_STATUS.getEnum(null));
    }
}