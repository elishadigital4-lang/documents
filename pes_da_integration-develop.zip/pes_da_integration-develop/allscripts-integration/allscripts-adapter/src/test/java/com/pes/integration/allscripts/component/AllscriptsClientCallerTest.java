package com.pes.integration.allscripts.component;

import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.MetricsUtil;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@ExtendWith(MockitoExtension.class)
class AllscriptsClientCallerTest {

    @Mock
    private WebClient webClient;

    @InjectMocks
    private AllscriptsClientCaller allscriptsClientCaller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void generateUnityToken() {
        String httpMethod = "POST";
        String url = "http://base.url/unityService/GetToken";
        String body = "{\"Username\":\"svcUsername\",\"Password\":\"svcPassword\"}";
        String errorResponse = "Invalid Token";

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(Mono.class), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(),any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("success"));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String string = allscriptsClientCaller.generateUnityToken(httpMethod, url, body);
            assertEquals("success", string);
        }

    }
    @Test
    void getData() {
        String httpMethod = "POST";
        String url = "http://base.url/unityService/GetToken";
        String body = "{\"Username\":\"svcUsername\",\"Password\":\"svcPassword\"}";
        String errorResponse = "Invalid Token";

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(Mono.class), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(),any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("success"));
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            String string = allscriptsClientCaller.getData(httpMethod, url, body);
            assertEquals("success", string);
        }

    }

    @Test
    void generateUnityTokenThrowsExceptionForInvalidToken() {
        String httpMethod = "POST";
        String url = "http://base.url/unityService/GetToken";
        String body = "{\"Username\":\"svcUsername\",\"Password\":\"svcPassword\"}";
        String errorResponse = "Invalid Token";

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        lenient().when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.body(any(Mono.class), eq(String.class))).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        lenient().when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(new IHubErrorCode(INVALID_REQUEST.getErrorCode().getCode()), errorResponse)));

        NullPointerException exception = assertThrows(NullPointerException.class, () -> {
            allscriptsClientCaller.generateUnityToken(httpMethod, url, body);
        });

    }

    @Test
    void getDataThrowsExceptionForNotFound() {
        String httpMethod = "POST";
        String url = "http://base.url/api/GetData";
        String body = "{\"param\":\"value\"}";
        String errorResponse = "Data not found";

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        lenient().when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        lenient().when(requestBodyUriSpec.body(any(Mono.class), eq(String.class))).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        lenient().when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.error(new IHubException(new IHubErrorCode(INVALID_REQUEST.getErrorCode().getCode()), errorResponse)));

        NullPointerException exception = assertThrows(NullPointerException.class, () -> {
            allscriptsClientCaller.getData(httpMethod, url, body);
        });

    }

    @Test
    void exceptionStoresErrorBodyCorrectly() {
        String errorBody = "{\"error\":\"Patient not found\"}";
        AllscriptsClientCaller.CustomNotFoundPatientException exception = new AllscriptsClientCaller.CustomNotFoundPatientException(errorBody);

        JSONObject errorBodyJson = exception.getErrorBody();
        assertNotNull(errorBodyJson);
        assertEquals("Patient not found", errorBodyJson.getString("error"));
    }

    @Test
    void exceptionThrowsJSONExceptionForInvalidJson() {
        String invalidErrorBody = "Invalid JSON";
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            new AllscriptsClientCaller.CustomNotFoundPatientException(invalidErrorBody);
        });

        assertTrue(thrown.getMessage().contains("Failed to parse error body as JSON"));
    }

    @Test
    void exceptionMessageIsSetCorrectly() {
        String errorBody = "{\"error\":\"Patient not found\"}";
        AllscriptsClientCaller.CustomNotFoundPatientException exception = new AllscriptsClientCaller.CustomNotFoundPatientException(errorBody);

        assertEquals(errorBody, exception.getMessage());
    }

    @Test
    void generateUnityTokenHandlesNotFoundStatus() {
        String httpMethod = "POST";
        String url = "http://base.url/unityService/GetToken";
        String body = "{\"Username\":\"svcUsername\",\"Password\":\"svcPassword\"}";
        String errorResponse = "Patient not found";

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(Mono.class), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        // Mock onStatus for NOT_FOUND
        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            java.util.function.Predicate<HttpStatusCode> predicate = invocation.getArgument(0);
            java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
            ClientResponse mockClientResponse = mock(ClientResponse.class);
            when(mockClientResponse.statusCode()).thenReturn(HttpStatus.NOT_FOUND);
            when(mockClientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorResponse));
            if (predicate.test(HttpStatus.NOT_FOUND)) {
                return function.apply(mockClientResponse);
            }
            return responseSpec;
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            Throwable thrown = assertThrows(Throwable.class, () -> {
                allscriptsClientCaller.generateUnityToken(httpMethod, url, body);
            });
            assertFalse(thrown.getCause() instanceof IHubException);
        }
    }

    @Test
    void generateUnityTokenHandlesOtherErrorStatus() {
        String httpMethod = "POST";
        String url = "http://base.url/unityService/GetToken";
        String body = "{\"Username\":\"svcUsername\",\"Password\":\"svcPassword\"}";
        String errorResponse = "Internal Server Error";

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(Mono.class), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        // Mock onStatus for INTERNAL_SERVER_ERROR
        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            java.util.function.Predicate<HttpStatusCode> predicate = invocation.getArgument(0);
            java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
            ClientResponse mockClientResponse = mock(ClientResponse.class);
            when(mockClientResponse.statusCode()).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
            when(mockClientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorResponse));
            if (predicate.test(HttpStatus.INTERNAL_SERVER_ERROR)) {
                return function.apply(mockClientResponse);
            }
            return responseSpec;
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);
            mockedStatic.when(() -> MetricsUtil.metricClientErrorCount(anyString(), anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            Throwable thrown = assertThrows(Throwable.class, () -> {
                allscriptsClientCaller.generateUnityToken(httpMethod, url, body);
            });
            assertFalse(thrown instanceof IHubException);
        }
    }

    @Test
    void getDataHandlesNotFoundStatus() {
        String httpMethod = "POST";
        String url = "http://base.url/unityService/GetToken";
        String body = "{\"Username\":\"svcUsername\",\"Password\":\"svcPassword\"}";
        String errorResponse = "Patient not found";

        WebClient.RequestBodyUriSpec requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);

        when(webClient.method(HttpMethod.valueOf(httpMethod))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(Mono.class), eq(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        // Mock onStatus for NOT_FOUND
        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            java.util.function.Predicate<HttpStatusCode> predicate = invocation.getArgument(0);
            java.util.function.Function<ClientResponse, Mono<? extends Throwable>> function = invocation.getArgument(1);
            ClientResponse mockClientResponse = mock(ClientResponse.class);
            when(mockClientResponse.statusCode()).thenReturn(HttpStatus.NOT_FOUND);
            when(mockClientResponse.bodyToMono(String.class)).thenReturn(Mono.just(errorResponse));
            if (predicate.test(HttpStatus.NOT_FOUND)) {
                return function.apply(mockClientResponse);
            }
            return responseSpec;
        });

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.metricClientRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            Throwable thrown = assertThrows(Throwable.class, () -> {
                allscriptsClientCaller.getData(httpMethod, url, body);
            });
            assertFalse(thrown.getCause() instanceof IHubException);
        }
    }
}