package com.pes.integration.allscripts.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.pes.integration.allscripts.component.ConfigCache;
import com.pes.integration.allscripts.factory.AllscriptsHandlerFactoryService;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.ALLSCRIPTS_CONFIG;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.UtilitiesConstants.TIME_ZONE;
import static com.pes.integration.enums.HandlerType.GET_PROVIDERS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HandlerUtilsTest {

    @Mock
    private RedisService redisService;

    @Mock
    private AllscriptsHandlerFactoryService allscriptsHandlerFactoryService;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;

    @InjectMocks
    private HandlerUtils handlerUtils;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        setStaticField(HandlerUtils.class, "allscriptsHandlerFactoryService", allscriptsHandlerFactoryService);
        setStaticField(HandlerUtils.class, "redisService", redisService);
    }

    private void setStaticField(Class<?> clazz, String fieldName, Object value) throws Exception {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(null, value);
    }

    @Test
    void handleLocationDeptIdE2D_validInput() throws IHubException {
        JSONObject inputObject = new JSONObject();
        JSONObject provider = new JSONObject().put("DepartmentId", "123").put("LocationId", "456");
        inputObject.put("SchedulingData", new JSONObject().put("Provider", new JSONArray().put(provider)));


        Object result = HandlerUtils.handleLocationDeptIdE2D(inputObject);

        assertEquals("456@123", JsonUtils.getValue(result, DocASAPConstants.Key.APPT_LOCATION_ID));
    }

    @Test
    void handleLocationDeptIdD2E_validInput() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.APPT_LOCATION_ID, "456@123");
        JSONObject provider = new JSONObject().put("DepartmentId", "123").put("LocationId", "456@123");
        inputObject.put("SchedulingData", new JSONObject().put("Provider", new JSONArray().put(provider)));


        Object result = HandlerUtils.handleLocationDeptIdD2E(inputObject);

        assertEquals("456", JsonUtils.getValue(result, DocASAPConstants.Key.APPT_LOCATION_ID));
        assertEquals("123", JsonUtils.getValue(result, DocASAPConstants.Key.APPT_DEPT_ID));
    }

    @Test
    void getProviderIds_validDeploymentId() throws IHubException {
        String deploymentId = "deployment1";
        JSONObject inputObject = new JSONObject();


        Assertions.assertDoesNotThrow(() -> HandlerUtils.getProviderIds(deploymentId, inputObject));
    }







    @Test
    void getSyncRunTime_validResponse() throws IHubException {
        String deploymentId = "deployment1";
        String syncResponse = "{\"osrid\":\"123\",\"sync_run_time\":\"01/01/2023 00:00:00\"}";
        when(iHubDataServiceDelegator.getOrgLastRealTimeRunTime(deploymentId)).thenReturn(syncResponse);
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, TIME_ZONE, false)).thenReturn("UTC");
        String result = HandlerUtils.getSyncRunTime(dataCacheManager, iHubDataServiceDelegator, deploymentId);

        assertNotNull(result);
    }



    @Test
    void getPatientSyncRunTime_validResponse() throws IHubException {
        String deploymentId = "deployment1";
        String lastSyncTime = "01/01/2023 00:00:00";
        when(redisService.get(deploymentId)).thenReturn(lastSyncTime);

        String result = HandlerUtils.getPatientSyncRunTime(dataCacheManager, deploymentId);

        assertNotNull(result);
    }

    @Test
    void getPatientSyncRunTime_emptyResponse() throws IHubException {
        String deploymentId = "deployment1";
        when(redisService.get(deploymentId)).thenReturn(null);
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, TIME_ZONE, false)).thenReturn("UTC");

        String result = HandlerUtils.getPatientSyncRunTime(dataCacheManager, deploymentId);

        assertNotNull(result);
    }

    @Test
    void getCurrentDateMinus2Mins_returnsExpectedDate() throws Exception {
        String expectedDate = "2024-06-01 10:00:00";
        String timezone = "UTC";

        try (MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class)) {
            dateUtilsMock.when(() -> DateUtils.getCurrentDateWithMinusMin(anyString(), anyString(), eq(2)))
                    .thenReturn(expectedDate);

            Method method = HandlerUtils.class.getDeclaredMethod("getCurrentDateMinus2Mins", String.class, String.class);
            method.setAccessible(true);
            String result = (String) method.invoke(null, "ignored", timezone);

            assertEquals(expectedDate, result);
        }
    }

    @Test
    void getCurrentDateMinus2Mins_handlesExceptionAndReturnsInput() throws Exception {
        String inputDate = "input-date";
        String timezone = "UTC";

        try (MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class)) {
            dateUtilsMock.when(() -> DateUtils.getCurrentDateWithMinusMin(anyString(), anyString(), eq(2)))
                    .thenThrow(new RuntimeException("Test exception"));

            Method method = HandlerUtils.class.getDeclaredMethod("getCurrentDateMinus2Mins", String.class, String.class);
            method.setAccessible(true);
            String result = (String) method.invoke(null, inputDate, timezone);

            assertEquals(inputDate, result);
        }
    }


    @Test
    void getTimeZone_returnsExpectedTimeZone() throws IHubException {
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        String deploymentId = "deployment1";
        String expectedTimeZone = "UTC";

        when(mockCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenReturn(expectedTimeZone);

        String result = HandlerUtils.getTimeZone(mockCacheManager, deploymentId);

        assertEquals(expectedTimeZone, result);
    }

    @Test
    void getTimeZone_handlesExceptionAndReturnsEmpty() throws Exception {
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        String deploymentId = "deployment1";

        when(mockCacheManager.getStoredProvidersConfig(anyString(), eq(deploymentId), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(null, "Test exception"));

        String result = HandlerUtils.getTimeZone(mockCacheManager, deploymentId);

        assertEquals("", result);
    }



}