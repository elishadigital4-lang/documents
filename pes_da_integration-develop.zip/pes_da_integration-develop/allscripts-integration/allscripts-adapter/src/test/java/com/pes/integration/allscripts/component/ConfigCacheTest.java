package com.pes.integration.allscripts.component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ConfigCacheTest {

    @Test
    void getProviderMapReturnsCorrectArrayNode() {
        ArrayNode mockArrayNode = Mockito.mock(ArrayNode.class);
        ConfigCache configCache = new ConfigCache();
        configCache.setProviderIdsMap("deployment1", mockArrayNode);
        assertEquals(mockArrayNode, ConfigCache.getProviderMap("deployment1"));
    }

    @Test
    void getProviderMapReturnsNullForUnknownDeploymentId() {
        assertNull(ConfigCache.getProviderMap("unknownDeployment"));
    }

    @Test
    void setProviderIdsMapStoresArrayNodeCorrectly() {
        ArrayNode mockArrayNode = Mockito.mock(ArrayNode.class);
        ConfigCache configCache = new ConfigCache();
        configCache.setProviderIdsMap("deployment1", mockArrayNode);
        assertEquals(mockArrayNode, ConfigCache.getProviderMap("deployment1"));
    }

    @Test
    void getSyncRunTimeMapReturnsCorrectValue() {
        ConfigCache configCache = new ConfigCache();
        configCache.setSyncRunTimeMap("deployment1", "syncTime1");
        assertEquals("syncTime1", configCache.getSyncRunTimeMap("deployment1"));
    }

    @Test
    void getSyncRunTimeMapReturnsNullForUnknownDeploymentId() {
        ConfigCache configCache = new ConfigCache();
        assertNull(configCache.getSyncRunTimeMap("unknownDeployment"));
    }

    @Test
    void setSyncRunTimeMapStoresValueCorrectly() {
        ConfigCache configCache = new ConfigCache();
        configCache.setSyncRunTimeMap("deployment1", "syncTime1");
        assertEquals("syncTime1", configCache.getSyncRunTimeMap("deployment1"));
    }

    @Test
    void getTokenMapReturnsCorrectValue() {
        ConfigCache configCache = new ConfigCache();
        configCache.setTokenMap("deployment1", "token1");
        assertEquals("token1", configCache.getTokenMap("deployment1"));
    }

    @Test
    void getTokenMapReturnsNullForUnknownDeploymentId() {
        ConfigCache configCache = new ConfigCache();
        assertNull(configCache.getTokenMap("unknownDeployment"));
    }

    @Test
    void setTokenMapStoresValueCorrectly() {
        ConfigCache configCache = new ConfigCache();
        configCache.setTokenMap("deployment1", "token1");
        assertEquals("token1", configCache.getTokenMap("deployment1"));
    }

    @Test
    void getPatientSyncRunTimeMapReturnsCorrectValue() {
        ConfigCache configCache = new ConfigCache();
        configCache.setPatientSyncRunTimeMap("deployment1", "syncTime1");
        assertEquals("syncTime1", configCache.getPatientSyncRunTimeMap("deployment1"));
    }

    @Test
    void getPatientSyncRunTimeMapReturnsNullForUnknownDeploymentId() {
        ConfigCache configCache = new ConfigCache();
        assertNull(configCache.getPatientSyncRunTimeMap("unknownDeployment"));
    }

    @Test
    void setPatientSyncRunTimeMapStoresValueCorrectly() {
        ConfigCache configCache = new ConfigCache();
        configCache.setPatientSyncRunTimeMap("deployment1", "syncTime1");
        assertEquals("syncTime1", configCache.getPatientSyncRunTimeMap("deployment1"));
    }

    @Test
    void getFilterDataMapReturnsCorrectJsonNode() {
        JsonNode mockJsonNode = Mockito.mock(JsonNode.class);
        ConfigCache.setFilterDataMap("deployment1", mockJsonNode);
        assertEquals(mockJsonNode, ConfigCache.getFilterDataMap("deployment1"));
    }

    @Test
    void getFilterDataMapReturnsNullForUnknownDeploymentId() {
        assertNull(ConfigCache.getFilterDataMap("unknownDeployment"));
    }

    @Test
    void setFilterDataMapStoresJsonNodeCorrectly() {
        JsonNode mockJsonNode = Mockito.mock(JsonNode.class);
        ConfigCache.setFilterDataMap("deployment1", mockJsonNode);
        assertEquals(mockJsonNode, ConfigCache.getFilterDataMap("deployment1"));
    }
}