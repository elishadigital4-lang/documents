package com.pes.integration.allscripts.factory;


import com.pes.integration.enums.HandlerType;
import com.pes.integration.handlers.AbstractNewPatientHandler;
import com.pes.integration.handlers.BaseHandler;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AllscriptsHandlerFactoryServiceTest {

    @Mock
    private Map<String, BaseHandler> handlerMap;

    @InjectMocks
    private AllscriptsHandlerFactoryService allscriptsHandlerFactoryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createReturnsCorrectHandlerForValidHandlerType() {
        BaseHandler mockHandler = mock(BaseHandler.class);
        lenient().when(handlerMap.get("NewPatient")).thenReturn(mockHandler);

        HandlerType handlerType = mock(HandlerType.class);
        when(handlerType.getKey()).thenReturn("NewPatient");

        Assertions.assertDoesNotThrow(() -> allscriptsHandlerFactoryService.create(handlerType, new Object(), new Object()));


    }

    @Test
    void createReturnsNullForInvalidHandlerType() {
        lenient().when(handlerMap.get("NewPatient")).thenReturn(null);

        HandlerType handlerType = mock(HandlerType.class);
        when(handlerType.getKey()).thenReturn("NewPatient");

        BaseHandler result = allscriptsHandlerFactoryService.create(handlerType, new Object(), new Object());

        assertNull(result);
    }



    @Test
    void createHandlesNullInputAndOutputObjects() {
        BaseHandler mockHandler = mock(BaseHandler.class);
        lenient().when(handlerMap.get("NewPatient")).thenReturn(mockHandler);

        HandlerType handlerType = mock(HandlerType.class);
        when(handlerType.getKey()).thenReturn("NewPatient");

        Assertions.assertDoesNotThrow(() -> allscriptsHandlerFactoryService.create(handlerType, new Object(), new Object()));

    }
}