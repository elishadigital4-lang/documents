package com.pes.integration.allscripts.api;


import static org.junit.jupiter.api.Assertions.*;

import org.json.JSONArray;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AllscriptApiTest {

    @Test
    void allArgsConstructorInitializesFieldsCorrectly() {
        JSONArray clientError = new JSONArray();
        AllscriptApi api = new AllscriptApi("deploymentId", "tokenUrl", "svcUsername", "svcPassword", "appname", "pmUsername", "pmPassword", "baseUrl", "unityService", clientError, "token");

        assertEquals("deploymentId", api.getDeploymentId());
        assertEquals("tokenUrl", api.getTokenUrl());
        assertEquals("svcUsername", api.getSvcUsername());
        assertEquals("svcPassword", api.getSvcPassword());
        assertEquals("appname", api.getAppname());
        assertEquals("pmUsername", api.getPmUsername());
        assertEquals("pmPassword", api.getPmPassword());
        assertEquals("baseUrl", api.getBaseUrl());
        assertEquals("unityService", api.getUnityService());
        assertEquals(clientError, api.getClientError());
        assertEquals("token", api.getToken());
    }

    @Test
    void noArgsConstructorInitializesFieldsToNull() {
        AllscriptApi api = new AllscriptApi();

        assertNull(api.getDeploymentId());
        assertNull(api.getTokenUrl());
        assertNull(api.getSvcUsername());
        assertNull(api.getSvcPassword());
        assertNull(api.getAppname());
        assertNull(api.getPmUsername());
        assertNull(api.getPmPassword());
        assertNull(api.getBaseUrl());
        assertNull(api.getUnityService());
        assertNull(api.getClientError());
        assertNull(api.getToken());
    }

    @Test
    void builderSetsFieldsCorrectly() {
        JSONArray clientError = new JSONArray();
        AllscriptApi api = AllscriptApi.builder()
                .deploymentId("deploymentId")
                .tokenUrl("tokenUrl")
                .svcUsername("svcUsername")
                .svcPassword("svcPassword")
                .appname("appname")
                .pmUsername("pmUsername")
                .pmPassword("pmPassword")
                .baseUrl("baseUrl")
                .unityService("unityService")
                .clientError(clientError)
                .token("token")
                .build();
        System.out.println(api.toString());
        assertEquals("deploymentId", api.getDeploymentId());
        assertEquals("tokenUrl", api.getTokenUrl());
        assertEquals("svcUsername", api.getSvcUsername());
        assertEquals("svcPassword", api.getSvcPassword());
        assertEquals("appname", api.getAppname());
        assertEquals("pmUsername", api.getPmUsername());
        assertEquals("pmPassword", api.getPmPassword());
        assertEquals("baseUrl", api.getBaseUrl());
        assertEquals("unityService", api.getUnityService());
        assertEquals(clientError, api.getClientError());
        assertEquals("token", api.getToken());
    }

    @Test
    void setClientErrorUpdatesFieldCorrectly() {
        AllscriptApi api = new AllscriptApi();
        JSONArray clientError = new JSONArray();
        api.setClientError(clientError);

        assertEquals(clientError, api.getClientError());
    }
}