package com.pes.integration.allscripts.contant;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class AllscriptsConstantsTest {

    @Test
    void unityEndPointConstantIsCorrect() {
        assertEquals("unityendpoint", AllscriptsConstants.UNITY_END_POINT);
    }

    @Test
    void unitServiceConstantIsCorrect() {
        assertEquals("unityservice", AllscriptsConstants.UNIT_SERVICE);
    }

    @Test
    void clientErrorConstantIsCorrect() {
        assertEquals("clientError", AllscriptsConstants.CLIENT_ERROR);
    }

    @Test
    void appNameConstantIsCorrect() {
        assertEquals("appname", AllscriptsConstants.APP_NAME);
    }

    @Test
    void svcUsernameConstantIsCorrect() {
        assertEquals("svcusername", AllscriptsConstants.SVC_USERNAME);
    }

    @Test
    void svcPasswordConstantIsCorrect() {
        assertEquals("svcpassword", AllscriptsConstants.SVC_PASSWORD);
    }

    @Test
    void pmUsernameConstantIsCorrect() {
        assertEquals("pmusername", AllscriptsConstants.PM_USERNAME);
    }

    @Test
    void pmPasswordConstantIsCorrect() {
        assertEquals("pmpassword", AllscriptsConstants.PM_PASSWORD);
    }

    @Test
    void dateFormatConstantIsCorrect() {
        assertEquals("MM/dd/yyyy", AllscriptsConstants.DATE_FORMAT);
    }

    @Test
    void dateFormatAlternateConstantIsCorrect() {
        assertEquals("MM-dd-yyyy", AllscriptsConstants.DATE_FORMAT_ALTERNATE);
    }

    @Test
    void dateTimeFormatConstantIsCorrect() {
        assertEquals("MM/dd/yyyy HH:mm:ss", AllscriptsConstants.DATE_TIME_FORMAT);
    }

    @Test
    void timeFormatConstantIsCorrect() {
        assertEquals("hh:mm a", AllscriptsConstants.TIME_FORMAT);
    }

    @Test
    void militaryTimeFormatConstantIsCorrect() {
        assertEquals("HHmm", AllscriptsConstants.MILITARY_TIME_FORMAT);
    }

    @Test
    void dateTimeFormatAmPmConstantIsCorrect() {
        assertEquals("MM/dd/yyyy hh:mm:ss a", AllscriptsConstants.DATE_TIME_FORMAT_AM_PM);
    }

    @Test
    void dateTimeFormatAmPmWithoutSecConstantIsCorrect() {
        assertEquals("MM/dd/yyyy hh:mma", AllscriptsConstants.DATE_TIME_FORMAT_AM_PM_WITHOUT_SEC);
    }

    @Test
    void falseConstantIsCorrect() {
        assertEquals("false", AllscriptsConstants.FALSE);
    }

    @Test
    void nextConstantIsCorrect() {
        assertEquals("next", AllscriptsConstants.NEXT);
    }

    @Test
    void apptSlotDurationConstantIsCorrect() {
        assertEquals("5", AllscriptsConstants.APPT_SLOT_DURATION);
    }

    @Test
    void codeCanceledConstantIsCorrect() {
        assertEquals("X", AllscriptsConstants.CODE_CANCELED);
    }

    @Test
    void codeNewConstantIsCorrect() {
        assertEquals("S", AllscriptsConstants.CODE_NEW);
    }

    @Test
    void codeRescheduledConstantIsCorrect() {
        assertEquals("B", AllscriptsConstants.CODE_RESCHEDULED);
    }

    @Test
    void codeNoShowConstantIsCorrect() {
        assertEquals("N", AllscriptsConstants.CODE_NO_SHOW);
    }

    @Test
    void baseUrlConstantIsCorrect() {
        assertEquals("http://pm.unitysandbox.com/UnityPM/unityservice.svc/json/MagicJson", AllscriptsConstants.BASE_URL);
    }

    @Test
    void getTokenConstantIsCorrect() {
        assertEquals("/GetToken", AllscriptsConstants.GET_TOKEN);
    }

    @Test
    void magicJsonConstantIsCorrect() {
        assertEquals("/MagicJson", AllscriptsConstants.MAGIC_JSON);
    }

    @Test
    void getOrgLastSyncRunTimeConstantIsCorrect() {
        assertEquals("/org/getOrgLastSyncRunTime", AllscriptsConstants.GET_ORG_LAST_SYNC_RUN_TIME);
    }

    @Test
    void bookedSlots1ConstantIsCorrect() {
        assertEquals("BookedSlots1", AllscriptsConstants.BOOKED_SLOTS1);
    }

    @Test
    void bookedSlots2ConstantIsCorrect() {
        assertEquals("BookedSlots2", AllscriptsConstants.BOOKED_SLOTS2);
    }

    @Test
    void openSlots1ConstantIsCorrect() {
        assertEquals("OpenSlots1", AllscriptsConstants.OPEN_SLOTS1);
    }

    @Test
    void openSlots2ConstantIsCorrect() {
        assertEquals("OpenSlots2", AllscriptsConstants.OPEN_SLOTS2);
    }

    @Test
    void availableScheduleConstantIsCorrect() {
        assertEquals("AvailableSchedule", AllscriptsConstants.AVAILABLE_SCHEDULE);
    }

    @Test
    void apptDurationConstantIsCorrect() {
        assertEquals("Duration", AllscriptsConstants.APPT_DURATION);
    }

    @Test
    void apptTypesConstantIsCorrect() {
        assertEquals("AppointmentTypes", AllscriptsConstants.APPT_TYPES);
    }

    @Test
    void updateTimeConstantIsCorrect() {
        assertEquals("temp.updateTime", AllscriptsConstants.UPDATE_TIME);
    }

    @Test
    void lastPulledConstantIsCorrect() {
        assertEquals("temp.last_pulled", AllscriptsConstants.LAST_PULLED);
    }

    @Test
    void lastChangedConstantIsCorrect() {
        assertEquals("temp.last_changed", AllscriptsConstants.LAST_CHANGED);
    }

    @Test
    void bookedStatusConstantIsCorrect() {
        assertEquals("booked_status", AllscriptsConstants.BOOKED_STATUS);
    }

    @Test
    void bookedAppointmentChunkSizeConstantIsCorrect() {
        assertEquals("book_chunk_size", AllscriptsConstants.BOOKED_APPOINTMENT_CHUNK_SIZE);
    }

    @Test
    void timeConstantIsCorrect() {
        assertEquals("Time", AllscriptsConstants.TIME);
    }

    @Test
    void startTimeConstantIsCorrect() {
        assertEquals("StartTime", AllscriptsConstants.START_TIME);
    }

    @Test
    void dobPlus2LnCharsMatchCountConstantIsCorrect() {
        assertEquals(" DOB + First 2 character of LastName Match Count = ", AllscriptsConstants.DOB_PLUS_2LN_CHARS_MATCH_COUNT);
    }

    @Test
    void dobPlus2LnCharsPlusMobilePhoneMatchCountConstantIsCorrect() {
        assertEquals(" DOB + Last 2 characters+MobilePhone Match Count = ", AllscriptsConstants.DOB_PLUS_2LN_CHARS_PLUS_MOBILE_PHONE_MATCH_COUNT);
    }

    @Test
    void tempVolumeConstantIsCorrect() {
        assertEquals("temp.volume", AllscriptsConstants.TEMP_VOLUME);
    }

    @Test
    void volumeConstantIsCorrect() {
        assertEquals("499", AllscriptsConstants.VOLUME);
    }

    @Test
    void patientCountThresholdConstantIsCorrect() {
        assertEquals("ptnt_count_thres", AllscriptsConstants.PATIENT_COUNT_THRESHOLD);
    }

    @Test
    void forDeploymentIdConstantIsCorrect() {
        assertEquals("For deploymentId=", AllscriptsConstants.FOR_DEPLOYMENT_ID);
    }

    @Test
    void andPatientIdConstantIsCorrect() {
        assertEquals(" and PatientId=", AllscriptsConstants.AND_PATIENT_ID);
    }

    @Test
    void filterConstantIsCorrect() {
        assertEquals("filter", AllscriptsConstants.FILTER);
    }

    @Test
    void statusConstantIsCorrect() {
        assertEquals("DemographicData.PatientInformation[0].Active", AllscriptsConstants.STATUS);
    }

    @Test
    void keyConstantIsCorrect() {
        assertEquals("Key", AllscriptsConstants.KEY);
    }

    @Test
    void fieldNameConstantIsCorrect() {
        assertEquals("FieldName", AllscriptsConstants.FIELD_NAME);
    }

    @Test
    void valueConstantIsCorrect() {
        assertEquals("Value", AllscriptsConstants.VALUE);
    }

    @Test
    void isDemographicConstantIsCorrect() {
        assertEquals("isDemographicData", AllscriptsConstants.IS_DEMOGRAPHIC);
    }

    @Test
    void getAppointmentsByChangeDttmConstantIsCorrect() {
        assertEquals("GetAppointmentsByChangeDTTM", AllscriptsConstants.GETAPPOINTMENTSBYCHANGEDTTM);
    }

    @Test
    void apiChangedAppointmentsConstantIsCorrect() {
        assertEquals("GetAppointmentsByChangeDTTM", AllscriptsConstants.API_CHANGED_APPOINTMENTS);
    }

    @Test
    void locationAbbreviationConstantIsCorrect() {
        assertEquals("LocAbbrv", AllscriptsConstants.LOCATION_ABBREVIATION);
    }

    @Test
    void departmentAbbreviationConstantIsCorrect() {
        assertEquals("DeptAbbrv", AllscriptsConstants.DEPARTMENT_ABBREVIATION);
    }

    @Test
    void scheduleLocationsConstantIsCorrect() {
        assertEquals("SchedLocations", AllscriptsConstants.SCHEDULE_LOCATIONS);
    }

    @Test
    void scheduleDepartmentsConstantIsCorrect() {
        assertEquals("SchedDepartments", AllscriptsConstants.SCHEDULE_DEPARTMENTS);
    }

    @Test
    void filtersConstantIsCorrect() {
        assertEquals("filters", AllscriptsConstants.FILTERS);
    }
}