package com.pes.integration.allscripts.dto;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TokenTest {

    @Test
    void accessToken_isSetCorrectly() {
        Token token = new Token();
        token.setAccessToken("testAccessToken");

        assertEquals("testAccessToken", token.getAccessToken());
    }

    @Test
    void expiresIn_isSetCorrectly() {
        Token token = new Token();
        token.setExpiresIn("3600");

        assertEquals("3600", token.getExpiresIn());
    }

    @Test
    void accessToken_isNullByDefault() {
        Token token = new Token();

        assertNull(token.getAccessToken());
    }

    @Test
    void expiresIn_isNullByDefault() {
        Token token = new Token();

        assertNull(token.getExpiresIn());
    }
}