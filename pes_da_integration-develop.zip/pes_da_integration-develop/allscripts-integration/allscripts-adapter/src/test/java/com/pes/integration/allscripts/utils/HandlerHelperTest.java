package com.pes.integration.allscripts.utils;


import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.UtilitiesConstants.JsonConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Optional;

import static com.pes.integration.allscripts.contant.AllscriptsConstants.FIELD_NAME;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HandlerHelperTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private DataCacheManager dataCacheManager;

    @InjectMocks
    private HandlerHelper handlerHelper;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        setStaticField(HandlerHelper.class, "allscriptsApiCaller", allscriptsApiCaller);
        setStaticField(HandlerHelper.class, "dataCacheManager", dataCacheManager);
    }

    private void setStaticField(Class<?> clazz, String fieldName, Object value) throws Exception {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(null, value);
    }
    @Test
    void buildPatientSyncObject_EmailNotificationStatus_ENABLED() throws IHubException {
        JSONObject patientObject = new JSONObject();

        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("ExternalPatientId", "12345");
        patientInformation.put("DOB", "01-01-2000");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        patientObject.put("DemographicData", demographicData);

        JSONObject inputJson = new JSONObject();
        inputJson.put(JsonConstants.DEPLOYMENT_ID, "deployment1");
        inputJson.put("temp", new JSONObject().put("patient_id", "12345"));
        JSONObject outputJson = new JSONObject();
        outputJson.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq(""))).thenReturn(outputJson);
        JSONObject prefOutJson = new JSONObject();
        prefOutJson.put("Key", new JSONArray().put(new JSONObject().put("Value", "emailValue").put(FIELD_NAME, "emailKey")));
        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_PREFERENCE.getKey()), any(), eq(""))).thenReturn(prefOutJson);

        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION, false)).thenReturn("emailKey:emailValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION, false)).thenReturn("textKey:textValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION, false)).thenReturn("callKey:callValue");
        JSONObject result = handlerHelper.buildPatientSyncObject(patientObject, "deployment1");

        System.out.println(result);
        assertNotNull(result);
        JSONObject patient = result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
        assertEquals("20000101", patient.getString("DOB"));
        assertEquals("12345", patient.getString("ExternalPatientId"));
        assertEquals("ENABLED", patient.getString("EmailNotificationStatus"));
        assertEquals("", patient.getString("TextNotificationStatus"));
        assertEquals("", patient.getString("VoiceNotificationStatus"));
    }

    @Test
    void buildPatientSyncObject_EmailNotificationStatus_DISABLED() throws IHubException {
        JSONObject patientObject = new JSONObject();

        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("ExternalPatientId", "12345");
        patientInformation.put("DOB", "01-01-2000");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        patientObject.put("DemographicData", demographicData);

        JSONObject inputJson = new JSONObject();
        inputJson.put(JsonConstants.DEPLOYMENT_ID, "deployment1");
        inputJson.put("temp", new JSONObject().put("patient_id", "12345"));
        JSONObject outputJson = new JSONObject();
        outputJson.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq(""))).thenReturn(outputJson);
        JSONObject prefOutJson = new JSONObject();
        prefOutJson.put("Key", new JSONArray().put(new JSONObject().put("Value", "emailValue1").put(FIELD_NAME, "emailKey")));
        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_PREFERENCE.getKey()), any(), eq(""))).thenReturn(prefOutJson);

        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION, false)).thenReturn("emailKey:emailValue,emailValue1");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION, false)).thenReturn("textKey:textValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION, false)).thenReturn("callKey:callValue");
        JSONObject result = handlerHelper.buildPatientSyncObject(patientObject, "deployment1");

        System.out.println(result);
        assertNotNull(result);
        JSONObject patient = result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
        assertEquals("20000101", patient.getString("DOB"));
        assertEquals("12345", patient.getString("ExternalPatientId"));
        assertEquals("DISABLED", patient.getString("EmailNotificationStatus"));
        assertEquals("", patient.getString("TextNotificationStatus"));
        assertEquals("", patient.getString("VoiceNotificationStatus"));
    }

    @Test
    void buildPatientSyncObject_TextNotificationStatus_ENABLED() throws IHubException {
        JSONObject patientObject = new JSONObject();

        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("ExternalPatientId", "12345");
        patientInformation.put("DOB", "01-01-2000");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        patientObject.put("DemographicData", demographicData);

        JSONObject inputJson = new JSONObject();
        inputJson.put(JsonConstants.DEPLOYMENT_ID, "deployment1");
        inputJson.put("temp", new JSONObject().put("patient_id", "12345"));
        JSONObject outputJson = new JSONObject();
        outputJson.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq(""))).thenReturn(outputJson);
        JSONObject prefOutJson = new JSONObject();
        prefOutJson.put("Key", new JSONArray().put(new JSONObject().put("Value", "textValue").put(FIELD_NAME, "textKey")));
        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_PREFERENCE.getKey()), any(), eq(""))).thenReturn(prefOutJson);

        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION, false)).thenReturn("emailKey:emailValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION, false)).thenReturn("textKey:textValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION, false)).thenReturn("callKey:callValue");
        JSONObject result = handlerHelper.buildPatientSyncObject(patientObject, "deployment1");

        System.out.println(result);
        assertNotNull(result);
        JSONObject patient = result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
        assertEquals("20000101", patient.getString("DOB"));
        assertEquals("12345", patient.getString("ExternalPatientId"));
        assertEquals("", patient.getString("EmailNotificationStatus"));
        assertEquals("ENABLED", patient.getString("TextNotificationStatus"));
        assertEquals("", patient.getString("VoiceNotificationStatus"));
    }

    @Test
    void buildPatientSyncObject_TextNotificationStatus_DISABLED() throws IHubException {
        JSONObject patientObject = new JSONObject();

        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("ExternalPatientId", "12345");
        patientInformation.put("DOB", "01-01-2000");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        patientObject.put("DemographicData", demographicData);

        JSONObject inputJson = new JSONObject();
        inputJson.put(JsonConstants.DEPLOYMENT_ID, "deployment1");
        inputJson.put("temp", new JSONObject().put("patient_id", "12345"));
        JSONObject outputJson = new JSONObject();
        outputJson.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq(""))).thenReturn(outputJson);
        JSONObject prefOutJson = new JSONObject();
        prefOutJson.put("Key", new JSONArray().put(new JSONObject().put("Value", "textValue1").put(FIELD_NAME, "textKey")));
        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_PREFERENCE.getKey()), any(), eq(""))).thenReturn(prefOutJson);

        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION, false)).thenReturn("emailKey:emailValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION, false)).thenReturn("textKey:textValue,textValue1");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION, false)).thenReturn("callKey:callValue");
        JSONObject result = handlerHelper.buildPatientSyncObject(patientObject, "deployment1");

        System.out.println(result);
        assertNotNull(result);
        JSONObject patient = result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
        assertEquals("20000101", patient.getString("DOB"));
        assertEquals("12345", patient.getString("ExternalPatientId"));
        assertEquals("", patient.getString("EmailNotificationStatus"));
        assertEquals("DISABLED", patient.getString("TextNotificationStatus"));
        assertEquals("", patient.getString("VoiceNotificationStatus"));
    }

    @Test
    void buildPatientSyncObject_VoiceNotificationStatus_ENABLED() throws IHubException {
        JSONObject patientObject = new JSONObject();

        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("ExternalPatientId", "12345");
        patientInformation.put("DOB", "01-01-2000");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        patientObject.put("DemographicData", demographicData);

        JSONObject inputJson = new JSONObject();
        inputJson.put(JsonConstants.DEPLOYMENT_ID, "deployment1");
        inputJson.put("temp", new JSONObject().put("patient_id", "12345"));
        JSONObject outputJson = new JSONObject();
        outputJson.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq(""))).thenReturn(outputJson);
        JSONObject prefOutJson = new JSONObject();
        prefOutJson.put("Key", new JSONArray().put(new JSONObject().put("Value", "callValue").put(FIELD_NAME, "callKey")));
        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_PREFERENCE.getKey()), any(), eq(""))).thenReturn(prefOutJson);

        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION, false)).thenReturn("emailKey:emailValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION, false)).thenReturn("textKey:textValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION, false)).thenReturn("callKey:callValue");
        JSONObject result = handlerHelper.buildPatientSyncObject(patientObject, "deployment1");

        System.out.println(result);
        assertNotNull(result);
        JSONObject patient = result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
        assertEquals("20000101", patient.getString("DOB"));
        assertEquals("12345", patient.getString("ExternalPatientId"));
        assertEquals("", patient.getString("EmailNotificationStatus"));
        assertEquals("", patient.getString("TextNotificationStatus"));
        assertEquals("ENABLED", patient.getString("VoiceNotificationStatus"));
    }

    @Test
    void buildPatientSyncObject_VoiceNotificationStatus_DISABLED() throws IHubException {
        JSONObject patientObject = new JSONObject();

        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("ExternalPatientId", "12345");
        patientInformation.put("DOB", "01-01-2000");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        patientObject.put("DemographicData", demographicData);

        JSONObject inputJson = new JSONObject();
        inputJson.put(JsonConstants.DEPLOYMENT_ID, "deployment1");
        inputJson.put("temp", new JSONObject().put("patient_id", "12345"));
        JSONObject outputJson = new JSONObject();
        outputJson.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq(""))).thenReturn(outputJson);
        JSONObject prefOutJson = new JSONObject();
        prefOutJson.put("Key", new JSONArray().put(new JSONObject().put("Value", "callValue1").put(FIELD_NAME, "callKey")));
        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_PREFERENCE.getKey()), any(), eq(""))).thenReturn(prefOutJson);

        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION, false)).thenReturn("emailKey:emailValue");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION, false)).thenReturn("textKey:textValue,textValue1");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION, false)).thenReturn("callKey:callValue,callValue1");
        JSONObject result = handlerHelper.buildPatientSyncObject(patientObject, "deployment1");

        System.out.println(result);
        assertNotNull(result);
        JSONObject patient = result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
        assertEquals("20000101", patient.getString("DOB"));
        assertEquals("12345", patient.getString("ExternalPatientId"));
        assertEquals("", patient.getString("EmailNotificationStatus"));
        assertEquals("", patient.getString("TextNotificationStatus"));
        assertEquals("DISABLED", patient.getString("VoiceNotificationStatus"));
    }
    @Test
    void GetPreferenceKeyAndValueReturnsCorrectValue() throws IHubException {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenReturn("key:value");

        String result = handlerHelper.GetPreferenceKeyAndValue("configType", "deployment1");

        assertEquals("key:value", result);
    }

    @Test
    void GetPreferenceKeyAndValueHandlesException() throws IHubException {
        when(dataCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean())).thenThrow(new RuntimeException("Error"));

        String result = handlerHelper.GetPreferenceKeyAndValue("configType", "deployment1");

        assertEquals("", result);
    }


    @Test
    void handlePhoneNumber_ValidDOB_FormatsDOB() throws Exception {
        JSONObject json = new JSONObject();
        json.put("DOB", "01-01-2000");

        try (
                MockedStatic<PhoneNumberUtils> phoneMock = mockStatic(PhoneNumberUtils.class);
                MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class);
                MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class)
        ) {
            phoneMock.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any(JSONObject.class))).thenAnswer(invocation -> null);
            jsonUtilsMock.when(() -> JsonUtils.getValue(any(JSONObject.class), any())).thenReturn("01-01-2000");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString())).thenReturn("20000101");
            jsonUtilsMock.when(() -> JsonUtils.setValue(any(JSONObject.class), any(), any())).thenAnswer(invocation -> {
                JSONObject obj = invocation.getArgument(0);
                obj.put("DOB", Optional.ofNullable(invocation.getArgument(2)));
                return null;
            });

            Method method = HandlerHelper.class.getDeclaredMethod("handlePhoneNumber", JSONObject.class);
            method.setAccessible(true);
            JSONObject result = (JSONObject) method.invoke(null, json);

            assertTrue(true);
        }
    }

    @Test
    void handlePhoneNumber_InvalidDOB_LogsError() throws Exception {
        JSONObject json = new JSONObject();
        json.put("DOB", "invalid-date");

        try (
                MockedStatic<PhoneNumberUtils> phoneMock = mockStatic(PhoneNumberUtils.class);
                MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class);
                MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class)
        ) {
            phoneMock.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any(JSONObject.class))).thenAnswer(invocation -> null);
            jsonUtilsMock.when(() -> JsonUtils.getValue(any(JSONObject.class), any())).thenReturn("invalid-date");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString())).thenThrow(new RuntimeException("Invalid date"));

            Method method = HandlerHelper.class.getDeclaredMethod("handlePhoneNumber", JSONObject.class);
            method.setAccessible(true);
            JSONObject result = (JSONObject) method.invoke(null, json);

            assertEquals("invalid-date", result.getString("DOB"));
        }
    }

    @Test
    void handlePhoneNumber_ValidDOB_FormatsDOB_IhubException() throws Exception {
        JSONObject json = new JSONObject();
        json.put("DOB", "01-01-2000");

        try (
                MockedStatic<PhoneNumberUtils> phoneMock = mockStatic(PhoneNumberUtils.class);
                MockedStatic<JsonUtils> jsonUtilsMock = mockStatic(JsonUtils.class);
                MockedStatic<DateUtils> dateUtilsMock = mockStatic(DateUtils.class)
        ) {
            phoneMock.when(() -> PhoneNumberUtils.handlePhoneNumbersE2D(any(JSONObject.class))).thenThrow(new IHubException(null, "error"));
            jsonUtilsMock.when(() -> JsonUtils.getValue(any(JSONObject.class), any())).thenReturn("01-01-2000");
            dateUtilsMock.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString())).thenReturn("20000101");
            jsonUtilsMock.when(() -> JsonUtils.setValue(any(JSONObject.class), any(), any())).thenAnswer(invocation -> {
                JSONObject obj = invocation.getArgument(0);
                obj.put("DOB", Optional.ofNullable(invocation.getArgument(2)));
                return null;
            });

            Method method = HandlerHelper.class.getDeclaredMethod("handlePhoneNumber", JSONObject.class);
            method.setAccessible(true);
            JSONObject result = (JSONObject) method.invoke(null, json);

            assertTrue(true);
        }
    }

    @Test
    void buildPatientSyncObject_IhubException() throws IHubException {
        JSONObject patientObject = new JSONObject();

        JSONObject demographicData = new JSONObject();
        JSONObject patientInformation = new JSONObject();
        patientInformation.put("ExternalPatientId", "12345");
        patientInformation.put("DOB", "01-01-2000");
        demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
        patientObject.put("DemographicData", demographicData);

        JSONObject inputJson = new JSONObject();
        inputJson.put(JsonConstants.DEPLOYMENT_ID, "deployment1");
        inputJson.put("temp", new JSONObject().put("patient_id", "12345"));
        JSONObject outputJson = new JSONObject();
        outputJson.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(), eq(""))).thenReturn(outputJson);
        JSONObject prefOutJson = new JSONObject();
        prefOutJson.put("Key", new JSONArray().put(new JSONObject().put("Value", "emailValue").put(FIELD_NAME, "emailKey")));
        when(allscriptsApiCaller.call(eq("deployment1"), eq(ApiName.GET_PATIENT_PREFERENCE.getKey()), any(), eq(""))).thenThrow(new IHubException(null, "error"));

        lenient().when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION, false)).thenReturn("emailKey:emailValue");
        lenient().when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION, false)).thenReturn("textKey:textValue");
        lenient().when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION, false)).thenReturn("callKey:callValue");
        JSONObject result = handlerHelper.buildPatientSyncObject(patientObject, "deployment1");

        System.out.println(result);
        assertNotNull(result);
        JSONObject patient = result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0);
        assertEquals("20000101", patient.getString("DOB"));
        assertEquals("12345", patient.getString("ExternalPatientId"));
    }
}