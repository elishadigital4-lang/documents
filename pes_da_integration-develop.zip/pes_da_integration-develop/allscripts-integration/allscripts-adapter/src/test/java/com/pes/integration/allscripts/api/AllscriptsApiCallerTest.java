package com.pes.integration.allscripts.api;


import com.google.gson.JsonObject;
import com.pes.integration.allscripts.component.AllscriptsClientCaller;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.thoughtworks.xstream.io.xml.XppReader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.allscripts.api.AllscriptsApiCaller.trim;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.ERROR;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.POST;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AllscriptsApiCallerTest {

    String deploymentId = "deployment1";
    String svcUsername = "svcUsername";
    String svcPassword = "svcPassword";
    String appName = "appName";
    String pmUsername = "pmUsername";
    String pmPassword = "pmPassword";
    String baseUrl = "http://base.url";
    String unityService = "/unityService";
    String tokenUrl = baseUrl + unityService + "/GetToken";
    @Mock
    private DataCacheManager cacheManager;
    @Mock
    private RedisService redisService;
    @Mock
    private AllscriptsClientCaller allscriptsClientCaller;
    @Mock
    private AllscriptApi allscriptApi;
    @InjectMocks
    private AllscriptsApiCaller allscriptsApiCaller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void callApi_AddsFilterXmlToParameters_WhenApiIsGetAppointmentsByChangedDttm() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(URL, GETAPPOINTMENTSBYCHANGEDTTM);

        JSONObject filterObj = new JSONObject();
        filterObj.put("field1", "value1");
        filterObj.put("field2", "value2");

        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "deployment1");
        requestObject.put(FILTER, filterObj);

        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("http://base.url");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("/unityService");

        when(redisService.get(anyString())).thenReturn("token");
        when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenReturn("{\"key\":\"value\"}");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        Object result = method.invoke(allscriptsApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertTrue(result instanceof JSONObject);
        assertEquals("value", ((JSONObject) result).getString("key"));
        // Optionally, verify that PARAMETER_6 contains the XML string
    }

    @Test
    void initializeObjectSetsCorrectConfigurations() throws IHubException {
        JSONObject mockRuestConfig = new JSONObject();
        JSONObject mockRuestMapping = new JSONObject();
        JSONObject mockResponseMapping = new JSONObject();

        when(cacheManager.getStoredComponentConfig((EPM_NAME_PREFIX), (ALLSCRIPTS_CONFIG), (REQUEST_CONFIG_KEY_NAME), (false)))
                .thenReturn(mockRuestConfig);
        when(cacheManager.getStoredComponentConfig((EPM_NAME_PREFIX), (ALLSCRIPTS_CONFIG), (REQUEST_CONFIG_KEY_NAME), (false)))
                .thenReturn(mockRuestMapping);
        when(cacheManager.getStoredComponentConfig((EPM_NAME_PREFIX), (ALLSCRIPTS_CONFIG), (REQUEST_CONFIG_KEY_NAME), (false)))
                .thenReturn(mockResponseMapping);

        Assertions.assertDoesNotThrow(() -> allscriptsApiCaller.initializeObject("deploymentId"));

    }

    @Test
    void getMappingConfig() throws IHubException {
        JSONObject mockRuestConfig = new JSONObject();
        JSONObject mockRuestMapping = new JSONObject();
        JSONObject mockResponseMapping = new JSONObject();

        when(cacheManager.getStoredComponentConfig((EPM_NAME_PREFIX), (ALLSCRIPTS_CONFIG), (REQUEST_CONFIG_KEY_NAME), (false)))
                .thenReturn(mockRuestConfig);
        when(cacheManager.getStoredComponentConfig((EPM_NAME_PREFIX), (ALLSCRIPTS_CONFIG), (REQUEST_CONFIG_KEY_NAME), (false)))
                .thenReturn(mockRuestMapping);
        when(cacheManager.getStoredComponentConfig((EPM_NAME_PREFIX), (ALLSCRIPTS_CONFIG), (REQUEST_CONFIG_KEY_NAME), (false)))
                .thenReturn(mockResponseMapping);

        Assertions.assertDoesNotThrow(() -> allscriptsApiCaller.getMappingConfig("deploymentId"));

    }

    @Test
    void apiCallerReturnsCorrectAllscriptApi() throws IHubException {


        when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn(svcUsername);
        when(cacheManager.getConfiguration((EPM_NAME_PREFIX), (deploymentId), (ALLSCRIPTS_CONFIG), (SVC_PASSWORD))).thenReturn(svcPassword);
        when(cacheManager.getConfiguration((EPM_NAME_PREFIX), (deploymentId), (ALLSCRIPTS_CONFIG), (APP_NAME))).thenReturn(appName);
        when(cacheManager.getConfiguration((EPM_NAME_PREFIX), (deploymentId), (ALLSCRIPTS_CONFIG), (PM_USERNAME))).thenReturn(pmUsername);
        when(cacheManager.getConfiguration((EPM_NAME_PREFIX), (deploymentId), (ALLSCRIPTS_CONFIG), (PM_PASSWORD))).thenReturn(pmPassword);
        when(cacheManager.getConfiguration((EPM_NAME_PREFIX), (deploymentId), (ALLSCRIPTS_CONFIG), (UNITY_END_POINT))).thenReturn(baseUrl);
        when(cacheManager.getConfiguration((EPM_NAME_PREFIX), (deploymentId), (ALLSCRIPTS_CONFIG), (UNIT_SERVICE))).thenReturn(unityService);

        AllscriptApi result = allscriptsApiCaller.apiCaller(deploymentId);

        assertNotNull(result);
        assertEquals(deploymentId, result.getDeploymentId());
        assertEquals(tokenUrl, result.getTokenUrl());
        assertEquals(svcUsername, result.getSvcUsername());
        assertEquals(svcPassword, result.getSvcPassword());
        assertEquals(appName, result.getAppname());
        assertEquals(pmUsername, result.getPmUsername());
        assertEquals(pmPassword, result.getPmPassword());
        assertEquals(baseUrl, result.getBaseUrl());
        assertEquals(unityService, result.getUnityService());
    }

    @Test
    void customizeResponseMapping() {
        JSONObject result = allscriptsApiCaller.customizeResponseMapping(new JSONObject(), "apiName", "deploymentId");
        assertNull(result);
    }

    @Test
    void callApi_SuccessfulResponse() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(URL, "apiName");

        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "deployment1");

        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("http://base.url");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("/unityService");

        lenient().when(redisService.get(anyString())).thenReturn("token");
        lenient().when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenReturn("{\"key\":\"value\"}");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);
        try {

            Object result = method.invoke(allscriptsApiCaller, apiConfig, requestObject);
        } catch (Exception e) {
            assertTrue(true);
        }
    }

    @Test
    void callApi_ExpiredToken() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(URL, "apiName");

        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "deployment1");

        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("http://base.url");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("/unityService");

        when(redisService.get(anyString())).thenReturn("expiredToken");
        when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenReturn("Expired Token");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        Object result = method.invoke(allscriptsApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertTrue(result instanceof JSONObject);
        assertEquals("Expired Token", ((JSONObject) result).getString("ErrorMessage"));
    }

    @Test
    void callApi_InvalidToken() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(URL, "apiName");

        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "deployment1");

        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("http://base.url");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("/unityService");

        when(redisService.get(anyString())).thenReturn("invalidToken");
        when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenReturn("Invalid Token");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        Object result = method.invoke(allscriptsApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertTrue(result instanceof JSONObject);
        assertEquals("Invalid Token", ((JSONObject) result).getString("ErrorMessage"));
    }

    @Test
    void callApi_ExceptionScenario() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(URL, "apiName");

        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "deployment1");

        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("http://base.url");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("/unityService");

        lenient().when(redisService.get(anyString())).thenReturn("token");
        lenient().when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenThrow(new RuntimeException("Test Exception"));

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        assertThrows(InvocationTargetException.class, () -> {
            method.invoke(allscriptsApiCaller, apiConfig, requestObject);
        });


    }


    @Test
    void getUserAuthenticationValidatesUserSuccessfully() throws IHubException {
        AllscriptApi allscriptApi = mock(AllscriptApi.class);
        String token = "validToken";
        String response = "[{\"getuserauthenticationinfo\":[{\"ValidUser\":\"YES\",\"ErrorMessage\":\"\"}]}]";

        when(allscriptApi.getPmPassword()).thenReturn("pmPassword");
        when(allscriptApi.getBaseUrl()).thenReturn("http://base.url");
        when(allscriptApi.getUnityService()).thenReturn("/unityService");
        when(allscriptsClientCaller.getData(eq(POST), anyString(), anyString())).thenReturn(response);

        allscriptsApiCaller.getUserAuthentication(allscriptApi, token);

        verify(allscriptsClientCaller, times(1)).getData(eq(POST), anyString(), anyString());
    }

    @Test
    void getUserAuthenticationThrowsExceptionForInvalidUser() throws IHubException {
        AllscriptApi allscriptApi = mock(AllscriptApi.class);
        String token = "validToken";
        String response = "[{\"getuserauthenticationinfo\":[{\"ValidUser\":\"NO\",\"ErrorMessage\":\"Invalid user\"}]}]";

        when(allscriptApi.getPmPassword()).thenReturn("pmPassword");
        when(allscriptApi.getBaseUrl()).thenReturn("http://base.url");
        when(allscriptApi.getUnityService()).thenReturn("/unityService");
        when(allscriptsClientCaller.getData(eq("POST"), anyString(), anyString())).thenReturn(response);

        IHubException exception = assertThrows(IHubException.class, () -> {
            allscriptsApiCaller.getUserAuthentication(allscriptApi, token);
        });

        assertEquals("error occurred while authenticating user", exception.getMessage());
    }

    @Test
    void getServerInfoCallsApiSuccessfully() throws IHubException {
        AllscriptApi allscriptApi = mock(AllscriptApi.class);
        String token = "validToken";
        String response = "{\"ServerInfo\":\"Info\"}";

        when(allscriptApi.getBaseUrl()).thenReturn("http://base.url");
        when(allscriptApi.getUnityService()).thenReturn("/unityService");
        when(allscriptsClientCaller.getData(eq(POST), anyString(), anyString())).thenReturn(response);

        allscriptsApiCaller.getServerInfo(allscriptApi, token);

        verify(allscriptsClientCaller, times(1)).getData(eq(POST), anyString(), anyString());
    }

    @Test
    void buildApiReqBodyReturnsCorrectRequestBody() {
        AllscriptApi allscriptApi = mock(AllscriptApi.class);
        String token = "validToken";
        String apiName = "SearchPatients";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("patientID", "12345");
        parameters.put("param2", "value2");
        parameters.put("param3", "value3");
        parameters.put("param4", "value4");
        parameters.put("param5", "value5");
        parameters.put("param6", "value6");

        when(allscriptApi.getAppname()).thenReturn("appName");
        when(allscriptApi.getPmUsername()).thenReturn("pmUsername");

        String requestBody = allscriptsApiCaller.buildApiReqBody(allscriptApi, token, apiName, parameters);

        String expectedJson = "{\"Action\":\"SearchPatients\",\"Appname\":\"appName\",\"AppUserID\":\"pmUsername\",\"PatientID\":\"12345\",\"Token\":\"validToken\",\"Parameter1\":\"<search volume='499'><param5>value5</param5><param6>value6</param6><patientID>12345</patientID><param3>value3</param3><param4>value4</param4><param2>value2</param2></search>\",\"Parameter2\":null,\"Parameter3\":null,\"Parameter4\":null,\"Parameter5\":null,\"Parameter6\":null,\"Data\":\"null\"}";

        assertEquals(expectedJson.toString(), requestBody);
    }

    @Test
    void buildApiReqBodyReturnsCorrectRequestBody_SavePatient() {
        AllscriptApi allscriptApi = mock(AllscriptApi.class);
        String token = "validToken";
        String apiName = "SavePatient";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("patientID", "12345");
        parameters.put("param2", "value2");
        parameters.put("param3", "value3");
        parameters.put("param4", "value4");
        parameters.put("param5", "value5");
        parameters.put("param6", "value6");

        when(allscriptApi.getAppname()).thenReturn("appName");
        when(allscriptApi.getPmUsername()).thenReturn("pmUsername");

        String requestBody = allscriptsApiCaller.buildApiReqBody(allscriptApi, token, apiName, parameters);

        String expectedJson = "{\"Action\":\"SavePatient\",\"Appname\":\"appName\",\"AppUserID\":\"pmUsername\",\"PatientID\":null,\"Token\":\"validToken\",\"Parameter1\":null,\"Parameter2\":\"<patient><param5>value5</param5><param6>value6</param6><patientID>12345</patientID><param3>value3</param3><param4>value4</param4><param2>value2</param2></patient>\",\"Parameter3\":\"value3\",\"Parameter4\":\"value4\",\"Parameter5\":\"value5\",\"Parameter6\":\"value6\",\"Data\":\"null\"}";
        System.out.println(requestBody);
        assertEquals(expectedJson.toString(), requestBody);
    }

    @Test
    void buildApiReqBodyReturnsCorrectRequestBody_SaveAppointment() {
        AllscriptApi allscriptApi = mock(AllscriptApi.class);
        String token = "validToken";
        String apiName = "SaveAppointment";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("patientID", "12345");
        parameters.put("param2", "value2");
        parameters.put("param3", "value3");
        parameters.put("param4", "value4");
        parameters.put("param5", "value5");
        parameters.put("param6", "value6");

        when(allscriptApi.getAppname()).thenReturn("appName");
        when(allscriptApi.getPmUsername()).thenReturn("pmUsername");

        String requestBody = allscriptsApiCaller.buildApiReqBody(allscriptApi, token, apiName, parameters);

        String expectedJson = "{\"Action\":\"SaveAppointment\",\"Appname\":\"appName\",\"AppUserID\":\"pmUsername\",\"PatientID\":\"12345\",\"Token\":\"validToken\",\"Parameter1\":\"<appt><param5>value5</param5><param6>value6</param6><patientID>12345</patientID><param3>value3</param3><param4>value4</param4><param2>value2</param2></appt>\",\"Parameter2\":\"value2\",\"Parameter3\":\"value3\",\"Parameter4\":\"value4\",\"Parameter5\":\"value5\",\"Parameter6\":\"value6\",\"Data\":\"null\"}";
        System.out.println(requestBody);
        assertEquals(expectedJson.toString(), requestBody);
    }

    @Test
    void buildApiReqBodyReturnsCorrectRequestBody_SavePatientPolicy() {
        AllscriptApi allscriptApi = mock(AllscriptApi.class);
        String token = "validToken";
        String apiName = "SavePatientPolicy";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("patientID", "12345");
        parameters.put("param2", "value2");
        parameters.put("param3", "value3");
        parameters.put("param4", "value4");
        parameters.put("param5", "value5");
        parameters.put("param6", "value6");

        when(allscriptApi.getAppname()).thenReturn("appName");
        when(allscriptApi.getPmUsername()).thenReturn("pmUsername");

        String requestBody = allscriptsApiCaller.buildApiReqBody(allscriptApi, token, apiName, parameters);

        String expectedJson = "{\"Action\":\"SavePatientPolicy\",\"Appname\":\"appName\",\"AppUserID\":\"pmUsername\",\"PatientID\":null,\"Token\":\"validToken\",\"Parameter1\":null,\"Parameter2\":null,\"Parameter3\":null,\"Parameter4\":null,\"Parameter5\":null,\"Parameter6\":\"<policy><param5>value5</param5><param6>value6</param6><patientID>12345</patientID><param3>value3</param3><param4>value4</param4><param2>value2</param2></policy>\",\"Data\":\"null\"}";
        System.out.println(requestBody);
        assertEquals(expectedJson.toString(), requestBody);
    }

    @Test
    void getAllscriptApi_ReturnsNewAllscriptApi_WhenApiMapIsNull() throws Exception {
        String deploymentId = "deployment1";
        AllscriptApi expectedApi = new AllscriptApi(deploymentId, "tokenUrl", "svcUsername", "svcPassword", "appName", "pmUsername", "pmPassword", "baseUrl", "unityService", new JSONArray(), null);
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("baseUrl");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("unityService");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getAllscriptApi", String.class);
        method.setAccessible(true);
        AllscriptApi result = (AllscriptApi) method.invoke(allscriptsApiCaller, deploymentId);

        assertNotNull(result);
        assertEquals(expectedApi.getDeploymentId(), result.getDeploymentId());
    }

    @Test
    void buildApiReqBodyReturnsCorrectRequestBody_unknown() {
        String token = "validToken";
        String apiName = "unknown";
        Map<String, String> parameters = new HashMap<>();
        parameters.put("patientID", "12345");
        parameters.put("param2", "value2");
        parameters.put("param3", "value3");
        parameters.put("param4", "value4");
        parameters.put("param5", "value5");
        parameters.put("param6", "value6");

        when(allscriptApi.getAppname()).thenReturn("appName");
        when(allscriptApi.getPmUsername()).thenReturn("pmUsername");

        String requestBody = allscriptsApiCaller.buildApiReqBody(allscriptApi, token, apiName, parameters);

        String expectedJson = "{\"Action\":\"unknown\",\"Appname\":\"appName\",\"AppUserID\":\"pmUsername\",\"PatientID\":null,\"Token\":\"validToken\",\"Parameter1\":null,\"Parameter2\":null,\"Parameter3\":null,\"Parameter4\":null,\"Parameter5\":null,\"Parameter6\":null,\"Data\":\"null\"}";
        System.out.println(requestBody);
        assertEquals(expectedJson.toString(), requestBody);
    }


    @Test
    void validateResponseLogsClientError() throws IHubException {
        String response = "Error: Invalid Token";
        JSONArray clientError = new JSONArray();
        clientError.put("Invalid Token");

        allscriptsApiCaller.validateResponse(response, clientError);
    }

    @Test
    void validateResponseNullClientError() throws IHubException {
        String response = "Error: Invalid Token";
        JSONArray clientError = null;

        allscriptsApiCaller.validateResponse(response, clientError);
    }

    @Test
    void getClientErrorConfig_ExceptionScenario() throws IHubException {
        AllscriptsApiCaller allscriptsApiCaller = new AllscriptsApiCaller();
        DataCacheManager cacheManager = mock(DataCacheManager.class);
        allscriptsApiCaller.cacheManager = cacheManager;

        when(cacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Test Exception"));

        JSONArray result = allscriptsApiCaller.getClientErrorConfig();

        assertNull(result);
    }


    @Test
    void validateResponseDoesNotLogWhenNoClientError() throws IHubException {
        String response = "Success";
        JSONArray clientError = new JSONArray();
        clientError.put("Invalid Token");

        allscriptsApiCaller.validateResponse(response, clientError);
    }

    @Test
    void getStringFromStreamReturnsCorrectString() {
        String expectedString = "This is a test string.";
        InputStream inputStream = new ByteArrayInputStream(expectedString.getBytes());

        String result = allscriptsApiCaller.getStringFromStream(inputStream);

        assertEquals(expectedString, result);
    }

    @Test
    void getStringFromStreamHandlesEmptyStream() {
        InputStream inputStream = new ByteArrayInputStream(new byte[0]);

        String result = allscriptsApiCaller.getStringFromStream(inputStream);

        assertEquals("", result);
    }

    @Test
    void getStringFromStreamHandlesNullStream() {
        InputStream inputStream = null;

        String result = allscriptsApiCaller.getStringFromStream(inputStream);

        assertNull(result);
    }

    @Test
    void sendRequest_CustomNotFoundPatientException() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        AllscriptsClientCaller.CustomNotFoundPatientException exception = Mockito.mock(AllscriptsClientCaller.CustomNotFoundPatientException.class);
        when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenThrow(exception);
        when(exception.getErrorBody()).thenReturn(new JSONObject().put(ERROR, "ERROR MESSAGE"));
        Method method = getMethod("sendRequest", String.class, String.class, String.class);
        String requestBody = (String) method.invoke(allscriptsApiCaller, "http://base.url", "/unityService", "requestBody");
        assertNotNull(requestBody);
        JSONObject jsonObject = new JSONObject(requestBody);
        Assertions.assertEquals("ERROR MESSAGE", jsonObject.getString(ERROR));
    }

    @Test
    void getToken_Exception() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        lenient().when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenThrow(new RuntimeException(ERROR));
        Method method = getMethod("getToken", AllscriptApi.class);
        AllscriptApi allscriptApi = new AllscriptApi();
        allscriptApi.setDeploymentId("deploymentId");
        InvocationTargetException exception = assertThrows(InvocationTargetException.class, () -> method.invoke(allscriptsApiCaller, allscriptApi));
        Throwable cause = exception.getCause();
        assertInstanceOf(IHubException.class, cause);
        assertTrue(cause.getMessage().contains("error occurred in AllscriptsApiCaller, getToken :"));
    }

    @Test
    void refreshToken() throws NoSuchMethodException {
        Method method = getMethod("refreshToken", AllscriptApi.class);
        AllscriptApi allscriptApi = new AllscriptApi();
        allscriptApi.setDeploymentId("deploymentId");
        assertDoesNotThrow(() -> method.invoke(allscriptsApiCaller, allscriptApi));
    }

    @Test
    void getUnityTokenThrowsExceptionForInvalidCredentials() throws NoSuchMethodException {
        // Arrange
        AllscriptApi allscriptApi = new AllscriptApi();
        allscriptApi.setTokenUrl("url");
        allscriptApi.setAppname("appName");
        allscriptApi.setPmUsername("pmUsername");
        allscriptApi.setPmPassword("pmPassword");
        allscriptApi.setToken("token");
        allscriptApi.setDeploymentId("deployment1");
        allscriptApi.setSvcUsername("svcUsername");
        allscriptApi.setSvcPassword("svcPassword");
        allscriptApi.setBaseUrl("http://base.url");
        allscriptApi.setUnityService("/unityService");
        allscriptApi.setClientError(new JSONArray().put("ERROR MESSAGE"));
        String invalidTokenResponse = "error";
        String tokenUrl = "http://base.url/unityService/GetToken";
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("Username", "svcUsername");
        requestBody.addProperty("Password", "svcPassword");

        when(allscriptsClientCaller.generateUnityToken("POST", tokenUrl, requestBody.toString())).thenReturn(invalidTokenResponse);

        Method method = getMethod("getUnityToken", AllscriptApi.class);
        InvocationTargetException exception = assertThrows(InvocationTargetException.class, () -> {
            method.invoke(allscriptsApiCaller, allscriptApi);
        });
        System.out.println(exception.getCause().getMessage());

        assertEquals("Invalid Unity credentials supplied", exception.getCause().getMessage());
    }

    @Test
    void trimThrowsRuntimeExceptionOnIOException() throws IOException {
        BufferedReader reader = mock(BufferedReader.class);
        lenient().when(reader.readLine()).thenThrow(new IOException("Test IOException"));
        Map<String, String> parameters = new HashMap<>();
        String xml;

        xml = allscriptsApiCaller.getXmlPayload("SavePatient", parameters);

        trim(xml);
    }

    @Test
    void unmarshalReturnsCorrectMap() throws Exception {
        String xml = "<map><key1>value1</key1><key2>value2</key2></map>";
        AllscriptsApiCaller.MapEntryConverter converter = new AllscriptsApiCaller.MapEntryConverter();

        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(true);
        XppReader reader = new XppReader(new StringReader(xml), factory.newPullParser());

        Map<String, String> result = (Map<String, String>) converter.unmarshal(reader, null);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("value1", result.get("key1"));
        assertEquals("value2", result.get("key2"));
    }

    private Method getMethod(String name, Class<?>... params) throws NoSuchMethodException {
        Method method = AllscriptsApiCaller.class.getDeclaredMethod(name, params);
        method.setAccessible(true);
        return method;
    }

    @Test
    void getXmlPayloadReturnsNullForUnknownApiName() {
        AllscriptsApiCaller allscriptsApiCaller = new AllscriptsApiCaller();
        Map<String, String> parameters = new HashMap<>();
        String result = allscriptsApiCaller.getXmlPayload("UnknownApiName", parameters);
        assertNull(result);
    }

    @Test
    void getAllscriptApi_returnsFromCache() throws Exception {
        AllscriptsApiCaller caller = new AllscriptsApiCaller();
        String deploymentId = "deployment1";
        AllscriptApi expectedApi = mock(AllscriptApi.class);

        // Set apiMap with a cached value
        Field apiMapField = AllscriptsApiCaller.class.getDeclaredField("apiMap");
        apiMapField.setAccessible(true);
        Map<String, AllscriptApi> apiMap = new HashMap<>();
        apiMap.put(deploymentId, expectedApi);
        apiMapField.set(null, apiMap);

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getAllscriptApi", String.class);
        method.setAccessible(true);
        AllscriptApi result = (AllscriptApi) method.invoke(caller, deploymentId);

        assertSame(expectedApi, result);
    }

    @Test
    void getAllscriptApi_callsApiCallerWhenNotCached() throws Exception {
        AllscriptsApiCaller caller = spy(new AllscriptsApiCaller());
        String deploymentId = "deployment2";
        AllscriptApi expectedApi = mock(AllscriptApi.class);

        // Ensure apiMap does not contain the deploymentId
        Field apiMapField = AllscriptsApiCaller.class.getDeclaredField("apiMap");
        apiMapField.setAccessible(true);
        Map<String, AllscriptApi> apiMap = new HashMap<>();
        apiMapField.set(null, apiMap);

        doReturn(expectedApi).when(caller).apiCaller(deploymentId);

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getAllscriptApi", String.class);
        method.setAccessible(true);
        AllscriptApi result = (AllscriptApi) method.invoke(caller, deploymentId);

        assertSame(expectedApi, result);
        verify(caller, times(1)).apiCaller(deploymentId);
    }

    @Test
    void getToken_returnsCachedToken() throws Exception {
        AllscriptsApiCaller caller = new AllscriptsApiCaller();
        AllscriptApi api = mock(AllscriptApi.class);
        when(api.getDeploymentId()).thenReturn("deployment1");

        RedisService redisService = mock(RedisService.class);
        setField(caller, "redisService", redisService);
        when(redisService.get("allScriptsToken_deployment1")).thenReturn("cachedToken");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getToken", AllscriptApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(caller, api);

        assertEquals("cachedToken", result);
    }

    @Test
    void getToken_createsAndSavesToken() throws Exception {
        AllscriptsApiCaller caller = spy(new AllscriptsApiCaller());
        AllscriptApi api = mock(AllscriptApi.class);
        when(api.getDeploymentId()).thenReturn("deployment2");

        RedisService redisService = mock(RedisService.class);
        setField(caller, "redisService", redisService);
        when(redisService.get("allScriptsToken_deployment2")).thenReturn("");

        lenient().doNothing().when(caller).getUserAuthentication(api, "newToken");
        lenient().doNothing().when(caller).getServerInfo(api, "newToken");
        lenient().doNothing().when(redisService).saveWithTtl("allScriptsToken_deployment2", "newToken", 3600);

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getToken", AllscriptApi.class);
        method.setAccessible(true);
        assertThrows(Exception.class, () ->  method.invoke(caller, api));
    }

    @Test
    void getToken_handlesIHubException() throws Exception {
        AllscriptsApiCaller caller = spy(new AllscriptsApiCaller());
        AllscriptApi api = mock(AllscriptApi.class);
        when(api.getDeploymentId()).thenReturn("deployment3");

        RedisService redisService = mock(RedisService.class);
        setField(caller, "redisService", redisService);
        when(redisService.get("allScriptsToken_deployment3")).thenReturn("");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getToken", AllscriptApi.class);
        method.setAccessible(true);

        Exception ex = assertThrows(Exception.class, () -> method.invoke(caller, api));
        assertTrue(ex.getCause() instanceof IHubException);
    }

    // Helper to set private fields
    private void setField(Object target, String fieldName, Object value) throws Exception {
        java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    void getToken_returnsCachedTokens() throws Exception {
        AllscriptsApiCaller caller = new AllscriptsApiCaller();
        AllscriptApi api = mock(AllscriptApi.class);
        when(api.getDeploymentId()).thenReturn("deployment1");

        RedisService redisService = mock(RedisService.class);
        setField(caller, "redisService", redisService);
        when(redisService.get("allScriptsToken_deployment1")).thenReturn("cachedToken");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getToken", AllscriptApi.class);
        method.setAccessible(true);
        String result = (String) method.invoke(caller, api);

        assertEquals("cachedToken", result);
    }

    @Test
    void getToken_handlesGenericException() throws Exception {
        AllscriptsApiCaller caller = spy(new AllscriptsApiCaller());
        AllscriptApi api = mock(AllscriptApi.class);
        when(api.getDeploymentId()).thenReturn("deployment4");

        RedisService redisService = mock(RedisService.class);
        setField(caller, "redisService", redisService);
        when(redisService.get("allScriptsToken_deployment4")).thenReturn("");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("getToken", AllscriptApi.class);
        method.setAccessible(true);

        Exception ex = assertThrows(InvocationTargetException.class, () -> method.invoke(caller, api));
        assertTrue(ex.getCause() instanceof IHubException);
        assertTrue(ex.getCause().getMessage().contains("error occurred in AllscriptsApiCaller, getToken :"));
    }

    @Test
    void callApi_AddsFilterXmlToParameters() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(URL, GETAPPOINTMENTSBYCHANGEDTTM);

        JSONObject filterObj = new JSONObject();
        filterObj.put("field1", "value1");
        filterObj.put("field2", "value2");

        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "deployment1");
        requestObject.put(FILTER, filterObj);

        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("http://base.url");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("/unityService");

        when(redisService.get(anyString())).thenReturn("token");
        when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenReturn("[{\"message_status\":\"recfromda\",\"deployment_id\":\"747292^0001\"}]");

        Method method = AllscriptsApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
        method.setAccessible(true);

        Object result = method.invoke(allscriptsApiCaller, apiConfig, requestObject);

        assertNotNull(result);
        assertTrue(result instanceof JSONArray);
        // Optionally, verify that PARAMETER_6 contains the XML string
    }

    @Test
    void callApi_AddsFilterXmlToParameters_Exception() throws Exception {
        JSONObject apiConfig = new JSONObject();
        apiConfig.put(URL, GETAPPOINTMENTSBYCHANGEDTTM);

        JSONObject filterObj = new JSONObject();
        filterObj.put("field1", "value1");
        filterObj.put("field2", "value2");

        JSONObject requestObject = new JSONObject();
        requestObject.put(DEPLOYMENT_ID, "deployment1");
        requestObject.put(FILTER, filterObj);

        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_USERNAME)).thenReturn("svcUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, SVC_PASSWORD)).thenReturn("svcPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, APP_NAME)).thenReturn("appName");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_USERNAME)).thenReturn("pmUsername");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, PM_PASSWORD)).thenReturn("pmPassword");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNITY_END_POINT)).thenReturn("http://base.url");
        lenient().when(cacheManager.getConfiguration(EPM_NAME_PREFIX, "deployment1", ALLSCRIPTS_CONFIG, UNIT_SERVICE)).thenReturn("/unityService");

        when(redisService.get(anyString())).thenReturn("token");
        lenient().when(allscriptsClientCaller.getData(anyString(), anyString(), anyString())).thenReturn("[{\"message_status\":\"recfromda\",\"deployment_id\":\"747292^0001\"}]");

        try(MockedStatic<JsonUtils> utilities = Mockito.mockStatic(JsonUtils.class)) {
            utilities.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("deployment1");
            utilities.when(() -> JsonUtils.getMapFromJson(any(JSONObject.class))).thenThrow(new RuntimeException("Test Exception"));

            Method method = AllscriptsApiCaller.class.getDeclaredMethod("callApi", JSONObject.class, JSONObject.class);
            method.setAccessible(true);

            Object result = method.invoke(allscriptsApiCaller, apiConfig, requestObject);

        } catch (Exception e) {
            assertTrue(true);
        }
        // Optionally, verify that PARAMETER_6 contains the XML string
    }
}
