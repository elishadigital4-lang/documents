package com.pes.integration.allscripts.api;

import static java.util.Arrays.stream;

public enum ApiName {

    SET_APPOINTMENT_STATUS("SetAppointmentStatus"),
    GET_INSURANCE_CARRIERS("GetCarriers"),
    CHANGED_APPOINTMENTS("changed_appointments"),
    GET_AVAILABLE_TIME_BLOCKS("get_avilable_time_blocks"),
    GET_USER_AUTHENTICATION("GetUserAuthentication"),
    GET_RESOURCES("get_providers"),
    GET_APPOINTMENT_TYPES("get_appointment_types"),
    NEW_PATIENT("new_patient"),
    GET_PATIENT_DEMOGRAPHICS("get_patient_demographics"),
    GET_SCHEDULING_LOCATIONS("get_locations"),
    CANCEL_APPOINTMENT("cancel_appointment"),
    BOOKED_APPOINTMENTS("booked_appointments"),
    OPEN_APPOINTMENTS("open_appointments"),
    NEW_APPOINTMENT("new_appointment"),
    GET_PATIENT("get_patient"),
    GET_PATIENT_INSURANCE("get_patient_insurance"),
    SET_PATIENT_INSURANCE("set_patient_insurance"),
    UPDATE_PATIENT_PREFERENCE("update_patient_preference"),
    GET_PATIENT_PREFERENCE("get_patient_preference"),
    CHANGED_PATIENTS("changed_patients"),
    GET_SCHEDULE_DAYS_FOR_PROVIDER("get_schedule_days_for_provider"),
    CONFIRM_APPOINTMENT("confirm_appointment"),
    // PROD-62526
    GET_PATIENT_POLICY_PRIMARY_CARE_PROVIDER("get_patient_policy_primary_care_provider");

    String key;

    ApiName(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public ApiName getEnum(String apiName) {
        return stream(values()).filter(api -> api.getKey().equals(apiName)).findFirst().orElse(null);
    }
}
