package com.pes.integration.allscripts.utils;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants.JsonConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;

@Slf4j
@Service
@AllArgsConstructor
public class HandlerHelper {

    @Autowired
    static AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    static DataCacheManager dataCacheManager;

    public static JSONObject buildPatientSyncObject(JSONObject patientObject, String deploymentId) throws IHubException {
        JSONObject inputJson = new JSONObject();
        JSONObject outputJson;
        String patientId = JsonUtils.getValue(patientObject, Key.PATIENT_ID).toString();
        JsonUtils.setValue(inputJson, JsonConstants.DEPLOYMENT_ID, deploymentId);
        JsonUtils.setValue(inputJson, TempKey.PATIENT_ID, patientId);
        outputJson = allscriptsApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), inputJson, "");

        JSONObject prefOutputJson = new JSONObject();
        try {
            prefOutputJson = allscriptsApiCaller.call(deploymentId, ApiName.GET_PATIENT_PREFERENCE.getKey(), inputJson, "");
        } catch (IHubException e) {
            log.error(e.getMessage(), e);
        }

        String isEmailOn = "";
        String isTextOn = "";
        String isCallOn = "";

        if (prefOutputJson.has(KEY)) {
            String emailKeyWithValues = (String) dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX,deploymentId, ALLSCRIPTS_CONFIG, EMAIL_NOTIFICATION,false);
            String textKeyWithValues = (String) dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX,deploymentId, ALLSCRIPTS_CONFIG, TEXT_NOTIFICATION,false);
            String callKeyWithValues = (String) dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, VOICE_NOTIFICATION,false);

            int index = emailKeyWithValues.indexOf(CharacterConstants.COLON);
            String emailKey = StringUtils.substring(emailKeyWithValues, 0, index);
            String emailKeyValues = StringUtils.substring(emailKeyWithValues, index + 1);
            List<String> emailVal = Arrays.asList(emailKeyValues.split(CharacterConstants.COMMA));

            index = textKeyWithValues.indexOf(CharacterConstants.COLON);
            String textKey = StringUtils.substring(textKeyWithValues, 0, index);
            String textKeyValues = StringUtils.substring(textKeyWithValues, index + 1);
            List<String> textVal = Arrays.asList(textKeyValues.split(CharacterConstants.COMMA));

            index = callKeyWithValues.indexOf(CharacterConstants.COLON);
            String callKey = StringUtils.substring(callKeyWithValues, 0, index);
            String callKeyValues = StringUtils.substring(callKeyWithValues, index + 1);
            List<String> callVal = Arrays.asList(callKeyValues.split(CharacterConstants.COMMA));

            JSONArray patientsPrefArray = prefOutputJson.getJSONArray(KEY);
            for (Object preferenceObj : patientsPrefArray) {
                String fieldName = JsonUtils.getValue(preferenceObj, FIELD_NAME).toString();
                String value = JsonUtils.getValue(preferenceObj, VALUE).toString();

                if (emailKey.equalsIgnoreCase(fieldName)) {
                    if (!NullChecker.isEmpty(value) && value.equalsIgnoreCase(emailVal.get(0)))
                        isEmailOn = Key.ENABLED;
                    else if (!NullChecker.isEmpty(value) && value.equalsIgnoreCase(emailVal.get(1)))
                        isEmailOn = Key.DISABLED;
                } else if (textKey.equalsIgnoreCase(fieldName)) {
                    if (!NullChecker.isEmpty(value) && value.equalsIgnoreCase(textVal.get(0)))
                        isTextOn = Key.ENABLED;
                    else if (!NullChecker.isEmpty(value) && value.equalsIgnoreCase(textVal.get(1)))
                        isTextOn = Key.DISABLED;
                } else if (callKey.equalsIgnoreCase(fieldName)) {
                    if (!NullChecker.isEmpty(value) && value.equalsIgnoreCase(callVal.get(0)))
                        isCallOn = Key.ENABLED;
                    else if (!NullChecker.isEmpty(value) && value.equalsIgnoreCase(callVal.get(1)))
                        isCallOn = Key.DISABLED;
                }
            }

            JsonUtils.setValue(outputJson, Key.TEXT_NOTIFICATION_STATUS, isTextOn);
            JsonUtils.setValue(outputJson, Key.EMAIL_NOTIFICATION_STATUS, isEmailOn);
            JsonUtils.setValue(outputJson, Key.VOICE_NOTIFICATION_STATUS, isCallOn);
        }

        outputJson = handlePhoneNumber(outputJson);

        return outputJson;
    }

    private static JSONObject handlePhoneNumber(JSONObject outputJson) {
        try {
            PhoneNumberUtils.handlePhoneNumbersE2D(outputJson);
        } catch (IHubException e) {
            log.error(e.getMessage(), e);
        }

        try {
            String dob = JsonUtils.getValue(outputJson, Key.DOB).toString();
            dob = DateUtils.convertDateFormat(dob, DATE_FORMAT_ALTERNATE, DocASAPConstants.DOCASAP_DATE_FORMAT);
            JsonUtils.setValue(outputJson, Key.DOB, dob);
        } catch (Exception e) {
            log.info("DOB received was invalid or null.");
            log.error(e.getMessage(), e);
        }

        return outputJson;
    }

    public static String GetPreferenceKeyAndValue(String configType, String deploymentId) {
        String keyWithValues = "";
        try {
            keyWithValues = (String)dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, configType,false);
        } catch (Exception e) {
            //intentionally empty
        }
        return keyWithValues;
    }
}