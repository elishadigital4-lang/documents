package com.pes.integration.allscripts.contant;

public class AllscriptsConstants {

    public static final String UNITY_END_POINT = "unityendpoint";
    public static final String UNIT_SERVICE = "unityservice";
    public static final String CLIENT_ERROR = "clientError";
    public static final String APP_NAME = "appname";

    // unity service credentials
    public static final String SVC_USERNAME = "svcusername";
    public static final String SVC_PASSWORD = "svcpassword";

    // valid PM username, used along with token in Magic call
    public static final String PM_USERNAME = "pmusername";
    public static final String PM_PASSWORD = "pmpassword";

    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String DATE_FORMAT_ALTERNATE = "MM-dd-yyyy";

    public static final String DATE_TIME_FORMAT = "MM/dd/yyyy HH:mm:ss";
    public static final String TIME_FORMAT = "hh:mm a";
    public static final String MILITARY_TIME_FORMAT = "HHmm";

    public static final String DATE_TIME_FORMAT_AM_PM = "MM/dd/yyyy hh:mm:ss a";
    public static final String DATE_TIME_FORMAT_AM_PM_WITHOUT_SEC = "MM/dd/yyyy hh:mma";
    public static final Object FALSE = "false";

    public static final String NEXT = "next";
    public static final String APPT_SLOT_DURATION = "5";

    // appointment status codes
    public static final String CODE_CANCELED = "X";
    public static final String CODE_NEW = "S";
    public static final String CODE_RESCHEDULED = "B";
    public static final String CODE_NO_SHOW = "N";

    public static final String BASE_URL = "http://pm.unitysandbox.com/UnityPM/unityservice.svc/json/MagicJson";
    public static final String GET_TOKEN = "/GetToken";
    public static final String MAGIC_JSON =	"/MagicJson";
    public static final String GET_ORG_LAST_SYNC_RUN_TIME = "/org/getOrgLastSyncRunTime";
    public static final String BOOKED_SLOTS1 = "BookedSlots1";
    public static final String BOOKED_SLOTS2 = "BookedSlots2";
    public static final String OPEN_SLOTS1 = "OpenSlots1";
    public static final String OPEN_SLOTS2 = "OpenSlots2";
    public static final String AVAILABLE_SCHEDULE = "AvailableSchedule";
    public static final String APPT_DURATION = "Duration";
    public static final String APPT_TYPES = "AppointmentTypes";
    public static final String UPDATE_TIME = "temp.updateTime";
    public static final String LAST_PULLED ="temp.last_pulled";
    public static final String LAST_CHANGED ="temp.last_changed";

    public static final String BOOKED_STATUS = "booked_status"; //Not sure what all status are booked, will be added here in comma separated value like "S,A,B,W"
    public static final String BOOKED_APPOINTMENT_CHUNK_SIZE = "book_chunk_size";


    public static final String TIME = "Time";
    public static final String START_TIME = "StartTime";

    public static final String DOB_PLUS_2LN_CHARS_MATCH_COUNT =" DOB + First 2 character of LastName Match Count = ";
    public static final String DOB_PLUS_2LN_CHARS_PLUS_MOBILE_PHONE_MATCH_COUNT =" DOB + Last 2 characters+MobilePhone Match Count = ";

    public static final String TEMP_VOLUME = "temp.volume";
    public static final String VOLUME = "499";
    public static final String PATIENT_COUNT_THRESHOLD = "ptnt_count_thres";
    public static final String FOR_DEPLOYMENT_ID = "For deploymentId=";
    public static final String AND_PATIENT_ID = " and PatientId=";
    public static final String FILTER = "filter";
    public static final String STATUS = "DemographicData.PatientInformation[0].Active";
    public static final String KEY = "Key";
    public static final String FIELD_NAME = "FieldName";
    public static final String VALUE ="Value";
    public static final String IS_DEMOGRAPHIC = "isDemographicData";
    public static final String GETAPPOINTMENTSBYCHANGEDTTM = "GetAppointmentsByChangeDTTM";

    public static final String API_CHANGED_APPOINTMENTS = "GetAppointmentsByChangeDTTM";
    public static final String LOCATION_ABBREVIATION = "LocAbbrv";
    public static final String DEPARTMENT_ABBREVIATION = "DeptAbbrv";
    public static final String SCHEDULE_LOCATIONS = "SchedLocations";
    public static final String SCHEDULE_DEPARTMENTS = "SchedDepartments";
    public static final String FILTERS = "filters";
    public static final String SLOT_INTERVAL = "slotInterval";

    private AllscriptsConstants() {
    }

}

