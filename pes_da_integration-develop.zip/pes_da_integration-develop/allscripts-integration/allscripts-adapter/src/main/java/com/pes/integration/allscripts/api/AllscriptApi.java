package com.pes.integration.allscripts.api;

import lombok.*;
import org.json.JSONArray;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class AllscriptApi {

    private String deploymentId;
    private String tokenUrl;
    private String svcUsername;
    private String svcPassword;
    private String appname;
    private String pmUsername;
    private String pmPassword;
    private String baseUrl;
    private String unityService;
    JSONArray clientError;
    String token;
}
