package com.pes.integration.allscripts.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Token {

    @JsonProperty("accessToken")
    private String accessToken;

    @JsonProperty("expiresIn")
    private String expiresIn;
}