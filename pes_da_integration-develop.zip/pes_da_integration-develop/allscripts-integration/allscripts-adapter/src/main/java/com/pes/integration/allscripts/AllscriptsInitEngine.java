package com.pes.integration.allscripts;

import com.pes.integration.adapter.BaseInitEngine;
import com.pes.integration.exceptions.IHubException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.constant.BaseEPMConstants.initialiseEPMConstants;
import static com.pes.integration.constant.UtilitiesConstants.*;


@Slf4j
@Component
public class AllscriptsInitEngine {

    @Autowired
    BaseInitEngine baseInitEngine;

    public void init() {
        String[] configTypes = {GENERIC_CONFIG, ALLSCRIPTS_CONFIG,
                ENVIRONMENT_CONFIG, FILTER_CONFIG};

        initialiseEPMConstants(DATE_FORMAT,
                DATE_TIME_FORMAT,
                TIME_FORMAT,
                BASE_URL,
                TRUE,
                EPM_NAME_PREFIX,
                ALLSCRIPTS_CONFIG,
                RETRY_COUNT,
                REQUEST_MAPPING_KEY_NAME,
                RESPONSE_MAPPING_KEY_NAME,
                REQUEST_CONFIG_KEY_NAME,
                RESPONSE_CODES_MAPPING_KEY_NAME,
                configTypes);
        baseInitEngine.initializeConfig(EPM_NAME_PREFIX, false);
    }
}