package com.pes.integration.allscripts.component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class ConfigCache {

    private static Map<String, ArrayNode> providerMap = new HashMap<>();
    private Map<String, String> syncRunTimeMap = new HashMap<>();
    private Map<String, String> patientSyncRunTimeMap = new HashMap<>();
    private Map<String, String> tokenMap = new HashMap<>();
    private static Map<String, JsonNode> filterDataMap = new HashMap<>();

    public static ArrayNode getProviderMap(String deploymentId) {
        return providerMap.get(deploymentId);
    }

    public void setProviderIdsMap(String deploymentId, ArrayNode providerArray) {
        log.info("Setting provider map for deployment ID: {}", deploymentId);
        providerMap.put(deploymentId, providerArray);
    }

    public String getSyncRunTimeMap(String deploymentId) {
        return syncRunTimeMap.get(deploymentId);
    }

    public void setSyncRunTimeMap(String deploymentId, String syncRunTime) {
        syncRunTimeMap.put(deploymentId, syncRunTime);
    }

    public String getTokenMap(String deploymentId) {
        return tokenMap.get(deploymentId);
    }

    public void setTokenMap(String deploymentId, String token) {
        tokenMap.put(deploymentId, token);
    }

    public String getPatientSyncRunTimeMap(String deploymentId) {
        return patientSyncRunTimeMap.get(deploymentId);
    }

    public void setPatientSyncRunTimeMap(String deploymentId, String syncRunTime) {
        patientSyncRunTimeMap.put(deploymentId, syncRunTime);
    }

    public static JsonNode getFilterDataMap(String deploymentId) {
        return filterDataMap.get(deploymentId);
    }

    public static void setFilterDataMap(String deploymentId, JsonNode filterData) {
        filterDataMap.put(deploymentId, filterData);
    }
}