package com.pes.integration.allscripts.component;

import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.RetryBackoffSpec;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.pes.integration.exceptions.UtilityErrors.INVALID_REQUEST;
import static com.pes.integration.utils.MetricsUtil.metricClientErrorCount;
import static com.pes.integration.utils.MetricsUtil.metricClientSuccessCount;
import static com.pes.integration.utils.MetricsUtil.metricClientRequestCount;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Slf4j
@Component
public class AllscriptsClientCaller {

    @Autowired
    WebClient webClient;
    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;
    public static final List<String> IGNORABLE_ERRORS = Arrays.asList("Invalid Token", "Execution Timeout Expired", "Multiple matching patients detected", "Magic Error - Action");
    public String generateUnityToken(String httpMethod, String url, String body) {
        metricClientRequestCount(engineName, appDescription, httpMethod+" - "+ url);
        return webClient.method(HttpMethod.valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> {
                    if (clientResponse.statusCode().equals(NOT_FOUND)) {
                        return clientResponse.bodyToMono(String.class)
                                .flatMap(errorBody -> Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,"")));
                    } else {
                        return clientResponse.bodyToMono(String.class)
                                .flatMap(errorBody -> {
                                    log.error("Error status code while calling Allscripts Token api is Status code:: {} and errorBody:: {}", clientResponse.statusCode(), errorBody);
                                    metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                                    return Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,""));
                                });
                    }
                })
                .bodyToMono(String.class)
                .doOnError(ex -> {
                    log.error("Error while calling Allscripts Token api with  Error message:: {} ", ex.getMessage());
                })
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                    log.info("Successfully fetched data for Allscripts Token Api for url {} ", url);
                })
                .block();
    }

    public String getData(String httpMethod, String url, String body) {
        metricClientRequestCount(engineName, appDescription, httpMethod+" - "+ url);
        return webClient.method(HttpMethod.valueOf(httpMethod))
                .uri(url)
                .accept(APPLICATION_JSON)
                .contentType(APPLICATION_JSON)
                .body(Mono.just(body), String.class)
                .retrieve()
                .onStatus(HttpStatusCode::isError, clientResponse -> {
                    if (clientResponse.statusCode().equals(NOT_FOUND)) {
                        return clientResponse.bodyToMono(String.class)
                                .flatMap(errorBody -> Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,"")));
                    } else {
                        return clientResponse.bodyToMono(String.class)
                                .flatMap(errorBody -> {
                                    log.error("Error status code while calling Allscripts api is Status code:: {} and errorBody:: {}", clientResponse.statusCode(), errorBody);
                                        metricClientErrorCount(engineName, appDescription, errorBody, String.valueOf(clientResponse.statusCode().value()));
                                    return Mono.error(new IHubException(StatusCodes.EPM_INTERNAL_ERROR, errorBody,""));
                                });
                    }
                })
                .bodyToMono(String.class)
                .doOnError(ex -> {
                    log.error("Error while calling Allscripts api with  Error message:: {} ", ex.getMessage());
                })
                .doOnSuccess(response -> {
                    metricClientSuccessCount(engineName, appDescription, httpMethod+" - "+ url);
                    log.info("Successfully fetched data for Allscripts Api for url {} ", url);
                })
                .block();
    }

    public static class CustomNotFoundPatientException extends RuntimeException {
        private final JSONObject errorBody;

        CustomNotFoundPatientException(String errorBody) {
            super(errorBody);
            try {
                this.errorBody = new JSONObject(errorBody);
            } catch (JSONException e) {
                throw new RuntimeException("Failed to parse error body as JSON: " + errorBody, e);
            }
        }

        public JSONObject getErrorBody() {
            return errorBody;
        }
    }
}