package com.pes.integration.allscripts.utils;


import com.fasterxml.jackson.databind.node.ArrayNode;
import com.pes.integration.allscripts.component.ConfigCache;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.allscripts.factory.AllscriptsHandlerFactoryService;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.allscripts.contant.AllscriptsConstants.DATE_TIME_FORMAT;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.DATE_TIME_FORMAT_AM_PM;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.ALLSCRIPTS_CONFIG;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.PathConstants.GET_ORG_LAST_REALTIME_RUN_TIME;
import static com.pes.integration.constant.UtilitiesConstants.TIME_ZONE;
import static com.pes.integration.enums.HandlerType.GET_PROVIDERS;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.DateUtils.getCurrentDate;

@Slf4j
@Service
@AllArgsConstructor
public class HandlerUtils {

    @Autowired
    static RedisService redisService;

    @Autowired
    static AllscriptsHandlerFactoryService allscriptsHandlerFactoryService;

    public static Object handleLocationDeptIdE2D(Object inputObject) throws IHubException {
        String deptId = JsonUtils.getValue(inputObject, Key.APPT_DEPT_ID).toString();
        String locationId = JsonUtils.getValue(inputObject, Key.APPT_LOCATION_ID).toString();
        JsonUtils.setValue(inputObject, Key.APPT_LOCATION_ID, locationId + CharacterConstants.ATMARK + deptId);
        return inputObject;
    }

    public static Object handleLocationDeptIdD2E(Object inputObject) throws IHubException {
        String concatenatedResourceId = JsonUtils.getValue(inputObject, Key.APPT_LOCATION_ID).toString();
        String[] splitArray = concatenatedResourceId.split(CharacterConstants.ATMARK);
        JsonUtils.setValue(inputObject, Key.APPT_LOCATION_ID, splitArray[0]);
        JsonUtils.setValue(inputObject, Key.APPT_DEPT_ID, splitArray[1]);
        return inputObject;
    }

    public static ArrayNode getProviderIds(String deploymentId, JSONObject inputObject) throws IHubException {
        log.info("Start of getProviderIds()");
        ArrayNode providerIds = ConfigCache.getProviderMap(deploymentId);
        if (NullChecker.isEmpty(providerIds)) {
            JSONObject providerOutputObj = new JSONObject();
            allscriptsHandlerFactoryService.create(GET_PROVIDERS, inputObject, providerOutputObj);
            providerOutputObj.clear();
            providerIds = ConfigCache.getProviderMap(deploymentId);
        }
        return providerIds;
    }

    @SneakyThrows
    public static String getSyncRunTime(DataCacheManager dataCacheManager, IHubDataServiceDelegator iHubDataServiceDelegator, String deploymentId) throws IHubException {
        String syncResponse = iHubDataServiceDelegator.getOrgLastRealTimeRunTime(deploymentId);
        JSONObject newObj = null;
        String lastSyncTime = "";
        String osrid = "";
        if (!NullChecker.isEmpty(syncResponse)) {
            newObj = new JSONObject(syncResponse);
            osrid =  String.valueOf(newObj.get(OSRID));
            lastSyncTime = newObj.getString(SYNC_RUN_TIME);
            log.info("lastSyncTime::{}", lastSyncTime);
        }
        if (NullChecker.isEmpty(osrid)) {
            String timezone = getTimeZone(dataCacheManager,deploymentId);
            lastSyncTime = getCurrentDate(DATE_TIME_FORMAT, timezone, 120);
        }
        String currentPullTime = convertDateFormat(lastSyncTime, DATE_TIME_FORMAT, DATE_TIME_FORMAT_AM_PM);
        String timezone = getTimeZone(dataCacheManager,deploymentId);
        String nextPullTime = getCurrentDate(DATE_TIME_FORMAT, timezone, -5);
        log.info("current pull time {} next pull time: {} ::deploymentId:: {}", currentPullTime, nextPullTime, deploymentId);

        JSONObject reqObj = new JSONObject();
        reqObj.put(DEPLOYMENT_ID, deploymentId);
        reqObj.put(SYNC_RUN_TIME, nextPullTime);
        reqObj.put(OSRID, osrid);
        iHubDataServiceDelegator.addUpdateOrgLastRealTimeRunTime(reqObj.toString());
        return currentPullTime;
    }

    private static String getSyncTimeFromRedis(String deploymentId, String lastSyncTime) {
        try {
            lastSyncTime = redisService.get(deploymentId);
            log.info("last patient sync time reading from redis cache ::{}", lastSyncTime);
        } catch (Exception e) {
            log.error("Error while fetching sync time from Redis", e);
        }
        return lastSyncTime;
    }

    public static String getPatientSyncRunTime(DataCacheManager dataCacheManager, String deploymentId) throws IHubException {
        String lastSyncTime = null;
        try {
            lastSyncTime = getSyncTimeFromRedis(deploymentId, lastSyncTime);
            lastSyncTime = prepareDateAndTime(dataCacheManager,deploymentId, lastSyncTime);
        } catch (Exception e) {
            log.error("Error in getting next patient sync run time", e);
        }
        log.info("End of getPatientSyncRunTime()");
        return lastSyncTime;
    }

    private static String prepareDateAndTime(DataCacheManager dataCacheManager,String deploymentId, String lastSyncTime)
            throws IHubException, ParseException {
        String timezone;
        if (NullChecker.isEmpty(lastSyncTime)) {
            log.info("last patient sync time not found in redis cache.");
            deploymentId = deploymentId.split("_")[0];
            timezone = HandlerUtils.getTimeZone(dataCacheManager,deploymentId);
            if (NullChecker.isEmpty(lastSyncTime)) {
                lastSyncTime = getCurrentDateMinus2Mins(lastSyncTime, timezone);
                log.info("Hence preparing it as current date time with 2 min back  :: {}", lastSyncTime);
            }
        }
        lastSyncTime = convertDateFormat(lastSyncTime, DATE_TIME_FORMAT, DATE_TIME_FORMAT_AM_PM);
        return lastSyncTime;
    }

    private static String getCurrentDateMinus2Mins(String lastSyncTime, String timezone) {
        try {
            lastSyncTime = DateUtils.getCurrentDateWithMinusMin(DATE_TIME_FORMAT, timezone, 2);
        } catch (Exception e) {
            log.error("Error while getting current date minus 2 minutes", e);
        }
        return lastSyncTime;
    }

    public static String getTimeZone(DataCacheManager dataCacheManager,String deploymentId) {
        String timeZone = "";
        try {
            timeZone = (String) dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, TIME_ZONE,false);
        } catch (IHubException e) {
            log.error("Error in fetching timezone for deploymentId {}", deploymentId, e);
        }
        return timeZone;
    }
}