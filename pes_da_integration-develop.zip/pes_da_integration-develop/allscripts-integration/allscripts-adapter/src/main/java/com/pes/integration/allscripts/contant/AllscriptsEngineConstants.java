package com.pes.integration.allscripts.contant;

public class AllscriptsEngineConstants {

    public static final String EPM_NAME_PREFIX = "al";
    public static final String ALLSCRIPTS_CONFIG = "allscriptsprop";
    public static final String BLANK = "";
    public static final String RETRY_COUNT = "retrycount";
    public static final String DOT = ".";
    public static final String SLASHED_DOT = "\\.";
    public static final String EMPTY_BRACKET = "[]";
    public static final String BRACKET_START = "[";
    public static final String ZERO_BRACKET = "[0]";
    public static final String URL = "url";
    public static final String METHOD = "method";
    public static final String FORWARD_SLASH = "/";
    public static final String COLON = ":";
    public static final String BRACKET_END = "]";
    public static final String SLASHED_BRACKET_END = "\\]";
    public static final String SLASHED_BRACKET_START = "\\[";
    public static final int BASELINE_START_DAYS_DEFAULT = 1;
    public static final int BASELINE_END_DAYS_DEFAULT = 15;
    public static final int BASELINE_CHUNK_SIZE_DEFAULT = 1;

    public static final String REQUEST_MAPPING_FILE_NAME = "allscripts_request_mapping.json";
    public static final String RESPONSE_MAPPING_FILE_NAME = "allscripts_response_mapping.json";
    public static final String RESPONSE_CODES_MAPPING_FILE_NAME = "allscripts_response_codes_mapping.json";
    public static final String REQUEST_MAPPING_KEY_NAME = "al_req_map";

    public static final String RESPONSE_MAPPING_KEY_NAME = "al_res_map";
    public static final String REQUEST_CONFIG_KEY_NAME = "al_req_conf";
    public static final String RESPONSE_CODES_MAPPING_KEY_NAME = "al_res_codes";
    public static final String BS_START_TIME = " 00:00:00";
    public static final String BS_END_TIME = " 23:59:00";
    public static final String BS_SLOT_INTERVAL = "slot_interval";

    public static final String EMAIL_NOTIFICATION = "email_notif";
    public static final String TEXT_NOTIFICATION = "text_notif";

    public static final String PROVIDER_CHUNK_SIZE = "prov_chunk_size";
    public static final String PATIENT_CUSTOM_FIELD= "patCustomField";
    public static final String RUN_REALTIME_BY_FILTER = "realt_by_fil";
    public static final String DA_SPECIALITY_MAP = "da_speciality_map";
    public static final String DA_SPECIALITY = "specialty";
    public static final String DA_MATCHED_PROVIDERS="MatchedProviders";
    public static final String VOICE_NOTIFICATION = "voice_notif";

    public static final String PARAMETER_1 = "Parameter1";
    public static final String PARAMETER_2 = "Parameter2";
    public static final String PARAMETER_3 = "Parameter3";
    public static final String PARAMETER_4 = "Parameter4";
    public static final String PARAMETER_5 = "Parameter5";
    public static final String PARAMETER_6 = "Parameter6";

    public static final String AUTHENTICATION_FAILED = "Authentication failed in Allscript : ";
    public static final String INPUT_OBJ = " inputObject::";
    public static final String POLICY_ID = " PolicyId:";
    public static final String PROVIDER_ID = " ProviderId:";
    public static final String BUT_RECEIVED_IS = ", but received is ";
    public static final String EFF_DATE_MUST_BE_BEFORE_SYS_DATE = "Effective Date must be before sysdate ";
    public static final String PATIENT_POLICY_ID = "PatientPolicyId:";
    public static final String MATCHING_FAILED_NOTES = "matching_failed_notes";

    private AllscriptsEngineConstants() {
    }
}
