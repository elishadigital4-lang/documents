package com.pes.integration.allscripts.api;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.allscripts.component.AllscriptsClientCaller;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.allscripts.contant.AllscriptsEngineConstants;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.naming.NoNameCoder;
import com.thoughtworks.xstream.io.xml.DomDriver;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.Charset;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.POST;
import static com.pes.integration.exceptions.UtilityErrors.*;
import static com.pes.integration.jsonmapper.JsonUtils.getMapFromJson;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;


@Slf4j
@Service
public class AllscriptsApiCaller extends BaseApiCaller {

    public static final String ERROR_OCCURRED_WHILE_CALLING_CLIENT_API = "Error occurred while calling client api -";
    public static final String WITH_ERROR_MESSAGE = " with error message ";
    private static Map<String, AllscriptApi> apiMap = new HashMap<>();

    @Autowired
    AllscriptsClientCaller allscriptsClientCaller;

    @Autowired
    DataCacheManager cacheManager;

    @Autowired
    RedisService redisService;


    public void initializeObject(String deploymentId) throws IHubException {
        //TODO  onboarding functionality is pending
        requestConfig = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, ALLSCRIPTS_CONFIG,
                REQUEST_CONFIG_KEY_NAME, false);
        requestMapping = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, ALLSCRIPTS_CONFIG,
                REQUEST_MAPPING_KEY_NAME, false);
        responseMapping = (JSONObject) cacheManager.getStoredComponentConfig(
                EPM_NAME_PREFIX, ALLSCRIPTS_CONFIG,
                RESPONSE_MAPPING_KEY_NAME, false);

    }

    private AllscriptApi getAllscriptApi(String deploymentId) throws IHubException {
        AllscriptApi allscriptApi = apiMap.getOrDefault(deploymentId, null);
        if (Objects.isNull(allscriptApi)) {
            return apiCaller(deploymentId);
        }
        return allscriptApi;
    }

    public AllscriptApi apiCaller(String deploymentId) throws IHubException {
        String svcUsername = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, SVC_USERNAME);
        String svcPassword = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, SVC_PASSWORD);
        String appName = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, APP_NAME);
        String pmUsername = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, PM_USERNAME);
        String pmPassword = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, PM_PASSWORD);
        String baseUrl = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, UNITY_END_POINT);
        String unityService = cacheManager.getConfiguration(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, UNIT_SERVICE);
        String tokenUrl = new StringBuilder(baseUrl).append(unityService).append(GET_TOKEN).toString();
        AllscriptApi allscriptApi = new AllscriptApi(deploymentId, tokenUrl, svcUsername, svcPassword, appName, pmUsername, pmPassword, baseUrl, unityService, getClientErrorConfig(), null);
        apiMap.put(deploymentId, allscriptApi);
        return allscriptApi;
    }


    @Override
    public void getMappingConfig(String deploymentId) throws IHubException {
        initializeObject(deploymentId);
    }

    @Override
    protected JSONObject customizeResponseMapping(JSONObject apiResponseMapping, String apiName, Object inputObject) {
        return null;
    }

    @Override
    protected Object callApi(JSONObject apiConfig, JSONObject requestObject) throws IHubException {
        String apiName = apiConfig.getString(URL);
        String method = POST;
        String deploymentId = getValue(requestObject, DEPLOYMENT_ID).toString();
        AllscriptApi allscriptApi = getAllscriptApi(deploymentId);
        String token = getToken(allscriptApi);
        requestObject.remove(DEPLOYMENT_ID);
        String url = allscriptApi.getBaseUrl().concat(allscriptApi.getUnityService()).concat(MAGIC_JSON);
        Object responseObject = null;
        try {
            Map<String, String> parameters = getMapFromJson(requestObject);
            if (apiName.equalsIgnoreCase(GETAPPOINTMENTSBYCHANGEDTTM) && requestObject.has(FILTER)) {
                JSONObject filterObj = requestObject.getJSONObject(FILTER);
                String filterXml = XML.toString(filterObj);
                parameters.put(PARAMETER_6, filterXml);
            }
            String requestData = buildApiReqBody(allscriptApi, token, apiName, parameters);
            String response = sendRequest(url, method, requestData);
            validateResponse(response, allscriptApi.getClientError());
            if (GETAPPOINTMENTSBYCHANGEDTTM.equalsIgnoreCase(apiName) && !response.contains("getappointmentsbychangedttminfo")) {
                log.info("GETAPPOINTMENTSBYCHANGEDTTM Request:: " + requestData);
            }
            if (response.contains("Expired Token") || response.contains("inactivity") || response.contains("Invalid Token")) {
                log.info("Expired Token/Inactivity:: " + response);
                refreshToken(allscriptApi);
                token = getToken(allscriptApi);
                requestData = buildApiReqBody(allscriptApi, token, apiName, parameters);
                response = sendRequest(url, method, requestData);
            }
            try {
                Object json = new JSONTokener(response).nextValue();
                if (json instanceof JSONArray) {
                    responseObject = new JSONArray(json.toString());
                } else {
                    responseObject = new JSONObject(json.toString());
                }
            } catch (JSONException e) {
                responseObject = new JSONObject();
                ((JSONObject) responseObject).accumulate("ErrorMessage", response);
                log.info("response conversion failed in Allscripts ");
            }
        } catch (IHubException ihe) {
            String errorMessage = ERROR_OCCURRED_WHILE_CALLING_CLIENT_API + " " + url + WITH_ERROR_MESSAGE + ihe.getMessage();
            log.error(errorMessage);
            throw ihe;
        } catch (Exception e) {
            String errorMessage = "error occurred in AllscriptsApiCaller, callApi : " + e.getMessage();
            log.error(errorMessage);
            throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, "error occurred in AllscriptsApiCaller, callApi : ", e.getMessage());
        }
        return responseObject;
    }

    private String sendRequest(String url, String method, String requestData) throws IHubException {
        try {
            return allscriptsClientCaller.getData(method, url, requestData);
        } catch (Exception e) {
            if (e instanceof AllscriptsClientCaller.CustomNotFoundPatientException) {
                AllscriptsClientCaller.CustomNotFoundPatientException customException = (AllscriptsClientCaller.CustomNotFoundPatientException) e;
                JSONObject errorBody = customException.getErrorBody();
                return errorBody.toString();
            }
            throw new IHubException(e, StatusCodes.EPM_INTERNAL_ERROR, e.getMessage(), "");
        }
    }


    private String getToken(AllscriptApi allscriptApi) throws IHubException {
        String tokenKey = "allScriptsToken_".concat(allscriptApi.getDeploymentId());
        String token = redisService.get(tokenKey);
        try {
            if (StringUtils.isEmpty(token)) {
                token = getUnityToken(allscriptApi);
                getUserAuthentication(allscriptApi, token);
                getServerInfo(allscriptApi, token);
                redisService.saveWithTtl(tokenKey, token, 3600);
            }
        } catch (IHubException ihe) {
            String errorMessage = ERROR_OCCURRED_WHILE_CALLING_CLIENT_API + " " + WITH_ERROR_MESSAGE + ihe.getMessage();
            log.error(errorMessage);
            throw ihe;
        } catch (Exception e) {
            throw new IHubException(StatusCodes.UNABLE_TO_PROCESS_MESSAGE, "error occurred in AllscriptsApiCaller, getToken : ", e.getMessage());
        }
        return token;
    }

    private void refreshToken(AllscriptApi allscriptApi) {
        String tokenKey = "allScriptsToken_".concat(allscriptApi.getDeploymentId());
        redisService.remove(tokenKey);
    }

    private String getUnityToken(AllscriptApi allscriptApi) throws IHubException {
        JsonObject jo = new JsonObject();
        jo.addProperty("Username", allscriptApi.getSvcUsername());
        jo.addProperty("Password", allscriptApi.getSvcPassword());
        String reqBody = jo.toString();
        String url = allscriptApi.getBaseUrl().concat(allscriptApi.getUnityService().concat(GET_TOKEN));
        String unityToken = allscriptsClientCaller.generateUnityToken("POST", url, reqBody);

        if (unityToken.matches((".*not valid.*")) || unityToken.matches((".*Token does not belong to user.*")) || unityToken.matches((".*Error.*"))
                || unityToken.matches((".*error.*"))) { // invalid user credentials
            log.debug("Error in getting token:: {} ", sanitizeForLog(unityToken));
            JSONArray clientError = allscriptApi.getClientError();
            if (clientError != null) {
                for (int i = 0; i < clientError.length(); i++) {
                    if (unityToken.matches(".*" + clientError.getString(i) + ".*")) {
                        throw new IHubException(NO_CONNECTION_ESTABLISHED.getErrorCode(), unityToken);
                    }
                }
            }
            throw new IHubException(StatusCodes.EPM_INTERNAL_ERROR, "Invalid Unity credentials supplied", "");
        }
        return unityToken;

    }

    public void getUserAuthentication(AllscriptApi allscriptApi, String token) throws IHubException {
        Map<String, String> parameters = new HashMap<>();
        parameters.put("Parameter1", allscriptApi.getPmPassword());
        Object requestData = buildApiReqBody(allscriptApi, token, ApiName.GET_USER_AUTHENTICATION.getKey(), parameters);
        String url = allscriptApi.getBaseUrl().concat(allscriptApi.getUnityService().concat(MAGIC_JSON));
        String response = allscriptsClientCaller.getData("POST", url, requestData.toString());
        log.debug("UserAuthentication:: " + response);
        JSONArray respArray = new JSONArray(response);
        String responseString = getValue(respArray, "[0].getuserauthenticationinfo[0].ValidUser").toString();
        String errorMessage = getValue(response, "[0].getuserauthenticationinfo[0].ErrorMessage").toString();
        if (responseString.equals("NO")) {
            log.debug(errorMessage);
            throw new IHubException(StatusCodes.EPM_INTERNAL_ERROR, "error occurred while authenticating user", "");
        }
    }

    public void getServerInfo(AllscriptApi allscriptApi, String token) throws IHubException {
        Map<String, String> parameters = new HashMap<>();
        Object requestData = buildApiReqBody(allscriptApi, token, "GetServerInfo", parameters);
        String url = allscriptApi.getBaseUrl().concat(allscriptApi.getUnityService().concat(MAGIC_JSON));
        String response = allscriptsClientCaller.getData("POST", url, requestData.toString());
        log.debug("ServerInfo:: " + response);
    }

    public String buildApiReqBody(AllscriptApi allscriptApi, String token, String apiName, Map<String, String> parameters) {
        String reqBody = null;
        String xml;
        String patientId = "patientId";
        switch (apiName) {
            case "SearchPatients":
                xml = getXmlPayload(apiName, parameters);
                xml = xml.replaceFirst("search", "search volume='499'");
                try {
                    reqBody = buildReqBody(allscriptApi, token, apiName, parameters.get("patientID"), trim(xml), parameters.get(PARAMETER_2),
                            parameters.get(PARAMETER_3), parameters.get(PARAMETER_4), parameters.get(PARAMETER_5),
                            parameters.get(PARAMETER_6), null);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
                break;
            case "SavePatient":
                xml = getXmlPayload(apiName, parameters);
                try {
                    reqBody = buildReqBody(allscriptApi, token, apiName, parameters.get(patientId), parameters.get("param1"), trim(xml),
                            parameters.get("param3"), parameters.get("param4"), parameters.get("param5"),
                            parameters.get("param6"), null);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
                break;
            case "SaveAppointment":
                xml = getXmlPayload(apiName, parameters);
                try {
                    reqBody = buildReqBody(allscriptApi, token, apiName, parameters.get("patientID"), trim(xml), parameters.get("param2"),
                            parameters.get("param3"), parameters.get("param4"), parameters.get("param5"),
                            parameters.get("param6"), null);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
                break;
            case "SavePatientPolicy":
                xml = getXmlPayload(apiName, parameters);
                try {
                    reqBody = buildReqBody(allscriptApi, token, apiName, parameters.get(patientId), parameters.get("Parameter1"),
                            parameters.get("Parameter2"), parameters.get("Parameter3"), parameters.get("Parameter4"),
                            parameters.get("Parameter5"), trim(xml), null);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
                break;
            default:
                try {
                    reqBody = buildReqBody(allscriptApi, token, apiName, parameters.get(patientId), parameters.get(PARAMETER_1),
                            parameters.get(PARAMETER_2), parameters.get(PARAMETER_3), parameters.get(PARAMETER_4),
                            parameters.get(PARAMETER_5), parameters.get(PARAMETER_6), null);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }
                break;
        }
        return reqBody;
    }

    private String buildReqBody(AllscriptApi allscriptApi, String token, String action, String patientId, String param1, String param2, String param3, String param4,
                                String param5, String param6, byte[] data) {
        Gson gson = new Gson();
        JsonObject requestBody = new JsonObject();
        try {
            requestBody.addProperty("Action", action);
            requestBody.addProperty("Appname", allscriptApi.getAppname());
            requestBody.addProperty("AppUserID", allscriptApi.getPmUsername());
            requestBody.addProperty("PatientID", patientId);
            requestBody.addProperty("Token", token);
            requestBody.addProperty(PARAMETER_1, param1);
            requestBody.addProperty(PARAMETER_2, param2);
            requestBody.addProperty(PARAMETER_3, param3);
            requestBody.addProperty(PARAMETER_4, param4);
            requestBody.addProperty(PARAMETER_5, param5);
            requestBody.addProperty(PARAMETER_6, param6);
            requestBody.addProperty("Data", gson.toJson(data));
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        return requestBody.toString();
    }


    // currently not implemented in common code

    public void validateResponse(String response, JSONArray clientError) throws IHubException {
        if (clientError != null) {
            for (int i = 0; i < clientError.length(); i++) {
                if (response.matches(".*" + clientError.getString(i) + ".*")) {

                    log.info(AllscriptsEngineConstants.AUTHENTICATION_FAILED);
                }
            }
        }
    }

    public JSONArray getClientErrorConfig() {
        JSONArray clientError = null;
        try {
            clientError = (JSONArray) cacheManager.getStoredComponentConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, AllscriptsConstants.CLIENT_ERROR, false);
        } catch (Exception e) {
            log.error("Error in fetching config " + AllscriptsConstants.CLIENT_ERROR + e);
        }
        return clientError;
    }

    public String getStringFromStream(InputStream in) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        String rData = null;

        try {
            int read;
            byte[] next = new byte[256];
            while ((read = in.read(next)) != -1) {
                out.write(next, 0, read);
            }

            byte[] byteArray = out.toByteArray();
            rData = new String(byteArray, Charset.forName("UTF-8"));

        } catch (Exception ex) {
            log.debug("Exception occurred while reading stream: " + ex);
        }
        return rData;
    }

    public static String trim(String input) {
        BufferedReader reader = new BufferedReader(new StringReader(input));
        StringBuilder result = new StringBuilder();
        try {
            String line;
            while ((line = reader.readLine()) != null)
                result.append(line.trim());
            return result.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static class MapEntryConverter implements Converter {
        public boolean canConvert(@SuppressWarnings("rawtypes") Class clazz) {
            return AbstractMap.class.isAssignableFrom(clazz);
        }

        public void marshal(Object value, HierarchicalStreamWriter writer, MarshallingContext context) {
            @SuppressWarnings("rawtypes")
            AbstractMap map = (AbstractMap) value;
            for (Object obj : map.entrySet()) {
                @SuppressWarnings("rawtypes")
                Map.Entry entry = (Map.Entry) obj;
                writer.startNode(entry.getKey().toString());
                writer.setValue(entry.getValue().toString());
                writer.endNode();
            }
        }

        public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
            Map<String, String> map = new HashMap<>();
            while (reader.hasMoreChildren()) {
                reader.moveDown();
                map.put(reader.getNodeName(), reader.getValue());
                reader.moveUp();
            }
            return map;
        }
    }

    public String getXmlPayload(String apiName, Map<?, ?> parameters) {
        XStream magicApi = new XStream(new DomDriver("UTF_8", new NoNameCoder()));
        if (apiName.equals("SavePatient")) {
            magicApi.alias("patient", Map.class);
        } else if (apiName.equals("SearchPatients")) {
            magicApi.alias("search", Map.class);
        } else if (apiName.equals("SaveAppointment")) {
            magicApi.alias("appt", Map.class);
        } else if (apiName.equals("SavePatientPolicy")) {
            magicApi.alias("policy", Map.class);
        } else {
            return null;
        }
        magicApi.registerConverter(new MapEntryConverter());
        return magicApi.toXML(parameters);
    }

}