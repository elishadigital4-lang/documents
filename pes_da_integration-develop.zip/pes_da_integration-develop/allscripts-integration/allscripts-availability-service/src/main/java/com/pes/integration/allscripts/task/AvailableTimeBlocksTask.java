package com.pes.integration.allscripts.task;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import static com.pes.integration.allscripts.util.AllScriptRequestUtil.createServiceRequest;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.prepareParameters;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;

@Slf4j
public class AvailableTimeBlocksTask {
    private String startDate;
    private String endDate;
    private String provider;
    private String appName;
    private String userId;
    private String exReasonId;
    private String deploymentId;
    private AllscriptsApiCaller allscriptsApiCaller;

    public AvailableTimeBlocksTask(String deploymentId, JSONObject availableTimeRequest,
                                   AllscriptsApiCaller allscriptsApiCaller) {
        this.deploymentId = deploymentId;
        this.startDate = availableTimeRequest.optString("startDate");
        this.endDate = availableTimeRequest.optString("endDate");
        this.provider = availableTimeRequest.optString("provider");
        this.appName = availableTimeRequest.optString("appName");
        this.userId = availableTimeRequest.optString("userId");
        this.exReasonId = availableTimeRequest.optString("exReasonId");
        this.allscriptsApiCaller = allscriptsApiCaller;
    }

    public Map<String, String[]> getAvailableTimeBlocks() throws IHubException {
        JSONObject response = allscriptsApiCaller.call(deploymentId, "get_avilable_time_blocks", buildRequest(), "");
        log.info("Available time blocks api called for resource id {} ", escapeJava(provider));
        Map<String, String[]> blockMap = new HashMap<>();

        JSONArray timeBlocksArray = response.optJSONArray("temp");
        if (timeBlocksArray != null) {
            for (Object block : timeBlocksArray) {
                JSONObject blockObject = new JSONObject(block.toString());
                String types = blockObject.optString("EligApptTypes");
                if (!isEmpty(exReasonId) && Arrays.stream(types.split("\\|")).noneMatch(exReasonId::equals)) {
                    continue;
                }
                if (!isEmpty(types)) {
                    String date = blockObject.optString("Available_Date");
                    String schedLoc = blockObject.optString("SchedLoc").trim();
                    String schedDept = blockObject.optString("SchedDept").trim();
                    String start = blockObject.optString("Start_Time");
                    String end = blockObject.optString("End_Time");

                    String replacedTypes = types.replace("|", "^");
                    int startTime = getMinutes(parseInt(start));
                    int endTime = getMinutes(parseInt(end));
                    String blockMapKey = new StringBuilder(date).append(schedLoc).append(schedDept).toString();

                    blockMap.computeIfAbsent(blockMapKey, k -> new String[288]);
                    String[] timeSlots = blockMap.get(blockMapKey);
                    Arrays.fill(timeSlots, startTime, endTime, replacedTypes);
                }
            }
        } else {
            log.error("Available time blocks error for resource -  {} ", escapeJava(provider));
        }
        return blockMap;
    }

    private JSONObject buildRequest() {
        return createServiceRequest("GetAvailableTimeBlocks", appName, userId, null,
                prepareParameters(provider, startDate, endDate, null, null, null), null);
    }

    private int getMinutes(int time) {
        int toReturn = 0;
        int hours = time / 100;
        int minutes = time - (hours * 100);
        hours *= 12;
        minutes /= 5;
        toReturn += hours;
        toReturn += minutes;
        return toReturn;
    }
}
