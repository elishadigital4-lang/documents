package com.pes.integration.allscripts.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.dto.EngineAppInfo;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.service.AvailabilityOperations;
import jakarta.validation.Valid;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeRequestCount;
import static com.pes.integration.utils.MetricsUtil.metricRealTimeSuccessCount;
import static org.springframework.http.HttpStatus.OK;

@RestController
public class AvailabilityController implements AvailabilityOperations {
    @Autowired
    @Qualifier(OPEN_APPOINTMENT)
    private AppointmentService openAppointmentService;

    @Value("${epm.engine.name}")
    private String engineName;
    @Value("${info.app.description}")
    private String appDescription;

    @Override
    public ResponseEntity<Object> getRealTimeData(@Valid RealTimeRequest realTimeRequest)
            throws JsonProcessingException {
        metricRealTimeRequestCount(engineName, appDescription,OPEN_APPOINTMENT);
        AvailabilityOperations.validateInput(realTimeRequest, new EngineAppInfo(engineName, appDescription));
        JSONObject openAppointments = openAppointmentService.getRealTimeAvailability(realTimeRequest);
        metricRealTimeSuccessCount(engineName, appDescription, OPEN_APPOINTMENT);
        return new ResponseEntity<>(openAppointments.toString(), OK);
    }

}
