package com.pes.integration.allscripts.service.open.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.task.PrepareOpenSlotsTask;
import com.pes.integration.allscripts.task.ProviderTask;
import com.pes.integration.allscripts.task.RealTimeOpenSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.regex.Pattern;

import static com.pes.integration.allscripts.contant.AllscriptsConstants.APP_NAME;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.PM_USERNAME;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.ALLSCRIPTS_CONFIG;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.constant.UtilitiesConstants.GENERIC_CONFIG;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.DateUtils.getNextDate;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Integer.parseInt;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.lang.Thread.currentThread;
import static java.util.Objects.nonNull;
import static java.util.concurrent.Executors.newFixedThreadPool;
import static java.util.stream.Collectors.toList;

@Qualifier(OPEN_APPOINTMENT)
@Slf4j
@Service
public class OpenAppointmentServiceImpl extends AppointmentService {

    @Value("${configuration.api.threadsize}")
    private String threadSize;

    @Value("${application.data.path}")
    private String dataLocation = "appointment/";

    @Autowired
    AllscriptsApiCaller allScriptsApiCaller;

    @Autowired
    private FileUploader fileUploader;

    @Autowired
    private EventTracker trackEvents;

    @Autowired
    DataCacheManager dataCacheManager;

    @Override
    public JSONArray getAvailability(AvailabilityRequest availabilityRequest,
                                     Map<String, JSONArray> providerLocationMap,
                                     String epmPrefix) throws JsonProcessingException, IHubException {
            fetchOpenAppointments(availabilityRequest, providerLocationMap);
            return null;
    }

    public void fetchOpenAppointments(AvailabilityRequest availabilityRequest, Map<String, JSONArray> providerLocationMap)
            throws JsonProcessingException, IHubException {
        String startDate = null;
        String endDate = null;
        try {
            startDate = convertDateFormat(availabilityRequest.getStartDate(), DATE_FORMAT, DATE_FORMAT_MM_DD_YYYY);
            endDate = convertDateFormat(getNextDate(availabilityRequest.getEndDate(), DATE_FORMAT), DATE_FORMAT,
                    DATE_FORMAT_MM_DD_YYYY);
        } catch (ParseException e) {
            throw new EpmApiCallerException(e.getMessage());
        }
        JSONArray providerList = new JSONArray();
        String maxPoolSize;
        if (nonNull(availabilityRequest.getEntityId())) {
            String formattedEntity =replaceCommas(availabilityRequest.getEntityId().toString());
            JSONArray providers = new JSONArray(formattedEntity);
            providerList.putAll(providers);
            maxPoolSize = valueOf(ONE);
        } else {
            providerList = providerLocationMap.get(PROVIDER_ID_LIST);
            String configuredPoolSize = dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, MAX_POOL_SIZE);
            maxPoolSize = !isEmpty(configuredPoolSize) ? configuredPoolSize : threadSize;
        }
        JSONObject inputObject = getInputObject(startDate, endDate, availabilityRequest);
        if (providerList.isEmpty()) {
            providerList.putAll(new ProviderTask(inputObject,availabilityRequest, allScriptsApiCaller).getProvider());
        }
        if (availabilityRequest.getIndex().equals(valueOf(FIRST_INDEX))) {
            trackEvents.trackEvent(availabilityRequest, OPEN_APPOINTMENT_PROCESSING_STARTED,
                    format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
                    getFragmentsDetails(availabilityRequest, providerList));
        }
        ExecutorService executorService = newFixedThreadPool(parseInt(maxPoolSize));
        List<CompletableFuture<Void>> openApptFutureList = new ArrayList<>();
        try {
            providerList.forEach(provider -> {
                String prov= provider.toString().replace("_",",");
                inputObject.put("provider", prov);
                PrepareOpenSlotsTask prepareOpenSlotsTask = new PrepareOpenSlotsTask(allScriptsApiCaller,
                        inputObject, fileUploader, trackEvents, availabilityRequest);
                openApptFutureList.add(CompletableFuture.supplyAsync(prepareOpenSlotsTask, executorService));
            });
            CompletableFuture<Void> openApptAllFutures = CompletableFuture
                    .allOf(openApptFutureList.toArray(new CompletableFuture[openApptFutureList.size()]));
            CompletableFuture<List<Void>> openApptAllCompletableFuture = openApptAllFutures.thenApply(
                    future -> openApptFutureList.stream().map(CompletableFuture<Void>::join).collect(toList()));
            CompletableFuture<List<Void>> openApptCompletableFuture = openApptAllCompletableFuture
                    .toCompletableFuture();

            openApptCompletableFuture.get();
        } catch (ExecutionException ee) {
            log.error("Error in getting the slotId " + ee);
            throw new EpmApiCallerException("Error in getting the slot " + ee.getMessage());
        } catch (InterruptedException ie) {
            log.error("Error in getting the slotId " + ie);
            currentThread().interrupt();
        } finally {
            executorService.shutdown();
        }
    }

    private String replaceCommas(String entity){
        Pattern pattern=Pattern.compile(",(?!\\s)");
        return pattern.matcher(entity).replaceAll("_");
    }
    private JSONObject getInputObject(String startDate, String endDate, AvailabilityRequest availabilityRequest) throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(STARTDATE, startDate);
        inputObject.put(ENDDATE, endDate);
        inputObject.put(APPOINTMENT_PATH, dataLocation);
        inputObject.put(APP_NAME, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, APP_NAME));
        inputObject.put(SLOT_INTERVAL, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), GENERIC_CONFIG, "slot_interval"));
        inputObject.put(PM_USERNAME, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, PM_USERNAME));
        return inputObject;
    }

    private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest, JSONArray providerList) {
        Map<String, Object> providerDetails = new HashMap<>();
        providerDetails.put(TOTAL_FRAGMENTS, providerList.length());
        providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        MDC.put(TOTAL_FRAGMENTS, String.valueOf(providerList.length()));
        return providerDetails;
    }

    @Override
    public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
        JSONArray openAppointmentsArray = new JSONArray();
        try {
            if (nonNull(realTimeRequest.getEntityId()))
                openAppointmentsArray = fetchRealtimeOpenAppointments(realTimeRequest);
        } catch (JsonProcessingException e) {
            throw new EpmApiCallerException("Error in getting the slot " + e.getMessage());
        }
        return getOpenAppointmentObject(openAppointmentsArray, realTimeRequest);
    }

    private JSONArray fetchRealtimeOpenAppointments(RealTimeRequest realTimeRequest)
            throws JsonProcessingException{
        List<Object> list = (List<Object>) realTimeRequest.getEntityId();
        JSONArray openAppointmentsArray = new JSONArray();
        try {
            JSONArray providerLocList = new JSONArray(
                    objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(list));
            providerLocList.forEach(obj -> {
                JSONObject inputObject = null;
                try {
                    inputObject = getRealtimeInputObject(realTimeRequest, new JSONObject(obj.toString()));
                } catch (IHubException e) {
                    throw new EpmApiCallerException(e.getMessage());
                }
                openAppointmentsArray.putAll(new RealTimeOpenSlotsTask(allScriptsApiCaller, inputObject, realTimeRequest).get());
            });
        }
        catch (Exception e) {
            throw new EpmApiCallerException("Error in getting the slotId" + e.getMessage());
        }
        return openAppointmentsArray;
    }

    private JSONObject getRealtimeInputObject(RealTimeRequest realTimeRequest, JSONObject provLocObj) throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(STARTDATE, realTimeRequest.getStartDate());
        inputObject.put(ENDDATE, realTimeRequest.getEndDate());
        inputObject.put(APPOINTMENT_PATH, dataLocation);
        inputObject.putOpt("location", provLocObj.opt("locationId"));
        inputObject.putOpt("reason", provLocObj.opt("reasonId"));
        inputObject.putOpt("provider", provLocObj.opt("providerId"));
        inputObject.put(APP_NAME, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, realTimeRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, APP_NAME));
        inputObject.put(SLOT_INTERVAL, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, realTimeRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, SLOT_INTERVAL));
        inputObject.put(PM_USERNAME, dataCacheManager.getConfiguration(EPM_NAME_PREFIX, realTimeRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, PM_USERNAME));
        return inputObject;
    }

    // Note: Used Strictly For Testing Purpose
    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

}
