package com.pes.integration.allscripts.task;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import static com.pes.integration.allscripts.contant.AllscriptsConstants.APP_NAME;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.PM_USERNAME;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.createServiceRequest;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.prepareParameters;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.MdcUtil.setContext;
import static com.pes.integration.utils.NullChecker.isEmpty;
import static java.lang.Character.isWhitespace;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class RealTimeOpenSlotsTask implements Supplier<JSONArray> {

    private static final String ERROR_PROCESSING_DATA =
            "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";

    private String startDate;
    private String endDate;
    private String provider;
    private String appName;
    private String userId;
    private String slotInterval;
    private String exReasonId;
    private AllscriptsApiCaller allscriptsApiCaller;
    private RealTimeRequest realTimeRequest;
    private Map<String, String> contextMap = getCopyOfContextMap();

    public RealTimeOpenSlotsTask(AllscriptsApiCaller allscriptsApiCaller, JSONObject openRequest,
                                 RealTimeRequest realTimeRequest) {
        this.startDate = openRequest.getString(STARTDATE);
        this.endDate = nextDate(openRequest.getString(ENDDATE));
        this.provider = openRequest.getString(PROVIDER);
        this.appName = openRequest.optString(APP_NAME);
        this.userId = openRequest.optString(PM_USERNAME);
        this.slotInterval = openRequest.optString("slotInterval");
        this.exReasonId = openRequest.optString("reason");
        this.allscriptsApiCaller = allscriptsApiCaller;
        this.realTimeRequest = realTimeRequest;
    }

    private String nextDate(String date) {
        return LocalDate.parse(date).plusDays(1).toString();
    }

    @Override
    public JSONArray get() {
        setContext(contextMap);
        JSONArray openApptOutput=new JSONArray();
        try {
            JSONArray openOutput = getOpenAppointment();
            if (!isEmpty(openOutput)) {
                openApptOutput.putAll(extractOpenSlotsFromResponse(openOutput));
            }

        } catch (JsonProcessingException e) {
            log.error("error  while tracking the request {}", e.getMessage());
            throw new EpmApiCallerException("error while tracking the request");
        } catch (EpmApiCallerException ee) {
            log.error("Error in getting the open slotId " + ee.getMessage());
        } catch (IHubException e) {
            throw new IllegalArgumentException("Error in getting the open slotId "+e.getMessage());
        }
        return openApptOutput;
    }

    private JSONArray getOpenAppointment() throws JsonProcessingException, IHubException {
        JSONArray openAppointmentsArray = new JSONArray();
        try {
            Map<String, String[]> apptTypesBlockMap =
                    new AvailableTimeBlocksTask(realTimeRequest.getDeploymentId(), getAvailableTimeBlockRequest(), allscriptsApiCaller)
                            .getAvailableTimeBlocks();
            if (!apptTypesBlockMap.isEmpty()) {
                JSONObject responseObject = openAppointments();
                if (!responseObject.isEmpty()) {
                    openAppointmentsArray
                            .putAll(extractOpenSlotsFromResponse(responseObject, apptTypesBlockMap));
                }
            }
        } catch (InvalidIdException | EpmApiCallerException e) {
            String exceptionDetails =
                    format(ERROR_PROCESSING_DATA, startDate, endDate, provider, e.getMessage());
            log.error(escapeJava(exceptionDetails));
            throw new EpmApiCallerException(exceptionDetails);
        }
        return openAppointmentsArray;
    }

    private JSONObject getAvailableTimeBlockRequest() {
        JSONObject availableTimeRequest = new JSONObject();
        availableTimeRequest.put("startDate", startDate);
        availableTimeRequest.put("endDate", endDate);
        availableTimeRequest.put("provider", provider);
        availableTimeRequest.put("appName", appName);
        availableTimeRequest.put("userId", userId);
        availableTimeRequest.put("exReasonId",exReasonId);
        return availableTimeRequest;
    }

    private JSONObject openAppointments() throws IHubException {
        JSONObject openAppointmentRequest = buildRequest();
        return allscriptsApiCaller.call(realTimeRequest.getDeploymentId(), "open_appointments", openAppointmentRequest, "");
    }

    private JSONObject buildRequest() {
        return createServiceRequest("GetAvailableSchedule", appName, userId, null,
                prepareParameters(provider, startDate, endDate, null, null, null), null);
    }

    private JSONArray extractOpenSlotsFromResponse(JSONObject availableSchedule,
                                                   Map<String, String[]> apptTypesBlockMap) {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray availableScheduleArray = availableSchedule.getJSONArray("Schedule");
        availableScheduleArray.forEach(object -> {
            JSONObject availableObject = new JSONObject(object.toString());
            String openSlots =
                    availableObject.optString("OpenSlots1").concat(availableObject.optString("OpenSlots2"));
            String date = availableObject.optString("Available_Date").trim();
            String providerId = availableObject.optString("Resource_Abbreviation").trim();
            String locationId = availableObject.optString("Scheduling_Location_Abbreviation").trim();
            String deptId = availableObject.optString("Scheduling_Department_Abbreviation").trim();
            String blockMapKey = new StringBuilder(date).append(locationId).append(deptId).toString();
            locationId = locationId + ATMARK + deptId;
            char[] openSlotsArr = openSlots.toCharArray();
            for (int c = 0; c < openSlotsArr.length; c++) {
                if (!((Character) openSlotsArr[c]).equals('0') && !isWhitespace((openSlotsArr[c]))
                        && !apptTypesBlockMap.isEmpty() && apptTypesBlockMap.containsKey(blockMapKey)
                        && apptTypesBlockMap.get(blockMapKey)[c] != null
                        && !apptTypesBlockMap.get(blockMapKey)[c].isEmpty()) {
                    String apptTimeStart = getTimeFromIndex(c);
                    JSONObject openApptObj = new JSONObject();
                    openApptObj.put("startTime", apptTimeStart);
                    openApptObj.put("providerId", providerId);
                    openApptObj.put("locationId", locationId);
                    openApptObj.put("reasonId", apptTypesBlockMap.get(blockMapKey)[c]);
                    openApptObj.put("duration", "5");
                    openApptObj.put("slotInterval", slotInterval);
                    openApptObj.put("durationUnit", "minutes");
                    openApptObj.put("OverbookLimit", valueOf(openSlotsArr[c]));
                    try {
                        openApptObj.put("date", convertDateFormat(date.trim(), AllscriptsConstants.DATE_FORMAT, DATE_FORMAT_MM_DD_YYYY));
                    } catch (ParseException e) {
                        throw new EpmApiCallerException(e.getMessage());
                    }
                    openAppointmentsArray.put(openApptObj);
                }
            }
        });
        return openAppointmentsArray;
    }

    private static String getTimeFromIndex(int index) {
        int hrs = 0;
        int mins = 0;
        hrs = (index * 5) / 60;
        if ((index * 5) % 60 == 0) {
            mins = 0;
        } else {
            mins = Math.abs(60 * hrs - (index * 5));
        }
        String hours = Integer.toString(hrs);
        String minutes = Integer.toString(mins);
        if (hrs < 10) {
            hours = "0" + hrs;
        }
        if (mins < 10) {
            minutes = "0" + mins;
        }
        return hours + minutes;
    }

    public JSONArray extractOpenSlotsFromResponse(JSONArray outputObject) {
        JSONArray openAppointmentsArray = new JSONArray();
        outputObject.forEach(
                appointmentObject ->
                        openAppointmentsArray.put(transformObject((JSONObject) appointmentObject)));
        return openAppointmentsArray;
    }

    public JSONObject transformObject(JSONObject appointmentObject) {
        JSONObject openAppointment = new JSONObject();
        String startTime = appointmentObject.getString(START_TIME);
        String duration = appointmentObject.getString("duration");
        String date = appointmentObject.optString("date");
        openAppointment.put(DURATION_UNIT_KEY, DURATION_IN_MINUTES);
        openAppointment.put(LOCATION_ID_KEY, appointmentObject.opt(LOCATION_ID_KEY));
        openAppointment.put(PROVIDER_ID_KEY, appointmentObject.opt(PROVIDER_ID_KEY));
        openAppointment.put(REASON_ID_KEY, appointmentObject.opt(REASON_ID_KEY));
        openAppointment.put(SLOT_INTERVAL, appointmentObject.opt(SLOT_INTERVAL));
        openAppointment.put(
                START_TIME, startTime);
        try {
            openAppointment.put(
                    DATE_KEY, convertDateFormat(date.trim(),DATE_FORMAT_MM_DD_YYYY, "yyyy-MM-dd'T'HH:mm:ss"));
        } catch (ParseException e) {
            throw new IllegalArgumentException("Error in transform object "+e.getMessage());
        }
        openAppointment.put(DURATION, duration);
        return openAppointment;
    }
}