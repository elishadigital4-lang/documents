package com.pes.integration.allscripts.service.booked.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.task.PrepareBookedSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.AppointmentService;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.adapter.Utils.trackBookedFragmentError;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.BOOKED_STATUS;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.LOCATIONS;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.FIRST_INDEX;
import static com.pes.integration.enums.DataflowStatus.BOOKED_APPOINTMENT_PROCESSING_STARTED;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static java.util.Arrays.asList;

@Slf4j
@Qualifier(BOOKED_APPOINTMENT)
@Service
public class BookedAppointmentServiceImpl extends AppointmentService {

    private static final int TOTAL_BOOKED_CALLS = 1;

    @Value("${application.data.path}")
    private String dataLocation;

    @Autowired
    private AllscriptsApiCaller allScriptsApiCaller;
    @Autowired

    private FileUploader fileUploader;

    @Autowired
    private EventTracker trackEvents;

    @Autowired
    private DataCacheManager dataCacheManager;



    @Override
    public JSONArray getAvailability(AvailabilityRequest availabilityRequest,
                                     Map<String, JSONArray> providerLocationMap,
                                     String epmPrefix) throws JsonProcessingException, IHubException {
        if (availabilityRequest.getIndex().equals(valueOf(FIRST_INDEX))) {
            trackEvents.trackEvent(availabilityRequest, BOOKED_APPOINTMENT_PROCESSING_STARTED,
                    format(REQUEST_RECEIVED, objectMapper.writeValueAsString(availabilityRequest)),
                    getFragmentsDetails(availabilityRequest));
        }

        String bookedStatusStr = dataCacheManager.getConfiguration(epmPrefix, availabilityRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, BOOKED_STATUS);
        List<String> bookedStatuses = new ArrayList<>();
        if (!bookedStatusStr.isEmpty()) {
            bookedStatuses = asList(bookedStatusStr.split(","));
        }
        try {
            fetchBookedAppointments(providerLocationMap.get(LOCATION_ID_LIST), availabilityRequest, bookedStatuses);
        } catch (ParseException e) {
            log.error("Error occurred while parsing the date");
            trackBookedFragmentError(availabilityRequest, trackEvents, e.getMessage());
        }
        return null;
    }

    public void fetchBookedAppointments(JSONArray locationJsonArray, AvailabilityRequest availabilityRequest, List<String> bookedStatuses)
            throws JsonProcessingException, ParseException, IHubException {
        String startDate = convertDateFormat(availabilityRequest.getStartDate(), DATE_FORMAT, DATE_FORMAT_MM_DD_YYYY) + BS_START_TIME;
        String endDate = convertDateFormat(availabilityRequest.getEndDate(), DATE_FORMAT, DATE_FORMAT_MM_DD_YYYY) + BS_END_TIME;
        JSONObject inputObject = getInputObject(startDate, endDate, locationJsonArray);
        try {
            new PrepareBookedSlotsTask(allScriptsApiCaller, inputObject, fileUploader, trackEvents,
                    availabilityRequest, dataCacheManager, bookedStatuses).processBookedAppointment();
        } catch (EpmApiCallerException e) {
            String message = "Error in getting the booked appointment slot for startDate " + startDate
                    + " endDate  " + endDate + e.getMessage();
            log.error(message);
            trackBookedFragmentError(availabilityRequest, trackEvents, message);
        }
    }

    private JSONObject getInputObject(String startDate, String endDate, JSONArray locationJsonArray) {
        JSONObject inputObject = new JSONObject();
        inputObject.put(STARTDATE, startDate);
        inputObject.put(ENDDATE, endDate);
        inputObject.put(APPOINTMENT_PATH, dataLocation);
        inputObject.put(LOCATIONS, locationJsonArray.toString());
        return inputObject;
    }

    private Map<String, Object> getFragmentsDetails(AvailabilityRequest availabilityRequest) {
        Map<String, Object> providerDetails = new HashMap<>();
        providerDetails.put(TOTAL_FRAGMENTS, valueOf(TOTAL_BOOKED_CALLS));
        providerDetails.put(TOTAL_SLICES, availabilityRequest.getTotalSlices());
        return providerDetails;
    }

    @Override
    public JSONObject getRealTimeAvailability(RealTimeRequest realTimeRequest) {
        return null;
    }

    // Note: Used Strictly For Testing Purpose
    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }


}
