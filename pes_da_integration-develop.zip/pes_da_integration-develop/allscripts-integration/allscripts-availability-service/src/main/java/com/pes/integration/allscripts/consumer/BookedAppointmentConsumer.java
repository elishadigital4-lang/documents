package com.pes.integration.allscripts.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.allscripts.contant.AllscriptsEngineConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.repository.RedisRepository;
import com.pes.integration.service.AppointmentService;
import io.awspring.cloud.sqs.annotation.SqsListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import static com.pes.integration.adapter.Utils.*;
import static com.pes.integration.constant.EpmConstant.BOOKED_APPOINTMENT;
import static com.pes.integration.constant.EpmConstant.MESSAGE_CONTROL_ID;
import static org.slf4j.MDC.put;


@Service
@Slf4j
public class BookedAppointmentConsumer {

    @Autowired
    @Qualifier(BOOKED_APPOINTMENT)
    private AppointmentService bookedAppointmentService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private EventTracker trackEvents;

    @Autowired
    private RedisRepository terminateBaselineRepository;

    @SqsListener(value = "${application.queue.bookedAppt.process}")
    public void consume(String request) throws JsonProcessingException {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        log.info("Booked Appointment data request received is {}", request);
        try {
            availabilityRequest = objectMapper.readValue(request, AvailabilityRequest.class);
            if (isTerminatedBaseline(terminateBaselineRepository, trackEvents, availabilityRequest)) {
                log.info("Baseline for messagecontrolId {} is terminated ",
                        availabilityRequest.getMessageControlId());
                return;
            }
            validateInput(availabilityRequest);
            put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
            bookedAppointmentService.getAppointments(availabilityRequest, AllscriptsEngineConstants.EPM_NAME_PREFIX);
        } catch (JsonProcessingException jpe) {
            String message = "Error while parsing the request " + availabilityRequest + jpe.getMessage();
            log.error(message);
            trackBookedSliceError(availabilityRequest, trackEvents, message);
        } catch (Exception ex) {
            String message = "Error in processing the data , Details: " + ex.getMessage();
            log.error(message);
            trackBookedSliceError(availabilityRequest, trackEvents, message);
        }
    }

    // Note: Used Strictly For Testing Purpose
    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }
}
