package com.pes.integration.allscripts.task;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.SlotDTO;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import java.io.File;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.adapter.Utils.getBookedDataFlowNifiStatus;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.ALLSCRIPTS_CONFIG;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.createServiceRequest;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.prepareParameters;
import static com.pes.integration.allscripts.util.AllScriptUtil.trackEventToNifi;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.APPOINTMENT_STATUS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_DATE_TIME;
import static com.pes.integration.constant.EpmConstant.DATE_FORMAT;
import static com.pes.integration.constant.EpmConstant.DATE_TIME_FORMAT_AM_PM;
import static com.pes.integration.constant.EpmConstant.DEPLOYMENT_ID;
import static com.pes.integration.constant.EpmConstant.MINUTES;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.NumberConstants.ONE;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext;
import static java.lang.String.valueOf;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class PrepareBookedSlotsTask {

    private static final String ERROR_MSG_FOR_FETCHING_FILTER =
            "failed to fetch location and department for location id : {}";

    private String startDate;
    private String endDate;
    private String locations;
    private String dataLocation;
    private EventTracker trackEvents;
    private FileUploader fileUploader;
    private AvailabilityRequest availabilityRequest;
    private List<String> bookedStatuses;
    private DataCacheManager dataCacheManager;
    private Map<String, String> contextMap = getCopyOfContextMap();
    private AllscriptsApiCaller allscriptsApiCaller;

    public PrepareBookedSlotsTask(AllscriptsApiCaller allscriptsApiCaller, JSONObject inputObject,
                                  FileUploader fileUploader, EventTracker trackEvents, AvailabilityRequest availabilityRequest,
                                  DataCacheManager dataCacheManager, List<String> bookedStatuses) {
        this.startDate = inputObject.getString(STARTDATE);
        this.endDate = inputObject.getString(ENDDATE);
        this.locations = inputObject.getString(LOCATIONS);
        this.dataLocation = inputObject.getString(APPOINTMENT_PATH);
        this.allscriptsApiCaller = allscriptsApiCaller;
        this.fileUploader = fileUploader;
        this.trackEvents = trackEvents;
        this.availabilityRequest = availabilityRequest;
        this.bookedStatuses = bookedStatuses;
        this.dataCacheManager = dataCacheManager;
    }

    public void processBookedAppointment() throws IHubException{
        setContext(contextMap);
        Map<String, File> appointmentDataFiles = new HashMap<>();
        try {
            JSONObject bookedApptOutput = getBookedAppointment();
            uploadBookedFiles(appointmentDataFiles, bookedApptOutput);
            trackEventToNifi(trackEvents, availabilityRequest, getBookedDataFlowNifiStatus(availabilityRequest), valueOf(ONE), EMPTY);
        } finally {
            deleteFiles(appointmentDataFiles);
        }
    }

    private JSONObject getBookedAppointment() throws IHubException {
        JSONArray bookedAppointmentsArray = new JSONArray();
        JSONObject responseObject = bookedAppointments();
        log.info("Booked api called ");
        if(nonNull(responseObject) && responseObject.has("temp")) {
            throw new EpmApiCallerException(getValue(responseObject, "temp.error_detail").toString());
        }
        else if (nonNull(responseObject)) {
            bookedAppointmentsArray.putAll(extractBookedSlots(responseObject));
        }
        return getBookedAppointmentObject(bookedAppointmentsArray);
    }

    private void uploadBookedFiles(Map<String, File> appointmentDataFiles,
                                   JSONObject bookedApptOutput) {
        appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
                prepareBookedFile(bookedApptOutput, availabilityRequest));
        fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
                availabilityRequest.getAppointmentType(), availabilityRequest.getSliceId(),
                appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    }

    private JSONObject getBookedAppointmentObject(JSONArray bookedAppointmentsArray) {
        JSONObject openApptOutput = new JSONObject();
        openApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
        openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
        openApptOutput.put(TOTAL_COUNT, bookedAppointmentsArray.length());
        openApptOutput.put(DATA, bookedAppointmentsArray);
        return openApptOutput;
    }

    private File prepareBookedFile(JSONObject apptresponse, AvailabilityRequest availabilityRequest) {
        return prepareFile(apptresponse.toString(),
                dataLocation + availabilityRequest.getMessageControlId() + SLASH
                        + availabilityRequest.getSliceId(),
                SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
    }

    private JSONObject bookedAppointments() throws IHubException {
        JSONObject allScriptRequestObject = buildRequest();
        return allscriptsApiCaller.call(availabilityRequest.getDeploymentId(), "changed_appointments_booked", allScriptRequestObject, "");
    }

    private JSONObject buildRequest() throws IHubException {
        String appName = dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, APP_NAME);
        String username = dataCacheManager.getConfiguration(EPM_NAME_PREFIX, availabilityRequest.getDeploymentId(), ALLSCRIPTS_CONFIG, PM_USERNAME);
        JSONObject filters = fetchFilterJSON(locations);
        String filterXml = XML.toString(filters);
        return createServiceRequest(API_CHANGED_APPOINTMENTS, appName, username, null,
                prepareParameters(startDate, endDate, null, null, null, filterXml), null);
    }

    private JSONObject fetchFilterJSON(String locations) {
        JSONObject filters = new JSONObject();
        JSONObject filterParam = new JSONObject();
        List<JSONObject> locationIdsList = new ArrayList<>();
        List<JSONObject> departIdList = new ArrayList<>();
        new JSONArray(locations).forEach(locationId -> {
            String[] splitArray = (locationId.toString()).split(ATMARK);
            try {
                JSONObject location = new JSONObject();
                JSONObject dept = new JSONObject();
                location.put(LOCATION_ABBREVIATION, splitArray[0]);
                dept.put(DEPARTMENT_ABBREVIATION, splitArray[1]);
                locationIdsList.add(location);
                departIdList.add(dept);
            } catch (Exception e) {
                log.warn(ERROR_MSG_FOR_FETCHING_FILTER, escapeJava(locationId.toString()));
            }
        });
        filterParam.put(SCHEDULE_LOCATIONS, locationIdsList);
        filterParam.put(SCHEDULE_DEPARTMENTS, departIdList);
        filters.put(FILTERS, filterParam);
        return filters;
    }

    private JSONArray extractBookedSlots(JSONObject outputObject) {
        List<SlotDTO> res = new ArrayList<>();
        JSONArray bookedAppointmentsArray = outputObject.optJSONArray(APPOINTMENT_SYNC);
        if (bookedAppointmentsArray == null || bookedAppointmentsArray.length() == 0) {
            return new JSONArray(res);
        }
        bookedAppointmentsArray.forEach(bookedAppointment -> {
            Object appointmentStatus = getValue(bookedAppointment, APPOINTMENT_STATUS);
            if (bookedStatuses.contains(appointmentStatus)) {
                try {
                    res.add(transformBookedAppointment(bookedAppointment.toString()));
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        return new JSONArray(res);
    }

    private SlotDTO transformBookedAppointment(String bookedAppointment) throws ParseException {
        JSONObject appointmentObject = new JSONObject(bookedAppointment);
        String date = getValue(appointmentObject, START_DATE_TIME).toString();
        String daDate = convertDateFormat(date.trim(), AllscriptsConstants.DATE_FORMAT, "yyyy-MM-dd'T'HH:mm:ss");
        String slotId = getValue(appointmentObject, APPOINTMENT_ID).toString();
        String providerId = getValue(appointmentObject, APPT_PROVIDER_ID).toString();
        String locationId = getValue(appointmentObject, APPT_LOCATION_ID).toString()
                + getValue(appointmentObject, APPT_DEPT_ID).toString();
        String duration = getValue(appointmentObject, APPOINTMENT_DURATION).toString();
        String reasonId = getValue(appointmentObject, EVENT_REASON_ID).toString();
        SlotDTO slotDto = SlotDTO.builder().slotId(slotId).duration(duration).durationUnit(MINUTES)
                .reasonId(reasonId.trim()).providerId(providerId.trim()).locationId(locationId.trim())
                .build();
        slotDto.setDate(daDate);
        String alDateFormat =
                date.length() >= 17 ? DATE_TIME_FORMAT_AM_PM_WITHOUT_SEC : DATE_TIME_FORMAT_AM_PM;
        slotDto.setStartTime(convertDateFormat(date, alDateFormat, TIME_FORMAT));
        return slotDto;
    }
}
