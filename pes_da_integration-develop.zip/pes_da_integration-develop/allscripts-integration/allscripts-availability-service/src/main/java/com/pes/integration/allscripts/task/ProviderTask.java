package com.pes.integration.allscripts.task;

import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.IHubException;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;

import static com.pes.integration.allscripts.util.AllScriptRequestUtil.createServiceRequest;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.prepareParameters;

@Slf4j
public class ProviderTask {

    private AvailabilityRequest availabilityRequest;
    private String appName;
    private String userId;
    private BaseApiCaller baseApiCaller;

    public ProviderTask(JSONObject providerRequest, AvailabilityRequest availabilityRequest, BaseApiCaller baseApiCaller) {
        this.availabilityRequest = availabilityRequest;
        this.appName = providerRequest.optString("appname");
        this.userId = providerRequest.optString("pmusername");
        this.baseApiCaller = baseApiCaller;
    }

    public JSONArray getProvider() throws IHubException {
        JSONArray resourceArray = new JSONArray();
        JSONObject response = baseApiCaller.call(availabilityRequest.getDeploymentId(),"get_resources", buildRequest(), "");
        response.remove("request");
        response.remove("response");
        log.info("get resources api called for baseline");
        response.getJSONArray("Resource").forEach(resource -> {
            JSONObject resourceObject = new JSONObject(resource.toString());
            resourceArray.put(resourceObject.optString("Abbreviation"));
        });
        return resourceArray;
    }

    private JSONObject buildRequest() {
        return createServiceRequest("GetResources", appName, userId, null,
                prepareParameters(null, null, null, null, null, null), null);
    }
}

