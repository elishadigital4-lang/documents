package com.pes.integration.allscripts.util;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public class AllScriptRequestUtil {

    private AllScriptRequestUtil() {}

    private static final String ACTION = "Action";
    private static final String APP_NAME = "Appname";
    private static final String APP_USER_ID = "AppUserID";
    private static final String PATIENT_ID = "PatientID";
    private static final String DATA = "Data";

    public static JSONObject createServiceRequest(String action, String appName, String appUserId,
                                                  String patientId, Map<String, String> parameters, String data) {

        JSONObject serviceRequest = new JSONObject();
        serviceRequest.put(ACTION, action);
        serviceRequest.put(APP_NAME, appName);
        serviceRequest.put(APP_USER_ID, appUserId);
        serviceRequest.put(PATIENT_ID, patientId);
        serviceRequest.put(PARAMETER_1, getValue(parameters.get(PARAMETER_1)));
        serviceRequest.put(PARAMETER_2, getValue(parameters.get(PARAMETER_2)));
        serviceRequest.put(PARAMETER_3, getValue(parameters.get(PARAMETER_3)));
        serviceRequest.put(PARAMETER_4, getValue(parameters.get(PARAMETER_4)));
        serviceRequest.put(PARAMETER_5, getValue(parameters.get(PARAMETER_5)));
        serviceRequest.put(PARAMETER_6, getValue(parameters.get(PARAMETER_6)));
        serviceRequest.put(DATA, getValue(data));
        return serviceRequest;
    }

    public static Map<String, String> prepareParameters(String parameter1, String parameter2,
                                                        String parameter3, String parameter4, String parameter5, String parameter6) {
        Map<String, String> parameters = new HashMap<>();
        parameters.put(PARAMETER_1, getValue(parameter1));
        parameters.put(PARAMETER_2, getValue(parameter2));
        parameters.put(PARAMETER_3, getValue(parameter3));
        parameters.put(PARAMETER_4, getValue(parameter4));
        parameters.put(PARAMETER_5, getValue(parameter5));
        parameters.put(PARAMETER_6, getValue(parameter6));
        return parameters;
    }

    public static Map<String, String> defaultParams() {
        return prepareParameters(null, null, null, null, null, null);
    }

    private static String getValue(String value) {
        if (isNotEmpty(value)) {
            return value.trim();
        }
        return EMPTY;
    }
}
