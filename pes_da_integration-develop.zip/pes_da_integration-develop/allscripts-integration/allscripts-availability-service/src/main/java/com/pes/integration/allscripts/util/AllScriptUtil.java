package com.pes.integration.allscripts.util;


import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;

import java.text.ParseException;

import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public class AllScriptUtil {

    private AllScriptUtil() {}

    public static void trackEventToNifi(EventTracker trackEvents,
                                        AvailabilityRequest availabilityRequest, DataflowStatus dataflowStatus, String totalFragments,
                                        String fragmentId) {
        NifiTrackingEvent nifiEvent = NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
                .messageControlId(availabilityRequest.getMessageControlId())
                .appointmentType(availabilityRequest.getAppointmentType())
                .sliceId(availabilityRequest.getSliceId())
                .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
                .entityType(availabilityRequest.getEntityType()).entityId(availabilityRequest.getEntityId())
                .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices())
                .flow(availabilityRequest.getFlow()).build();
        trackEvents.trackEventToNifi(nifiEvent);
    }

    public static String getDateKey(String date) throws ParseException {
        if (isNotEmpty(date)) {
            date = convertDateFormat(date, "MM/dd/yyyy hh:mm:ss a", "MM/dd/yyyy");
        }
        return date;
    }

}
