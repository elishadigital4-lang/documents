package com.pes.integration.allscripts;

import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.RefreshBaseInitEngine;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class InitEngine implements RefreshBaseInitEngine {

    @Autowired
    AllscriptsInitEngine allscriptsInitEngine;

    @PostConstruct
    public void init() throws IHubException {
        allscriptsInitEngine.init();
    }
}
