package com.pes.integration.allscripts.task;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.NifiTrackingEvent;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.InvalidIdException;
import com.pes.integration.upload.FileUploader;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.MDC;

import java.io.File;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import static com.pes.integration.adapter.Utils.getOpenDataFlowNifiStatus;
import static com.pes.integration.adapter.Utils.trackOpenFragmentError;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.createServiceRequest;
import static com.pes.integration.allscripts.util.AllScriptRequestUtil.prepareParameters;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.PathConstants.JSON_TYPE;
import static com.pes.integration.constant.PathConstants.SLASH;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.FileUtil.deleteFiles;
import static com.pes.integration.utils.FileUtil.prepareFile;
import static com.pes.integration.utils.MdcUtil.setContext;
import static java.lang.Character.isWhitespace;
import static java.lang.String.format;
import static java.lang.String.valueOf;
import static org.slf4j.MDC.getCopyOfContextMap;

@Slf4j
public class PrepareOpenSlotsTask implements Supplier<Void> {

    private static final String ERROR_PROCESSING_DATA =
            "Error in processing the data for open appointment slot, Details:- Start Date : %s, End date: %s, Provider ID: %s with error %s ";

    private String startDate;
    private String endDate;
    private String provider;
    private String dataLocation;
    private String appName;
    private String userId;
    private String slotInterval;
    private EventTracker trackEvents;
    private FileUploader fileUploader;
    private AllscriptsApiCaller allscriptsApiCaller;
    private AvailabilityRequest availabilityRequest;
    private Map<String, Object> payload = new HashMap<>();
    private Map<String, String> contextMap = getCopyOfContextMap();

    public PrepareOpenSlotsTask(AllscriptsApiCaller allscriptsApiCaller, JSONObject openRequest,
                                FileUploader fileUploader, EventTracker trackEvents,
                                AvailabilityRequest availabilityRequest) {
        this.startDate = openRequest.getString(STARTDATE);
        this.endDate = openRequest.getString(ENDDATE);
        this.provider = openRequest.getString(PROVIDER);
        this.dataLocation = openRequest.getString("appointmentPath");
        this.appName = openRequest.optString(APP_NAME);
        this.userId = openRequest.optString(PM_USERNAME);
        this.slotInterval = openRequest.optString("slotInterval");
        this.allscriptsApiCaller = allscriptsApiCaller;
        this.fileUploader = fileUploader;
        this.trackEvents = trackEvents;
        this.availabilityRequest = availabilityRequest;
    }

    @Override
    public Void get() {
        setContext(contextMap);
        Map<String, File> appointmentDataFiles = new HashMap<>();
        try {
            JSONObject openApptOutput = getOpenAppointment();
            uploadFiles(appointmentDataFiles, openApptOutput);
            trackEventToNifi(trackEvents, availabilityRequest,
                    getOpenDataFlowNifiStatus(availabilityRequest), MDC.get(TOTAL_FRAGMENTS), provider,
                    payload);
        } catch (JsonProcessingException e) {
            log.error("error while tracking the request {}", e.getMessage());
            throw new EpmApiCallerException("error while tracking the request");
        } catch (EpmApiCallerException ee) {
            log.error("Error in getting the open slotId " + ee.getMessage());
        } catch (IHubException e) {
            throw new IllegalArgumentException("Error in getting the open slotId "+e.getMessage());
        } finally {
            deleteFiles(appointmentDataFiles);
        }
        return null;
    }

    private JSONObject getOpenAppointment() throws JsonProcessingException, IHubException {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONObject openApptOutput = new JSONObject();
        try {
            Map<String, String[]> apptTypesBlockMap =
                    new AvailableTimeBlocksTask(availabilityRequest.getDeploymentId(), getAvailableTimeBlockRequest(), allscriptsApiCaller)
                            .getAvailableTimeBlocks();
            if (!apptTypesBlockMap.isEmpty()) {
                JSONObject responseObject = openAppointments();
                if (!responseObject.isEmpty()) {
                    openAppointmentsArray
                            .putAll(extractOpenSlotsFromResponse(responseObject, apptTypesBlockMap));
                }
            }
            openApptOutput = getOpenAppointmentObject(openAppointmentsArray);
        } catch (Exception e) {
            String exceptionDetails =
                    format(ERROR_PROCESSING_DATA, startDate, endDate, provider, e.getMessage());
            log.error(exceptionDetails);
            trackOpenFragmentError(availabilityRequest, trackEvents, provider, exceptionDetails);
            throw new EpmApiCallerException(exceptionDetails);
        }
        return openApptOutput;
    }

    private JSONObject getAvailableTimeBlockRequest() {
        JSONObject availableTimeRequest = new JSONObject();
        availableTimeRequest.put("startDate", startDate);
        availableTimeRequest.put("endDate", endDate);
        availableTimeRequest.put("provider", provider);
        availableTimeRequest.put("appName", appName);
        availableTimeRequest.put("userId", userId);
        return availableTimeRequest;
    }

    private File prepareOpenAppointmentFile(JSONObject apptresponse,
                                            AvailabilityRequest availabilityRequest) {
        return prepareFile(apptresponse.toString(),
                dataLocation + availabilityRequest.getMessageControlId() + SLASH
                        + availabilityRequest.getSliceId() + SLASH + provider,
                SLASH + availabilityRequest.getAppointmentType() + JSON_TYPE);
    }

    private JSONObject openAppointments() throws IHubException {
        JSONObject openAppointmentRequest = buildRequest();
        return allscriptsApiCaller.call(availabilityRequest.getDeploymentId(), "open_appointments", openAppointmentRequest, "");
    }

    private JSONObject buildRequest() {
        return createServiceRequest("GetAvailableSchedule", appName, userId, null,
                prepareParameters(provider, startDate, endDate, null, null, null), null);
    }

    private JSONArray extractOpenSlotsFromResponse(JSONObject availableSchedule,
                                                   Map<String, String[]> apptTypesBlockMap) {
        JSONArray openAppointmentsArray = new JSONArray();
        JSONArray availableScheduleArray = availableSchedule.getJSONArray("Schedule");
        availableScheduleArray.forEach(object -> {
            JSONObject availableObject = new JSONObject(object.toString());
            String openSlots =
                    availableObject.optString("OpenSlots1").concat(availableObject.optString("OpenSlots2"));
            String date = availableObject.optString("Available_Date").trim();
            String providerId = availableObject.optString("Resource_Abbreviation").trim();
            String locationId = availableObject.optString("Scheduling_Location_Abbreviation").trim();
            String deptId = availableObject.optString("Scheduling_Department_Abbreviation").trim();
            String blockMapKey = new StringBuilder(date).append(locationId).append(deptId).toString();
            locationId = locationId + ATMARK + deptId;
            char[] openSlotsArr = openSlots.toCharArray();
            for (int c = 0; c < openSlotsArr.length; c++) {
                if (!((Character) openSlotsArr[c]).equals('0') && !isWhitespace((openSlotsArr[c]))
                        && !apptTypesBlockMap.isEmpty() && apptTypesBlockMap.containsKey(blockMapKey)
                        && apptTypesBlockMap.get(blockMapKey)[c] != null
                        && !apptTypesBlockMap.get(blockMapKey)[c].isEmpty()) {
                    String apptTimeStart = getTimeFromIndex(c);
                    JSONObject openApptObj = new JSONObject();
                    openApptObj.put("startTime", apptTimeStart);
                    openApptObj.put("providerId", providerId);
                    openApptObj.put("locationId", locationId);
                    openApptObj.put("reasonId", apptTypesBlockMap.get(blockMapKey)[c]);
                    openApptObj.put("duration", "5");
                    openApptObj.put("slotInterval", slotInterval);
                    openApptObj.put("durationUnit", "minutes");
                    openApptObj.put("OverbookLimit", valueOf(openSlotsArr[c]));
                    try {
                        openApptObj.put("date", convertDateFormat(date.trim(), AllscriptsConstants.DATE_FORMAT, "yyyy-MM-dd'T'HH:mm:ss"));
                    } catch (ParseException e) {
                        throw new EpmApiCallerException(e.getMessage());
                    }
                    openAppointmentsArray.put(openApptObj);
                }
            }
        });
        return openAppointmentsArray;
    }

    private static String getTimeFromIndex(int index) {
        int hrs = 0;
        int mins = 0;
        hrs = (index * 5) / 60;
        if ((index * 5) % 60 == 0) {
            mins = 0;
        } else {
            mins = Math.abs(60 * hrs - (index * 5));
        }
        String hours = Integer.toString(hrs);
        String minutes = Integer.toString(mins);
        if (hrs < 10) {
            hours = "0" + hrs;
        }
        if (mins < 10) {
            minutes = "0" + mins;
        }
        return hours + minutes;
    }

    private void uploadFiles(Map<String, File> appointmentDataFiles, JSONObject openApptOutput) {
        appointmentDataFiles.put(availabilityRequest.getAppointmentType(),
                prepareOpenAppointmentFile(openApptOutput, availabilityRequest));
        fileUploader.uploadFile(availabilityRequest.getMessageControlId(),
                availabilityRequest.getAppointmentType(),
                availabilityRequest.getSliceId() + SLASH + provider,
                appointmentDataFiles.get(availabilityRequest.getAppointmentType()));
    }

    private JSONObject getOpenAppointmentObject(JSONArray openAppointmentsArray) {
        JSONObject openApptOutput = new JSONObject();
        openApptOutput.put(DEPLOYMENT_ID, availabilityRequest.getDeploymentId());
        openApptOutput.put(MESSAGE_CONTROL_ID, availabilityRequest.getMessageControlId());
        openApptOutput.put(TOTAL_COUNT, openAppointmentsArray.length());
        openApptOutput.put(DATA, openAppointmentsArray);
        return openApptOutput;
    }

    public void trackEventToNifi(EventTracker trackEvents, AvailabilityRequest availabilityRequest,
                                 DataflowStatus dataflowStatus, String totalFragments, String fragmentId,
                                 Map<String, Object> payload) {
        NifiTrackingEvent nifiEvent = NifiTrackingEvent.builder().flowPoint(dataflowStatus.toString())
                .messageControlId(availabilityRequest.getMessageControlId())
                .appointmentType(availabilityRequest.getAppointmentType())
                .sliceId(availabilityRequest.getSliceId())
                .deploymentId(availabilityRequest.getDeploymentId()).totalFragments(totalFragments)
                .fragmentId(fragmentId).totalSlices(availabilityRequest.getTotalSlices()).payload(payload)
                .entityType(availabilityRequest.getEntityType()).entityId(availabilityRequest.getEntityId())
                .flow(availabilityRequest.getFlow()).build();
        trackEvents.trackEventToNifi(nifiEvent);
    }
}