package com.pes.integration.allscripts.task;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class RealTimeOpenSlotsTaskTest {

    AllscriptsApiCaller allscriptsApiCaller = mock(AllscriptsApiCaller.class);
    RealTimeRequest realTimeRequest = mock(RealTimeRequest.class);
    RealTimeOpenSlotsTask realTimeOpenSlotsTask;

    @BeforeEach
    void setUp() {

        allscriptsApiCaller = mock(AllscriptsApiCaller.class);

        JSONObject openRequest = new JSONObject();
        openRequest.put("startDate", "2023-01-01");
        openRequest.put("endDate", "2023-01-02");
        openRequest.put("provider", "provider1");
        openRequest.put("appointmentPath", "path/to/appointment");
        openRequest.put("appname", "appName");
        openRequest.put("pmusername", "userId");
        openRequest.put("slotInterval", "15");
        openRequest.put("reason", "reason1");


        realTimeOpenSlotsTask = spy(new RealTimeOpenSlotsTask(allscriptsApiCaller, openRequest, realTimeRequest));
    }

    @Test
    void testBuildRequest() throws Exception {
        Method method = RealTimeOpenSlotsTask.class.getDeclaredMethod("buildRequest");
        method.setAccessible(true);
        JSONObject request = (JSONObject) method.invoke(realTimeOpenSlotsTask);
        assertNotNull(request);
        assertEquals("GetAvailableSchedule", request.getString("Action"));
    }

    @Test
    void testGetAvailableTimeBlockRequest() throws Exception {
        Method method = RealTimeOpenSlotsTask.class.getDeclaredMethod("getAvailableTimeBlockRequest");
        method.setAccessible(true);
        JSONObject request = (JSONObject) method.invoke(realTimeOpenSlotsTask);
        assertNotNull(request);
        assertEquals("2023-01-01", request.getString("startDate"));
        assertEquals("2023-01-03", request.getString("endDate")); // nextDate adds one day
        assertEquals("provider1", request.getString("provider"));
    }


    @Test
    void getReturnsValidResponse() throws JsonProcessingException, IHubException {

        try (MockedConstruction<AvailableTimeBlocksTask> construction =
                     Mockito.mockConstruction(AvailableTimeBlocksTask.class, (mock, context) -> {

                         Map<String, String[]> apptTypesBlockMap = new HashMap<>();
                         apptTypesBlockMap.put("01/01/2023location1dept1", new String[]{"reason1", "reason2", "reason3", "reason4"});

                         when(mock.getAvailableTimeBlocks()).thenReturn(apptTypesBlockMap);
                     })) {
                JSONArray expectedResponse = new JSONArray();
                expectedResponse.put(new JSONObject().put("key", "value"));
                JSONObject scheduleObject = new JSONObject();
                scheduleObject.put("OpenSlots1", "10");
                scheduleObject.put("OpenSlots2", "01");
                scheduleObject.put("Available_Date", "01/01/2023");
                scheduleObject.put("Resource_Abbreviation", "provider1");
                scheduleObject.put("Scheduling_Location_Abbreviation", "location1");
                scheduleObject.put("Scheduling_Department_Abbreviation", "dept1");
                JSONArray scheduleArray = new JSONArray();
                scheduleArray.put(scheduleObject);
                JSONObject availableSchedule = new JSONObject();
                availableSchedule.put("Schedule", scheduleArray);

                when(realTimeRequest.getDeploymentId()).thenReturn("deploymentId");
                when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                        .thenReturn(availableSchedule);

                JSONArray result = realTimeOpenSlotsTask.get();

                assertNotNull(result);
                assertEquals(2, result.length());
        }
    }

    @Test
    void getHandlesJsonProcessingException() throws JsonProcessingException, IHubException {
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenThrow(new IHubException(new IHubErrorCode("code"), "message"));

        assertThrows(NullPointerException.class, () -> realTimeOpenSlotsTask.get());
    }

    @Test
    void getHandlesIHubException() throws JsonProcessingException, IHubException {
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenThrow(IHubException.class);

        assertThrows(RuntimeException.class, () -> realTimeOpenSlotsTask.get());
    }
}