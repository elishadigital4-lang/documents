package com.pes.integration.allscripts.service.open;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.service.open.impl.OpenAppointmentServiceImpl;
import com.pes.integration.allscripts.task.AvailableTimeBlocksTask;
import com.pes.integration.allscripts.task.RealTimeOpenSlotsTask;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.upload.FileUploader;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.FileUtil;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pes.integration.constant.EpmConstant.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpenAppointmentServiceTest {

    @Mock
    private EventTracker trackEvents;

    @Mock
    private AllscriptsApiCaller allscriptApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private RealTimeOpenSlotsTask realTimeOpenSlotsTask;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;
    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private FileUtil fileUtil;

    @InjectMocks
    private OpenAppointmentServiceImpl openAppointmentServiceImpl;

    private AvailabilityRequest availabilityRequest;
    private JSONObject inputParam;
    private JSONObject outputObject;
    private JSONObject provLocObj;
    private RealTimeRequest realTimeRequest;
    private Map<String, JSONArray> providerLocationMap;
    private String startDate;
    private String endDate;
    private JSONArray locations;
    private String deploymentId;
    private String providerId;
    private String epmPrefix;
    private JSONObject appointmentTypeRequest;

    @BeforeEach
    void setUp() throws IHubException {
        startDate = "2023-01-01";
        endDate = "2023-01-10";
        locations = new JSONArray().put("location1");
        deploymentId = "deploymentId";
        providerId = "providerId";
        epmPrefix = "epmPrefix";

        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("messageControlId");
        availabilityRequest.setAppointmentType("appointmentType");
        availabilityRequest.setSliceId("sliceId");
        availabilityRequest.setDeploymentId("deploymentId");
        availabilityRequest.setTotalSlices("5");
        availabilityRequest.setFlow("flow");
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-10");
        availabilityRequest.setIndex("1");

        providerLocationMap = new HashMap<>();
        providerLocationMap.put("locationIdList", new JSONArray().put("location1"));
        providerLocationMap.put("providerIdList", new JSONArray().put("provider1"));
        realTimeRequest = new RealTimeRequest();
        realTimeRequest.setDeploymentId("deploymentId");
        realTimeRequest.setMessageControlId("messageControlId");
        realTimeRequest.setStartDate("2023-01-01");
        realTimeRequest.setEndDate("2023-01-10");
        realTimeRequest.setEntityType("entityType");
        realTimeRequest.setFlow("flow");
        realTimeRequest.setEntityId(new JSONArray().put(new JSONObject().put("locationId", "1").put("providerId", "1").put("reasonId", "1")));

        provLocObj = new JSONObject();
        provLocObj.put("locationId", "location1");
        provLocObj.put("providerId", "provider1");
        provLocObj.put("reasonId", "reason1");
        provLocObj.put("slotInterval", "slotInterval");
        provLocObj.put("appname", "appname");

        inputParam = new JSONObject();
        inputParam.put("departmentid", new JSONArray().put("location1"));
        inputParam.put("providerId", "providerId");
        inputParam.put("deploymentId", "deployment123");
        inputParam.put("reasonMapExist", "true");
        inputParam.put("maxPoolSize", "10");
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-10");
        inputParam.put("practice_id", "practiceId");
        inputParam.put("ignoreSchedPermission", "ignoreSchedPermission");
        inputParam.put("limit", "10");
        inputParam.put("reason_id", "reasonId");
        inputParam.put("appt_resource_id", "resourceId");
        inputParam.put("appt_location_id", "locationId");

        ReflectionTestUtils.setField(openAppointmentServiceImpl, "trackEvents", trackEvents);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataCacheManager", dataCacheManager);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "fileUploader", fileUploader);
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "objectMapper", objectMapper);
    }

    @Test
    void testGetFragmentsDetails() throws Exception {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setTotalSlices("5");

        JSONArray providerLocation = new JSONArray();
        providerLocation.put("LOCATION_ID_LIST");

        // Use reflection to invoke the private method
        Map<String, Object> result = ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getFragmentsDetails", availabilityRequest, providerLocation);

        // Verify the result
        assertEquals(1, result.get(TOTAL_FRAGMENTS));
        assertEquals("5", result.get(TOTAL_SLICES));
    }

    @Test
    void testGetRealTimeInputObject_Success() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        JSONObject result = ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getRealtimeInputObject", realTimeRequest, provLocObj);

        assertEquals("location1", result.getString("location"));
        assertEquals("provider1", result.getString("provider"));
        assertEquals("2023-01-01", result.getString(STARTDATE));
        assertEquals("2023-01-10", result.getString(ENDDATE));
        assertEquals("configValue", result.getString("slotInterval"));
    }

    @Test
    void testGetInputObject() throws IHubException {
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getInputObject", startDate, endDate, availabilityRequest);

        assertEquals(startDate, result.getString(STARTDATE));
        assertEquals(endDate, result.getString(ENDDATE));
        assertEquals("configValue", result.getString("appname"));
        assertEquals("configValue", result.getString("slotInterval"));
        assertEquals("configValue", result.getString("pmusername"));

    }

    @Test
    void testGetInputObject_WithDepartmentId() {
        JSONObject inputParam = new JSONObject();
        inputParam.put("departmentid", new JSONArray().put("location1"));
        inputParam.put("startDate", "2023-01-01");
        inputParam.put("endDate", "2023-01-10");
        inputParam.put("practiceid", "practice_id");
        inputParam.put("reason_id", "reasonId");
        inputParam.put("ignore_schedulable_permission", "ignore_sched_permission");

        OpenAppointmentServiceImpl service = new OpenAppointmentServiceImpl();

        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getInputObject", startDate, endDate, availabilityRequest);

        assertEquals("2023-01-01", result.getString("startDate"));
        assertEquals("2023-01-10", result.getString("endDate"));
    }

    @Test
    void testGetOpenAppointment_InvalidIdException() throws Exception {
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getOpenAppointmentObject", new JSONArray(), realTimeRequest);

        assertEquals("deploymentId", result.getString(DEPLOYMENT_ID));
        assertEquals("messageControlId", result.getString(MESSAGE_CONTROL_ID));
        assertEquals(0, result.get(TOTAL_COUNT));
    }

    @Test
    void testGetAvailability_Success() throws JsonProcessingException, ParseException, IHubException {

        // Use a spy to mock the fetchOpenAppointments method
        OpenAppointmentServiceImpl spyService = spy(openAppointmentServiceImpl);
        doNothing().when(spyService).fetchOpenAppointments(any(), any());

        // Call the method and assert the result
        JSONArray result = spyService.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix");

        assertNull(result);
    }

    @Test
    void testGetAvailability_ParseException() throws ParseException {
        // Mock the necessary methods to throw ParseException
        try (MockedStatic<DateUtils> dateUtil = mockStatic(DateUtils.class)) {

            dateUtil.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString())).thenThrow(new ParseException("ParseException", 0));

            availabilityRequest.setStartDate("invalid-date");

            // Call the method and assert the exception
            assertThrows(RuntimeException.class, () -> openAppointmentServiceImpl.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix"));
        }
    }

    @Test
    void testFetchOpenAppointments_ParseException() {
        // Arrange
        String invalidDate = "invalid-date";
        ReflectionTestUtils.setField(openAppointmentServiceImpl, "dataCacheManager", dataCacheManager);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            openAppointmentServiceImpl.fetchOpenAppointments(availabilityRequest, providerLocationMap);
        });
    }


    @Test
    void testPrivateMethodInvocation() throws Exception {
        String startDate = "2023-01-01";
        String endDate = "2023-01-10";

        JSONObject result = ReflectionTestUtils.invokeMethod(
                openAppointmentServiceImpl, "getInputObject", startDate, endDate, availabilityRequest);

        assertNotNull(result);
        assertEquals(startDate, result.getString("startDate"));
        assertEquals(endDate, result.getString("endDate"));
    }

    @Test
    void fetchOpenAppointmentsExecutesSuccessfully() throws JsonProcessingException, IHubException {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-10");
        availabilityRequest.setEntityId("entityId");
        availabilityRequest.setDeploymentId("deploymentId");
        availabilityRequest.setIndex("0");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        providerLocationMap.put(PROVIDER_ID_LIST, new JSONArray().put("provider1"));

//        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        OpenAppointmentServiceImpl spyService = spy(openAppointmentServiceImpl);
        doNothing().when(spyService).fetchOpenAppointments(any(), any());

        spyService.fetchOpenAppointments(availabilityRequest, providerLocationMap);

        verify(spyService, times(1)).fetchOpenAppointments(availabilityRequest, providerLocationMap);
    }

    @Test
    void fetchOpenAppointmentsHandlesParseException() throws JsonProcessingException, IHubException {
        AvailabilityRequest availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setStartDate("invalid-date");
        availabilityRequest.setEndDate("2023-01-10");

        Map<String, JSONArray> providerLocationMap = new HashMap<>();

        assertThrows(EpmApiCallerException.class, () -> openAppointmentServiceImpl.fetchOpenAppointments(availabilityRequest, providerLocationMap));
    }


    @Test
    void getRealTimeAvailabilityReturnsValidResponse() throws Exception {
        try (MockedConstruction<RealTimeOpenSlotsTask> construction =
                     Mockito.mockConstruction(RealTimeOpenSlotsTask.class, (mock, context) -> {
                         when(mock.get()).thenReturn(new JSONArray().put(new JSONObject().put("key", "value")));
                     })) {
            RealTimeRequest realTimeRequest = new RealTimeRequest();
            realTimeRequest.setStartDate("2023-01-01");
            realTimeRequest.setEndDate("2023-01-10");

            OpenAppointmentServiceImpl spyService = spy(openAppointmentServiceImpl);
            JSONArray mockOpenAppointmentsArray = new JSONArray();
            JSONObject mockAppointment = new JSONObject();
            mockAppointment.put("slotId", "slot1");
            mockOpenAppointmentsArray.put(mockAppointment);
            realTimeRequest.setEntityId(List.of(mockOpenAppointmentsArray));
            ObjectWriter objectWriter = mock(ObjectWriter.class);
            when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
            when(objectWriter.writeValueAsString(any())).thenReturn(mockOpenAppointmentsArray.toString());
//        doNothing().when(spyService).fetchRealtimeOpenAppointments(any());
//        doReturn(mockOpenAppointmentsArray).when(spyService).fetchRealtimeOpenAppointments(any());

            JSONObject result = spyService.getRealTimeAvailability(realTimeRequest);

            assertNotNull(result);
            assertEquals("value", result.getJSONArray("data").getJSONObject(0).getString("key"));
            assertEquals("1", result.getBigInteger("totalCount").toString());
        }
    }

    @Test
    void getRealTimeAvailabilityHandlesException() throws Exception {
        RealTimeRequest realTimeRequest = new RealTimeRequest();
        realTimeRequest.setStartDate("2023-01-01");
        realTimeRequest.setEndDate("2023-01-10");
        realTimeRequest.setEntityId(List.of("entity1", "entity2"));

        OpenAppointmentServiceImpl spyService = spy(openAppointmentServiceImpl);
//        doThrow(new EpmApiCallerException("Error in getting the slot")).when(spyService).fetchRealtimeOpenAppointments(any());

        assertThrows(EpmApiCallerException.class, () -> spyService.getRealTimeAvailability(realTimeRequest));
    }

}