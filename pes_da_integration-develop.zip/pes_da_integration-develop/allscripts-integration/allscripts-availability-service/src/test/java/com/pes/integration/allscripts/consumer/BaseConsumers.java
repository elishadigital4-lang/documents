package com.pes.integration.allscripts.consumer;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.repository.RedisRepository;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mock;


public class BaseConsumers {
    @Mock
    protected EventTracker eventTracker;

    @Mock
    protected RedisRepository terminateBaselineRepository;

    protected AvailabilityRequest availabilityRequest;
    protected ObjectMapper objectMapper;


    @BeforeEach
    public void init() {
//        when(terminateBaselineRepository.findCacheById(TERMINATE_HASH_KEY, TERMINATE_KEY_PREFIX,
//                "terminatedMsid")).thenReturn("terminatedMsid");
//        terminateBaselineRepository.save(TERMINATE_HASH_KEY, TERMINATE_KEY_PREFIX, "terminatedMsid",
//                "terminatedMsid");
    }

    protected ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return objectMapper;
    }

    public static AvailabilityRequest getAppointmentDTO(String appointmentType) {
        AvailabilityRequest apptdto = new AvailabilityRequest();
        String currentDate = "2024-08-20";
        apptdto.setSliceId("samplechunkId");
        apptdto.setAppointmentType(appointmentType);
        apptdto.setDeploymentId("74468^0001");
        apptdto.setStartDate(currentDate);
        apptdto.setEndDate(currentDate);
        apptdto.setMessageControlId("sampleId01234");
        apptdto.setTotalSlices("4");
        apptdto.setIndex("1");
        apptdto.setFlow("Baseline");
        return apptdto;
    }

}

