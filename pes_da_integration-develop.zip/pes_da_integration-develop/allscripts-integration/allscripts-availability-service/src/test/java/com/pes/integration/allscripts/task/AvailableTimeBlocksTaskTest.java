package com.pes.integration.allscripts.task;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AvailableTimeBlocksTaskTest {

    private AllscriptsApiCaller allscriptsApiCaller;
    private AvailableTimeBlocksTask availableTimeBlocksTask;

    @BeforeEach
    void setUp() {
        allscriptsApiCaller = mock(AllscriptsApiCaller.class);
        JSONObject availableTimeRequest = new JSONObject();
        availableTimeRequest.put("startDate", "2023-01-01");
        availableTimeRequest.put("endDate", "2023-01-02");
        availableTimeRequest.put("provider", "provider1");
        availableTimeRequest.put("token", "token1");
        availableTimeRequest.put("appName", "appName1");
        availableTimeRequest.put("userId", "userId1");
        availableTimeRequest.put("exReasonId", "exReasonId1");

        availableTimeBlocksTask = new AvailableTimeBlocksTask("deploymentId1", availableTimeRequest, allscriptsApiCaller);
    }

    @Test
    void testGetAvailableTimeBlocks_Success() throws IHubException {
        JSONObject response = new JSONObject();
        JSONArray tempArray = new JSONArray();
        JSONObject blockObject = new JSONObject();
        blockObject.put("EligApptTypes", "type1|type2|exReasonId1");
        blockObject.put("Available_Date", "2023-01-01");
        blockObject.put("SchedLoc", "loc1");
        blockObject.put("SchedDept", "dept1");
        blockObject.put("Start_Time", "0900");
        blockObject.put("End_Time", "1000");
        tempArray.put(blockObject);
        response.put("temp", tempArray);

        when(allscriptsApiCaller.call(eq("deploymentId1"), eq("get_avilable_time_blocks"), any(JSONObject.class), eq("")))
                .thenReturn(response);

        Map<String, String[]> result = availableTimeBlocksTask.getAvailableTimeBlocks();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.keySet().toString().contains("2023-01-01"));
    }

    @Test
    void testGetAvailableTimeBlocks_EmptyResponse() throws IHubException {
        JSONObject response = new JSONObject();

        when(allscriptsApiCaller.call(eq("deploymentId1"), eq("get_avilable_time_blocks"), any(JSONObject.class), eq("")))
                .thenReturn(response);

        Map<String, String[]> result = availableTimeBlocksTask.getAvailableTimeBlocks();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetAvailableTimeBlocks_NoEligibleTypes() throws IHubException {
        JSONObject response = new JSONObject();
        JSONArray tempArray = new JSONArray();
        JSONObject blockObject = new JSONObject();
        blockObject.put("EligApptTypes", "type3|type4");
        blockObject.put("Available_Date", "2023-01-01");
        blockObject.put("SchedLoc", "loc1");
        blockObject.put("SchedDept", "dept1");
        blockObject.put("Start_Time", "0900");
        blockObject.put("End_Time", "1000");
        tempArray.put(blockObject);
        response.put("temp", tempArray);

        when(allscriptsApiCaller.call(eq("deploymentId1"), eq("get_avilable_time_blocks"), any(JSONObject.class), eq("")))
                .thenReturn(response);

        Map<String, String[]> result = availableTimeBlocksTask.getAvailableTimeBlocks();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetMinutes() throws Exception {
        Method method = AvailableTimeBlocksTask.class.getDeclaredMethod("getMinutes", int.class);
        method.setAccessible(true);
        int minutes = (int) method.invoke(availableTimeBlocksTask, 930);
        assertEquals(114, minutes);
    }

    @Test
    void testBuildRequest() throws Exception {
        Method method = AvailableTimeBlocksTask.class.getDeclaredMethod("buildRequest");
        method.setAccessible(true);
        JSONObject request = (JSONObject) method.invoke(availableTimeBlocksTask);
        assertNotNull(request);
        assertEquals("GetAvailableTimeBlocks", request.getString("Action"));
    }

    @Test
    void testGetAvailableTimeBlocks_NoEligibleType() throws IHubException {
        JSONObject response = new JSONObject();
        JSONArray tempArray = new JSONArray();
        JSONObject blockObject = new JSONObject();
        blockObject.put("EligApptTypes", "type3|type4");
        blockObject.put("Available_Date", "2023-01-01");
        blockObject.put("SchedLoc", "loc1");
        blockObject.put("SchedDept", "dept1");
        blockObject.put("Start_Time", "0900");
        blockObject.put("End_Time", "1000");
        tempArray.put(blockObject);
        response.put("temp", tempArray);

        when(allscriptsApiCaller.call(eq("deploymentId1"), eq("get_avilable_time_blocks"), any(JSONObject.class), eq("")))
                .thenReturn(response);

        Map<String, String[]> result = availableTimeBlocksTask.getAvailableTimeBlocks();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetAvailableTimeBlocks_MissingTempKey() throws IHubException {
        JSONObject response = new JSONObject();

        when(allscriptsApiCaller.call(eq("deploymentId1"), eq("get_avilable_time_blocks"), any(JSONObject.class), eq("")))
                .thenReturn(response);

        Map<String, String[]> result = availableTimeBlocksTask.getAvailableTimeBlocks();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}