package com.pes.integration.allscripts.utils;

import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.pes.integration.utils.DateUtils.getNextDate;
import static org.apache.commons.lang3.StringUtils.EMPTY;

@Slf4j
public class TestUtils {

  public static final String URL = "SampleUrl";
  public static final String DEPLOYMENT_ID = "deploymentId";
  public static final String MESSAGE_CONTROL_ID = "messageControlId";
  public static final String RANDOM_VALUE = "random value";
  public static final String ERROR_MESSAGE = "errorMessage";
  public static final String TIMESTAMP = "timestamp";
  public static final String OPEN_APPOINTMENT_PATH = "/appointments/open";
  public static final String BOOKED_APPOINTMENT_PATH = "/appointments/booked";
  public static final String DATA = "data";

  public static JSONObject getData(String fileName) {
    JSONObject respObject = null;
    try {
      String content = new String(Files.readAllBytes(Paths.get("src/test/resources/" + fileName)));
      respObject = new JSONObject(content);
    } catch (IOException e) {
      log.error(e.getMessage());
    }

    return respObject;
  }

  public static String getDataInString(String fileName) {
    String respObject = EMPTY;
    try {
      respObject = new String(Files.readAllBytes(Paths.get("src/test/resources/" + fileName)));
    } catch (IOException e) {
      log.error(e.getMessage());
    }
    return respObject;
  }


  public static AvailabilityRequest getAppointmentDTO(String appointmentType) {
    AvailabilityRequest apptdto = new AvailabilityRequest();
    String currentDate = getCurrentDate();
    apptdto.setSliceId("samplechunkId");
    apptdto.setAppointmentType(appointmentType);
    apptdto.setDeploymentId("74343^0001");
    apptdto.setStartDate(currentDate);
    apptdto.setEndDate(currentDate);
    apptdto.setMessageControlId("sampleId01234");
    apptdto.setTotalSlices("4");
    apptdto.setIndex("1");
    apptdto.setFlow("Baseline");
    return apptdto;
  }

  public static RealTimeRequest getRealTimeAppointmentDTO() {
    RealTimeRequest realtimeRequest = new RealTimeRequest();
    String currentDate = getCurrentDate();
    realtimeRequest.setDeploymentId("74343^0001");
    realtimeRequest.setStartDate(currentDate);
    realtimeRequest.setEndDate(getNextDate(currentDate, "yyyy-MM-dd", 5));
    realtimeRequest.setMessageControlId("sampleId01234");
    realtimeRequest.setReasonId("1");
    realtimeRequest.setEntityType("location");
    realtimeRequest.setFlow("RealTime");
    return realtimeRequest;
  }


  public static String getCurrentDate() {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    LocalDateTime now = LocalDateTime.now();
    return dtf.format(now);
  }
}
