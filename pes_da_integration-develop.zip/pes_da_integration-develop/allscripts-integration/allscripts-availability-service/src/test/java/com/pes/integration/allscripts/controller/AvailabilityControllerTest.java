package com.pes.integration.allscripts.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pes.integration.allscripts.service.open.impl.OpenAppointmentServiceImpl;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.utils.MetricsUtil;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class) public class AvailabilityControllerTest {

    @Mock
    private OpenAppointmentServiceImpl openAppointmentService;

    @InjectMocks
    private AvailabilityController availabilityController;

    private RealTimeRequest realTimeRequest;
    private JSONObject mockResponse;

    @BeforeEach
    void setUp() {
        realTimeRequest = new RealTimeRequest();
        realTimeRequest.setMessageControlId("testMessageControlId");
        realTimeRequest.setEntityId("testEntityId");
        realTimeRequest.setReasonId("testReasonId");
        realTimeRequest.setFlow("testFlow");
        realTimeRequest.setDeploymentId("testDeploymentId");
        realTimeRequest.setEntityType("testEntityType");
        realTimeRequest.setStartDate("2024-08-20");
        realTimeRequest.setEndDate("2024-08-26");

        mockResponse = new JSONObject();
        mockResponse.put("key", "value");
    }

    @Test
    void testGetRealTimeData_Success() throws JsonProcessingException {
        when(openAppointmentService.getRealTimeAvailability(any(RealTimeRequest.class)))
                .thenReturn(mockResponse);
        try (MockedStatic<MetricsUtil> metricsUtilMockedStatic = mockStatic(MetricsUtil.class)) {
            metricsUtilMockedStatic.when(() -> MetricsUtil.metricRealTimeRequestCount(anyString(), anyString(), anyString())).thenAnswer(invocation -> invocation);
            ResponseEntity<Object> response = availabilityController.getRealTimeData(realTimeRequest);

            assertEquals(true, response.getStatusCode().is2xxSuccessful());
            assertEquals(mockResponse.toString(), response.getBody());
        }
    }
}