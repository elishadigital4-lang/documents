package com.pes.integration.allscripts.task;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.component.EventTracker;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_TYPES;
import static com.pes.integration.constant.EpmConstant.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrepareOpenSlotsTaskTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    private PrepareOpenSlotsTask prepareOpenSlotsTask;
    private JSONObject inputParam;
    private AvailabilityRequest availabilityRequest;

    @BeforeEach
    void setUp() {
        JSONObject openAppointmentRequest = new JSONObject();
        inputParam = new JSONObject();
        inputParam.put(STARTDATE, "2023-01-01");
        inputParam.put(ENDDATE, "2023-01-31");
        inputParam.put("deploymentId", "deployment123");
        inputParam.put("ATHENA_PRACTICE_ID", "practice123");
        inputParam.put(PROVIDER, "provider123");
        inputParam.put("appointmentPath", "appointmentPath123");
        inputParam.put("appname", "appname123");
        inputParam.put("pmusername", "pmusername123");
        inputParam.put("slotInterval", "slotInterval123");

        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setIndex("someIndex");
        availabilityRequest.setDeploymentId("deployment123");
        availabilityRequest.setMessageControlId("messageControl123");
        availabilityRequest.setAppointmentType("appointmentType123");
        availabilityRequest.setSliceId("sliceId123");

        prepareOpenSlotsTask = new PrepareOpenSlotsTask(allscriptsApiCaller, inputParam, fileUploader,
                trackEvents, availabilityRequest);
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "contextMap", Map.of());
    }

    @Test
    void testGet_Success() throws Exception {
        // Mock responses for each call to athenaApiCaller.call
        JSONObject openAppointmentsResponse = new JSONObject();
        openAppointmentsResponse.put(OPEN_APPOINTMENTS, new JSONArray());

        JSONObject appointmentTypesResponse = new JSONObject();
        appointmentTypesResponse.put(APPOINTMENT_TYPES, new JSONArray());

        JSONObject providersResponse = new JSONObject();
        providersResponse.put("PROVIDERS", new JSONArray());

        // Mock the call method to return the appropriate response for each call
        when(allscriptsApiCaller.call(anyString(), any(), any(), any())).thenReturn(openAppointmentsResponse);

        // Call the get method and verify the result
        prepareOpenSlotsTask.get();

        // Verify interactions with mocks
        verify(allscriptsApiCaller, times(1)).call(anyString(), any(), any(), any());
        verify(fileUploader, times(1)).uploadFile(any(), any(), any(), any());
    }

    @Test
    void testGet_WithEpmApiCallerException() throws Exception {
        // Mock the athenaApiCaller.call method to throw EpmApiCallerException
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenThrow(new EpmApiCallerException("API Caller Exception"));

        // Call the get method and verify that the exception is thrown
        prepareOpenSlotsTask.get();

        // Verify interactions with mocks
        verify(allscriptsApiCaller, times(1)).call(any(), any(), any(), any());
        verify(fileUploader, never()).uploadFile(any(), any(), any(), any());
    }

    @Test
    void testGetOpenAppointmentObject() throws Exception {
        // Mock input data
        JSONArray openAppointmentsArray = new JSONArray();
        openAppointmentsArray.put(new JSONObject().put("appointment", "details"));

        JSONArray apptTypes = new JSONArray();
        apptTypes.put(new JSONObject().put("type", "general"));

        JSONArray resources = new JSONArray();
        resources.put(new JSONObject().put("provider", "details"));

        // Expected values
        String expectedDeploymentId = "deployment123";
        String expectedMessageControlId = "messageControl123";

        // Mock the availabilityRequest methods
        AvailabilityRequest mockAvailabilityRequest = mock(AvailabilityRequest.class);
        when(mockAvailabilityRequest.getDeploymentId()).thenReturn(expectedDeploymentId);
        when(mockAvailabilityRequest.getMessageControlId()).thenReturn(expectedMessageControlId);

        // Set the mock object in the prepareOpenSlotsTask instance
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "availabilityRequest", mockAvailabilityRequest);

        // Access the private method using reflection
        Method method = PrepareOpenSlotsTask.class.getDeclaredMethod("getOpenAppointmentObject", JSONArray.class);
        method.setAccessible(true);

        // Invoke the method
        JSONObject result = (JSONObject) method.invoke(prepareOpenSlotsTask, openAppointmentsArray);

        // Verify the result
        assertNotNull(result);
        assertEquals(expectedDeploymentId, result.getString(DEPLOYMENT_ID));
        assertEquals(expectedMessageControlId, result.getString(MESSAGE_CONTROL_ID));
        assertEquals(openAppointmentsArray.length(), result.getInt(TOTAL_COUNT));
        assertEquals(openAppointmentsArray, result.getJSONArray(DATA));
    }


    @Test
    void testOpenAppointments() throws Exception {

        // Mock the allscriptsApiCaller call method
        JSONObject mockResponse = new JSONObject();
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(mockResponse);

        // Access the private method using reflection
        JSONObject result = ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "openAppointments");

        // Verify the result
        assertNotNull(result);
        verify(allscriptsApiCaller, times(1)).call(eq("deployment123"), eq("open_appointments"), any(), eq(""));
    }
    @Test
    void extractOpenSlotsFromResponseReturnsValidResponse() {
        JSONObject availableSchedule = new JSONObject();
        JSONArray scheduleArray = new JSONArray();
        JSONObject scheduleObject = new JSONObject();
        scheduleObject.put("OpenSlots1", "10");
        scheduleObject.put("OpenSlots2", "01");
        scheduleObject.put("Available_Date", "01/01/2023");
        scheduleObject.put("Resource_Abbreviation", "provider1");
        scheduleObject.put("Scheduling_Location_Abbreviation", "location1");
        scheduleObject.put("Scheduling_Department_Abbreviation", "dept1");
        scheduleArray.put(scheduleObject);
        availableSchedule.put("Schedule", scheduleArray);

        Map<String, String[]> apptTypesBlockMap = new HashMap<>();
        apptTypesBlockMap.put("01/01/2023location1dept1", new String[]{"reason1", "reason2", "reason3", "reason4"});

        JSONArray result = ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask,
                "extractOpenSlotsFromResponse",availableSchedule, apptTypesBlockMap);

        System.out.println(result);
        assertNotNull(result);
        assertEquals(2, result.length());
        JSONObject firstSlot = result.getJSONObject(0);
        assertEquals("provider1", firstSlot.getString("providerId"));
        assertEquals("location1@dept1", firstSlot.getString("locationId"));
        assertEquals("reason1", firstSlot.getString("reasonId"));
        assertEquals("0000", firstSlot.getString("startTime"));
    }
    @Test
    void testBuildRequest() throws Exception {
        // Set necessary fields using reflection
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "appName", "appname123");
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "userId", "userid123");
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "provider", "provider123");
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "startDate", "2023-01-01");
        ReflectionTestUtils.setField(prepareOpenSlotsTask, "endDate", "2023-01-31");

        // Access the private method using reflection
        JSONObject result = ReflectionTestUtils.invokeMethod(prepareOpenSlotsTask, "buildRequest");

        // Verify the result
        assertNotNull(result);
    }

}