package com.pes.integration.allscripts.task;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.SlotDTO;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import static com.pes.integration.constant.DocASAPConstants.Key.LOCATIONS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.APPOINTMENT_STATUS;
import static com.pes.integration.constant.EpmConstant.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrepareBookedSlotsTaskTest {

    @InjectMocks
    private PrepareBookedSlotsTask prepareBookedSlotsTask;

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private AvailabilityRequest availabilityRequest;

    @Mock
    private JSONObject inputObject;

    @BeforeEach
    void setUp() {
        JSONObject openAppointmentRequest = new JSONObject();
        inputObject = new JSONObject();
        inputObject.put(STARTDATE, "2023-01-01");
        inputObject.put(ENDDATE, "2023-01-31");
        inputObject.put("deploymentId", "deployment123");
        inputObject.put(LOCATIONS, new JSONArray().put("location1").put("location2").toString());
        inputObject.put(APPOINTMENT_PATH, "appointmentPath");

        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setIndex("someIndex");
        availabilityRequest.setDeploymentId("deployment123");
        availabilityRequest.setMessageControlId("messageControl123");
        availabilityRequest.setAppointmentType("appointmentType123");
        availabilityRequest.setSliceId("sliceId123");


        prepareBookedSlotsTask = new PrepareBookedSlotsTask(allscriptsApiCaller,
                inputObject, fileUploader, trackEvents, availabilityRequest, dataCacheManager, List.of("location1", "location2"));
        ReflectionTestUtils.setField(prepareBookedSlotsTask, "contextMap", Map.of());
    }

    @Test
    void testGetBookedAppointment() throws Exception {
        // Prepare the response object
        JSONObject responseObject = new JSONObject();
        responseObject.put("BookedAppointments", new JSONArray());
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(responseObject);

        // Access the private method using reflection
        Method method = PrepareBookedSlotsTask.class.getDeclaredMethod("getBookedAppointment");
        method.setAccessible(true);

        // Invoke the method
        JSONObject result = (JSONObject) method.invoke(prepareBookedSlotsTask);

        // Verify the result
        assertNotNull(result);
    }

    @Test
    void testExtractBookedSlots() throws Exception {
        JSONObject outputObject = new JSONObject();
        JSONArray tempAppointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        appointmentObject.put("LocalProviderId", "localProviderId");
        appointmentObject.put("ProviderId", "providerId");
        appointmentObject.put("ApptReasonId", "reasonId");
        JSONObject temp = new JSONObject();
        temp.put("start_time", "10:00");
        temp.put("start_date", "01/01/2023");
        appointmentObject.put("temp", temp);
        appointmentObject.put("LocationId", "locationId");
        appointmentObject.put("Duration", 30);
        appointmentObject.put("ExternalApptId", "slotId");
        appointmentObject.put("CreateDateTime", "2023/01/01 10:00:00");
        appointmentObject.put(APPOINTMENT_STATUS, new JSONObject());
        tempAppointmentsArray.put(appointmentObject);
        outputObject.put("BookedAppointments", tempAppointmentsArray);

        JSONObject transformedAppointment = new JSONObject();
        transformedAppointment.put("transformedKey", "transformedValue");

        PrepareBookedSlotsTask spyTask = spy(prepareBookedSlotsTask);
        // Access the private method using reflection
        Method method = PrepareBookedSlotsTask.class.getDeclaredMethod("extractBookedSlots", JSONObject.class);
        method.setAccessible(true);

        // Invoke the method
        JSONArray result = (JSONArray) method.invoke(spyTask, outputObject);

        // Verify the result
        assertNotNull(result);
    }

    @Test
    void processBookedAppointmentExecutesSuccessfully() throws Exception {
        // Mock the response of getBookedAppointment
        JSONObject bookedApptOutput = new JSONObject();
        bookedApptOutput.put("BookedAppointments", new JSONArray());
        PrepareBookedSlotsTask spyTask = spy(prepareBookedSlotsTask);

        // Mock the file upload
        doNothing().when(fileUploader).uploadFile(anyString(), anyString(), anyString(), any(File.class));

        // Ensure no exceptions are thrown
        assertDoesNotThrow(() -> spyTask.processBookedAppointment());

        verify(fileUploader, times(1)).uploadFile(anyString(), anyString(), anyString(), any(File.class));
    }

    @Test
    void extractBookedSlotsReturnsValidResponse() throws Exception {

        JSONObject scheduleObject = new JSONObject();
        scheduleObject.put("ApptTimingEnd", "2023-01-01T11:00:00");
        scheduleObject.put("ExternalApptId", "12345");
        scheduleObject.put("AppointmentDuration", "30");
        scheduleObject.put("EventReasonId", "reasonId");

        JSONObject providerObject = new JSONObject();
        providerObject.put("ProviderId", "providerId");
        providerObject.put("LocationId", "locationId");
        providerObject.put("DepartmentId", "deptId");

        // Create the inner JSONArray and add the scheduleObject
        JSONArray scheduleArray = new JSONArray();
        scheduleArray.put(scheduleObject);

        // Create the inner JSONArray and add the scheduleObject
        JSONArray providerArray = new JSONArray();
        providerArray.put(providerObject);

        // Create the outer JSONObject and add the scheduleArray
        JSONObject schedulingDataObject = new JSONObject();
        schedulingDataObject.put("Schedule", scheduleArray);
        schedulingDataObject.put("Provider", providerArray);

        JSONObject outputObject = new JSONObject();
        JSONArray bookedAppointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        JSONObject tempObject = new JSONObject();
        tempObject.put("start_date_time", "01/01/2023 10:00AM");
        tempObject.put("appointment_status", "location1");
        appointmentObject.put("temp", tempObject);
        appointmentObject.put("SchedulingData", schedulingDataObject);
        bookedAppointmentsArray.put(appointmentObject);
        outputObject.put(APPOINTMENT_SYNC, bookedAppointmentsArray);

        PrepareBookedSlotsTask spyTask = spy(prepareBookedSlotsTask);

        JSONArray result = ReflectionTestUtils.invokeMethod(spyTask, "extractBookedSlots", outputObject);

        Assertions.assertNotNull(result);
        Assertions.assertEquals(1, result.length());
        JSONObject firstSlot = result.getJSONObject(0);
        Assertions.assertEquals("12345", firstSlot.getString("slotId"));
        Assertions.assertEquals("providerId", firstSlot.getString("providerId"));
        Assertions.assertEquals("locationIddeptId", firstSlot.getString("locationId"));
        Assertions.assertEquals("30", firstSlot.getString("duration"));
        Assertions.assertEquals("reasonId", firstSlot.getString("reasonId"));
        Assertions.assertEquals("2023-01-01T00:00:00", firstSlot.getString("date"));
    }

    @Test
    void extractBookedSlotsR_RuntimeException() throws Exception {

        JSONObject scheduleObject = new JSONObject();
        scheduleObject.put("ApptTimingEnd", "2023-01-01T11:00:00");
        scheduleObject.put("ExternalApptId", "12345");
        scheduleObject.put("AppointmentDuration", "30");
        scheduleObject.put("EventReasonId", "reasonId");

        JSONObject providerObject = new JSONObject();
        providerObject.put("ProviderId", "providerId");
        providerObject.put("LocationId", "locationId");
        providerObject.put("DepartmentId", "deptId");

        // Create the inner JSONArray and add the scheduleObject
        JSONArray scheduleArray = new JSONArray();
        scheduleArray.put(scheduleObject);

        // Create the inner JSONArray and add the scheduleObject
        JSONArray providerArray = new JSONArray();
        providerArray.put(providerObject);

        // Create the outer JSONObject and add the scheduleArray
        JSONObject schedulingDataObject = new JSONObject();
        schedulingDataObject.put("Schedule", scheduleArray);
        schedulingDataObject.put("Provider", providerArray);

        JSONObject outputObject = new JSONObject();
        JSONArray bookedAppointmentsArray = new JSONArray();
        JSONObject appointmentObject = new JSONObject();
        JSONObject tempObject = new JSONObject();
        tempObject.put("start_date_time", "01/01/2023 10:00 XAM");
        tempObject.put("appointment_status", "location1");
        appointmentObject.put("temp", tempObject);
        appointmentObject.put("SchedulingData", schedulingDataObject);
        bookedAppointmentsArray.put(appointmentObject);
        outputObject.put(APPOINTMENT_SYNC, bookedAppointmentsArray);

        PrepareBookedSlotsTask spyTask = spy(prepareBookedSlotsTask);

        RuntimeException exception = Assertions.assertThrows(RuntimeException.class, () ->
                ReflectionTestUtils.invokeMethod(spyTask, "extractBookedSlots", outputObject));
        Assertions.assertInstanceOf(ParseException.class, exception.getCause());
        Assertions.assertTrue(exception.getMessage().contains("Unparseable date"));
        Assertions.assertTrue(exception.getMessage().contains("01/01/2023 10:00 XAM"));

    }
}