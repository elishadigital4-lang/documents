package com.pes.integration.allscripts.service.booked;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.service.booked.impl.BookedAppointmentServiceImpl;
import com.pes.integration.component.EventTracker;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.dto.RealTimeRequest;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.upload.FileUploader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.constant.EpmConstant.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookedAppointmentServiceTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private FileUploader fileUploader;

    @Mock
    private EventTracker trackEvents;

    @Mock
    private DataCacheManager dataCacheManager;

    @Mock
    private ObjectMapper objectMapper;
    @InjectMocks
    private BookedAppointmentServiceImpl bookedAppointmentService;

    private AvailabilityRequest availabilityRequest;
    private JSONArray locationJsonArray;

    private JSONObject responseObject;

    private Map<String, JSONArray> providerLocationMap;
    private String startDate;
    private String endDate;
    private String epmPrefix;
    private String deploymentId;

    private RealTimeRequest realTimeRequest;

    @BeforeEach
    void setUp() {
        availabilityRequest = new AvailabilityRequest();
        availabilityRequest.setMessageControlId("12345");
        availabilityRequest.setIndex("1");
        availabilityRequest.setStartDate("2023-01-01");
        availabilityRequest.setEndDate("2023-01-31");
        availabilityRequest.setIndex("1");
        availabilityRequest.setTotalSlices("5");
        availabilityRequest.setDeploymentId("deploymentId");

        responseObject = new JSONObject();
        responseObject.put("BookedAppointments", new JSONArray());

        startDate = "2023-01-01";
        endDate = "2023-01-31";
        locationJsonArray = new JSONArray();
        epmPrefix = "epmPrefix";
        deploymentId = "deploymentId";

        providerLocationMap = new HashMap<>();
        providerLocationMap.put(LOCATION_ID_LIST, new JSONArray());
        epmPrefix = "epmPrefix";

        realTimeRequest = new RealTimeRequest();
    }

    @Test
    void testGetInputObject() throws IHubException {
        JSONObject result = (JSONObject) ReflectionTestUtils.invokeMethod(
                bookedAppointmentService, "getInputObject", startDate, endDate, locationJsonArray);

        assertEquals(startDate, result.getString(STARTDATE));
        assertEquals(endDate, result.getString(ENDDATE));
    }

    @Test
    void testGetFragmentsDetails() {
        Map<String, Object> result = ReflectionTestUtils.invokeMethod(
                bookedAppointmentService, "getFragmentsDetails", availabilityRequest);

        assertEquals("1", result.get(TOTAL_FRAGMENTS));
        assertEquals("5", result.get(TOTAL_SLICES));
    }

    @Test
    void testGetRealTimeAvailability() {
        JSONObject result = bookedAppointmentService.getRealTimeAvailability(realTimeRequest);
        assertNull(result);
    }

    @Test
    void testGetAvailability_Success() throws JsonProcessingException, IHubException, ParseException {
        // Mock the necessary methods
        when(objectMapper.writeValueAsString(any())).thenReturn("availabilityRequest");
        doNothing().when(trackEvents).trackEvent(any(), any(), any(), any());
        when(dataCacheManager.getConfiguration(anyString(), anyString(), anyString(), anyString())).thenReturn("configValue");

        // Use a spy to mock the fetchBookedAppointments method
        BookedAppointmentServiceImpl spyService = spy(bookedAppointmentService);
        doNothing().when(spyService).fetchBookedAppointments(any(), any(), any());

        // Call the method and assert the result
        JSONArray result = spyService.getAvailability(availabilityRequest, providerLocationMap, "epmPrefix");

        // Verify the interactions and assert the result
        verify(trackEvents, times(1)).trackEvent(any(), any(), any(), any());
        verify(spyService, times(1)).fetchBookedAppointments(any(), any(), any());
        assertNull(result);
    }

    @Test
    void testFetchBookedAppointments_ParseException() {
        // Arrange
        String invalidDate = "invalid-date";
        ReflectionTestUtils.setField(bookedAppointmentService, "dataCacheManager", dataCacheManager);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            bookedAppointmentService.fetchBookedAppointments(locationJsonArray, availabilityRequest, new ArrayList<>());
        });
    }
}