package com.pes.integration.allscripts.utils;

import org.apache.commons.io.FileUtils;
import org.json.JSONArray;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.constant.EpmConstant.LOCATION_ID_LIST;
import static com.pes.integration.constant.EpmConstant.PROVIDER_ID_LIST;
import static org.apache.commons.lang3.StringUtils.EMPTY;

public class TestUtil {

    public static final String CONFIGURATION_DATA_PULL_FILTER_TRUE =
            "configurationDataPullFilterTrue.json";
    public static final String OPEN_APPOINTMENT_EPM_RESPONSE = "open-appointment_get_available_scheduler_raw.json";
    public static final String CONFIGURATION_DATA = "configurationData.json";
    public static final String FILTER_DATA = "filterData.json";
    public static final String BOOKED_APPOINTMENT_EPM_RESPONSE = "booked-appointment_raw.json";
    public static final String PRACTICIONER_RESPONSE = "[\n"
            + "  {\n"
            + "    \"getresourcesinfo\": [\n"
            + "      {\n"
            + "        \"Appointment_Group_ID\": \"\",\n"
            + "        \"Resource_ID\": \"363\",\n"
            + "        \"Resource_Type\": \"P\",\n"
            + "        \"Abbreviation\": \"ABBATED\",\n"
            + "        \"Practitioner_ID\": \"29465\",\n"
            + "        \"Description\": \"Abbate APRN, Denise\",\n"
            + "        \"Encounter_Form_Format\": \"\",\n"
            + "        \"Default_Appointment_Type_ID\": \"\"\n"
            + "      },\n"
            + "      {\n"
            + "        \"Appointment_Group_ID\": \"458\",\n"
            + "        \"Resource_ID\": \"2781\",\n"
            + "        \"Resource_Type\": \"P\",\n"
            + "        \"Abbreviation\": \"ABBOTTA\",\n"
            + "        \"Practitioner_ID\": \"37251\",\n"
            + "        \"Description\": \"Abbott APRN, Allison\",\n"
            + "        \"Encounter_Form_Format\": \"\",\n"
            + "        \"Default_Appointment_Type_ID\": \"\"\n"
            + "      }]}]";

    public static Map<String, JSONArray> getProviderLocationMapData() {
        Map<String, JSONArray> providerLocationMap = new HashMap<>();
        JSONArray providers = new JSONArray();
        providers.put("1");
        providers.put("2");
        JSONArray locations = new JSONArray();
        locations.put("2");
        locations.put("4");
        providerLocationMap.put(LOCATION_ID_LIST, locations);
        providerLocationMap.put(PROVIDER_ID_LIST, providers);
        return providerLocationMap;
    }

    public static String getData(String fileName) throws IOException {
        File file = new File("src/test/resources/" + fileName);
        if (file.exists()) {
            return FileUtils.readFileToString(file, Charset.defaultCharset());
        }
        return EMPTY;
    }
}

