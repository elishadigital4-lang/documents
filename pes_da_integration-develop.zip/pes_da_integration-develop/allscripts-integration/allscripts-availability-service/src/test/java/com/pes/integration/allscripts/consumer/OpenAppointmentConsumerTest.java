package com.pes.integration.allscripts.consumer;

import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.enums.DataflowStatus;
import com.pes.integration.exceptions.EpmApiCallerException;
import com.pes.integration.service.AppointmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.enums.DataflowStatus.OPEN_APPOINTMENT_SLICE_PROCESSING_FAILED;
import static com.pes.integration.enums.DataflowStatus.RETRY_OPEN_APPOINTMENT_SLICE_PROCESSING_FAILED;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class OpenAppointmentConsumerTest extends BaseConsumers {

    @Mock
    private AppointmentService openAppointmentService;

    @InjectMocks
    private OpenAppointmentConsumer openAppointmentConsumer;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        availabilityRequest = getAppointmentDTO("open");
        objectMapper = objectMapper();
        openAppointmentConsumer.setObjectMapper(objectMapper);
        doNothing().when(eventTracker).trackEvent(any(AvailabilityRequest.class),
                any(DataflowStatus.class), anyString(), any());

    }

    @Test
    public void Given_ValidRequest_When_Consume_Then_FileAreUploadedAndEventIsTracked()
            throws Exception {
        openAppointmentConsumer.consume(objectMapper.writeValueAsString(availabilityRequest));
        verify(openAppointmentService).getAppointments(any(AvailabilityRequest.class), eq(EPM_NAME_PREFIX));
    }

    @Test
    public void Given_ValidRequest_When_Consume_Then_Then_ExceptionIsThrown() throws Exception {
        doThrow(new EpmApiCallerException("Error while creating files")).when(openAppointmentService)
                .getAppointments(any(AvailabilityRequest.class), eq(EPM_NAME_PREFIX));
        openAppointmentConsumer.consume(objectMapper.writeValueAsString(availabilityRequest));
        verify(eventTracker).trackEvent(any(AvailabilityRequest.class), any(DataflowStatus.class),
                anyString(), any());
    }

    @Test
    public void Given_ValidRequest_AND_isTerminatedBaseline_When_Consume_Then_BaselineNotProcessed()
            throws Exception {
        availabilityRequest.setMessageControlId("terminatedMsid");
        openAppointmentConsumer.consume(objectMapper.writeValueAsString(availabilityRequest));
    }

    @Test
    public void Given_AppointmentParamsWithInvalidDate_When_GetOpenAppointments_Then_ExceptionIsThrown()
            throws Exception {
        availabilityRequest.setStartDate("20-08-2024");
        openAppointmentConsumer.consume(objectMapper.writeValueAsString(availabilityRequest));
        verify(eventTracker).trackEvent(any(AvailabilityRequest.class),
                eq(OPEN_APPOINTMENT_SLICE_PROCESSING_FAILED), anyString(), any());
    }

    @Test
    public void Given_OPEXValidRequest_When_Consume_Then_FileAreUploadedAndEventIsTracked()
            throws Exception {
        openAppointmentConsumer.consume(objectMapper.writeValueAsString(availabilityRequest));
        verify(openAppointmentService).getAppointments(any(AvailabilityRequest.class), eq(EPM_NAME_PREFIX));
    }

    @Test
    public void Given_OPEXInValidRequest_When_Consume_Then_ApiExceptionIsThrownAndEventTracked()
            throws Exception {
        availabilityRequest.setIndex("-1");
        doThrow(new EpmApiCallerException("Api Error occured")).when(openAppointmentService)
                .getAppointments(any(AvailabilityRequest.class), eq(EPM_NAME_PREFIX));
        openAppointmentConsumer.consume(objectMapper.writeValueAsString(availabilityRequest));
        verify(openAppointmentService).getAppointments(any(AvailabilityRequest.class), eq(EPM_NAME_PREFIX));
        verify(eventTracker).trackEvent(any(AvailabilityRequest.class),
                eq(RETRY_OPEN_APPOINTMENT_SLICE_PROCESSING_FAILED), anyString(), any());
    }
}