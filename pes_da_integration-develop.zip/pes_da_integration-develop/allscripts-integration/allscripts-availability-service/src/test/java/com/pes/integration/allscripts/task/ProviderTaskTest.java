package com.pes.integration.allscripts.task;

import com.pes.integration.adapter.BaseApiCaller;
import com.pes.integration.dto.AvailabilityRequest;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ProviderTaskTest {

    private BaseApiCaller baseApiCaller;
    private ProviderTask providerTask;
    private AvailabilityRequest availabilityRequest;

    @BeforeEach
    void setUp() {
        baseApiCaller = mock(BaseApiCaller.class);
        availabilityRequest = mock(AvailabilityRequest.class);

        JSONObject providerRequest = new JSONObject();
        providerRequest.put("token", "someToken");
        providerRequest.put("appname", "someAppName");
        providerRequest.put("pmusername", "someUserId");

        providerTask = new ProviderTask(providerRequest,availabilityRequest, baseApiCaller);
    }

    @Test
    void testGetProvider_Success() throws IHubException {
        JSONObject response = new JSONObject();
        JSONArray resourceArray = new JSONArray();
        JSONObject resourceObject = new JSONObject();
        resourceObject.put("Abbreviation", "Provider1");
        resourceArray.put(resourceObject);
        response.put("Resource", resourceArray);
        when(availabilityRequest.getDeploymentId()).thenReturn("deploymentId");

        when(baseApiCaller.call(eq("deploymentId"),eq("get_resources"), any(JSONObject.class), eq(""))).thenReturn(response);

        JSONArray result = providerTask.getProvider();

        assertNotNull(result);
        assertEquals(1, result.length());
        assertEquals("Provider1", result.getString(0));
    }

    @Test
    void testGetProvider_EmptyResponse() throws IHubException {
        JSONObject response = new JSONObject();
        response.put("Resource", new JSONArray());
        when(availabilityRequest.getDeploymentId()).thenReturn("deploymentId");

        when(baseApiCaller.call(eq("deploymentId"),eq("get_resources"), any(JSONObject.class), eq(""))).thenReturn(response);

        JSONArray result = providerTask.getProvider();

        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void testBuildRequest() throws Exception {
        Method method = ProviderTask.class.getDeclaredMethod("buildRequest");
        method.setAccessible(true);
        JSONObject request = (JSONObject) method.invoke(providerTask);
        assertNotNull(request);
        assertEquals("GetResources", request.getString("Action"));
    }
}