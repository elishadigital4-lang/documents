package com.pes.integration.allscripts.handler;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.component.ConfigCache;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.allscripts.handler.ChangedAppointmentsHandlerService;
import com.pes.integration.allscripts.utils.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.FilterDataService;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.utils.MetricsUtil;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import static com.pes.integration.allscripts.contant.AllscriptsConstants.CODE_CANCELED;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.CODE_NO_SHOW;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_DEPT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.enums.HandlerType.CANCEL_APPOINTMENT;
import static com.pes.integration.enums.HandlerType.NEW_APPOINTMENT;
import static com.pes.integration.enums.HandlerType.NO_SHOW_APPOINTMENT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ChangedAppointmentsHandlerServiceTest {

    @InjectMocks
    private ChangedAppointmentsHandlerService changedAppointmentsHandlerService;

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private HandlerUtils handlerUtils;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private FilterDataService filterDataService;
    @Mock
    private IHubDataServiceDelegator iHubDataServiceDelegator;

    @BeforeEach
    void setUp() {
//        ReflectionTestUtils.setField(changedAppointmentsHandlerService, "iHubDataServiceDelegator", mock(IHubDataServiceDelegator.class));
    }

    @Test
    void testGetFilterDataUsingReflection() throws Exception {
        // Arrange
        String deploymentId = "testDeploymentId";
        FilterDataService mockFilterDataService = mock(FilterDataService.class);
        Object expectedFilterData = new Object(); // Replace with the actual expected object type
        when(mockFilterDataService.getFilterDataFromDocASAP(deploymentId)).thenReturn(expectedFilterData);

        ChangedAppointmentsHandlerService service = new ChangedAppointmentsHandlerService();
        Field filterDataServiceField = ChangedAppointmentsHandlerService.class.getDeclaredField("filterDataService");
        filterDataServiceField.setAccessible(true);
        filterDataServiceField.set(service, mockFilterDataService);

        // Act
        Method getFilterDataMethod = ChangedAppointmentsHandlerService.class.getDeclaredMethod("getFilterData", String.class);
        getFilterDataMethod.setAccessible(true);
        Object actualFilterData = getFilterDataMethod.invoke(service, deploymentId);

        // Assert
        assertNotNull(actualFilterData);
        assertEquals(expectedFilterData, actualFilterData);
    }

    @Test
    void shouldStoreFilterLocationInCache_handlesIHubException() throws IHubException {
        String deploymentId = "testDeploymentId";
        ChangedAppointmentsHandlerService service = new ChangedAppointmentsHandlerService();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        when(mockCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("22"), "Error"));
        org.springframework.test.util.ReflectionTestUtils.setField(service, "cacheManager", mockCacheManager);

        boolean result = org.springframework.test.util.ReflectionTestUtils.invokeMethod(service, "shouldStoreFilterLocationInCache", deploymentId);

        assertFalse(result);
    }

    @Test
    void getBookedStatusesHandlesException() throws IHubException {
        String deploymentId = "testDeploymentId";
        when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Simulated exception"));

        ChangedAppointmentsHandlerService service = new ChangedAppointmentsHandlerService();
        ReflectionTestUtils.setField(service, "cacheManager", cacheManager);

        List<String> result = ReflectionTestUtils.invokeMethod(service, "getBookedStatuses", deploymentId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testProtectedMethods() throws Exception {
        ChangedAppointmentsHandlerService service = new ChangedAppointmentsHandlerService();

        // applyFilter
        Method applyFilterMethod = ChangedAppointmentsHandlerService.class.getDeclaredMethod("applyFilter", String.class, JSONArray.class);
        applyFilterMethod.setAccessible(true);
        JSONArray inputArray = new JSONArray();
        JSONArray resultArray = (JSONArray) applyFilterMethod.invoke(service, "deploymentId", inputArray);
        assertSame(inputArray, resultArray);

        // postE2DSyncAction
        Method postE2DSyncActionMethod = ChangedAppointmentsHandlerService.class.getDeclaredMethod("postE2DSyncAction", JSONArray.class, String.class);
        postE2DSyncActionMethod.setAccessible(true);
        // Should not throw any exception
        postE2DSyncActionMethod.invoke(service, inputArray, "deploymentId");

        // isNewOrg
        Method isNewOrgMethod = ChangedAppointmentsHandlerService.class.getDeclaredMethod("isNewOrg", String.class);
        isNewOrgMethod.setAccessible(true);
        boolean isNew = (boolean) isNewOrgMethod.invoke(service, "deploymentId");
        assertFalse(isNew);

        // updateIsNewOrgConfig
        Method updateIsNewOrgConfigMethod = ChangedAppointmentsHandlerService.class.getDeclaredMethod("updateIsNewOrgConfig", String.class);
        updateIsNewOrgConfigMethod.setAccessible(true);
        // Should not throw any exception
        updateIsNewOrgConfigMethod.invoke(service, "deploymentId");
    }

    @Test
    void getChangedAppointmentsReturnsValidResponse() throws Exception {
        try (MockedStatic<HandlerUtils> handlerUtilsMockedStatic = mockStatic(HandlerUtils.class)) {

            handlerUtilsMockedStatic.when(() -> HandlerUtils.getSyncRunTime(any(DataCacheManager.class), any(IHubDataServiceDelegator.class), eq("testDeploymentId"))).thenReturn("2021-08-20T00:00:00Z");
            JSONObject inputObject = new JSONObject();
            inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

            JSONObject expectedResponse = new JSONObject();
            expectedResponse.put("key", "value");

//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put(OSRID,"testOSRId");
//        jsonObject.put(SYNC_RUN_TIME,"2021-08-20T00:00:00Z");
//        when(iHubDataServiceDelegator.getOrgLastRealTimeRunTime("testDeploymentId")).thenReturn(jsonObject.toString());
            when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(expectedResponse);
            when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "testDeploymentId",
                    ALLSCRIPTS_CONFIG, RUN_REALTIME_BY_FILTER, false)).thenReturn("true");
            JSONObject result = changedAppointmentsHandlerService.getChangedAppointments(inputObject);

            assertNotNull(result);
            assertEquals("value", result.getString("key"));
        }
    }

    @Test
    void getChangedAppointmentsHandlesIHubException() throws Exception {
        try (MockedStatic<HandlerUtils> handlerUtilsMockedStatic = mockStatic(HandlerUtils.class)) {

            handlerUtilsMockedStatic.when(() -> HandlerUtils.getSyncRunTime(any(DataCacheManager.class), any(IHubDataServiceDelegator.class), eq("testDeploymentId"))).thenReturn("2021-08-20T00:00:00Z");
            JSONObject inputObject = new JSONObject();
            inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

            when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new IHubException(new IHubErrorCode("22"), "Error"));
            when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "testDeploymentId",
                    ALLSCRIPTS_CONFIG, RUN_REALTIME_BY_FILTER, false)).thenReturn("true");
            try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
                mockedStatic.when(() -> MetricsUtil.metricErrorCount(anyString(), anyString(), anyString()))
                        .thenAnswer(invocation -> null);

                assertThrows(IHubException.class, () -> changedAppointmentsHandlerService.getChangedAppointments(inputObject));
            }
        }
    }

    @Test
    void buildE2DSyncObjectReturnsValidJSONArray_CANCEL_APPOINTMENT() throws Exception {
        JSONArray appointmentsArray = getAppointmentsArray(CODE_CANCELED);

        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        JSONArray result = changedAppointmentsHandlerService.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);

        System.out.println(result);
        assertNotNull(result);
        assertEquals(1, result.length());
        Assertions.assertTrue(result.getJSONObject(0).has("SchedulingData"));
        Assertions.assertTrue(result.toString().contains(CANCEL_APPOINTMENT.getKey()));
    }

    @Test
    void buildE2DSyncObjectReturnsValidJSONArray_NO_SHOW_APPOINTMENT() throws Exception {
        JSONArray appointmentsArray = getAppointmentsArray(CODE_NO_SHOW);

        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        JSONArray result = changedAppointmentsHandlerService.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);

        System.out.println(result);
        assertNotNull(result);
        assertEquals(1, result.length());
        Assertions.assertTrue(result.getJSONObject(0).has("SchedulingData"));
        Assertions.assertTrue(result.toString().contains(NO_SHOW_APPOINTMENT.getKey()));
    }

    @Test
    void buildE2DSyncObjectReturnsValidJSONArray_NEW_APPOINTMENT() throws Exception {
        JSONArray appointmentsArray = getAppointmentsArray("NEW_APPOINTMENT");

        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
                ALLSCRIPTS_CONFIG, AllscriptsConstants.BOOKED_STATUS,false)).thenReturn("NEW_APPOINTMENT");
        JSONArray result = changedAppointmentsHandlerService.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);

        System.out.println(result);
        assertNotNull(result);
        assertEquals(1, result.length());
        Assertions.assertTrue(result.getJSONObject(0).has("SchedulingData"));
        Assertions.assertTrue(result.toString().contains(NEW_APPOINTMENT.getKey()));
    }

    private static JSONArray getAppointmentsArray(String codeNoShow) {
        JSONObject scheduleObject = new JSONObject();
        scheduleObject.put("ApptTimingEnd", "2023-01-01T11:00:00");
        scheduleObject.put("ExternalApptId", "12345");
        scheduleObject.put("AppointmentDuration", "30");
        scheduleObject.put("EventReasonId", "reasonId");

        JSONObject providerObject = new JSONObject();
        providerObject.put("ProviderId", "providerId");
        providerObject.put("LocationId", "locationId");
        providerObject.put("DepartmentId", "deptId");

        // Create the inner JSONArray and add the scheduleObject
        JSONArray scheduleArray = new JSONArray();
        scheduleArray.put(scheduleObject);

        // Create the inner JSONArray and add the scheduleObject
        JSONArray providerArray = new JSONArray();
        providerArray.put(providerObject);

        // Create the outer JSONObject and add the scheduleArray
        JSONObject schedulingDataObject = new JSONObject();
        schedulingDataObject.put("Schedule", scheduleArray);
        schedulingDataObject.put("Provider", providerArray);

        JSONObject appointmentObject = new JSONObject();
        JSONObject tempObject = new JSONObject();
        tempObject.put("start_date_time", "01/01/2023 10:00AM");
        tempObject.put("appointment_status", codeNoShow);
        appointmentObject.put("temp", tempObject);
        appointmentObject.put("SchedulingData", schedulingDataObject);

        JSONArray appointmentsArray = new JSONArray();
        appointmentsArray.put(appointmentObject);
        return appointmentsArray;
    }

    @Test
    void buildE2DSyncObjectHandlesEmptyAppointmentsArray() throws Exception {
        JSONArray appointmentsArray = new JSONArray();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        JSONArray result = changedAppointmentsHandlerService.buildE2DSyncObject(appointmentsArray, inputObject, deploymentId);

        assertNotNull(result);
        assertEquals(0, result.length());
    }

    @Test
    void addLocationDepartmentListAddsLocationAndDepartment() throws Exception {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        JsonNode filterData = mock(JsonNode.class);
        when(filterData.has(DocASAPConstants.Key.EXT_LOCATION_IDS)).thenReturn(true);
        ArrayNode locationIdsNode = mock(ArrayNode.class);
        when(filterData.get(DocASAPConstants.Key.EXT_LOCATION_IDS)).thenReturn(locationIdsNode);
        when(locationIdsNode.toString()).thenReturn("[\"loc1@dept1\"]");

        ConfigCache.setFilterDataMap(deploymentId, filterData);
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "testDeploymentId",
                ALLSCRIPTS_CONFIG, RUN_REALTIME_BY_FILTER, false)).thenReturn("true");

        ReflectionTestUtils.invokeMethod(changedAppointmentsHandlerService, "addLocationDepartmentList", inputObject, deploymentId);

        System.out.println(inputObject);
        assertTrue(inputObject.has("SchedulingData"));
        assertEquals(List.of("loc1"),inputObject.getJSONObject("SchedulingData").getJSONArray("Provider").getJSONObject(0).get("LocationId"));
        assertEquals(List.of("dept1"),inputObject.getJSONObject("SchedulingData").getJSONArray("Provider").getJSONObject(0).get("DepartmentId"));
    }

    @Test
    void addLocationDepartmentListHandlesEmptyFilterData() throws Exception {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";

        JsonNode filterData = mock(JsonNode.class);
        when(filterData.has(DocASAPConstants.Key.EXT_LOCATION_IDS)).thenReturn(false);

        ConfigCache.setFilterDataMap(deploymentId, filterData);
        when(cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, "testDeploymentId",
                ALLSCRIPTS_CONFIG, RUN_REALTIME_BY_FILTER, false)).thenReturn("true");

        ReflectionTestUtils.invokeMethod(changedAppointmentsHandlerService, "addLocationDepartmentList", inputObject, deploymentId);

        assertFalse(inputObject.has("SchedulingData"));
        assertFalse(inputObject.has("LocationId"));
        assertFalse(inputObject.has("DepartmentId"));
    }
}