package com.pes.integration.allscripts;

import com.pes.integration.exceptions.IHubErrorCode;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.KafkaService;
import com.pes.integration.service.RefreshBaseInitEngine;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InitEngineTest {

    @InjectMocks
    private InitEngine initEngine;

    @Mock
    private KafkaService kafkaService;

    @Mock
    private DataCacheManager cacheManager;

    @Mock
    private AllscriptsInitEngine allscriptsInitEngine;

    @BeforeEach
    void setUp() {
        // Initialize any required fields or mocks here
    }

    @Test
    void initCallsAllscriptsInitEngineAndKafkaService() throws Exception {
        when(cacheManager.getRedisConfig(any())).thenReturn(new JSONObject());

        initEngine.init();

        verify(allscriptsInitEngine, times(1)).init();
    }

}