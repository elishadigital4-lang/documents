package com.pes.integration.allscripts.handler;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.utils.HandlerHelper;
import com.pes.integration.allscripts.utils.HandlerUtils;
import com.pes.integration.component.RedisService;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.pes.integration.constant.DocASAPConstants.Key.DEM;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.APPOINTMENT_SYNC;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DATA;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ChangedPatientsHandlerTest {

    @InjectMocks
    private ChangedPatientsHandler changedPatientsHandler;

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private RedisService redisService;

    @Mock
    private DataCacheManager dataCacheManager;

    @BeforeEach
    void setUp() {
        // Initialize any required fields or mocks here
    }

    @Test
    void getChangedPatientsReturnsValidResponse() throws Exception {
        try (MockedStatic<HandlerUtils> utilsMockedStatic = mockStatic(HandlerUtils.class)) {

            utilsMockedStatic.when(() -> HandlerUtils.getPatientSyncRunTime(any(), anyString())).thenReturn("2023-01-01T00:00:00Z");
            utilsMockedStatic.when(() -> HandlerUtils.getTimeZone(any(), any())).thenReturn("UTC");
            JSONObject inputObject = new JSONObject();
            inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "testDeploymentId");
            JSONObject input = new JSONObject();
            JSONObject data = new JSONObject();
            JSONArray appointmentSync = new JSONArray();
            JSONObject appointment = new JSONObject();
            appointment.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("Section", "dem"))));
            appointmentSync.put(new JSONArray().put(appointment));
            data.put(APPOINTMENT_SYNC, appointmentSync);
            input.put(DATA, data);

            JSONObject expectedResponse = new JSONObject();
            expectedResponse.put("key", "value");

            when(allscriptsApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(data);

            JSONObject result = changedPatientsHandler.getChangedPatients(inputObject);
            System.out.println(result);
            assertNotNull(result);
            assertEquals(result.toString(), data.toString());
        }
    }

    @Test
    void getChangedPatientsReturnsValidResponse_Empty() throws Exception {
        try (MockedStatic<HandlerUtils> utilsMockedStatic = mockStatic(HandlerUtils.class)) {

            utilsMockedStatic.when(() -> HandlerUtils.getPatientSyncRunTime(any(), anyString())).thenReturn("2023-01-01T00:00:00Z");
            utilsMockedStatic.when(() -> HandlerUtils.getTimeZone(any(), any())).thenReturn("UTC");
            JSONObject inputObject = new JSONObject();
            inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "testDeploymentId");
            JSONObject input = new JSONObject();
            JSONObject data = new JSONObject();
            JSONArray appointmentSync = new JSONArray();
            JSONObject appointment = new JSONObject();
            appointment.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("Section", "123"))));
            appointmentSync.put(new JSONArray().put(appointment));
            data.put(APPOINTMENT_SYNC, appointmentSync);
            input.put(DATA, data);

            JSONObject expectedResponse = new JSONObject();
            expectedResponse.put("key", "value");

            when(allscriptsApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenReturn(data);

            JSONObject result = changedPatientsHandler.getChangedPatients(inputObject);

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void getChangedPatientsHandlesIHubException() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DocASAPConstants.Key.DEPLOYMENT_ID, "testDeploymentId");

        when(allscriptsApiCaller.call(anyString(), any(JSONObject.class), anyString())).thenThrow(
                new IHubException(new IHubErrorCode("22"), "Error"));

        assertThrows(IHubException.class, () -> changedPatientsHandler.getChangedPatients(inputObject));
    }

    @Test
    void buildE2DSyncObjectReturnsValidJSONArray() throws Exception {
        try (MockedStatic<HandlerHelper> utilsMockedStatic = mockStatic(HandlerHelper.class)) {

            JSONObject expectedOutputJson = new JSONObject();
            expectedOutputJson.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("IsInactive", "1"))));

            utilsMockedStatic.when(() -> HandlerHelper.buildPatientSyncObject(any(JSONObject.class), anyString())).thenReturn(expectedOutputJson);
            JSONArray patientArray = new JSONArray();
            JSONObject appointment = new JSONObject();
            appointment.put("DemographicData", new JSONObject().put("PatientInformation", new JSONArray().put(new JSONObject().put("Section", DEM))));
            patientArray.put(appointment);

            String deploymentId = "testDeploymentId";

            JSONArray result = changedPatientsHandler.buildE2DSyncObject(patientArray, deploymentId);

            assertNotNull(result);
            assertEquals(1, result.length());
            assertEquals(expectedOutputJson.getJSONObject("DemographicData").toString(), result.getJSONObject(0).getJSONObject("DemographicData").toString());
            assertEquals("UpdatePatient", result.getJSONObject(0).getString("message_type"));
        }
    }

    @Test
    void applyFilter() throws Exception {
        JSONArray patientArray = new JSONArray();
        JSONArray result = changedPatientsHandler.applyFilter(patientArray);
        assertNotNull(result);
        assertEquals(patientArray, result);
    }

    @Test
    void postE2DSyncAction() throws Exception {
        JSONArray patientArray = new JSONArray();
        Assertions.assertDoesNotThrow(() -> changedPatientsHandler.postE2DSyncAction(patientArray));
    }

    @Test
    void updateIsNewOrgConfig() throws Exception {
        Assertions.assertDoesNotThrow(() -> changedPatientsHandler.updateIsNewOrgConfig());
    }

    @Test
    void isNewOrg() throws Exception {
        Assertions.assertFalse(changedPatientsHandler.isNewOrg());
    }


}
