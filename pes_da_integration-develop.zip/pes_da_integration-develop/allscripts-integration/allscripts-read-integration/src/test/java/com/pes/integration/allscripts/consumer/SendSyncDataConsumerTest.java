package com.pes.integration.allscripts.consumer;

import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.utils.MetricsUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SendSyncDataConsumerTest {

    @InjectMocks
    private SendSyncDataConsumer sendSyncDataConsumer;

    @Mock
    private SyncDataConsumerService syncDataConsumerService;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @BeforeEach
    void setUp() {
        // Initialize any required fields or mocks here
    }

    @Test
    void consumeSendSyncDataMessageProcessesValidPayload() {
        String payload = "{\"key\":\"value\"}";
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            sendSyncDataConsumer.consumeSendSyncDataMessage(payload);

            verify(syncDataConsumerService, times(1)).processSendSyncData(payload);
        }
    }

    @Test
    void consumeSendSyncDataMessageHandlesNullPayload() {
        String payload = null;
        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            sendSyncDataConsumer.consumeSendSyncDataMessage(payload);

            verify(syncDataConsumerService, times(1)).processSendSyncData(payload);
        }
    }

    @Test
    void listenProcessesValidMessage() {
        String topic = "testTopic";
        String message = "{\"key\":\"value\"}";

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            sendSyncDataConsumer.listen(topic, message);

            verify(syncDataConsumerService, times(1)).processSendSyncData(message);
        }
    }

    @Test
    void listenHandlesNullMessage() {
        String topic = "testTopic";
        String message = null;

        try (MockedStatic<MetricsUtil> mockedStatic = mockStatic(MetricsUtil.class)) {
            mockedStatic.when(() -> MetricsUtil.syncLayerRequestCount(anyString(), anyString(), anyString()))
                    .thenAnswer(invocation -> null);

            sendSyncDataConsumer.listen(topic, message);

            verify(syncDataConsumerService, times(1)).processSendSyncData(message);
        }
    }
}