package com.pes.integration.allscripts.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.component.ConfigCache;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.allscripts.utils.HandlerUtils;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.constant.UtilitiesConstants.JsonConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractE2DSyncHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.service.FilterDataService;
import com.pes.integration.service.IHubDataServiceDelegator;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.MessageControlIdGenerator;
import com.pes.integration.utils.NullChecker;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.pes.integration.allscripts.api.ApiName.CHANGED_APPOINTMENTS;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.allscripts.utils.HandlerUtils.getSyncRunTime;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.DocASAPConstants.DATE_TIME_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_DEPT_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.APPT_LOCATION_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.APPOINTMENT_STATUS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.START_DATE_TIME;
import static com.pes.integration.constant.UtilitiesConstants.FALSE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.enums.HandlerType.CANCEL_APPOINTMENT;
import static com.pes.integration.enums.HandlerType.NEW_APPOINTMENT;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static com.pes.integration.utils.MessageControlIdGenerator.generateMessageControlId;
import static com.pes.integration.utils.MetricsUtil.metricErrorCount;

@Slf4j
@Service(value = "ChangedAppt")
public class ChangedAppointmentsHandlerService extends AbstractE2DSyncHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    DataCacheManager cacheManager;

    @Autowired
    FilterDataService filterDataService;

    @Value("${epm.engine.name}")
    private String engineName;

    @Value("${info.app.description}")
    private String appDescription;

    @Override
    public JSONObject getChangedAppointments(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        try {
            addLocationDepartmentList(inputObject, deploymentId);
            outputObject = allscriptsApiCaller.call(deploymentId, CHANGED_APPOINTMENTS.getKey(), inputObject, "CHANGED_APPOINTMENTS");
        } catch (IHubException ihubExc) {
            metricErrorCount(engineName, appDescription, ihubExc.getMessage());
            log.error("IHUB_EXCEPTION:: While getting changed appointments. Allscripts- ChangedAppts Flow. DeploymentId: {} {}", deploymentId, ihubExc.getMessage());
            throw ihubExc;
        } catch (Exception exc) {
            metricErrorCount(engineName, appDescription, exc.getMessage());
            log.error("EXCEPTION:: Allscripts- ChangedAppts Flow. DeploymentId: {} {}", deploymentId, exc.getMessage());
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), exc.toString());
        }
        return outputObject;
    }

    @SneakyThrows
    @Override
    protected JSONArray buildE2DSyncObject(JSONArray appointmentsArray, JSONObject inputObject,String deploymentId) throws IHubException {
        JSONArray newAppointmentsArray = new JSONArray();
        for (int i = 0; i < appointmentsArray.length(); i++) {
            JSONObject appointmentObject = appointmentsArray.getJSONObject(i);
            Object providerId = getValue(appointmentObject, Key.APPT_PROVIDER_ID);
            setValue(appointmentObject, Key.APPT_RESOURCE_ID, providerId);
            setValue(appointmentObject, Key.APPT_PROVIDER_ID, null);
            String dateTimeFromJson = (String) getValue(appointmentObject, START_DATE_TIME);
            String startDateTime = DateUtils.convertDateFormat(dateTimeFromJson, DATE_TIME_FORMAT_AM_PM_WITHOUT_SEC, DATE_TIME_FORMAT);
            String jsonString = HandlerUtils.handleLocationDeptIdE2D(appointmentObject).toString();
            appointmentObject = new JSONObject(jsonString);
            setValue(appointmentObject, Key.APPOINTMENT_TIMING_START, startDateTime);
            Object appointmentStatus = getValue(appointmentObject, APPOINTMENT_STATUS);
            String messageType = null;
            List<String> bookedStatuses = getBookedStatuses(deploymentId);
            if (appointmentStatus.equals(CODE_CANCELED) ||
                    appointmentStatus.equals(CODE_RESCHEDULED)) {
                setValue(appointmentObject, DEMOGRAPHIC_DATA, null);
                messageType = CANCEL_APPOINTMENT.getKey();
            } else if (appointmentStatus.equals(CODE_NO_SHOW)) {
                setValue(appointmentObject, DEMOGRAPHIC_DATA, null);
                messageType = HandlerType.NO_SHOW_APPOINTMENT.getKey();
            } else if (bookedStatuses.contains(appointmentStatus.toString())) {
                messageType = NEW_APPOINTMENT.getKey();
            }
            setValue(appointmentObject, DocASAPConstants.TempKey.TEMP, null);
            setValue(appointmentObject, MESSAGE_TYPE, messageType);
            setValue(appointmentObject, IS_DEMOGRAPHIC, FALSE);
            setValue(appointmentObject, DEPLOYMENT_ID, deploymentId);
            setValue(appointmentObject, MESSAGE_CONTROL_ID, generateMessageControlId());
            if (messageType != null) {
                newAppointmentsArray.put(appointmentObject);
            }
        }
        return newAppointmentsArray;
    }

    private List<String> getBookedStatuses(String deploymentId) {
        List<String> bookedStatuses = new ArrayList<>();
        try {
            String bookedStatusStr = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
                    ALLSCRIPTS_CONFIG, AllscriptsConstants.BOOKED_STATUS,false);
            if (!NullChecker.isEmpty(bookedStatusStr))
                bookedStatuses = Arrays.asList(bookedStatusStr.split(","));
        } catch (Exception e) {
            log.info("booked_status Config is not set for org: {}", deploymentId);
        }
        return bookedStatuses;
    }

    @Override
    protected JSONArray applyFilter(String deploymentId, JSONArray appointmentsArray) {
        return appointmentsArray;
    }

    @Override
    protected void postE2DSyncAction(JSONArray appointmentsArray, String deploymentId) {
    /*
    Not Required Here
     */
    }

    @Override
    protected boolean isNewOrg(String deploymentId) {
        return false;
    }

    @Override
    protected void updateIsNewOrgConfig(String deploymentId) {
    /*
    Not Required Here
    */
    }

    private void addLocationDepartmentList(Object inputObject, String deploymentId) throws IHubException {
        JSONArray locationIds = null;
        boolean flag = shouldStoreFilterLocationInCache(deploymentId);
        log.info("{} : Add location and department list in realtime pull: {}", deploymentId, flag);
        if (flag) {
            JsonNode filterData = ConfigCache.getFilterDataMap(deploymentId);
            if (NullChecker.isEmpty(filterData)) {
                filterData = (JsonNode) getFilterData(deploymentId);
                ConfigCache.setFilterDataMap(deploymentId, filterData);
            }
            if (!NullChecker.isEmpty(filterData) && filterData.has(Key.EXT_LOCATION_IDS)) {
                ArrayNode locationIdsNode = (ArrayNode) filterData.get(Key.EXT_LOCATION_IDS);
                locationIds = new JSONArray(locationIdsNode.toString());
                getLocationIdsList(inputObject, locationIds);
            }
        }
    }

    private void getLocationIdsList(Object inputObject, JSONArray locationIds) throws IHubException {
        List<String> locationIdsList = new ArrayList<>();
        List<String> departIdList = new ArrayList<>();
        for (int i = 0; i < locationIds.length(); i++) {
            String loacDeptId = locationIds.getString(i);
            String[] splitArray = loacDeptId.split(ATMARK);
            try {
                locationIdsList.add(splitArray[0]);
                departIdList.add(splitArray[1]);
            } catch (Exception e) {
                // Intentionally empty
            }
        }
        setValue(inputObject, APPT_LOCATION_ID, locationIdsList);
        setValue(inputObject, APPT_DEPT_ID, departIdList);
    }

    private boolean shouldStoreFilterLocationInCache(String deploymentId) {
        try {
            String realtimeByFilter = (String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId,
                    ALLSCRIPTS_CONFIG, RUN_REALTIME_BY_FILTER,false);
            return realtimeByFilter.equalsIgnoreCase(UtilitiesConstants.TRUE);
        } catch (IHubException e) {
            log.info("Error while checking if filter location should be stored in cache {} ", e.getMessage());
            return false;
        }
    }

    private Object getFilterData(String deploymentId) throws IHubException {
        return filterDataService.getFilterDataFromDocASAP(deploymentId);
    }
}