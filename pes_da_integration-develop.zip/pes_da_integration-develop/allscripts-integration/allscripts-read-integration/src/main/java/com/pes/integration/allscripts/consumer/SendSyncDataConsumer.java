package com.pes.integration.allscripts.consumer;

import com.pes.integration.service.SyncDataConsumerService;
import com.pes.integration.service.impl.KafkaServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.DocASAPConstants.Key.MESSAGE_TYPE;
import static com.pes.integration.utils.MetricsUtil.syncLayerRequestCount;

@Slf4j
@Service
public class SendSyncDataConsumer extends KafkaServiceImpl {

  @Autowired
  SyncDataConsumerService syncDataConsumerService;

  @Value("${epm.engine.name}")
  private String engineName;

  @Value("${info.app.description}")
  private String appDescription;

  @KafkaListener(topics = "${kafka.sync.data.topic}",
          groupId = "${kafka.config.group.id}", containerFactory = "sampleListListener")
  public void consumeSendSyncDataMessage(@Payload(required = false) String payload) {
    syncLayerRequestCount(engineName, appDescription, "received sync data event on epm specific topic with payload");
    log.info("received sync data event on epm specific topic with payload {} ", payload);
    syncDataConsumerService.processSendSyncData(payload);
    log.info("sync data event consumed and processed on epm topic");
  }

  @Override
  public void listen(String topic, String message) {
    syncLayerRequestCount(engineName, appDescription,"SendSyncDataConsumer-listen on org topic");
    log.info("received sync data  event on org topic with payload {} ", message);
     syncDataConsumerService.processSendSyncData(message);
    log.info("sync data event consumed and process on org topic");
  }

}