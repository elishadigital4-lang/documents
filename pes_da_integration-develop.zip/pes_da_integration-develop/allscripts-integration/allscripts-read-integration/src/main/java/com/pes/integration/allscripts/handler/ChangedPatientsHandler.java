package com.pes.integration.allscripts.handler;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.utils.HandlerHelper;
import com.pes.integration.allscripts.utils.HandlerUtils;
import com.pes.integration.component.RedisService;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.EngineConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.HandlerType;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractE2DSyncPatientHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.MessageControlIdGenerator;
import com.pes.integration.utils.NullChecker;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.allscripts.api.ApiName.CHANGED_PATIENTS;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.allscripts.utils.HandlerUtils.getPatientSyncRunTime;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EngineConstants.REDIS_CHANED_PATIENT_KEY;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.Y;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service(value = "ChangedPatient")
public class ChangedPatientsHandler extends AbstractE2DSyncPatientHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    HandlerUtils handlerUtils;

    @Autowired
    RedisService redisService;

    @Override
    protected JSONObject getChangedPatients(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        String lastPatientSyncDate = getPatientSyncRunTime(dataCacheManager,deploymentId + REDIS_CHANED_PATIENT_KEY);
        buildInput(inputObject, lastPatientSyncDate);

        String currentDate = setSyncRunTime(deploymentId);
        JSONObject outputObject = allscriptsApiCaller.call(CHANGED_PATIENTS.getKey(), inputObject, "E2D");
        validateOutputObject(outputObject);

        log.info("current pull time {} next pull time: {} ::deploymentId:: {}", lastPatientSyncDate, currentDate, deploymentId);
        return outputObject;
    }

    private void validateOutputObject(JSONObject outputObject) throws IHubException {
        Object appointmentSyncObject = JsonUtils.getValue(outputObject, APPOINTMENT_SYNC);
        JSONArray patientsArray = appointmentSyncObject instanceof JSONArray ? (JSONArray) appointmentSyncObject : new JSONArray();
        boolean messageType = false;
        for (int i = 0; i < patientsArray.length(); i++) {
            JSONObject patientObject = patientsArray.getJSONObject(i);
            Object section = JsonUtils.getValue(patientObject, SECTION);
            if (section.equals(DEM)) {
                messageType = true;
                break;
            }
        }
        if (!messageType) {
            outputObject.clear();
        }
    }

    @SneakyThrows
    private void buildInput(JSONObject inputObject, String lastPatientSyncDate) {
        JsonUtils.setValue(inputObject, LAST_PULLED, lastPatientSyncDate);
        JsonUtils.setValue(inputObject, LAST_CHANGED, Y);
    }

    private String setSyncRunTime(String deploymentId) throws IHubException {
        String currentDate = "";
        try {
            String timezone = HandlerUtils.getTimeZone(dataCacheManager,deploymentId);
            currentDate = DateUtils.getCurrentDate(DATE_TIME_FORMAT, timezone, 0);
            redisService.save(deploymentId + REDIS_CHANED_PATIENT_KEY, currentDate);
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        return currentDate;
    }

    @Override
    protected JSONArray buildE2DSyncObject(JSONArray patientArray, String deploymentId) throws IHubException {
        JSONArray newPatientsArray = new JSONArray();
        for (int i = 0; i < patientArray.length(); i++) {
            JSONObject outputJson = new JSONObject();
            JSONObject patientObject = patientArray.getJSONObject(i);

            Object section = JsonUtils.getValue(patientObject, SECTION);

            String messageType = null;
            boolean isMessageTypeAdded = false;

            if (section.equals(DEM)) {
                isMessageTypeAdded = true;
                messageType = HandlerType.UPDATE_PATIENT.getKey();
            }
            if (isMessageTypeAdded) {
                outputJson = HandlerHelper.buildPatientSyncObject(patientObject, deploymentId);
            }

            JsonUtils.copyKey(DEMOGRAPHIC_DATA, outputJson, patientObject);

            // PROD-57509 update patient status and send to product
            Object isInactive = JsonUtils.getValue(outputJson, IS_INACTIVE);
            if (isInactive != null && !isInactive.toString().trim().isEmpty() && "1".equals(isInactive.toString().trim())) {
                JsonUtils.setValue(patientObject, KEPT_PATIENT_ID, "0");
            }
            JsonUtils.setValue(patientObject, DocASAPConstants.TempKey.TEMP, null);
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.MESSAGE_TYPE, messageType);

            String messageControlId = MessageControlIdGenerator.generateMessageControlId();
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, deploymentId);
            JsonUtils.setValue(patientObject, UtilitiesConstants.JsonConstants.MESSAGE_CONTROL_ID, messageControlId);
            if (messageType != null) newPatientsArray.put(patientObject);
        }
        return newPatientsArray;
    }

    @Override
    protected JSONArray applyFilter(JSONArray patientArray) {
        return patientArray;
    }

    @Override
    protected void postE2DSyncAction(JSONArray patientArray) {
        // intentionally empty
    }

    @Override
    protected boolean isNewOrg() throws IHubException {
        return false;
    }

    @Override
    protected void updateIsNewOrgConfig() throws IHubException {
        // intentionally empty
    }
}
