package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractCancelAppointmentsHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static com.pes.integration.allscripts.api.ApiName.CANCEL_APPOINTMENT;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_OBJECT;
import static com.pes.integration.constant.DocASAPConstants.TempKey.STATUS;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.StatusCodes.INVALID_FORMAT;
import static com.pes.integration.enums.StatusCodes.NO_APPOINTMENT_FOUND;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static java.util.Objects.isNull;

@Slf4j
@Service(value = "CancelAppt")
public class CancelAppointmentHandlerService extends AbstractCancelAppointmentsHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Override
    @Observed(name = "integration.cancelAppointment", contextualName = "integration")
    public JSONObject cancelAppointment(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        try {
            DateFormat dateFormat = new SimpleDateFormat(MILITARY_TIME_FORMAT);
            Calendar cal = Calendar.getInstance();
            String currentTime = dateFormat.format(cal.getTime());
            setValue(inputObject, UPDATE_TIME, currentTime);
            setValue(inputObject, STATUS, CODE_CANCELED);
            outputObject = allscriptsApiCaller.call(deploymentId, CANCEL_APPOINTMENT.getKey(), inputObject, Flow.CANCEL_APPOINTMENT.getKey());
            Object errorMessage = getValue(outputObject, "temp.error_message");
            if(errorMessage !=null){
                throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), errorMessage.toString());
            }
        } catch (IHubException ihubExc) {
            log.error("IHUB_EXCEPTION:: While canceling appointment. Allscripts- CancelAppt Flow. DeploymentId: {} {}", deploymentId, ihubExc.getMessage());
            setExceptionDetails(ihubExc);
            log.error("EXCEPTION:: Allscripts- CancelAppt Flow. DeploymentId: {} {}", deploymentId, ihubExc.getMessage());
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), ihubExc.getMessage());
        } catch (Exception exc) {
            log.error("EXCEPTION:: Allscripts- CancelAppt Flow. DeploymentId: {} {}", deploymentId, exc.getMessage());
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), exc.getMessage());
        }
        JSONObject response  = new JSONObject();
        setValue(response, APPOINTMENT_OBJECT,inputObject);
        return response;
    }

    private void setExceptionDetails(IHubException ihubExc) throws IHubException {
        if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("Appointment not found".toLowerCase()))){
            ihubExc.setStatusCode(NO_APPOINTMENT_FOUND);
        }
        else if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("Patient ID".toLowerCase()))){
            ihubExc.setStatusCode(INVALID_FORMAT);
        }
        else if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("Appointment Id is empty".toLowerCase()))){
            ihubExc.setStatusCode(NO_APPOINTMENT_FOUND);
        }
    }
}