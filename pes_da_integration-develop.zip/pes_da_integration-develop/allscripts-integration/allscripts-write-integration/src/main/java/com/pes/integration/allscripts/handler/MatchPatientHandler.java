package com.pes.integration.allscripts.handler;

import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractMatchPatientHandler;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.utils.NullChecker;
import io.micrometer.observation.annotation.Observed;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.DOB_PLUS_2LN_CHARS_MATCH_COUNT;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.PATIENT_COUNT_THRESHOLD;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.ALLSCRIPTS_CONFIG;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.DocASAPConstants.TempKey.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static java.lang.Integer.parseInt;

@Slf4j
@Service
public class MatchPatientHandler extends AbstractMatchPatientHandler {
    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    DataCacheManager cacheManager;

    private String deploymentId;

    @Override
    @Observed(name = "integration.MatchPatientHandler.doExecute", contextualName = "integration")
    public JSONObject getPatients(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        Map<String, String> patientIdAndName = new HashMap<>();
        try {
            this.deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
            setVolume(inputObject);
            patientIdAndName = setPatientIdAndNameNull(inputObject);
            setValue(inputObject, DocASAPConstants.TempKey.STATUS, "Y"); // search only active patients
            Object mobilePhone = getValue(inputObject, MOBILE_PHONE);
            setValue(inputObject, MOBILE_PHONE, null);
            outputObject = allscriptsApiCaller.call(deploymentId, GET_PATIENT.getKey(), inputObject, "MatchPatient");
            setValue(inputObject, MOBILE_PHONE, mobilePhone);
            Object error = getValue(outputObject, ERROR);
            Integer patientCountThreshold = callStoredProviderConfig(deploymentId);
            Integer countRecordsFound = getApptSyncSize(outputObject);
            StringBuilder baseLogMsg = new StringBuilder(AllscriptsConstants.FOR_DEPLOYMENT_ID + deploymentId);
            log.info(String.valueOf(new StringBuilder(baseLogMsg).append(DOB_PLUS_2LN_CHARS_MATCH_COUNT).append(countRecordsFound)));
            if (countRecordsFound >= patientCountThreshold || (!NullChecker.isEmpty(error) && error.toString().contains("Timed out"))) {
                setFirst2CharsOfLastName(inputObject, patientIdAndName);
                outputObject.clear();
                outputObject = allscriptsApiCaller.call(deploymentId, GET_PATIENT.getKey(), inputObject, "Match_Patient");
                countRecordsFound = getApptSyncSize(outputObject);
                log.info(String.valueOf(new StringBuilder(baseLogMsg)
                        .append(AllscriptsConstants.DOB_PLUS_2LN_CHARS_PLUS_MOBILE_PHONE_MATCH_COUNT).append(countRecordsFound)));
            }
            resetPatientNameAndId(inputObject, patientIdAndName);
        }catch (Exception e) {
            log.error("EXCEPTION:: Allscripts:PatientDemogSearch Flow - While getting the Patients {}", e.getMessage());
            resetPatientNameAndId(inputObject, patientIdAndName);
        }
        return outputObject;
    }

    @Override
    public JSONArray getPatientDemographicsDetails(JSONArray patientsArray) throws IHubException {
        if (pullDemographic(deploymentId)) {
            for (Object patientJsonOb : patientsArray) {
                JSONObject patientInputOb = (JSONObject) patientJsonOb;
                String patientId = getValue(patientInputOb, DocASAPConstants.Key.PATIENT_ID).toString();
                setValue(patientInputOb, DocASAPConstants.TempKey.PATIENT_ID, patientId);
                setValue(patientInputOb, DEPLOYMENT_ID, deploymentId);

                JSONObject patientOutputOb;
                patientOutputOb = allscriptsApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), patientInputOb, "");
                String email = getValue(patientOutputOb, EMAIL).toString();
                setValue(patientInputOb, EMAIL, email);
            }
        }
        return patientsArray;
    }

    @Override
    public boolean isSingleMatch() throws IHubException {
        return false;
    }

    private void setVolume(JSONObject inputObject) {
        try {
            setValue(inputObject, AllscriptsConstants.TEMP_VOLUME, AllscriptsConstants.VOLUME);
        } catch (IHubException e) {
            log.error("EXCEPTION:: Allscripts:PatientDemogSearch Flow - While setting up the volume in the inputObject {}", e.getMessage());
        }
    }

    private Map<String, String> setPatientIdAndNameNull(JSONObject inputObject) {
        Map<String, String> patientIdName = new HashMap<>();
        patientIdName.put(DocASAPConstants.Key.PATIENT_ID, getValue(inputObject, DocASAPConstants.Key.PATIENT_ID).toString());
        patientIdName.put(DocASAPConstants.Key.FIRST_NAME, getValue(inputObject, DocASAPConstants.Key.FIRST_NAME).toString());
        patientIdName.put(DocASAPConstants.Key.LAST_NAME, getValue(inputObject, DocASAPConstants.Key.LAST_NAME).toString());
        try {
            setValue(inputObject, DocASAPConstants.Key.PATIENT_ID, null);
            setValue(inputObject, DocASAPConstants.Key.FIRST_NAME, null);
            setValue(inputObject, DocASAPConstants.Key.LAST_NAME, null);
        } catch (IHubException e) {
            log.info("EXCEPTION:: Allscripts:PatientDemogSearch Flow - While setting up Names and PatientId as Null {}", e.getMessage());
        }
        return patientIdName;
    }

    private Integer getApptSyncSize(JSONObject outputObject) {
        if (outputObject.has(APPOINTMENT_SYNC_ARRAY))
            return ((JSONArray) getValue(outputObject, APPOINTMENT_SYNC_ARRAY)).length();
        return 0;
    }


    private void setFirst2CharsOfLastName(JSONObject inputObject, Map<String, String> patientIdName) {
        try {
            setValue(inputObject, LAST_NAME, patientIdName.get(LAST_NAME).substring(0, 2));
        } catch (IHubException e) {
            log.error("EXCEPTION:: Allscripts:PatientDemogSearch Flow - While setting up the First 2 Chars Of LastName {}", e.getMessage());
        }
    }

    private void resetPatientNameAndId(JSONObject inputObject, Map<String, String> patientIdName) {
        try {
            if (patientIdName.containsKey(FIRST_NAME))
                setValue(inputObject, FIRST_NAME, patientIdName.get(FIRST_NAME));
            if (patientIdName.containsKey(LAST_NAME))
                setValue(inputObject, LAST_NAME, patientIdName.get(LAST_NAME));
            if (patientIdName.containsKey(DocASAPConstants.Key.PATIENT_ID))
                setValue(inputObject, DocASAPConstants.Key.PATIENT_ID, patientIdName.get(DocASAPConstants.Key.PATIENT_ID));
        } catch (IHubException e) {
            log.error("EXCEPTION:: Allscripts:PatientDemogSearch Flow - While setting up the Patient's Name & Id {}", e.getMessage());
        }
    }

    private Integer callStoredProviderConfig(String deploymentId) {
        Integer patCountThreshHold = 0;
        try {
            patCountThreshHold = parseInt((String) cacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX,ALLSCRIPTS_CONFIG, PATIENT_COUNT_THRESHOLD,false));
        } catch (Exception e) {
            log.info("patientCountThreshold is not set for deploymentId {}", deploymentId);
            patCountThreshHold = callStoredComponentConfig(patCountThreshHold);
        }
        return patCountThreshHold;
    }

    private Integer callStoredComponentConfig(Integer patCountThreshHold) {
        try {
            patCountThreshHold = parseInt((String) cacheManager.getStoredComponentConfig(EPM_NAME_PREFIX,ALLSCRIPTS_CONFIG, PATIENT_COUNT_THRESHOLD,false));
        } catch (Exception e) {
            patCountThreshHold = 20; // Default value
        }
        return patCountThreshHold;
    }
}