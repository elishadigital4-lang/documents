package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.allscripts.handler.PatientNotificationPreferences;
import com.pes.integration.allscripts.utils.HandlerUtils;
import com.pes.integration.config.data.ManageFlagsUtility;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.handlers.AbstractNewAppointmentHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.NullChecker;
import io.micrometer.observation.annotation.Observed;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.allscripts.api.ApiName.NEW_APPOINTMENT;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.allscripts.handler.PatientNotificationPreferences.setNotificationPreference;
import static com.pes.integration.constant.CharacterConstants.BLANK;
import static com.pes.integration.constant.DocASAPConstants.DATE_TIME_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.APPOINTMENT_TIMING_START;
import static com.pes.integration.constant.DocASAPConstants.Key.TEXT_NOTIFICATION_STATUS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.PATIENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.enums.Flow.CREATE_APPOINTMENT;
import static com.pes.integration.enums.StatusCodes.*;
import static com.pes.integration.exceptions.UtilityErrors.DATA_VALIDATION_ERROR;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static java.util.Objects.isNull;

@Slf4j
@Service(value = "NewAppt")
public class NewAppointmentHandlerService extends AbstractNewAppointmentHandler {

    @Value("${epm.engine.component_id}")
    String componentId;

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    ManageFlagsUtility manageFlagsUtility;

    @Override
    @Observed(name = "integration.createNewAppointment", contextualName = "integration")
    protected JSONObject createNewAppointment(Object inputObject) throws IHubException {
        JSONObject outputObject = new JSONObject();
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        try {
            String appDtDA = (String) getValue(inputObject, APPOINTMENT_TIMING_START);
            String appDtAllscripts = convertDateFormat(appDtDA, DATE_TIME_FORMAT, AllscriptsConstants.DATE_TIME_FORMAT);
            setValue(inputObject, APPOINTMENT_TIMING_START, appDtAllscripts);
            inputObject = HandlerUtils.handleLocationDeptIdD2E(inputObject);
            addReferringDoctor(inputObject, deploymentId);
            outputObject = allscriptsApiCaller.call(deploymentId, NEW_APPOINTMENT.getKey(), inputObject, CREATE_APPOINTMENT.getKey());
            setValue(inputObject, APPOINTMENT_TIMING_START, appDtDA);
            inputObject = HandlerUtils.handleLocationDeptIdE2D(inputObject);

            try {
                Object textNotificationStatus = getValue(inputObject, TEXT_NOTIFICATION_STATUS);
                Object emailNotificationStatus = getValue(inputObject, Key.EMAIL_NOTIFICATION_STATUS);
                Object voiceNotificationStatus = getValue(inputObject, Key.VOICE_NOTIFICATION_STATUS);

                setNotificationPreference(allscriptsApiCaller,textNotificationStatus, TEXT_NOTIFICATION, (JSONObject) inputObject, deploymentId);
                setNotificationPreference(allscriptsApiCaller,emailNotificationStatus, EMAIL_NOTIFICATION, (JSONObject) inputObject, deploymentId);
                setNotificationPreference(allscriptsApiCaller,voiceNotificationStatus, VOICE_NOTIFICATION, (JSONObject) inputObject, deploymentId);
            } catch (Exception exc) {
                log.info("EXCEPTION:: While setting the patient's notification preference. DeploymentId: {}", deploymentId);
            }
        } catch (IHubException ihubExc) {
            log.error("IHUB_EXCEPTION:: While setting/getting JSON keys. Allscripts- NewAppt Flow. DeploymentId: {} {}", deploymentId, ihubExc.getMessage());
            setExceptionDetails(ihubExc);
            log.error("EXCEPTION:: Allscripts- NewAppt Flow. DeploymentId: {} {}", deploymentId, ihubExc.getMessage());
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), ihubExc.getMessage());
        } catch (Exception exc) {
            log.error("EXCEPTION:: Allscripts- NewAppt Flow. DeploymentId: {} {}", deploymentId, exc.getMessage());
            throw new IHubException(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), exc.getMessage());
        }
        outputObject.remove("SaveAppointment");
        return outputObject;
    }

    private void setExceptionDetails(IHubException ihubExc) throws IHubException {
        if (ihubExc.getMessage() != null && (ihubExc.getMessage().toString().toLowerCase().contains("Available day".toLowerCase())
                && ihubExc.getMessage().toString().toLowerCase().contains("not found".toLowerCase()))) {
            ihubExc.setStatusCode(NO_APPOINTMENT_FOUND);
        }
        else if (ihubExc.getMessage() != null && (ihubExc.getMessage().toString().toLowerCase().contains("PatientID".toLowerCase())
                && ihubExc.getMessage().toString().toLowerCase().contains("not found".toLowerCase()))) {
            ihubExc.setStatusCode(NO_PATIENT_FOUND);
        }
        else if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("The appointment ID is already booked".toLowerCase()))){
            ihubExc.setStatusCode(INVALID_FORMAT);
        }
        else if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("appointmentType".toLowerCase()))){
            ihubExc.setStatusCode(EVENT_REASON_NOT_FOUND);
        }
    }

    @SneakyThrows
    private void addReferringDoctor(Object inputObject, String deploymentId) {
        if (!NullChecker.isEmpty(getValue(inputObject, Key.APPT_REF_PROV)) && (getValue(inputObject, Key.APPT_REF_PROV)).equals(UtilitiesConstants.PATIENT_REFERRING_PROV)) {
            JSONObject outputObject = new JSONObject();
            JSONObject responseObject = new JSONObject();
            try {
                setValue(outputObject, DEPLOYMENT_ID, deploymentId);
                setValue(outputObject, PATIENT_ID, getValue(inputObject, Key.PATIENT_ID));
                responseObject = allscriptsApiCaller.call(deploymentId, GET_PATIENT_DEMOGRAPHICS.getKey(), outputObject, CREATE_APPOINTMENT.getKey());
                if (!NullChecker.isEmpty(getValue(responseObject, Key.REFERRING_DR_ABBR)))
                    setValue(inputObject, Key.REFERRING_DR_ABBR, getValue(responseObject, Key.REFERRING_DR_ABBR));
            } catch (IHubException e) {
                log.info("EXCEPTION::While fetching the PatientDemographics - Allscripts_NewAppt_Flow");
                setValue(inputObject, Key.REFERRING_DR_ABBR, BLANK);
            }
        } else if (!NullChecker.isEmpty(getValue(inputObject, Key.APPT_REF_PROV)))
            setValue(inputObject, Key.REFERRING_DR_ABBR, getValue(inputObject, Key.APPT_REF_PROV));
    }
}