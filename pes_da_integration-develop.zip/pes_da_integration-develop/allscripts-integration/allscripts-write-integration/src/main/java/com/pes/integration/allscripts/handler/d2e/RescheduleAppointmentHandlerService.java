package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service(value = "RescheduleAppt")
public class RescheduleAppointmentHandlerService extends BaseHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Override
    @Observed(name = "integration.rescheduleAppointment", contextualName = "integration")
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        log.info("Start of rescheduleAppointment()");
        JSONObject outputObject = new JSONObject();
        String deploymentId = JsonUtils.getValue(inputObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID).toString();
        try {
            JSONObject newApptInputObject = (JSONObject) inputObject;
            newApptInputObject.put(UtilitiesConstants.JsonConstants.MESSAGE_TYPE, "NewAppt");
            outputObject = allscriptsApiCaller.call(deploymentId, ApiName.NEW_APPOINTMENT.getKey(), newApptInputObject, "rescheduleAppointment");
        } catch (IHubException ihubExc) {
            log.error("IHUB_EXCEPTION:: While rescheduling appointment. Allscripts- RescheduleAppt Flow. DeploymentId: {} {}", deploymentId, ihubExc);
            throw ihubExc;
        } catch (Exception exc) {
            log.error("EXCEPTION:: Allscripts- RescheduleAppt Flow. DeploymentId: {} {}", deploymentId, exc);
            throw new RuntimeException("Error occurred during appointment rescheduling.", exc);
        }
        log.info("End of rescheduleAppointment()");
        return outputObject;
    }
}