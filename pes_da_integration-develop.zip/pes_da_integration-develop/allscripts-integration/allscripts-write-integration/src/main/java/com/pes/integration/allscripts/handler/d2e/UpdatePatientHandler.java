package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants.JsonConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.ParseException;
import java.util.List;

import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.allscripts.handler.PatientNotificationPreferences.setNotificationPreference;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.DocASAPConstants.DOCASAP_DATE_FORMAT;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.EngineConstants.HOME_PHONE;
import static com.pes.integration.constant.EngineConstants.HOME_PHONE_AREACODE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.PATIENT_INFORMATION;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;

@Slf4j
@Service("UpdatePatient")
public class UpdatePatientHandler extends BaseHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    PatientInsuranceHandler patientInsuranceHandler;

    @Override
    @Observed(name = "integration.UpdatePatientHandler", contextualName = "integration")
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        JSONObject responseObject = new JSONObject();
        JSONObject outputObject = new JSONObject();
        handlePhoneNumbersD2E(inputObject, responseObject, deploymentId);
        String daDob = getValue(inputObject, Key.DOB).toString();
        String dob = null;
        try {
            dob = convertDateFormat(daDob, DOCASAP_DATE_FORMAT, AllscriptsConstants.DATE_FORMAT);
        } catch (ParseException e) {
           log.error("Error in DOB {}",e.getMessage());
        }
        setValue(inputObject, Key.DOB, dob);
        try {
            // New Patient API called with patient id acts as Update Patient
            Object textNotificationStatus = getValue(inputObject, TEXT_NOTIFICATION_STATUS);
            Object emailNotificationStatus = getValue(inputObject, EMAIL_NOTIFICATION_STATUS);
            Object voiceNotificationStatus = getValue(inputObject, VOICE_NOTIFICATION_STATUS);
            setNotificationPreference(allscriptsApiCaller,textNotificationStatus, TEXT_NOTIFICATION, inputObject, deploymentId);
            setNotificationPreference(allscriptsApiCaller,emailNotificationStatus, EMAIL_NOTIFICATION, inputObject, deploymentId);
            setNotificationPreference(allscriptsApiCaller,voiceNotificationStatus, VOICE_NOTIFICATION, inputObject, deploymentId);
            copyKey(Key.DA_PATIENT_ID, inputObject, responseObject);
            PhoneNumberUtils.handlePhoneNumbersE2D(responseObject);
            setValue(responseObject, Key.DOB, daDob);
            copyKey(JsonConstants.SCHEDULING_DATA, inputObject, responseObject);
            setValue(responseObject, TempKey.TEMP, null);
            copyKey(JsonConstants.DEPLOYMENT_ID, inputObject, responseObject);
            JSONObject insuranceObject = new JSONObject();
            try {
                copyKey(INSURANCE_INFORMATION, inputObject, responseObject);
                insuranceObject = patientInsuranceHandler.doExecute(responseObject);
            } catch (Exception e) {
                log.info(e.getMessage());
            }
            try {
                Object outputInsurancesObject = getValue(insuranceObject, INSURANCE_INFORMATION);
                JSONArray insurancesArray;
                if (outputInsurancesObject instanceof JSONArray) {
                    JSONArray outputInsurancesArray = (JSONArray) outputInsurancesObject;
                    insurancesArray = updateInsurance(outputInsurancesArray);
                    setValue(responseObject, INSURANCE_INFORMATION, insurancesArray);
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }
            setValue(responseObject, TEXT_NOTIFICATION_STATUS, textNotificationStatus);
            setValue(responseObject, EMAIL_NOTIFICATION_STATUS, emailNotificationStatus);
            setValue(responseObject, VOICE_NOTIFICATION_STATUS, voiceNotificationStatus);
        } catch (Exception e1) {
            log.error(e1.getMessage());
        }
        copyKey(Key.DEMOGRAPHIC_PATIENT_INFO, inputObject, responseObject);
        setValue(outputObject, APPOINTMENT_OBJECT, responseObject);
        return outputObject;
    }

    private void handlePhoneNumbersD2E(JSONObject messageObject, JSONObject responseObject, String deploymentId) throws IHubException {
        JSONObject requestObject = new JSONObject();
        String externalPatientId = getValue(messageObject, Key.PATIENT_ID).toString();
        setValue(requestObject, TempKey.PATIENT_ID, externalPatientId);
        copyKey(JsonConstants.DEPLOYMENT_ID, messageObject, requestObject);
        copyKey(JsonConstants.MESSAGE_CONTROL_ID, messageObject, requestObject);
        copyKey(JsonConstants.MESSAGE_TYPE, messageObject, requestObject);
        copyKey(JsonConstants.DEPLOYMENT_ID, messageObject, responseObject);
        copyKey(JsonConstants.MESSAGE_CONTROL_ID, messageObject, responseObject);
        copyKey(JsonConstants.MESSAGE_TYPE, messageObject, responseObject);
        responseObject = allscriptsApiCaller.call(deploymentId, GET_PATIENT_DEMOGRAPHICS.getKey(), requestObject, Flow.UPDATE_PATIENT.getKey());
        Object homePhoneNumberOrig = getValue(responseObject, Key.HOME_PHONE);
        Object workPhoneNumberOrig = getValue(responseObject, Key.WORK_PHONE);
        Object mobilePhoneNumberOrig = getValue(responseObject, Key.MOBILE_PHONE);
        Integer populateHomePhone;
        Integer populateWorkPhone;
        Integer populateMobilePhone;
        try {
            populateHomePhone = getValue(messageObject, Key.POPULATE_HOME_PHONE) != null ? (Integer) getValue(messageObject, Key.POPULATE_HOME_PHONE) : 1;
        } catch (Exception e) {
            populateHomePhone = 1;
            log.info(e.getMessage());
        }
        try {
            populateWorkPhone = getValue(messageObject, Key.POPULATE_WORK_PHONE) != null ? (Integer) getValue(messageObject, Key.POPULATE_WORK_PHONE) : 1;
        } catch (Exception e) {
            populateWorkPhone = 1;
            log.info(e.getMessage());
        }
        try {
            populateMobilePhone = getValue(messageObject, Key.POPULATE_MOBILE_PHONE) != null ? (Integer) getValue(messageObject, Key.POPULATE_MOBILE_PHONE) : 1;
        } catch (Exception e) {
            populateMobilePhone = 1;
            log.info(e.getMessage());
        }

        Object homePhoneNumber = getValue(messageObject, Key.HOME_PHONE);
        Object homePhoneAreaCode = getValue(messageObject, HOME_PHONE_AREA_CODE);

        Object workPhoneNumber = getValue(messageObject, Key.WORK_PHONE);
        Object workPhoneAreaCode = getValue(messageObject, Key.WORK_PHONE_AREA_CODE);

        Object mobilePhoneNumber = getValue(messageObject, Key.MOBILE_PHONE);
        Object mobilePhoneAreaCode = getValue(messageObject, Key.MOBILE_PHONE_AREA_CODE);

        if (populateHomePhone == 1 && !NullChecker.isEmpty(homePhoneNumber) && !NullChecker.isEmpty(homePhoneAreaCode)) {
            homePhoneNumber = homePhoneAreaCode.toString() + homePhoneNumber;
            setValue(messageObject, Key.HOME_PHONE, homePhoneNumber);
        } else {
            messageObject = removeUnwantedPhones(messageObject, HOME_PHONE, HOME_PHONE_AREACODE);
            if (!NullChecker.isEmpty(homePhoneNumberOrig)) {
                setValue(messageObject, Key.HOME_PHONE, homePhoneNumberOrig);
            }
        }

        if (populateWorkPhone == 1 && !NullChecker.isEmpty(workPhoneNumber) && !NullChecker.isEmpty(workPhoneAreaCode)) {
            workPhoneNumber = workPhoneAreaCode.toString() + workPhoneNumber;
            setValue(messageObject, Key.WORK_PHONE, workPhoneNumber);
        } else {
            messageObject = removeUnwantedPhones(messageObject, Key.WORK_PHONE, Key.WORK_PHONE_AREA_CODE);
            if (!NullChecker.isEmpty(workPhoneNumberOrig)) {
                setValue(messageObject, Key.WORK_PHONE, workPhoneNumberOrig);
            }
        }

        if (populateMobilePhone == 1 && !NullChecker.isEmpty(mobilePhoneNumber) && !NullChecker.isEmpty(mobilePhoneAreaCode)) {
            mobilePhoneNumber = mobilePhoneAreaCode.toString() + mobilePhoneNumber;
            setValue(messageObject, Key.MOBILE_PHONE, mobilePhoneNumber);
        } else {
            messageObject = removeUnwantedPhones(messageObject, Key.MOBILE_PHONE, Key.MOBILE_PHONE_AREA_CODE);
            if (!NullChecker.isEmpty(mobilePhoneNumberOrig)) {
                setValue(messageObject, Key.MOBILE_PHONE, mobilePhoneNumberOrig);
            }
        }

        // handle insurance company phone numbers.
        try {
            if (!NullChecker.isEmpty(getValue(messageObject, INSURANCE_INFORMATION))) {
                JSONArray insuranceArray = getValue(messageObject, INSURANCE_INFORMATION) instanceof JSONArray
                        ? (JSONArray) getValue(messageObject, INSURANCE_INFORMATION)
                        : new JSONArray();
                if (!insuranceArray.isEmpty()) {
                    int insuranceCount = insuranceArray.length();
                    for (int i = 0; i < insuranceCount; i++) {
                        List<Integer> indices = List.of(i);
                        String insCoPhoneNumber = (String) getValue(messageObject, INSURANCE_CO_PHONE, indices);
                        String insCoPhoneAreaCode = (String) getValue(messageObject, INSURANCE_CO_PHONE_AREA_CODE, indices);
                        if (!NullChecker.isEmpty(insCoPhoneAreaCode) && !NullChecker.isEmpty(insCoPhoneNumber)) {
                            insCoPhoneNumber = insCoPhoneAreaCode + insCoPhoneNumber;
                            setValue(messageObject, INSURANCE_CO_PHONE, indices, insCoPhoneNumber);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // do nothing.. phone number will be sent without updation
            log.info(e.getMessage());
        }
    }

    private static JSONObject removeUnwantedPhones(JSONObject messageObject, String phoneKey, String phoneCodeKey) {
        JSONObject demographicData = messageObject.getJSONObject(JsonConstants.DEMOGRAPHIC_DATA);
        JSONArray patientInformation = demographicData.getJSONArray(PATIENT_INFORMATION);
        if (!patientInformation.isEmpty()) {
            JSONObject patientInfo = patientInformation.getJSONObject(0);
            patientInfo.remove(phoneKey);
            patientInfo.remove(phoneCodeKey);
            JSONArray updatedPatientArray = new JSONArray();
            updatedPatientArray.put(patientInfo);
            demographicData.put(PATIENT_INFORMATION, updatedPatientArray);
            messageObject.put(JsonConstants.DEMOGRAPHIC_DATA, demographicData);
        }
        return messageObject;
    }

    private static JSONArray updateInsurance(JSONArray outputInsurancesArray) throws IHubException {
        JSONArray insurancesArray = new JSONArray();
        for (int i = 0; i < outputInsurancesArray.length(); i++) {
            JSONObject outputInsuranceObject = outputInsurancesArray.getJSONObject(i);
            String insId = getValue(outputInsuranceObject, INSURANCE_ID).toString();
            String planId = getValue(outputInsuranceObject, INSURANCE_PLAN_ID).toString();
            setValue(outputInsuranceObject, INSURANCE_PLAN_ID, insId.trim() + ATMARK + planId.trim());
            insurancesArray.put(outputInsuranceObject);
        }
        return insurancesArray;
    }
}