package com.pes.integration.allscripts.handler;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import static com.pes.integration.allscripts.api.ApiName.UPDATE_PATIENT_PREFERENCE;
import static com.pes.integration.allscripts.utils.HandlerHelper.GetPreferenceKeyAndValue;
import static com.pes.integration.constant.DocASAPConstants.Key.DISABLED;
import static com.pes.integration.constant.DocASAPConstants.Key.ENABLED;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;

@Slf4j
@Service
public class PatientNotificationPreferences {
    private PatientNotificationPreferences() {
        // intentionally empty
    }

    public static void setNotificationPreference(AllscriptsApiCaller allscriptsApiCaller,Object notificationStatus, String notificationStatusKey, JSONObject inputObject, String deploymentId) {
        try {
            if (!NullChecker.isEmpty(notificationStatus) && !(notificationStatus.equals(JSONObject.NULL))) {
                String keyWithValues = GetPreferenceKeyAndValue(notificationStatusKey, deploymentId);
                if (!NullChecker.isEmpty(keyWithValues)) {
                    String key = keyWithValues.split(":")[0];
                    String val = keyWithValues.split(":")[1];
                    if (!NullChecker.isEmpty(key) && !NullChecker.isEmpty(val)) {
                        notificationStatusCheck(notificationStatus, inputObject, val, key, allscriptsApiCaller, deploymentId);
                    } else {
                        log.debug("Key or Value is not set for {} {}", sanitizeForLog(String.valueOf(notificationStatus)), deploymentId);
                    }
                }
            }
        } catch (IHubException ihubExc) {
            log.error("IHubEXCEPTION:: While fetching the config/key/value for {} {}", sanitizeForLog(String.valueOf(notificationStatus)), deploymentId);
        } catch (Exception exc) {
            log.error("EXCEPTION:: Some technical error has occurred for {} {}", sanitizeForLog(String.valueOf(notificationStatus)), deploymentId);
        }
    }

    private static void notificationStatusCheck(Object notificationStatus, JSONObject inputObject, String val, String key, AllscriptsApiCaller allscriptsApiCaller,
                                                String deploymentId) throws IHubException {
        if (notificationStatus.toString().equalsIgnoreCase(ENABLED) && !NullChecker.isEmpty(val.split(",")[0])) {
            setValue(inputObject, "temp.key_value", val.split(",")[0].trim());
            setValue(inputObject, "temp.key_name", key);
            callUpdatePreference(allscriptsApiCaller,inputObject, deploymentId);
        } else if (notificationStatus.toString().equalsIgnoreCase(DISABLED) && !NullChecker.isEmpty(val.split(",")[1])) {
            setValue(inputObject, "temp.key_value", val.split(",")[1].trim());
            setValue(inputObject, "temp.key_name", key);
            callUpdatePreference(allscriptsApiCaller,inputObject, deploymentId);
        }
    }

    private static void callUpdatePreference(AllscriptsApiCaller allscriptsApiCaller,JSONObject inputObject, String deploymentId) {
        try {
             allscriptsApiCaller.call(deploymentId, UPDATE_PATIENT_PREFERENCE.getKey(), inputObject, "Update_Patient_Preference");
        } catch (Exception e) {
            log.info("Error in calling:: {} {}", UPDATE_PATIENT_PREFERENCE.getKey(), e.getMessage());
        }
    }
}