package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

import static com.pes.integration.allscripts.api.ApiName.SET_PATIENT_INSURANCE;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;

@Slf4j
@Service
public class PatientInsuranceHandler extends BaseHandler {

    JSONArray inputInsurancesArray = new JSONArray();
    JSONArray outputInsurancesArray = new JSONArray();

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    GetPatientInsurancesHandler  getPatientInsurancesHandler;
    @Override
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        JSONObject outputObject;
        outputObject = getPatientInsurancesHandler.doExecute(inputObject);
        Object inputInsurancesObject = getValue(inputObject, INSURANCE_INFORMATION);
        Object outputInsurancesObject = getValue(outputObject, INSURANCE_INFORMATION);
        String inputPlanId ="";
        boolean isAvailable = false;
        if(inputInsurancesObject != null&& inputInsurancesObject instanceof JSONArray){
            inputInsurancesArray = (JSONArray) inputInsurancesObject;
            inputPlanId = (String) getValue(inputInsurancesArray.get(0), INSURANCE_PAYOR_ID);
        }
        if(!NullChecker.isEmpty(inputInsurancesArray)){
            if(outputInsurancesObject != null&& outputInsurancesObject instanceof JSONArray){
                outputInsurancesArray = (JSONArray) outputInsurancesObject;
            }
            List<String> availableSeq = new ArrayList<>();
            for (int i=0;i<outputInsurancesArray.length();i++) {
                JSONObject outputInsuranceObject = outputInsurancesArray.getJSONObject(i);
                String sequenceNumber = (String) getValue(outputInsuranceObject, SEQUENCE_NUMBER);
                String insId = (String) getValue(outputInsuranceObject, INSURANCE_ID);
                String planId = (String) getValue(outputInsuranceObject, INSURANCE_PLAN_ID);
                if(inputPlanId !=null && inputPlanId.equals(insId.trim() + ATMARK + planId.trim())){
                    isAvailable=true;
                    break;
                } else{
                    availableSeq.add(sequenceNumber);
                }
            }
            if(!isAvailable){
                if(!availableSeq.contains("P")){
                    setValue(inputObject, SEQ_NUMBER, "P");
                }else if (!availableSeq.contains("S")){
                    setValue(inputObject, SEQ_NUMBER, "S");
                }else if (!availableSeq.contains("T")){
                    setValue(inputObject, SEQ_NUMBER, "T");
                }else setValue(inputObject, SEQ_NUMBER, "X");
                if(inputPlanId != null && !inputPlanId.isEmpty()){
                    int index = inputPlanId.indexOf(ATMARK);
                    String insuranceAbr = inputPlanId.substring(0,index);
                    String planCode = inputPlanId.substring(index+1, (inputPlanId.length()));
                    setValue(inputObject, "DemographicData.InsuranceInformation[0].InsId", insuranceAbr);
                    setValue(inputObject, INS_PLAN_ID, planCode);
                    outputObject = allscriptsApiCaller.call(deploymentId, SET_PATIENT_INSURANCE.getKey(), inputObject, "patientInsurance");
                }
            }
        }
        return outputObject;
    }
}
