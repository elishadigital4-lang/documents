package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service
public class GetPatientInsurancesHandler extends BaseHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;
    @Override
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        return allscriptsApiCaller.call(deploymentId, GET_PATIENT_INSURANCE.getKey(),inputObject, "GetPatientInsurancesHandler");
    }
}
