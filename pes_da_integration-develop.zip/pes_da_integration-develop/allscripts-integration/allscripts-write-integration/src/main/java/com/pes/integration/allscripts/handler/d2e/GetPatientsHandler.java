package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.constant.BaseEPMConstants;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants.JsonConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;

@Slf4j
@Service
public class GetPatientsHandler extends BaseHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Override
    @Observed(name = "integration.GetPatientsHandler", contextualName = "integration")
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        JSONObject outputObject = new JSONObject();
        try {
            outputObject = allscriptsApiCaller.call(deploymentId, ApiName.GET_PATIENT.getKey(), inputObject, Flow.SEARCH_PATIENT.getKey());

            // Iterate and change the DOB format needed for get care patient match micro-service
            if (outputObject.has(JsonConstants.APPOINTMENT_SYNC)) {
                JSONArray data = outputObject.getJSONArray(JsonConstants.APPOINTMENT_SYNC);
                for (int i = 0; i < data.length(); i++) {
                    JSONObject json = data.getJSONObject(i);

                    String dob1 = JsonUtils.getValue(json, Key.DOB).toString();
                    dob1 = DateUtils.convertDateFormat(dob1, BaseEPMConstants.EPM_DATE_FORMAT, DocASAPConstants.DOCASAP_DATE_FORMAT);
                    JsonUtils.setValue(json, Key.DOB, dob1);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        JSONArray patientsArray = new JSONArray();
        try {
            patientsArray = outputObject.getJSONArray(JsonConstants.APPOINTMENT_SYNC);
        } catch (Exception e) {
            // intentionally empty
        }

        if (pullDemographic(deploymentId)) {
            getPatientDemographicsDetails(patientsArray,deploymentId);
            JsonUtils.setValue(outputObject, JsonConstants.APPOINTMENT_SYNC, patientsArray);
        }

        log.info("End of method");
        return outputObject;
    }

    private JSONArray getPatientDemographicsDetails(JSONArray patientsArray, String deploymentId) throws IHubException {

        if (pullDemographic(deploymentId)) {
            for (Object patientJsonOb : patientsArray) {
                JSONObject patientInputOb = (JSONObject) patientJsonOb;
                String patientId = JsonUtils.getValue(patientInputOb, Key.PATIENT_ID).toString();
                JsonUtils.setValue(patientInputOb, TempKey.PATIENT_ID, patientId);
                JsonUtils.setValue(patientInputOb, Key.DEPLOYMENT_ID, deploymentId);

                // PROD-59177
                JsonUtils.setValue(patientInputOb, JsonConstants.MESSAGE_TYPE, JsonConstants.MESSAGE_TYPE);
                JsonUtils.setValue(patientInputOb, JsonConstants.MESSAGE_CONTROL_ID, JsonConstants.MESSAGE_CONTROL_ID);

                JSONObject patientOutputOb;
                patientOutputOb = allscriptsApiCaller.call(deploymentId, ApiName.GET_PATIENT_DEMOGRAPHICS.getKey(), patientInputOb, "GET_PATIENT_DEMOGRAPHICS");
                String email = JsonUtils.getValue(patientOutputOb, Key.EMAIL).toString();
                JsonUtils.setValue(patientInputOb, Key.EMAIL, email);
            }
            log.info("End of method");
        }
        return patientsArray;
    }
}