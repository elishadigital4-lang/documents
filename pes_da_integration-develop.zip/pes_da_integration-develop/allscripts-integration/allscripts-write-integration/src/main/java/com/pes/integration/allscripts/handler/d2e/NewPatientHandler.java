package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.allscripts.handler.MatchPatientHandler;
import com.pes.integration.allscripts.handler.PatientNotificationPreferences;
import com.pes.integration.config.data.ManageFlagsUtility;
import com.pes.integration.constant.DocASAPConstants.Key;
import com.pes.integration.constant.DocASAPConstants.TempKey;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.enums.Flow;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.AbstractNewPatientHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.NullChecker;
import com.pes.integration.utils.PhoneNumberUtils;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT_DEMOGRAPHICS;
import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.DATE_FORMAT;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.DATE_FORMAT_ALTERNATE;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.allscripts.handler.PatientNotificationPreferences.setNotificationPreference;
import static com.pes.integration.constant.DocASAPConstants.Key.INSURANCE_INFORMATION;
import static com.pes.integration.constant.DocASAPConstants.Key.NEW_PATIENT_SET_USUAL_PROVIDER;
import static com.pes.integration.constant.UtilitiesConstants.CharacterConstants.BLANK;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.StatusCodes.*;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static com.pes.integration.utils.LogUtil.sanitizeForLog;
import static com.pes.integration.jsonmapper.JsonUtils.*;
import static com.pes.integration.utils.DateUtils.convertDateFormat;
import static com.pes.integration.utils.PhoneNumberUtils.handlePhoneNumberFromFlag;
import static java.util.Objects.isNull;

@Slf4j
@Service(value = "NewPatient")
public class NewPatientHandler extends AbstractNewPatientHandler {

    @Value("${epm.engine.component_id}")
    String componentId;

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    MatchPatientHandler matchPatientHandler;

    @Autowired
    ManageFlagsUtility manageFlagsUtility;

    @Override
    @Observed(name = "integration.allscriptsCreateNewPatient", contextualName = "integration")
    public JSONObject createNewPatient(JSONObject inputObject) throws IHubException {
        String deploymentId = getValue(inputObject, DEPLOYMENT_ID).toString();
        JSONObject outputObject = new JSONObject();
        try {
            outputObject = matchPatientHandler.doExecute(inputObject);
            Object patientId = getValue(outputObject, Key.APPOINTMENT_PATIENT_ID);
            Object error = getValue(outputObject, Key.ERROR_CODE);
            Object errorStr = getValue(outputObject, TempKey.ERROR_MESSAGE);
            setValue(inputObject, Key.PHONE, getValue(inputObject, Key.MOBILE_PHONE));
            setValue(inputObject, Key.MOBILE, getValue(inputObject, Key.MOBILE_PHONE));
            handlePhoneNumberFromFlag(inputObject);
            setValue(inputObject, Key.MOBILE_PHONE, getValue(inputObject, Key.PHONE));
            setPatientDetails(patientId, error, errorStr, inputObject, deploymentId, outputObject);

        } catch (IHubException ihubExc) {
            log.info("IHUB_EXCEPTION:: While creating a new patient- Allscripts engine - DeploymentId:", ihubExc);
            setExceptionDetails(ihubExc);
            throw ihubExc;
        } catch (Exception exc) {
            log.info("EXCEPTION:: DeploymentId:", exc);
        }
        return inputObject;
    }

    private void setPatientDetails(Object patientId, Object error, Object errorStr, JSONObject inputObject,
                                   String deploymentId, JSONObject outputObject) throws IHubException {
        if ((patientId == null || patientId.equals(0)) && !StatusCodes.MULTIPLE_PATIENT.getKey().equals(error) && NullChecker.isEmpty(errorStr)) {
            if (outputObject != null) outputObject.clear();
            setPatientCustomFields(inputObject);
            if (getUsualProviderFlag(deploymentId)) {
                String patientUsualProv = NullChecker.isEmpty(getValue(inputObject, Key.PATIENT_REF_PROV)) ? "" : (String) getValue(inputObject, Key.APPT_RESOURCE_ID);
                setValue(inputObject, Key.PATIENT_REF_PROV_USUAL_PROV, patientUsualProv);
            }
            if (!manageFlagsUtility.checkIfFlagValid(inputObject, Key.POPULATE_PATIENT_REF_PROV))
                manageFlagsUtility.deleteKey(inputObject, Key.PATIENT_REF_PROV);
            outputObject = allscriptsApiCaller.call(deploymentId, ApiName.NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey());
            patientId = getValue(outputObject, Key.PATIENT_ID);
            log.debug("External PatientId: {}", patientId);
            String externalPatientId = patientId + BLANK;
            setValue(inputObject, Key.PATIENT_ID, externalPatientId);
            setValue(outputObject, Key.PATIENT_ID, externalPatientId);
        } else if (!NullChecker.isEmpty(error) && StatusCodes.MULTIPLE_PATIENT.getKey().equals(error)) {
            setValue(outputObject, TempKey.ERROR_MESSAGE, "Multiple matching patients detected");
            setValue(outputObject, Key.ERROR_CODE, StatusCodes.MULTIPLE_PATIENT.getKey());
            log.info("Found multiple matching patients.");
        }
        checkErroStr(errorStr, patientId, outputObject);
        checkPatientId(patientId, inputObject);
        setNotification(patientId, inputObject, deploymentId);
    }

    private void checkErroStr(Object errorStr, Object patientId, JSONObject outputObject) throws IHubException {
        if (!NullChecker.isEmpty(errorStr) && NullChecker.isEmpty(patientId)) {
            setValue(outputObject, TempKey.ERROR_DETAIL, "Error in patient search");
            setValue(outputObject, Key.ERROR_CODE, StatusCodes.EPM_INTERNAL_ERROR.getKey());
            log.info("Error in patient search");
        }
    }

    private void checkPatientId(Object patientId, JSONObject inputObject) throws IHubException {
        if (!NullChecker.isEmpty(patientId)) {
            log.info("No Patient API call");
            setValue(inputObject, Key.PATIENT_ID, patientId.toString());
        }
    }

    private void setNotification(Object patientId, JSONObject inputObject, String deploymentId) {
        if (!NullChecker.isEmpty(patientId)) {
            try {
                Object textNotificationStatus = getValue(inputObject, Key.TEXT_NOTIFICATION_STATUS);
                Object emailNotificationStatus = getValue(inputObject, Key.EMAIL_NOTIFICATION_STATUS);
                Object voiceNotificationStatus = getValue(inputObject, Key.VOICE_NOTIFICATION_STATUS);
                setNotificationPreference(allscriptsApiCaller, textNotificationStatus, TEXT_NOTIFICATION, inputObject, deploymentId);
                setNotificationPreference(allscriptsApiCaller, emailNotificationStatus, EMAIL_NOTIFICATION, inputObject, deploymentId);
                setNotificationPreference(allscriptsApiCaller, voiceNotificationStatus, VOICE_NOTIFICATION, inputObject, deploymentId);
            } catch (Exception exc) {
                log.info("EXCEPTION:: While setting the patient's notification preference. DeploymentId:{}", deploymentId);
            }
        }
    }

    private void setExceptionDetails(IHubException ihubExc) throws IHubException {
        if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("lastname".toLowerCase()))){
            ihubExc.setStatusCode(NO_LAST_NAME_FOUND);
        }
        else if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("firstname".toLowerCase()))){
            ihubExc.setStatusCode(NO_FIRST_NAME_FOUND);
        }
        else if((ihubExc.getMessage()!=null && ihubExc.getMessage().toString().toLowerCase().contains("PRIMARYPHONE".toLowerCase()))) {
            ihubExc.setStatusCode(INVALID_FORMAT);
        }
    }

    @Override
    public JSONObject getPatientDemographics(JSONObject inputObject) throws IHubException {
        JSONObject outputObject = allscriptsApiCaller.call(getValue(inputObject, DEPLOYMENT_ID).toString(), GET_PATIENT_DEMOGRAPHICS.getKey(), inputObject, CREATE_PATIENT.getKey());
        String dob = (String) getValue(outputObject, Key.DOB);
        try {
            dob = convertDateFormat(dob, DATE_FORMAT_ALTERNATE, DATE_FORMAT);
            setValue(outputObject, Key.DOB, dob);
        } catch (ParseException e) {
            log.info("DOB received was invalid or null. {}", e.getMessage());
        }
        copyKey(SCHEDULING_DATA, inputObject, outputObject);
        copyKey(Key.TEXT_NOTIFICATION_STATUS, inputObject, outputObject);
        copyKey(Key.EMAIL_NOTIFICATION_STATUS, inputObject, outputObject);
        copyKey(Key.VOICE_NOTIFICATION_STATUS, inputObject, outputObject);
        return outputObject;
    }

    @Override
    public JSONObject getPatientInsuranceInfo(JSONObject inputObject) {
        JSONObject outputObject = new JSONObject();
        JSONObject insuranceObject = new JSONObject();
        try {
            copyKey(TempKey.PRACTICE_ID, inputObject, outputObject);
            insuranceObject = allscriptsApiCaller.call(getValue(inputObject, DEPLOYMENT_ID).toString(), GET_PATIENT_INSURANCE.getKey(), inputObject, CREATE_PATIENT.getKey());
            copyKey(INSURANCE_INFORMATION, insuranceObject, outputObject);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return insuranceObject;
    }

    private void setPatientCustomFields(JSONObject inputObject) {
        try {
            List<String> customFieldList = getCustomFields(inputObject);
            if (!NullChecker.isEmpty(customFieldList)) {
                for (String customField : customFieldList) {
                    int index = customField.indexOf(":");
                    String customKey = customField.substring(0, index);
                    String customKeyValue = customField.substring(index + 1);
                    setValue(inputObject, customKey, customKeyValue);
                }
            }
        } catch (IHubException e) {
            log.info("ERROR in setting patCustomField for deploymentId {}", sanitizeForLog(String.valueOf(getValue(inputObject, DEPLOYMENT_ID))));
        }
    }

    private List<String> getCustomFields(JSONObject inputObject) {
        String customFieldListStr = "";
        List<String> customFieldList = new ArrayList<>();
        try {
            customFieldListStr = (String) dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, getValue(inputObject, DEPLOYMENT_ID).toString(),
                    ALLSCRIPTS_CONFIG, PATIENT_CUSTOM_FIELD, false);
            if (!NullChecker.isEmpty(customFieldListStr))
                customFieldList = Arrays.asList(customFieldListStr.split(UtilitiesConstants.CharacterConstants.COMMA));
        } catch (IHubException e) {
            log.info("ERROR in fetching patCustomField for deploymentId {}", sanitizeForLog(String.valueOf(getValue(inputObject, DEPLOYMENT_ID))));
        }
        return customFieldList;
    }

    private boolean getUsualProviderFlag(String deploymentId) throws IHubException {
        boolean setUsualProvider = false;
        try {
            Object setUsualProviderObject = dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, NEW_PATIENT_SET_USUAL_PROVIDER, false);
            setUsualProvider = (Integer.parseInt((String) setUsualProviderObject) == 1);
        } catch (IHubException exc) {
            log.info("EXCEPTION:: deploymentID:{} configKey:{} or configGroup:{} not available", deploymentId, NEW_PATIENT_SET_USUAL_PROVIDER, ALLSCRIPTS_CONFIG, exc.getMessage());
        }
        return setUsualProvider;
    }
}