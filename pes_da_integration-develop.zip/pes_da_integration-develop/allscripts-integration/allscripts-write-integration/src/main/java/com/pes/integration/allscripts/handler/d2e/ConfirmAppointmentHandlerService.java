package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.contant.AllscriptsEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.constant.CharacterConstants;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.handlers.BaseHandler;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import io.micrometer.observation.annotation.Observed;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.pes.integration.constant.DocASAPConstants.Key.APT_CONF_STATUS;
import static com.pes.integration.constant.DocASAPConstants.Key.CNF_RESULT_ID;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP_APT_CONF_STATUS;
import static com.pes.integration.constant.DocASAPConstants.TempKey.TEMP_CNF_RESULT_ID;

@Slf4j
@Service(value = "ConfirmAppt")
public class ConfirmAppointmentHandlerService extends BaseHandler {

    @Autowired
    AllscriptsApiCaller allscriptsApiCaller;

    @Autowired
    DataCacheManager cacheManager;

    @Override
    @Observed(name = "integration.confirmAppointment", contextualName = "integration")
    public JSONObject doExecute(JSONObject inputObject) throws IHubException {
        log.info("Start of confirmAppointment()");
        JSONObject outputObject = new JSONObject();
        String deploymentId = JsonUtils.getValue(inputObject, UtilitiesConstants.JsonConstants.DEPLOYMENT_ID).toString();
        try {
            String apptConfirmationStatus = getConfiguration(deploymentId, AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, APT_CONF_STATUS);
            String confirmationResultId = getConfiguration(deploymentId, AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, CNF_RESULT_ID);
            JsonUtils.setValue(inputObject, TEMP_APT_CONF_STATUS, apptConfirmationStatus);
            if (!NullChecker.isEmpty(confirmationResultId) && !CharacterConstants.ZERO.equals(confirmationResultId))
                JsonUtils.setValue(inputObject, TEMP_CNF_RESULT_ID, confirmationResultId);
            outputObject = allscriptsApiCaller.call(deploymentId, ApiName.CONFIRM_APPOINTMENT.getKey(), inputObject, "CONFIRM_APPOINTMENT");
        } catch (IHubException ihubExc) {
            log.error("IHUB_EXCEPTION:: While confirming appointment. Allscripts- ConfirmAppt Flow. DeploymentId: {} {}", deploymentId, ihubExc);
            throw ihubExc;
        } catch (Exception exc) {
            log.error("EXCEPTION:: Allscripts- ConfirmAppt Flow. DeploymentId: {} {}", deploymentId, exc);
            throw new RuntimeException("Error occurred during appointment confirmation.", exc);
        }
        log.info("End of confirmAppointment()");
        return outputObject;
    }

    private String getConfiguration(String deploymentId, String configGroup, String configKey) throws IHubException {
        String providerConfig = null;
        try {
            providerConfig = (String) cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, deploymentId, configGroup, configKey,false);
        } catch (IHubException exc) {
            log.error("EXCEPTION:: deploymentID: {} configKey: {} or configGroup: {} not available {}", deploymentId, configKey, configGroup, exc);
            try {
                providerConfig = (String) cacheManager.getStoredComponentConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, configGroup, configKey,false);
            } catch (Exception e) {
                // Intentionally empty
            }
        }
        return providerConfig;
    }
}