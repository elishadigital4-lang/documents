package com.pes.integration.allscripts.service;

import com.pes.integration.allscripts.handler.d2e.GetPatientsHandler;
import com.pes.integration.allscripts.handler.d2e.UpdatePatientHandler;
import com.pes.integration.exceptions.IHubErrorCode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.pes.integration.allscripts.handler.d2e.NewPatientHandler;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONObject;
import org.json.JSONArray;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessPatientServiceTest {

    @InjectMocks
    private ProcessPatientService processPatientService;

    @Mock
    private NewPatientHandler newPatientHandlerService;

    @Mock
    GetPatientsHandler getPatientHandler;

    @Mock
    UpdatePatientHandler updatePatientHandler;
    @Mock
    private DataTransactionService dataTransactionService;

    @BeforeEach
    void setUp() {
        // Initialize any required fields or mocks here
    }

    @Test
    void createPatientReturnsValidResponse() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject expectedResponse = new JSONObject();
        when(newPatientHandlerService.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        JSONObject result = processPatientService.createPatient(input);

        assertNotNull(result);
        assertEquals(expectedResponse.toString(), result.toString());
    }

    @Test
    void createPatientHandlesIHubException() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        when(newPatientHandlerService.doExecute(any(JSONObject.class))).thenThrow(new IHubException(new IHubErrorCode("22"), "Error"));

        assertThrows(IHubException.class, () -> processPatientService.createPatient(input));
    }

    @Test
    void searchPatientReturnsValidResponse() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        when(getPatientHandler.doExecute(any(JSONObject.class))).thenReturn(response);

        JSONObject result = processPatientService.searchPatient(input);

        assertNotNull(result);
        assertTrue(result.has("data"));
    }

    @Test
    void searchPatientHandlesIHubException() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        when(getPatientHandler.doExecute(any(JSONObject.class))).thenThrow(new IHubException(new IHubErrorCode("11"), "Error"));

        assertThrows(IHubException.class, () -> processPatientService.searchPatient(input));
    }

    @Test
    void searchPatientLogsDataOnSuccess() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject response = new JSONObject();
        response.put("temp", new JSONObject());
        when(getPatientHandler.doExecute(any(JSONObject.class))).thenReturn(response);

        processPatientService.searchPatient(input);

        verify(dataTransactionService, times(1)).logData(input, "SEARCH_PATIENT", "CREATED", "iHub Search Patient Request Message");
    }

    @Test
    void getPatient() throws IHubException {
        Assertions.assertNull(processPatientService.getPatient(new JSONObject()));
    }

    @Test
    void updatePatientReturnsValidResponse() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        JSONObject expectedResponse = new JSONObject();
        when(updatePatientHandler.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        JSONObject result = processPatientService.updatePatient(input);

        assertNotNull(result);
        assertEquals(expectedResponse.toString(), result.toString());
    }

    @Test
    void updatePatientHandlesIHubException() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        JSONArray appointmentSync = new JSONArray();
        JSONObject appointment = new JSONObject();
        appointmentSync.put(appointment);
        data.put("appointment_sync", appointmentSync);
        input.put("data", data);

        when(updatePatientHandler.doExecute(any(JSONObject.class))).thenThrow(new IHubException(new IHubErrorCode("22"), "Error"));

        assertThrows(IHubException.class, () -> processPatientService.updatePatient(input));
    }
}