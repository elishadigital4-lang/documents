package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.contant.AllscriptsEngineConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;

import static com.pes.integration.constant.DocASAPConstants.Key.APT_CONF_STATUS;
import static com.pes.integration.constant.DocASAPConstants.Key.CNF_RESULT_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;


@ExtendWith(MockitoExtension.class)
class ConfirmAppointmentHandlerServiceTest {

    @InjectMocks
    ConfirmAppointmentHandlerService confirmAppointmentHandlerService;
    @Mock
    AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    DataCacheManager cacheManager;

    @Test
    void doExecute() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, APT_CONF_STATUS, false)).thenReturn("1");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, CNF_RESULT_ID, false)).thenReturn("1");
        JSONObject outputObject = new JSONObject();
        outputObject.put("test", "value");
        Mockito.when(allscriptsApiCaller.call("testDeploymentId", ApiName.CONFIRM_APPOINTMENT.getKey(), inputObject, "CONFIRM_APPOINTMENT")).thenReturn(outputObject);
        JSONObject result = confirmAppointmentHandlerService.doExecute(inputObject);
        Assertions.assertEquals(outputObject, result);
    }

    @Test
    void doExecute_2() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, APT_CONF_STATUS, false)).thenReturn("1");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, CNF_RESULT_ID, false)).thenThrow(new IHubException(new IHubErrorCode("22"), "IHubException"));
        JSONObject outputObject = new JSONObject();
        outputObject.put("test", "value");
        Mockito.when(allscriptsApiCaller.call("testDeploymentId", ApiName.CONFIRM_APPOINTMENT.getKey(), inputObject, "CONFIRM_APPOINTMENT")).thenReturn(outputObject);
        JSONObject result = confirmAppointmentHandlerService.doExecute(inputObject);
        Assertions.assertEquals(outputObject, result);
    }

    @Test
    void doExecute_IHubException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, APT_CONF_STATUS, false)).thenReturn("1");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, CNF_RESULT_ID, false)).thenReturn("1");
        JSONObject outputObject = new JSONObject();
        outputObject.put("test", "value");
        Mockito.when(allscriptsApiCaller.call("testDeploymentId", ApiName.CONFIRM_APPOINTMENT.getKey(), inputObject, "CONFIRM_APPOINTMENT")).thenThrow(new IHubException(new IHubErrorCode("11"), "test error"));
        Assertions.assertThrows(IHubException.class, () -> confirmAppointmentHandlerService.doExecute(inputObject));
    }

    @Test
    void doExecute_RuntimeException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, APT_CONF_STATUS, false)).thenReturn("1");
        Mockito.when(cacheManager.getStoredProvidersConfig(AllscriptsEngineConstants.EPM_NAME_PREFIX, "testDeploymentId", AllscriptsEngineConstants.ALLSCRIPTS_CONFIG, CNF_RESULT_ID, false)).thenReturn("1");
        JSONObject outputObject = new JSONObject();
        outputObject.put("test", "value");
        Mockito.when(allscriptsApiCaller.call("testDeploymentId", ApiName.CONFIRM_APPOINTMENT.getKey(), inputObject, "CONFIRM_APPOINTMENT")).thenThrow(new RuntimeException("test error"));
        Assertions.assertThrows(RuntimeException.class, () -> confirmAppointmentHandlerService.doExecute(inputObject));
    }

    @Test
    void getConfiguration_providersConfigSuccess() throws Exception {
        Mockito.when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("providerValue");

        Method method = ConfirmAppointmentHandlerService.class.getDeclaredMethod("getConfiguration", String.class, String.class, String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(confirmAppointmentHandlerService, "depId", "group", "key");
        assertEquals("providerValue", result);
    }

    @Test
    void getConfiguration_providersConfigThrows_componentConfigSuccess() throws Exception {
        Mockito.when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(null, "fail"));
        Mockito.when(cacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("componentValue");

        Method method = ConfirmAppointmentHandlerService.class.getDeclaredMethod("getConfiguration", String.class, String.class, String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(confirmAppointmentHandlerService, "depId", "group", "key");
        assertEquals("componentValue", result);
    }

    @Test
    void getConfiguration_bothThrow_returnsNull() throws Exception {
        Mockito.when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new IHubException(null, "fail"));
        Mockito.when(cacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("fail"));

        Method method = ConfirmAppointmentHandlerService.class.getDeclaredMethod("getConfiguration", String.class, String.class, String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(confirmAppointmentHandlerService, "depId", "group", "key");
        assertNull(result);
    }
}