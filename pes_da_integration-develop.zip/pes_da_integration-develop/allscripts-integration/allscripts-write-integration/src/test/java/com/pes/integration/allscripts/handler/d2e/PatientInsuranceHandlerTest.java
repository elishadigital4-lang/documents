package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import static com.pes.integration.allscripts.api.ApiName.SET_PATIENT_INSURANCE;
import static com.pes.integration.constant.CharacterConstants.ATMARK;
import static com.pes.integration.constant.DocASAPConstants.Key.SEQUENCE_NUMBER;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class PatientInsuranceHandlerTest {

    @InjectMocks
    PatientInsuranceHandler patientInsuranceHandler;
    @Mock
    AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    GetPatientInsurancesHandler getPatientInsurancesHandler;

    @Test
    void doExecute() throws IHubException {

        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        JSONObject outputObject = new JSONObject();
        String insId = "11";
        String planId = "22";
        String payroleid = "33".trim() + ATMARK + planId.trim();
        JSONObject payorId = new JSONObject().put("InsPayorId", payroleid);
        payorId.put("InsId", insId);
        payorId.put("SequenceNumber", "10");
        payorId.put("InsPlanId", planId);
        JSONObject jsonObject = new JSONObject().put("InsuranceInformation", new JSONArray().put(payorId));
        inputObject.put("DemographicData", jsonObject);
        outputObject.put("DemographicData", jsonObject);
        Mockito.when(getPatientInsurancesHandler.doExecute(inputObject)).thenReturn(outputObject);
        Mockito.when(allscriptsApiCaller.call("testDeploymentId", SET_PATIENT_INSURANCE.getKey(), inputObject, "patientInsurance")).thenReturn(outputObject);
        JSONObject execute = patientInsuranceHandler.doExecute(inputObject);

        Assertions.assertEquals(outputObject, execute);
        Mockito.verify(allscriptsApiCaller, Mockito.times(1)).call("testDeploymentId", SET_PATIENT_INSURANCE.getKey(), inputObject, "patientInsurance");

    }

    @Test
    void doExecute_1() throws IHubException {

        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        JSONObject outputObject = new JSONObject();
        String insId = "11";
        String planId = "22";
        String payroleid = insId.trim() + ATMARK + planId.trim();
        JSONObject payorId = new JSONObject().put("InsPayorId", payroleid);
        payorId.put("InsId", insId);
        payorId.put("SequenceNumber", "10");
        payorId.put("InsPlanId", planId);
        JSONObject jsonObject = new JSONObject().put("InsuranceInformation", new JSONArray().put(payorId));
        inputObject.put("DemographicData", jsonObject);
        outputObject.put("DemographicData", jsonObject);
        Mockito.when(getPatientInsurancesHandler.doExecute(inputObject)).thenReturn(outputObject);
        JSONObject execute = patientInsuranceHandler.doExecute(inputObject);

        Assertions.assertEquals(outputObject, execute);
    }

    @Test
    void testInsuranceAlreadyAvailable_noUpdateOrCall() throws Exception {
        try (
                MockedStatic<NullChecker> nullCheckerMock = mockStatic(NullChecker.class);
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)
        ) {
            JSONObject input = new JSONObject();
            JSONObject output = new JSONObject();
            JSONArray insArr = new JSONArray();
            JSONObject insObj = new JSONObject();
            insObj.put("InsPayorId", "11@22");
            insArr.put(insObj);

            // Mock getValue for input
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq("DemographicData.InsuranceInformation"))).thenReturn(insArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq("InsPayorId"))).thenReturn("11@22");
            // Mock getValue for output
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq("DemographicData.InsuranceInformation"))).thenReturn(insArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq("SequenceNumber"))).thenReturn("P");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq("InsId"))).thenReturn("11");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq("InsPlanId"))).thenReturn("22");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            nullCheckerMock.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);

            when(getPatientInsurancesHandler.doExecute(any())).thenReturn(output);

            JSONObject result = patientInsuranceHandler.doExecute(input);

            verify(allscriptsApiCaller, never()).call(anyString(), anyString(), any(), anyString());
            assertEquals(output, result);
        }
    }

    @Test
    void testInsuranceNotAvailable_assignSequenceAndCall() throws Exception {
        try (
                MockedStatic<NullChecker> nullCheckerMock = mockStatic(NullChecker.class);
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)
        ) {
            JSONObject input = new JSONObject();
            JSONObject output = new JSONObject();
            JSONArray inputArr = new JSONArray();
            JSONObject inputObj = new JSONObject();
            inputObj.put("InsPayorId", "11@22");
            inputArr.put(inputObj);

            JSONArray outputArr = new JSONArray();
            JSONObject outputObj = new JSONObject();
            outputObj.put("InsId", "99");
            outputObj.put("InsPlanId", "88");
            outputObj.put("SequenceNumber", "S");
            outputArr.put(outputObj);

            // Mock getValue for input
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(input, "DemographicData.InsuranceInformation")).thenReturn(inputArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(inputArr.get(0), "InsPayorId")).thenReturn("11@22");
            // Mock getValue for output
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(output, "DemographicData.InsuranceInformation")).thenReturn(outputArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(SEQUENCE_NUMBER))).thenReturn("S");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(outputArr.get(0), "InsId")).thenReturn("99");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(outputArr.get(0), "InsPlanId")).thenReturn("88");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            nullCheckerMock.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);

            when(getPatientInsurancesHandler.doExecute(any())).thenReturn(output);
            when(allscriptsApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(output);

            JSONObject result = patientInsuranceHandler.doExecute(input);

            verify(allscriptsApiCaller, times(1)).call(anyString(), anyString(), any(), anyString());
            com.pes.integration.jsonmapper.JsonUtils.setValue(eq(input), eq("SequenceNumber"), eq("P"));
            assertEquals(output, result);
        }
    }

    @Test
    void testEmptyInputInsurancesArray_noAction() throws Exception {
        try (
                MockedStatic<NullChecker> nullCheckerMock = mockStatic(NullChecker.class);
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)
        ) {
            JSONObject input = new JSONObject();
            JSONObject output = new JSONObject();

            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(input, "DemographicData.InsuranceInformation")).thenReturn(null);
            nullCheckerMock.when(() -> NullChecker.isEmpty(anyString())).thenReturn(true);

            when(getPatientInsurancesHandler.doExecute(any())).thenReturn(output);

            JSONObject result = getPatientInsurancesHandler.doExecute(input);

            verify(allscriptsApiCaller, never()).call(anyString(), anyString(), any(), anyString());
            assertEquals(output, result);
        }
    }

    @Test
    void testInsuranceNotAvailable_assignSequenceAndCalls() throws Exception {
        try (
                MockedStatic<NullChecker> nullCheckerMock = mockStatic(NullChecker.class);
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)
        ) {
            JSONObject input = new JSONObject();
            JSONObject output = new JSONObject();
            JSONArray inputArr = new JSONArray();
            JSONObject inputObj = new JSONObject();
            inputObj.put("InsPayorId", "11@22");
            inputArr.put(inputObj);

            JSONArray outputArr = new JSONArray();
            JSONObject outputObj = new JSONObject();
            outputObj.put("InsId", "99");
            outputObj.put("InsPlanId", "88");
            outputObj.put("SequenceNumber", "S");
            outputArr.put(outputObj);

            // Mock getValue for input
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(input, "DemographicData.InsuranceInformation")).thenReturn(inputArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(inputArr.get(0), "InsPayorId")).thenReturn("11@22");
            // Mock getValue for output
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(output, "DemographicData.InsuranceInformation")).thenReturn(outputArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(SEQUENCE_NUMBER))).thenReturn("T");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(outputArr.get(0), "InsId")).thenReturn("99");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(outputArr.get(0), "InsPlanId")).thenReturn("88");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            nullCheckerMock.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);

            when(getPatientInsurancesHandler.doExecute(any())).thenReturn(output);
            when(allscriptsApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(output);

            JSONObject result = patientInsuranceHandler.doExecute(input);

            verify(allscriptsApiCaller, times(1)).call(anyString(), anyString(), any(), anyString());
            com.pes.integration.jsonmapper.JsonUtils.setValue(eq(input), eq("SequenceNumber"), eq("P"));
            assertEquals(output, result);
        }
    }

    @Test
    void testInsuranceNotAvailables_assignSequenceAndCalls() throws Exception {
        try (
                MockedStatic<NullChecker> nullCheckerMock = mockStatic(NullChecker.class);
                MockedStatic<com.pes.integration.jsonmapper.JsonUtils> jsonUtilsMock = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)
        ) {
            JSONObject input = new JSONObject();
            JSONObject output = new JSONObject();
            JSONArray inputArr = new JSONArray();
            JSONObject inputObj = new JSONObject();
            inputObj.put("InsPayorId", "11@22");
            inputArr.put(inputObj);

            JSONArray outputArr = new JSONArray();
            JSONObject outputObj = new JSONObject();
            outputObj.put("InsId", "99");
            outputObj.put("InsPlanId", "88");
            outputObj.put("SequenceNumber", "S");
            outputArr.put(outputObj);

            // Mock getValue for input
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(input, "DemographicData.InsuranceInformation")).thenReturn(inputArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(inputArr.get(0), "InsPayorId")).thenReturn("11@22");
            // Mock getValue for output
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(output, "DemographicData.InsuranceInformation")).thenReturn(outputArr);
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(SEQUENCE_NUMBER))).thenReturn("P");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(outputArr.get(0), "InsId")).thenReturn("99");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(outputArr.get(0), "InsPlanId")).thenReturn("88");
            jsonUtilsMock.when(() -> com.pes.integration.jsonmapper.JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("testDeploymentId");

            nullCheckerMock.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);

            when(getPatientInsurancesHandler.doExecute(any())).thenReturn(output);
            when(allscriptsApiCaller.call(anyString(), anyString(), any(), anyString())).thenReturn(output);

            JSONObject result = patientInsuranceHandler.doExecute(input);

            verify(allscriptsApiCaller, times(1)).call(anyString(), anyString(), any(), anyString());
            com.pes.integration.jsonmapper.JsonUtils.setValue(eq(input), eq("SequenceNumber"), eq("P"));
            assertEquals(output, result);
        }
    }

}