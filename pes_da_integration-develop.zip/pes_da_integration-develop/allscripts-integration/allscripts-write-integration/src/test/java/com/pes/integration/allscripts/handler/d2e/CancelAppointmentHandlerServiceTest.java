package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static com.pes.integration.allscripts.api.ApiName.CANCEL_APPOINTMENT;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.StatusCodes.INVALID_FORMAT;
import static com.pes.integration.enums.StatusCodes.NO_APPOINTMENT_FOUND;
import static com.pes.integration.exceptions.UtilityErrors.UNABLE_TO_PROCESS_MESSAGE;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
class CancelAppointmentHandlerServiceTest {

    @InjectMocks
    CancelAppointmentHandlerService cancelAppointmentHandlerService;

    @Mock
    AllscriptsApiCaller allscriptsApiCaller;

    @Test
    void cancelAppointment() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("temp", new JSONObject("error_message", "error"));
        Mockito.when(allscriptsApiCaller.call(eq("testDeploymentId"), eq(CANCEL_APPOINTMENT.getKey()), any(), eq(Flow.CANCEL_APPOINTMENT.getKey()))).thenReturn(jsonObject);
        JSONObject response = cancelAppointmentHandlerService.cancelAppointment(inputObject);
        System.out.println(response);
        JSONObject object = response.getJSONObject("data").getJSONArray("appointment_sync").getJSONObject(0);
        Assertions.assertEquals("testDeploymentId", object.getString("deployment_id"));
        Assertions.assertEquals("X", object.getJSONObject("temp").getString("status"));
    }

    @Test
    void cancelAppointment_error() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("temp", new JSONObject().put("error_message", "error my message"));
        Mockito.when(allscriptsApiCaller.call(eq("testDeploymentId"), eq(CANCEL_APPOINTMENT.getKey()), any(), eq(Flow.CANCEL_APPOINTMENT.getKey()))).thenReturn(jsonObject);
        IHubException hubException = assertThrows(IHubException.class, () -> cancelAppointmentHandlerService.cancelAppointment(inputObject));
        Assertions.assertEquals(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), hubException.getErrorCode());
        Assertions.assertEquals("error my message", hubException.getMessage());
    }

    @Test
    void cancelAppointment_IHubException() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        Mockito.when(allscriptsApiCaller.call(eq("testDeploymentId"), eq(CANCEL_APPOINTMENT.getKey()), any(), eq(Flow.CANCEL_APPOINTMENT.getKey()))).thenThrow(new IHubException(new IHubErrorCode("11"), "test ihub message"));
        IHubException hubException = assertThrows(IHubException.class, () -> cancelAppointmentHandlerService.cancelAppointment(inputObject));
        Assertions.assertEquals(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), hubException.getErrorCode());
        Assertions.assertEquals("test ihub message", hubException.getMessage());
    }

    @Test
    void cancelAppointment_RuntimeException() throws Exception {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        Mockito.when(allscriptsApiCaller.call(eq("testDeploymentId"), eq(CANCEL_APPOINTMENT.getKey()), any(), eq(Flow.CANCEL_APPOINTMENT.getKey()))).thenThrow(new RuntimeException("test runtime message"));
        IHubException hubException = assertThrows(IHubException.class, () -> cancelAppointmentHandlerService.cancelAppointment(inputObject));
        Assertions.assertEquals(UNABLE_TO_PROCESS_MESSAGE.getErrorCode(), hubException.getErrorCode());
        Assertions.assertEquals("test runtime message", hubException.getMessage());
    }

    @Test
    void setExceptionDetails_NO_APPOINTMENT_FOUND() {
        IHubException hubException = new IHubException(new IHubErrorCode("11"), "Appointment not found");
        ReflectionTestUtils.invokeMethod(cancelAppointmentHandlerService, "setExceptionDetails", hubException);
        Assertions.assertEquals(NO_APPOINTMENT_FOUND, hubException.getStatusCode());
        Assertions.assertEquals("Appointment not found", hubException.getMessage());
    }

    @Test
    void setExceptionDetails_NO_APPOINTMENT_FOUND_2() {
        IHubException hubException = new IHubException(new IHubErrorCode("11"), "Appointment Id is empty");
        ReflectionTestUtils.invokeMethod(cancelAppointmentHandlerService, "setExceptionDetails", hubException);
        Assertions.assertEquals(NO_APPOINTMENT_FOUND, hubException.getStatusCode());
        Assertions.assertEquals("Appointment Id is empty", hubException.getMessage());
    }

    @Test
    void setExceptionDetails_INVALID_FORMAT() {
        IHubException hubException = new IHubException(new IHubErrorCode("11"), "Patient ID");
        ReflectionTestUtils.invokeMethod(cancelAppointmentHandlerService, "setExceptionDetails", hubException);
        Assertions.assertEquals(INVALID_FORMAT, hubException.getStatusCode());
        Assertions.assertEquals("Patient ID", hubException.getMessage());
    }
}