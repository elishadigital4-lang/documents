package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT_INSURANCE;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GetPatientInsurancesHandlerTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @InjectMocks
    private GetPatientInsurancesHandler getPatientInsurancesHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteReturnsExpectedResult() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "12345");
        JSONObject expectedResponse = new JSONObject();
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(expectedResponse);

        JSONObject result = getPatientInsurancesHandler.doExecute(inputObject);

        assertEquals(expectedResponse, result);
        verify(allscriptsApiCaller, times(1)).call("12345", GET_PATIENT_INSURANCE.getKey(), inputObject, "GetPatientInsurancesHandler");
    }


}