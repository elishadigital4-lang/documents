package com.pes.integration.allscripts.service;

import com.pes.integration.allscripts.handler.d2e.CancelAppointmentHandlerService;
import com.pes.integration.allscripts.handler.d2e.NewAppointmentHandlerService;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.service.DataTransactionService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessAppointmentsServiceTest {

    @InjectMocks
    private ProcessAppointmentsService processAppointmentsService;

    @Mock
    private NewAppointmentHandlerService newAppointmentHandlerService;

    @Mock
    CancelAppointmentHandlerService cancelAppointmentHandler;

    @Mock
    private DataTransactionService dataTransactionService;

    @BeforeEach
    void setUp() {
        // Initialize any required fields or mocks here
    }

    @Test
    void createAppointmentReturnsValidResponse() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("appointment_sync", new JSONArray().put(new JSONObject()));
        input.put("data", data);

        JSONObject expectedResponse = new JSONObject();
        when(newAppointmentHandlerService.doExecute(any())).thenReturn(expectedResponse);

        JSONObject result = processAppointmentsService.createAppointment(input);

        assertNotNull(result);
        assertEquals(expectedResponse.toString(), result.toString());
    }

    @Test
    void createAppointmentHandlesIHubException() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("appointment_sync", new JSONArray().put(new JSONObject()));
        input.put("data", data);

        when(newAppointmentHandlerService.doExecute(any(JSONObject.class))).thenThrow(new IHubException(new IHubErrorCode("11"), "Error"));

        assertThrows(IHubException.class, () -> processAppointmentsService.createAppointment(input));
    }

    @Test
    void createAppointmentLogsDataOnSuccess() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("appointment_sync", new JSONArray().put(new JSONObject()));
        input.put("data", data);

        JSONObject expectedResponse = new JSONObject();
        when(newAppointmentHandlerService.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        processAppointmentsService.createAppointment(input);

        verify(dataTransactionService, times(1)).logData(input, "CREATE_APPOINTMENT", "CREATED", "iHub Create Appointment Request Message");
    }

    @Test
    void createAppointmentLogsDataOnFailure() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("appointment_sync", new JSONArray().put(new JSONObject()));
        input.put("data", data);

        IHubException exception = new IHubException(new IHubErrorCode("11"), "Error");
        when(newAppointmentHandlerService.doExecute(any(JSONObject.class))).thenThrow(exception);

        assertThrows(IHubException.class, () -> processAppointmentsService.createAppointment(input));

        verify(dataTransactionService, times(1)).logData(input, "CREATE_APPOINTMENT", "CREATED", "iHub Create Appointment Request Message");
        verify(dataTransactionService, times(1)).logData(input, "CREATE_APPOINTMENT", "FAILED", exception.getMessage());
    }

    @Test
    void cancelAppointmentReturnsValidResponse() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("appointment_sync", new JSONArray().put(new JSONObject()));
        input.put("data", data);

        JSONObject expectedResponse = new JSONObject();
        when(cancelAppointmentHandler.doExecute(any(JSONObject.class))).thenReturn(expectedResponse);

        JSONObject result = processAppointmentsService.cancelAppointment(input);

        assertNotNull(result);
        assertEquals(expectedResponse.toString(), result.toString());
    }

    @Test
    void cancelAppointmentHandlesIHubException() throws Exception {
        JSONObject input = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("appointment_sync", new JSONArray().put(new JSONObject()));
        input.put("data", data);

        IHubException exception = new IHubException(new IHubErrorCode("22"), "Error");
        when(cancelAppointmentHandler.doExecute(any(JSONObject.class))).thenThrow(exception);

        assertThrows(IHubException.class, () -> processAppointmentsService.cancelAppointment(input));

        verify(dataTransactionService, times(1)).logData(input, "CANCEL_APPOINTMENT", "CREATED", "iHub Cancel Appointment Request Message");
        verify(dataTransactionService, times(1)).logData(input, "CANCEL_APPOINTMENT", "FAILED", exception.getMessage());
    }

}