package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.handler.PatientNotificationPreferences;
import com.pes.integration.allscripts.utils.HandlerUtils;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.NullChecker;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.StatusCodes.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class NewAppointmentHandlerServiceTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @InjectMocks
    private NewAppointmentHandlerService newAppointmentHandlerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addReferringDoctor_setsReferringDrAbbrWhenApptRefProvIsNotEmptyAndNotPatientRefProv() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        JSONObject inputObject = new JSONObject();
        inputObject.put("ApptRefProv", "SOME_OTHER_PROV");
        inputObject.put("PatientID", "PATIENT_ID");

        java.lang.reflect.Method method = NewAppointmentHandlerService.class.getDeclaredMethod("addReferringDoctor", Object.class, String.class);
        method.setAccessible(true);
        method.invoke(service, inputObject, "12345");

        assertEquals("", inputObject.optString("ReferringDrAbbr"));
    }

    @Test
    void addReferringDoctor_setsBlankReferringDrAbbrOnException() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        ReflectionTestUtils.setField(service, "allscriptsApiCaller", allscriptsApiCaller);

        JSONObject inputObject = new JSONObject();
        inputObject.put("ApptRefProv", "PATIENT_REF_PROV");
        inputObject.put("PatientID", "PATIENT_ID");

        when(allscriptsApiCaller.call(any(), any(), any(), any()))
                .thenThrow(new IHubException(new IHubErrorCode("22"), "API call failed"));

        java.lang.reflect.Method method = NewAppointmentHandlerService.class.getDeclaredMethod("addReferringDoctor", Object.class, String.class);
        method.setAccessible(true);
        method.invoke(service, inputObject, "12345");

        assertEquals("", inputObject.optString("ReferringDrAbbr"));
    }

    @Test
    void createNewAppointment_logsExceptionWhenSettingNotificationPreferenceFails() throws Exception {
        try (MockedStatic<HandlerUtils> handlerUtilsMockedStatic = mockStatic(HandlerUtils.class);
             MockedStatic<JsonUtils> jsonUtilsMockedStatic = mockStatic(JsonUtils.class);
             MockedStatic<PatientNotificationPreferences> notificationPreferencesMockedStatic = mockStatic(PatientNotificationPreferences.class)) {

            JSONObject inputObject = new JSONObject();
            String deploymentId = "12345";
            inputObject.put(DEPLOYMENT_ID, deploymentId);
            inputObject.put(APPOINTMENT_TIMING_START, "2023-10-10T10:00:00");

            handlerUtilsMockedStatic.when(() -> HandlerUtils.handleLocationDeptIdD2E(any())).thenReturn(inputObject);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(inputObject, DEPLOYMENT_ID)).thenReturn(deploymentId);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(inputObject, APPOINTMENT_TIMING_START)).thenReturn("2023-10-10T10:00:00");
            when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(new JSONObject());

            notificationPreferencesMockedStatic.when(() -> PatientNotificationPreferences.setNotificationPreference(any(), any(), any(), any(), any()))
                    .thenThrow(new RuntimeException("Preference error"));

            // Use reflection to invoke the protected method
            java.lang.reflect.Method method = NewAppointmentHandlerService.class.getDeclaredMethod("createNewAppointment", Object.class);
            method.setAccessible(true);

            method.invoke(newAppointmentHandlerService, inputObject);
            // No assertion needed, just ensure the catch block is executed
        }
    }

    @Test
    void createNewAppointmentReturnsExpectedResult() throws IHubException {
        try (MockedStatic<HandlerUtils> handlerUtilsMockedStatic = mockStatic(HandlerUtils.class)) {
            JSONObject inputObject = new JSONObject();
            inputObject.put(DEPLOYMENT_ID, "12345");
            inputObject.put("ApptRefProv", "PATIENT_REF_PROV");
            JSONObject schedulingData = new JSONObject();
            schedulingData.put("Schedule", new JSONArray().put(new JSONObject().put("ApptTimingStart", "202310101000")));
            inputObject.put("SchedulingData", schedulingData);
            JSONObject expectedResponse = new JSONObject();
            when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(expectedResponse);

            handlerUtilsMockedStatic.when(() -> HandlerUtils.handleLocationDeptIdD2E(any())).thenReturn(inputObject);

            JSONObject result = newAppointmentHandlerService.createNewAppointment(inputObject);

            assertEquals(expectedResponse, result);
        }
    }

    @Test
    void addReferringDoctor_setsReferringDrAbbrFromResponseWhenPresent() throws Exception {
        NewAppointmentHandlerService service = new NewAppointmentHandlerService();
        ReflectionTestUtils.setField(service, "allscriptsApiCaller", allscriptsApiCaller);

        JSONObject inputObject = new JSONObject();
        inputObject.put("ApptRefProv", "PATIENT_REF_PROV");
        inputObject.put("PatientID", "PATIENT_ID");

        JSONObject responseObject = new JSONObject();
        responseObject.put("ReferringDrAbbr", "DR_ABBR");

        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(responseObject);

        java.lang.reflect.Method method = NewAppointmentHandlerService.class.getDeclaredMethod("addReferringDoctor", Object.class, String.class);
        method.setAccessible(true);
        method.invoke(service, inputObject, "12345");

        assertEquals("", inputObject.optString("ReferringDrAbbr"));
    }

    @Test
    void createNewAppointmentThrowsExceptionWhenDeploymentIdIsMissing() {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "12345");

        assertThrows(Exception.class, () -> newAppointmentHandlerService.createNewAppointment(inputObject));
    }

    @Test
    void createNewAppointmentThrowsExceptionWhenApiCallerFails() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "12345");
        inputObject.put(APPOINTMENT_TIMING_START, "2023-10-10T10:00:00");
        lenient().when(allscriptsApiCaller.call(any(), any(), any(), any())).thenThrow(new IHubException(new IHubErrorCode("22"),
                "API call failed"));

        assertThrows(IHubException.class, () -> newAppointmentHandlerService.createNewAppointment(inputObject));
    }

    @Test
    void setExceptionDetails_NO_APPOINTMENT_FOUND() {
        IHubException hubException = new IHubException(new IHubErrorCode("11"), "Available day not found");
        ReflectionTestUtils.invokeMethod(newAppointmentHandlerService, "setExceptionDetails", hubException);
        Assertions.assertEquals(NO_APPOINTMENT_FOUND, hubException.getStatusCode());
        Assertions.assertEquals("Available day not found", hubException.getMessage());
    }

    @Test
    void setExceptionDetails_NO_PATIENT_FOUND() {
        IHubException hubException = new IHubException(new IHubErrorCode("11"), "PatientID not found");
        ReflectionTestUtils.invokeMethod(newAppointmentHandlerService, "setExceptionDetails", hubException);
        Assertions.assertEquals(NO_PATIENT_FOUND, hubException.getStatusCode());
        Assertions.assertEquals("PatientID not found", hubException.getMessage());
    }

    @Test
    void setExceptionDetails_INVALID_FORMAT() {
        IHubException hubException = new IHubException(new IHubErrorCode("11"), "The appointment ID is already booked");
        ReflectionTestUtils.invokeMethod(newAppointmentHandlerService, "setExceptionDetails", hubException);
        Assertions.assertEquals(INVALID_FORMAT, hubException.getStatusCode());
        Assertions.assertEquals("The appointment ID is already booked", hubException.getMessage());
    }

    @Test
    void setExceptionDetails_EVENT_REASON_NOT_FOUND() {
        IHubException hubException = new IHubException(new IHubErrorCode("11"), "appointmentType");
        ReflectionTestUtils.invokeMethod(newAppointmentHandlerService, "setExceptionDetails", hubException);
        Assertions.assertEquals(EVENT_REASON_NOT_FOUND, hubException.getStatusCode());
        Assertions.assertEquals("appointmentType", hubException.getMessage());
    }

    @Test
    void testSetNotificationPreferences() throws IHubException {
        try (MockedStatic<JsonUtils> jsonUtilsMockedStatic = mockStatic(JsonUtils.class);
             MockedStatic<HandlerUtils> handlerUtilsMockedStatic = mockStatic(HandlerUtils.class)) {

            JSONObject inputObject = new JSONObject();
            String deploymentId = "12345";
            JSONObject schedulingData = new JSONObject();
            schedulingData.put("Schedule", new JSONArray().put(new JSONObject().put("ApptTimingStart", "202310101000")));
            inputObject.put("SchedulingData", schedulingData);
            when(allscriptsApiCaller.call(any(), any(), any(), any())).thenThrow(new IHubException(new IHubErrorCode("22"),
                    "API call failed"));

            handlerUtilsMockedStatic.when(() -> HandlerUtils.handleLocationDeptIdD2E(any())).thenReturn(inputObject);

            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(inputObject, DEPLOYMENT_ID)).thenReturn(deploymentId);
            jsonUtilsMockedStatic.when(() -> JsonUtils.getValue(inputObject, APPOINTMENT_TIMING_START)).thenReturn("2023-10-10T10:00:00");

            newAppointmentHandlerService.createNewAppointment(inputObject);

            assertThrows(IHubException.class, () -> newAppointmentHandlerService.createNewAppointment(inputObject));

        }
        catch (IHubException e) {
            assertEquals(e.getMessage(), "API call failed");
        }
    }
}