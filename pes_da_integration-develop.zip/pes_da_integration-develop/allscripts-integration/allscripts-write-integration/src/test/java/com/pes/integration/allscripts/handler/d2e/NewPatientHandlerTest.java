package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.allscripts.handler.MatchPatientHandler;
import com.pes.integration.allscripts.handler.PatientNotificationPreferences;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.config.data.ManageFlagsUtility;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.enums.StatusCodes;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import com.pes.integration.utils.LogUtil;
import com.pes.integration.utils.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.*;

import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.*;
import static com.pes.integration.constant.DocASAPConstants.Key.ERROR_CODE;
import static com.pes.integration.constant.DocASAPConstants.Key.NEW_PATIENT_SET_USUAL_PROVIDER;
import static com.pes.integration.constant.DocASAPConstants.TempKey.ERROR_DETAIL;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static com.pes.integration.enums.Flow.CREATE_PATIENT;
import static com.pes.integration.enums.StatusCodes.MULTIPLE_PATIENT;
import static com.pes.integration.exceptions.UtilityErrors.ERROR_IN_SERVICE_EXECUTION;
import static com.pes.integration.jsonmapper.JsonUtils.getValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

@Slf4j
@ExtendWith(MockitoExtension.class)
class NewPatientHandlerTest {

    @InjectMocks
    NewPatientHandler newPatientHandler;
    @Mock
    AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    MatchPatientHandler matchPatientHandler;

    @Mock
    ManageFlagsUtility manageFlagsUtility;
    @Mock
    DataCacheManager dataCacheManager;

    @Test
    void createNewPatient() throws IHubException {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        JSONObject outputObject = new JSONObject();
        outputObject.put("error_code", "1111");
        outputObject.put("temp", new JSONObject());
        JSONObject demographic = new JSONObject();
        demographic.put("PatientInformation", new JSONArray().put(new JSONObject().put("ExternalPatientId", 0)));
        JSONObject demographicData = new JSONObject().put("DemographicData", demographic);
        outputObject.put("appointment_sync", new JSONArray().put(demographicData));

        when(matchPatientHandler.doExecute(inputObject)).thenReturn(outputObject);
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, getValue(inputObject, DEPLOYMENT_ID).toString(),
                ALLSCRIPTS_CONFIG, PATIENT_CUSTOM_FIELD, false)).thenReturn("key:value,key1:value1");
        when(dataCacheManager.getStoredProvidersConfig(EPM_NAME_PREFIX, deploymentId, ALLSCRIPTS_CONFIG, NEW_PATIENT_SET_USUAL_PROVIDER, false)).thenReturn("1");
        when(allscriptsApiCaller.call(deploymentId, ApiName.NEW_PATIENT.getKey(), inputObject, CREATE_PATIENT.getKey())).thenReturn(demographicData);
        JSONObject newPatient = newPatientHandler.createNewPatient(inputObject);

        Assertions.assertEquals(newPatient, inputObject);
    }

    @Test
    public void testGetPatientInsuranceInfo_Exception() throws IHubException {
        // Arrange
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenThrow(new RuntimeException("API error"));

        // Act
        JSONObject result = newPatientHandler.getPatientInsuranceInfo(inputObject);

        // Assert
        assertNotNull(result);
        // Optionally, check that result is empty since insuranceObject is returned
        assertEquals(0, result.length());
    }

    @Test
    public void testGetPatientDemographics_invalidDOBFormat() throws Exception {
        JSONObject demographic = new JSONObject();
        demographic.put("PatientInformation", new JSONArray().put(new JSONObject().put("DOB", "invalid-date")));
        JSONObject demographicData = new JSONObject().put("DemographicData", demographic);
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(demographicData);

        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        // Use reflection to mock static convertDateFormat to throw ParseException
        try (var mocked = org.mockito.Mockito.mockStatic(DateUtils.class)) {
            mocked.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenThrow(new ParseException("Invalid format", 0));
            JSONObject result = newPatientHandler.getPatientDemographics(inputObject);
            assertNotNull(result);
            // Optionally, check that DOB remains unchanged
            assertEquals("invalid-date", result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("DOB"));
        }
    }

    @Test
    void testSetExceptionDetails_lastname() throws Exception {
        IHubException exception = new IHubException(new IHubErrorCode("1"), "Missing lastname");
        Method method = NewPatientHandler.class.getDeclaredMethod("setExceptionDetails", IHubException.class);
        method.setAccessible(true);
        NewPatientHandler handler = new NewPatientHandler();
        method.invoke(handler, exception);
        Assertions.assertEquals(StatusCodes.NO_LAST_NAME_FOUND, exception.getStatusCode());
    }

    @Test
    void testSetExceptionDetails_firstname() throws Exception {
        IHubException exception = new IHubException(new IHubErrorCode("1"), "Missing firstname");
        Method method = NewPatientHandler.class.getDeclaredMethod("setExceptionDetails", IHubException.class);
        method.setAccessible(true);
        NewPatientHandler handler = new NewPatientHandler();
        method.invoke(handler, exception);
        Assertions.assertEquals(StatusCodes.NO_FIRST_NAME_FOUND, exception.getStatusCode());
    }

    @Test
    void testSetExceptionDetails_primaryphone() throws Exception {
        IHubException exception = new IHubException(new IHubErrorCode("1"), "Invalid PRIMARYPHONE format");
        Method method = NewPatientHandler.class.getDeclaredMethod("setExceptionDetails", IHubException.class);
        method.setAccessible(true);
        NewPatientHandler handler = new NewPatientHandler();
        method.invoke(handler, exception);
        Assertions.assertEquals(StatusCodes.INVALID_FORMAT, exception.getStatusCode());
    }

    @Test
    void createNewPatient_IHubException() throws IHubException {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        JSONObject outputObject = new JSONObject();
        outputObject.put("error_code", "1111");
        outputObject.put("temp", new JSONObject());
        JSONObject demographic = new JSONObject();
        demographic.put("PatientInformation", new JSONArray().put(new JSONObject().put("ExternalPatientId", 0)));
        JSONObject demographicData = new JSONObject().put("DemographicData", demographic);
        outputObject.put("appointment_sync", new JSONArray().put(demographicData));

        when(matchPatientHandler.doExecute(inputObject)).thenThrow(new IHubException(new IHubErrorCode("11"), "error"));
        Assertions.assertThrows(IHubException.class, () -> newPatientHandler.createNewPatient(inputObject));
    }

    @Test
    void createNewPatient_Exception() throws IHubException {
        JSONObject inputObject = new JSONObject();
        String deploymentId = "testDeploymentId";
        inputObject.put(DEPLOYMENT_ID, deploymentId);

        JSONObject outputObject = new JSONObject();
        outputObject.put("error_code", "1111");
        outputObject.put("temp", new JSONObject());
        JSONObject demographic = new JSONObject();
        demographic.put("PatientInformation", new JSONArray().put(new JSONObject().put("ExternalPatientId", 0)));
        JSONObject demographicData = new JSONObject().put("DemographicData", demographic);
        outputObject.put("appointment_sync", new JSONArray().put(demographicData));

        when(matchPatientHandler.doExecute(inputObject)).thenThrow(new RuntimeException("error"));
        Assertions.assertEquals(inputObject, newPatientHandler.createNewPatient(inputObject));
    }


    @Test
    public void testGetPatientDemographics() throws IHubException {
        // Mocking the behavior of allscriptsApiCaller
        JSONObject demographic = new JSONObject();
        demographic.put("PatientInformation", new JSONArray().put(new JSONObject().put("DOB", "10-10-2000")));
        JSONObject demographicData = new JSONObject().put("DemographicData", demographic);
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(demographicData);

        // Calling the method to test
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        JSONObject result = newPatientHandler.getPatientDemographics(inputObject);

        // Assertions to verify the expected behavior
        assertNotNull(result);
        assertEquals("10/10/2000", result.getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("DOB"));
    }
    @Test
    public void testGetPatientInsuranceInfo() throws IHubException {
        // Mocking the behavior of allscriptsApiCaller
        JSONObject mockResponse = new JSONObject();
        mockResponse.put("InsuranceInformation", new JSONObject().put("policyNumber", "12345"));
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(mockResponse);
        JSONObject inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        // Calling the method to test
        JSONObject result = newPatientHandler.getPatientInsuranceInfo(inputObject);

        // Assertions to verify the expected behavior
        assertNotNull(result);
        assertTrue(result.has("InsuranceInformation"));
        assertEquals("12345", result.getJSONObject("InsuranceInformation").getString("policyNumber"));
    }

    @Test
    void testCheckErroStr_errorStrNotEmpty_patientIdEmpty() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        Object errorStr = "Some error";
        Object patientId = null;
        JSONObject outputObject = new JSONObject();

        try (MockedStatic<JsonUtils> mockedStatic = Mockito.mockStatic(JsonUtils.class)) {
            mockedStatic.when(() -> JsonUtils.setValue(eq(outputObject), eq(DocASAPConstants.TempKey.ERROR_DETAIL), eq("Error in patient search"))).thenAnswer(invocation -> null);
            mockedStatic.when(() -> JsonUtils.setValue(eq(outputObject), eq(DocASAPConstants.Key.ERROR_CODE), eq(StatusCodes.EPM_INTERNAL_ERROR.getKey()))).thenAnswer(invocation -> null);

            Method method = NewPatientHandler.class.getDeclaredMethod("checkErroStr", Object.class, Object.class, JSONObject.class);
            method.setAccessible(true);
            method.invoke(handler, errorStr, patientId, outputObject);

            mockedStatic.verify(() -> JsonUtils.setValue(outputObject, DocASAPConstants.TempKey.ERROR_DETAIL, "Error in patient search"), times(1));
            mockedStatic.verify(() -> JsonUtils.setValue(outputObject, DocASAPConstants.Key.ERROR_CODE, StatusCodes.EPM_INTERNAL_ERROR.getKey()), times(1));
        }
    }

    @Test
    void testSetNotification_patientIdEmpty() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        Object patientId = null;
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";

        try (MockedStatic<JsonUtils> mockedGetValue = Mockito.mockStatic(JsonUtils.class);
             MockedStatic<PatientNotificationPreferences> mockedSetNotification = Mockito.mockStatic(PatientNotificationPreferences.class)) {

            mockedSetNotification.when(() -> PatientNotificationPreferences.setNotificationPreference(any(), any(), any(), any(), any()))
                    .thenThrow(new RuntimeException("Should not be called"));

            Method method = NewPatientHandler.class.getDeclaredMethod("setNotification", Object.class, JSONObject.class, String.class);
            method.setAccessible(true);
            method.invoke(handler, patientId, inputObject, deploymentId);

            mockedGetValue.verify(() -> JsonUtils.getValue(any(), any()), times(0));
            mockedSetNotification.verify(() -> PatientNotificationPreferences.setNotificationPreference(any(), any(), any(), any(), any()), times(0));
        }
    }

    @Test
    void testSetNotification_patientIdIsEmpty_staticMethodsNotCalled() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        Object patientId = ""; // Empty patientId
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";

        try (MockedStatic<JsonUtils> mockedGetValue = Mockito.mockStatic(JsonUtils.class);
             MockedStatic<PatientNotificationPreferences> mockedSetNotification = Mockito.mockStatic(PatientNotificationPreferences.class)) {

            mockedGetValue.when(() -> JsonUtils.getValue(any(), any()))
                    .thenThrow(new RuntimeException("Should not be called"));
            Method method = NewPatientHandler.class.getDeclaredMethod("setNotification", Object.class, JSONObject.class, String.class);
            method.setAccessible(true);
            method.invoke(handler, patientId, inputObject, deploymentId);

            assertTrue(true);
        }
    }

    @Test
    void testGetCustomFields_returnsList() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";
        String customFields = "key1:value1,key2:value2";

        // Mock dependencies
        handler.dataCacheManager = mock(DataCacheManager.class);

        try (MockedStatic<JsonUtils> mockedGetValue = Mockito.mockStatic(JsonUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = Mockito.mockStatic(NullChecker.class)) {

            mockedGetValue.when(() -> JsonUtils.getValue(any(), any())).thenReturn(deploymentId);
            when(handler.dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                    .thenReturn(customFields);
            mockedNullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);

            Method method = NewPatientHandler.class.getDeclaredMethod("getCustomFields", JSONObject.class);
            method.setAccessible(true);
            List<String> result = (List<String>) method.invoke(handler, inputObject);

            assertNotNull(result);
            assertEquals(2, result.size());
            assertEquals("key1:value1", result.get(0));
            assertEquals("key2:value2", result.get(1));
        }
    }

    @Test
    void testGetCustomFields_emptyCustomFieldList() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";

        handler.dataCacheManager = mock(DataCacheManager.class);

        try (MockedStatic<JsonUtils> mockedGetValue = Mockito.mockStatic(JsonUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = Mockito.mockStatic(NullChecker.class)) {

            mockedGetValue.when(() -> JsonUtils.getValue(any(), any())).thenReturn(deploymentId);
            when(handler.dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                    .thenReturn("");
            mockedNullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(true);

            Method method = NewPatientHandler.class.getDeclaredMethod("getCustomFields", JSONObject.class);
            method.setAccessible(true);
            List<String> result = (List<String>) method.invoke(handler, inputObject);

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void testGetCustomFields_exceptionHandling() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        JSONObject inputObject = new JSONObject();
        String deploymentId = "depId";

        handler.dataCacheManager = mock(DataCacheManager.class);

        try (MockedStatic<JsonUtils> mockedGetValue = Mockito.mockStatic(JsonUtils.class);
             MockedStatic<NullChecker> mockedNullChecker = Mockito.mockStatic(NullChecker.class)) {

            mockedGetValue.when(() -> JsonUtils.getValue(any(), any())).thenReturn(deploymentId);
            when(handler.dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                    .thenThrow(new IHubException(new IHubErrorCode("1"), "error"));
            mockedNullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(true);

            Method method = NewPatientHandler.class.getDeclaredMethod("getCustomFields", JSONObject.class);
            method.setAccessible(true);
            List<String> result = (List<String>) method.invoke(handler, inputObject);

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void testGetUsualProviderFlag_returnsTrue() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        String deploymentId = "depId";
        handler.dataCacheManager = mock(DataCacheManager.class);

        when(handler.dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenReturn("1");

        Method method = NewPatientHandler.class.getDeclaredMethod("getUsualProviderFlag", String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(handler, deploymentId);

        assertTrue(result);
    }

    @Test
    void testGetUsualProviderFlag_returnsFalse() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        String deploymentId = "depId";
        handler.dataCacheManager = mock(DataCacheManager.class);

        when(handler.dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenReturn("0");

        Method method = NewPatientHandler.class.getDeclaredMethod("getUsualProviderFlag", String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(handler, deploymentId);

        assertFalse(result);
    }

    @Test
    void testGetUsualProviderFlag_exceptionHandling() throws Exception {
        NewPatientHandler handler = new NewPatientHandler();
        String deploymentId = "depId";
        handler.dataCacheManager = mock(DataCacheManager.class);

        when(handler.dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                .thenThrow(new IHubException(new IHubErrorCode("1"), "error"));

        Method method = NewPatientHandler.class.getDeclaredMethod("getUsualProviderFlag", String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(handler, deploymentId);

        assertFalse(result);
    }

    @Test
    void testSetPatientCustomFields_setsFields() throws Exception {
        NewPatientHandler handler = spy(new NewPatientHandler());
        JSONObject inputObject = new JSONObject();

        // Mock getCustomFields to return a list
        List<String> customFields = Arrays.asList("key1:value1", "key2:value2");
        Method getCustomFieldsMethod = NewPatientHandler.class.getDeclaredMethod("getCustomFields", JSONObject.class);
        getCustomFieldsMethod.setAccessible(true);


        try (MockedStatic<NullChecker> mockedNullChecker = Mockito.mockStatic(NullChecker.class);
             MockedStatic<JsonUtils> mockedSetValue = Mockito.mockStatic(JsonUtils.class)) {

            mockedNullChecker.when(() -> NullChecker.isEmpty(anyString())).thenReturn(false);
            mockedSetValue.when(() -> JsonUtils.getValue(any(), eq(DEPLOYMENT_ID))).thenReturn("depId");

            handler.dataCacheManager = mock(DataCacheManager.class);

            List<String> list = new ArrayList<>();
            list.add("key1:value1");
            list.add("key2:value2");


            when(handler.dataCacheManager.getStoredProvidersConfig(any(), any(), any(), any(), anyBoolean()))
                    .thenReturn(list.toString());

            mockedSetValue.when(() -> JsonUtils.setValue(any(), any(), any())).thenThrow(new IHubException(null, "error"));

            Method method = NewPatientHandler.class.getDeclaredMethod("setPatientCustomFields", JSONObject.class);
            method.setAccessible(true);
            method.invoke(handler, inputObject);

            assertTrue(true);
        }
    }


}