package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.constant.UtilitiesConstants;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RescheduleAppointmentHandlerServiceTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @InjectMocks
    private RescheduleAppointmentHandlerService rescheduleAppointmentHandlerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteReturnsExpectedResult() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, "12345");
        JSONObject expectedResponse = new JSONObject();
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(expectedResponse);

        JSONObject result = rescheduleAppointmentHandlerService.doExecute(inputObject);

        assertEquals(expectedResponse, result);
    }



    @Test
    void doExecuteThrowsExceptionWhenApiCallerFails() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, "12345");
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenThrow(new IHubException(new IHubErrorCode("22"), "API call failed"));

        assertThrows(IHubException.class, () -> rescheduleAppointmentHandlerService.doExecute(inputObject));
    }

    @Test
    void doExecuteHandlesNewAppointmentMessageType() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, "12345");
        JSONObject expectedResponse = new JSONObject();
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenReturn(expectedResponse);

        JSONObject result = rescheduleAppointmentHandlerService.doExecute(inputObject);

        assertEquals("NewAppt", inputObject.getString(UtilitiesConstants.JsonConstants.MESSAGE_TYPE));
        assertEquals(expectedResponse, result);
    }

    @Test
    void doExecuteThrowsRunExeption() throws IHubException {
        JSONObject inputObject = new JSONObject();
        inputObject.put(UtilitiesConstants.JsonConstants.DEPLOYMENT_ID, "12345");
        when(allscriptsApiCaller.call(any(), any(), any(), any())).thenThrow(new RuntimeException("Unexpected error"));

        assertThrows(Exception.class, () -> rescheduleAppointmentHandlerService.doExecute(inputObject));
    }
}