package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.constant.DocASAPConstants;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import com.pes.integration.utils.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;
import java.text.ParseException;

import static com.pes.integration.constant.DocASAPConstants.Key.INSURANCE_ID;
import static com.pes.integration.constant.DocASAPConstants.Key.INSURANCE_PLAN_ID;
import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UpdatePatientHandlerTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private PatientInsuranceHandler patientInsuranceHandler;

    @InjectMocks
    private UpdatePatientHandler updatePatientHandler;

    private JSONObject inputObject;

    JSONObject demographic = new JSONObject();

    @BeforeEach
    public void setUp() {
        inputObject = new JSONObject();
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");

        JSONObject jsonObject = new JSONObject().put("DOB", "01-01-2000");
        jsonObject.put("TextNotificationStatus", "ENABLED");
        jsonObject.put("EmailNotificationStatus", "ENABLED");
        jsonObject.put("VoiceNotificationStatus", "ENABLED");
        jsonObject.put("ExternalPatientId", "12345");
        jsonObject.put("HomePhone", "12345");
        jsonObject.put("WorkPhone", "12345");
        jsonObject.put("CellPhone", "12345");
        jsonObject.put("PopulateHomePhone", "12345");
        jsonObject.put("PopulateWorkPhone", "12345");
        jsonObject.put("PopulateCellPhone", "12345");
        jsonObject.put("HomePhoneAreaCode", "12345");
        jsonObject.put("WorkPhoneAreaCode", "12345");
        jsonObject.put("CellPhoneAreaCode", "12345");
        demographic.put("PatientInformation", new JSONArray()
                .put(jsonObject));
        demographic.put("InsuranceInformation", new JSONArray().put("payorId"));

        inputObject.put("DemographicData", demographic);

    }

    @Test
    public void testDoExecute() throws IHubException {
        // Mocking the behavior of allscriptsApiCaller
        JSONObject jsonObject = new JSONObject();
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(demographic);

        // Mocking the behavior of patientInsuranceHandler
        when(patientInsuranceHandler.doExecute(any(JSONObject.class)))
                .thenReturn(demographic);

        // Calling the method to test
        JSONObject result = updatePatientHandler.doExecute(inputObject);

        // Assertions to verify the expected behavior
        assertNotNull(result);
        System.out.println(result);
        assertTrue(result.has("data"));
        JSONObject demographicData = result.getJSONObject("data").getJSONArray("appointment_sync").getJSONObject(0);
        assertTrue(demographicData.has("DemographicData"));
    }


    @Test
    public void testRemoveUnwantedPhones() throws Exception {
        updatePatientHandler = new UpdatePatientHandler();
        JSONObject messageObject = new JSONObject();
        JSONObject demographicData = new JSONObject();
        JSONArray patientInformation = new JSONArray();
        JSONObject patientInfo = new JSONObject();
        patientInfo.put("HomePhone", "12345");
        patientInfo.put("HomePhoneAreaCode", "123");
        patientInformation.put(patientInfo);
        demographicData.put(PATIENT_INFORMATION, patientInformation);
        messageObject.put(DEMOGRAPHIC_DATA, demographicData);
        Method method = UpdatePatientHandler.class.getDeclaredMethod("removeUnwantedPhones", JSONObject.class, String.class, String.class);
        method.setAccessible(true);

        JSONObject result = (JSONObject) method.invoke(updatePatientHandler, messageObject, "HomePhone", "HomePhoneAreaCode");

        assertNotNull(result);
    }

    @Test
    public void testUpdateInsurance() throws Exception {
        // Create a sample input JSONArray
        JSONArray inputArray = new JSONArray();
        JSONObject insuranceObject1 = new JSONObject();
        insuranceObject1.put(INSURANCE_ID, "123");
        insuranceObject1.put(INSURANCE_PLAN_ID, "ABC");
        inputArray.put(insuranceObject1);

        JSONObject insuranceObject2 = new JSONObject();
        insuranceObject2.put(INSURANCE_ID, "456");
        insuranceObject2.put(INSURANCE_PLAN_ID, "DEF");
        inputArray.put(insuranceObject2);

        // Mock the static methods from JsonUtils
        try (MockedStatic<JsonUtils> mockedJsonUtils = mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(INSURANCE_ID)))
                    .thenAnswer(invocation -> {
                        JSONObject arg = invocation.getArgument(0);
                        return arg.getString(INSURANCE_ID);
                    });

            mockedJsonUtils.when(() -> JsonUtils.getValue(any(JSONObject.class), eq(INSURANCE_PLAN_ID)))
                    .thenAnswer(invocation -> {
                        JSONObject arg = invocation.getArgument(0);
                        return arg.getString(INSURANCE_PLAN_ID);
                    });

            mockedJsonUtils.when(() -> JsonUtils.setValue(any(JSONObject.class), eq(INSURANCE_PLAN_ID), anyString())).thenAnswer(invocation -> {
                JSONObject arg = invocation.getArgument(0);
                return arg.getString(INSURANCE_PLAN_ID);
            });

            // Use reflection to access the private method
            JSONArray resultArray = (JSONArray) ReflectionTestUtils.invokeMethod(updatePatientHandler, "updateInsurance", inputArray);

            // Assertions to verify the expected behavior
            assertNotNull(resultArray);
            assertEquals(2, resultArray.length());

            JSONObject resultObject1 = resultArray.getJSONObject(0);
            assertEquals("ABC", resultObject1.getString(INSURANCE_PLAN_ID));

            JSONObject resultObject2 = resultArray.getJSONObject(1);
            assertEquals("DEF", resultObject2.getString(INSURANCE_PLAN_ID));
        }
    }

    @Test
    public void testDoExecute_parse_exception() throws IHubException {
        // Mocking the behavior of allscriptsApiCaller
        JSONObject jsonObject = new JSONObject();
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString()))
                .thenReturn(demographic);

        try(MockedStatic<DateUtils> mockedDateUtils = mockStatic(DateUtils.class)) {
            mockedDateUtils.when(() -> DateUtils.convertDateFormat(anyString(), anyString(), anyString()))
                    .thenThrow(new ParseException("Parse error", 0));

            when(patientInsuranceHandler.doExecute(any(JSONObject.class))).thenThrow(new IHubException(null, "error"));


            // Calling the method to test
            JSONObject result = updatePatientHandler.doExecute(inputObject);

            // Assertions to verify the expected behavior
            assertNotNull(result);
            System.out.println(result);
            assertTrue(result.has("data"));
            JSONObject demographicData = result.getJSONObject("data").getJSONArray("appointment_sync").getJSONObject(0);
            assertTrue(demographicData.has("DemographicData"));
        }
    }
}