package com.pes.integration.allscripts.handler.d2e;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.api.ApiName;
import com.pes.integration.enums.Flow;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.exceptions.UtilityErrors;
import com.pes.integration.utils.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.pes.integration.constant.UtilitiesConstants.JsonConstants.DEPLOYMENT_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class GetPatientsHandlerTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @InjectMocks
    @Spy
    private GetPatientsHandler getPatientsHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void doExecuteReturnsExpectedResult() throws IHubException {
        try (MockedStatic<DateUtils> dateUtilsMockedStatic = mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(), any(), any())).thenReturn("20230101");
            JSONObject inputObject = new JSONObject();
            inputObject.put(DEPLOYMENT_ID, "12345");
            JSONObject expectedResponse = new JSONObject();
            JSONObject patientInformation = new JSONObject();
            patientInformation.put("DOB", "20230101");
            patientInformation.put("ExternalPatientId", "123");
            patientInformation.put("Email", "test@gmail.com");
            JSONObject demographicData = new JSONObject();
            demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
            JSONObject value = new JSONObject().put("DemographicData", demographicData);
            expectedResponse.put("appointment_sync", new JSONArray().put(value));
            when(allscriptsApiCaller.call(anyString(),eq(ApiName.GET_PATIENT.getKey()), any(JSONObject.class), eq(Flow.SEARCH_PATIENT.getKey()))).thenReturn(expectedResponse);
            when(allscriptsApiCaller.call(anyString(), eq(ApiName.GET_PATIENT_DEMOGRAPHICS.getKey()), any(JSONObject.class), eq("GET_PATIENT_DEMOGRAPHICS"))).thenReturn(value);
            JSONObject result = getPatientsHandler.doExecute(inputObject);

            assertEquals(expectedResponse, result);
        }
    }

    @Test
    void doExecuteReturnsExpectedResult_Exception() throws IHubException {
        try (MockedStatic<DateUtils> dateUtilsMockedStatic = mockStatic(DateUtils.class)) {
            dateUtilsMockedStatic.when(() -> DateUtils.convertDateFormat(any(), any(), any())).thenReturn("20230101");
            JSONObject inputObject = new JSONObject();
            inputObject.put(DEPLOYMENT_ID, "12345");
            JSONObject expectedResponse = new JSONObject();
            JSONObject patientInformation = new JSONObject();
            patientInformation.put("DOB", "20230101");
            patientInformation.put("ExternalPatientId", "123");
            patientInformation.put("Email", "test@gmail.com");
            JSONObject demographicData = new JSONObject();
            demographicData.put("PatientInformation", new JSONArray().put(patientInformation));
            JSONObject value = new JSONObject().put("DemographicData", demographicData);
            expectedResponse.put("appointment_sync", new JSONArray().put(value));
            when(allscriptsApiCaller.call(anyString(),eq(ApiName.GET_PATIENT.getKey()), any(JSONObject.class), eq(Flow.SEARCH_PATIENT.getKey()))).thenThrow(new IHubException(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), "Error"));
            getPatientsHandler.doExecute(inputObject);
        }
        catch (IHubException e) {
            assertEquals(UtilityErrors.ERROR_IN_SERVICE_EXECUTION.getErrorCode(), e.getErrorCode());
            assertEquals("Error", e.getMessage());
        }
    }
}