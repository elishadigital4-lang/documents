package com.pes.integration.allscripts.handler;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.contant.AllscriptsConstants;
import com.pes.integration.config.data.DataCacheManager;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.jsonmapper.JsonUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.pes.integration.allscripts.api.ApiName.GET_PATIENT;
import static com.pes.integration.allscripts.contant.AllscriptsConstants.PATIENT_COUNT_THRESHOLD;
import static com.pes.integration.allscripts.contant.AllscriptsEngineConstants.ALLSCRIPTS_CONFIG;
import static com.pes.integration.constant.BaseEPMConstants.EPM_NAME_PREFIX;
import static com.pes.integration.constant.DocASAPConstants.Key.*;
import static com.pes.integration.jsonmapper.JsonUtils.setValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MatchPatientHandlerTest {

    @Mock
    private AllscriptsApiCaller allscriptsApiCaller;

    @Mock
    private DataCacheManager cacheManager;

    @InjectMocks
    private MatchPatientHandler matchPatientHandler;

    private JSONObject inputObject;
    JSONArray patientsArray;
    JSONObject demographicData;

    @BeforeEach
    void setUp() {
        inputObject = new JSONObject();
        JSONObject patientData = new JSONObject();
        patientData.put("ExternalPatientId", "testPatientId");
        patientData.put("PatientFirstName", "John");
        patientData.put("PatientLastName", "Doe");
        patientData.put("Email", "test@example.com");

        demographicData = new JSONObject();
        patientsArray = new JSONArray();
        patientsArray.put(patientData);
        demographicData.put("PatientInformation", patientsArray);
        inputObject.put(DEPLOYMENT_ID, "testDeploymentId");
        inputObject.put(MOBILE_PHONE, "1234567890");
        inputObject.put("DemographicData", demographicData);
    }

    @Test
    void testSetVolume_exceptionHandling() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        JSONObject inputObject = new JSONObject();

        // Use reflection to set up a scenario where setValue throws IHubException
        try (MockedStatic<com.pes.integration.jsonmapper.JsonUtils> mockedJsonUtils = mockStatic(com.pes.integration.jsonmapper.JsonUtils.class)) {
            mockedJsonUtils.when(() -> setValue(any(JSONObject.class), anyString(), any()))
                    .thenThrow(new IHubException(null, "Simulated exception"));

            Method method = MatchPatientHandler.class.getDeclaredMethod("setVolume", JSONObject.class);
            method.setAccessible(true);
            method.invoke(handler, inputObject);
            // No assertion needed, just ensure no exception is thrown and log is called
        }
    }

    @Test
    void testCallStoredComponentConfig_withExceptionSetsDefaultValue() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        ReflectionTestUtils.setField(handler, "cacheManager", mockCacheManager);

        // Simulate exception for getStoredComponentConfig
        when(mockCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Simulated exception"));

        Method method = MatchPatientHandler.class.getDeclaredMethod("callStoredComponentConfig", Integer.class);
        method.setAccessible(true);
        Integer result = (Integer) method.invoke(handler, 0);

        assertEquals(20, result);
        verify(mockCacheManager, times(1)).getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean());
    }

    @Test
    void testCallStoredProviderConfig_exceptionTriggersComponentConfig() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        ReflectionTestUtils.setField(handler, "cacheManager", mockCacheManager);

        // Simulate exception for getStoredProvidersConfig
        when(mockCacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenThrow(new RuntimeException("Simulated exception"));
        // Simulate value for getStoredComponentConfig
        when(mockCacheManager.getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn("25");

        Method method = MatchPatientHandler.class.getDeclaredMethod("callStoredProviderConfig", String.class);
        method.setAccessible(true);
        Integer result = (Integer) method.invoke(handler, "testDeploymentId");

        assertEquals(25, result);
        verify(mockCacheManager, times(1)).getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean());
        verify(mockCacheManager, times(1)).getStoredComponentConfig(anyString(), anyString(), anyString(), anyBoolean());
    }

    @Test
    void testCallStoredComponentConfig() throws Exception {
        MatchPatientHandler matchPatientHandler = new MatchPatientHandler();
        DataCacheManager mockCacheManager = mock(DataCacheManager.class);
        ReflectionTestUtils.setField(matchPatientHandler, "cacheManager", mockCacheManager);

        // Mocking the behavior of cacheManager.getStoredComponentConfig
        when(mockCacheManager.getStoredComponentConfig(eq("al"), anyString(), anyString(), anyBoolean()))
                .thenReturn("15");

        // Accessing the private method using Reflection
        Method method = MatchPatientHandler.class.getDeclaredMethod("callStoredComponentConfig", Integer.class);
        method.setAccessible(true);

        // Invoking the private method
        Integer result = (Integer) method.invoke(matchPatientHandler, 0);

        // Assertions
        assertEquals(15, result);

        // Verifying the mock interaction
        verify(mockCacheManager, times(1))
                .getStoredComponentConfig("al", ALLSCRIPTS_CONFIG, PATIENT_COUNT_THRESHOLD, false);
    }

    @Test
    void testGetPatients_withValidInput() throws Exception {
        JSONObject outputObject = new JSONObject();
        outputObject.put("appointment_sync",
                Collections.nCopies(12, "TEST"
                ));
        when(allscriptsApiCaller.call(eq("testDeploymentId"), eq(GET_PATIENT.getKey()), any(), eq("MatchPatient"))).thenReturn(outputObject);
        when(allscriptsApiCaller.call(eq("testDeploymentId"), eq(GET_PATIENT.getKey()), any(), eq("Match_Patient"))).thenReturn(outputObject);
        when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("10");

        JSONObject result = matchPatientHandler.getPatients(inputObject);

        verify(allscriptsApiCaller, times(2)).call(anyString(), anyString(), any(JSONObject.class), anyString());
        assertEquals(outputObject.toString(), result.toString());
    }

    @Test
    void testGetPatients_withTimeoutError() throws Exception {
        JSONObject outputObject = new JSONObject();
        outputObject.put("error", "Timed out");
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenReturn(outputObject);
        when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("10");

        JSONObject result = matchPatientHandler.getPatients(inputObject);

        verify(allscriptsApiCaller, times(2)).call(anyString(), anyString(), any(JSONObject.class), anyString());
        assertEquals(outputObject.toString(), result.toString());
    }

    @Test
    void testGetPatients_withException() throws Exception {
        when(allscriptsApiCaller.call(anyString(), anyString(), any(JSONObject.class), anyString())).thenThrow(new IHubException(new IHubErrorCode("22"), "Test Exception"));

        matchPatientHandler.getPatients(inputObject);
        assertTrue(true);
    }

    @Test
    void testGetPatientDemographicsDetails_withValidData() throws Exception {
        ReflectionTestUtils.setField(matchPatientHandler, "deploymentId", "testDeploymentId");

        JSONObject patientOutputOb = new JSONObject();
        patientOutputOb.put("DemographicData", demographicData);

        when(allscriptsApiCaller.call(anyString(), any(), any(JSONObject.class), anyString())).thenReturn(patientOutputOb);
        when(cacheManager.getStoredProvidersConfig(anyString(), anyString(), anyString(), anyBoolean())).thenReturn("layer2");

        JSONArray result = matchPatientHandler.getPatientDemographicsDetails(new JSONArray().put(inputObject));
        System.out.println(result);
        verify(allscriptsApiCaller, times(1)).call(anyString(), anyString(), any(JSONObject.class), anyString());
        assertEquals("test@example.com", result.getJSONObject(0).getJSONObject("DemographicData").getJSONArray("PatientInformation").getJSONObject(0).getString("Email"));
    }

    @Test
    void isSingleMatch() throws IHubException {
        assertFalse(matchPatientHandler.isSingleMatch());
    }


    @Test
    void testSetPatientIdAndNameNull_setsValuesAndReturnsMap() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        JSONObject inputObject = new JSONObject();

        // Mock getValue to return expected values
        try (MockedStatic<JsonUtils> mockedJsonUtils = Mockito.mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> JsonUtils.getValue(any(), anyString()))
                    .thenReturn("pid").thenReturn("fname").thenReturn("lname");
            mockedJsonUtils.when(() -> setValue(any(), anyString(), any()))
                    .thenThrow(new IHubException(null, "Simulated"));

            Method method = MatchPatientHandler.class.getDeclaredMethod("setPatientIdAndNameNull", JSONObject.class);
            method.setAccessible(true);
            Map<String, String> result = (Map<String, String>) method.invoke(handler, inputObject);

           assertTrue(true);
        }
    }

    @Test
    void testSetFirst2CharsOfLastName_setValueThrowsException() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        JSONObject inputObject = new JSONObject();
        Map<String, String> patientIdName = new HashMap<>();
        patientIdName.put(LAST_NAME, "Smith");

        try (MockedStatic<JsonUtils> mockedJsonUtils = Mockito.mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> setValue(any(), any(), any()))
                    .thenThrow(new IHubException(null, "Simulated"));

            Method method = MatchPatientHandler.class.getDeclaredMethod("setFirst2CharsOfLastName", JSONObject.class, Map.class);
            method.setAccessible(true);
            method.invoke(handler, inputObject, patientIdName);

            // No exception should be thrown, log is called internally
            assertTrue(true);
        }
    }

    @Test
    void testResetPatientNameAndId_success() throws Exception {
        MatchPatientHandler handler = new MatchPatientHandler();
        JSONObject inputObject = new JSONObject();
        Map<String, String> patientIdName = new HashMap<>();
        patientIdName.put(FIRST_NAME, "John");
        patientIdName.put("LastName", "Doe");
        patientIdName.put("PatientId", "123");

        try (MockedStatic<JsonUtils> mockedJsonUtils = Mockito.mockStatic(JsonUtils.class)) {
            mockedJsonUtils.when(() -> setValue(any(), eq(FIRST_NAME), eq("John"))).thenThrow(new IHubException(null, "Simulated"));

            Method method = MatchPatientHandler.class.getDeclaredMethod("resetPatientNameAndId", JSONObject.class, Map.class);
            method.setAccessible(true);
            method.invoke(handler, inputObject, patientIdName);

            assertTrue(true);
        }
    }
}