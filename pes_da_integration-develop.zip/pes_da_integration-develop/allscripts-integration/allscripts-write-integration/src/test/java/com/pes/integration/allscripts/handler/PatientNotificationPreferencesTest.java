package com.pes.integration.allscripts.handler;

import com.pes.integration.allscripts.api.AllscriptsApiCaller;
import com.pes.integration.allscripts.utils.HandlerHelper;
import com.pes.integration.exceptions.IHubErrorCode;
import com.pes.integration.exceptions.IHubException;
import com.pes.integration.utils.NullChecker;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
class PatientNotificationPreferencesTest {

    @InjectMocks
    PatientNotificationPreferences patientNotificationPreferences;

    @Test
    void setNotificationPreference_Enabled() {
        try (MockedStatic<HandlerHelper> mockedStatic = Mockito.mockStatic(HandlerHelper.class)) {
            mockedStatic.when(() -> HandlerHelper.GetPreferenceKeyAndValue(any(), any())).thenReturn("mykey:myvalue,value2");
            AllscriptsApiCaller allscriptsApiCaller = Mockito.spy(new AllscriptsApiCaller());
            JSONObject jsonObject = new JSONObject();

            PatientNotificationPreferences.setNotificationPreference(allscriptsApiCaller, "ENABLED", "ENABLED", jsonObject, "testDeploymentId");

            System.out.println(jsonObject);

            Assertions.assertEquals("mykey", jsonObject.getJSONObject("temp").getString("key_name"));
            Assertions.assertEquals("myvalue", jsonObject.getJSONObject("temp").getString("key_value"));
        }
    }

    @Test
    void setNotificationPreference_Disabled() {
        try (MockedStatic<HandlerHelper> mockedStatic = Mockito.mockStatic(HandlerHelper.class)) {
            mockedStatic.when(() -> HandlerHelper.GetPreferenceKeyAndValue(any(), any())).thenReturn("mykey:myvalue,value2");
            AllscriptsApiCaller allscriptsApiCaller = Mockito.spy(new AllscriptsApiCaller());
            JSONObject jsonObject = new JSONObject();

            PatientNotificationPreferences.setNotificationPreference(allscriptsApiCaller, "DISABLED", "KEY", jsonObject, "testDeploymentId");

            System.out.println(jsonObject);

            Assertions.assertEquals("mykey", jsonObject.getJSONObject("temp").getString("key_name"));
            Assertions.assertEquals("value2", jsonObject.getJSONObject("temp").getString("key_value"));
        }
    }

    @Test
    void setNotificationPreference_Exception() {
        try (MockedStatic<HandlerHelper> mockedStatic = Mockito.mockStatic(HandlerHelper.class)) {
            mockedStatic.when(() -> HandlerHelper.GetPreferenceKeyAndValue(any(), any())).thenThrow(new RuntimeException("test"));
            AllscriptsApiCaller allscriptsApiCaller = Mockito.spy(new AllscriptsApiCaller());
            JSONObject jsonObject = new JSONObject();

            PatientNotificationPreferences.setNotificationPreference(allscriptsApiCaller, "DISABLED", "KEY", jsonObject, "testDeploymentId");

            System.out.println(jsonObject);
            assertTrue(jsonObject.isEmpty());
        }
    }

    @Test
    void setNotificationPreference_Enabled_empty() {
        try (MockedStatic<HandlerHelper> mockedStatic = Mockito.mockStatic(HandlerHelper.class)) {
            mockedStatic.when(() -> HandlerHelper.GetPreferenceKeyAndValue(any(), any())).thenReturn(" : ");
            AllscriptsApiCaller allscriptsApiCaller = Mockito.spy(new AllscriptsApiCaller());
            JSONObject jsonObject = new JSONObject();

            PatientNotificationPreferences.setNotificationPreference(allscriptsApiCaller, "ENABLED", "ENABLED", jsonObject, "testDeploymentId");

            System.out.println(jsonObject);

            assertTrue(true);
        }
    }

}